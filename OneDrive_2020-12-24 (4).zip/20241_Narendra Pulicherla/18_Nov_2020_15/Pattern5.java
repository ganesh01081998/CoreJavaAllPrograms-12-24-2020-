package patterns;
import java.util.Scanner;
public class Pattern5 {
	static String getPatterns() {
		String result = "";
		for(int i = 1; i <= 5; i++) {
			for(int j = 1 ; j <= i; j++) {
				result += i;
			}
			result += " \n";
		}
		return result;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println(getPatterns());
	}
}
