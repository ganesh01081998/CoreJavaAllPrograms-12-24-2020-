package patterns;
import java.util.Scanner;

public class StarProgram {
	static String starProgram(int rows,int columns) {
		String result = "";
		for(int i = 1; i <= rows; i++) {
			for(int j = 1; j <= columns; j++) {
				result += "*";

			}
			result += "\n";
		}
		return result;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter any two values");
		System.out.println(starProgram(sc.nextInt(),sc.nextInt()));
	}
}
