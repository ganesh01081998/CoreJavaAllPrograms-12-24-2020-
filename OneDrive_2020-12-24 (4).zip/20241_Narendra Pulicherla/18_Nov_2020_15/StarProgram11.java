package patterns;

import java.util.Scanner;

public class StarProgram11 {
	static String getStarProgram(int rows, int columns) {
		String result = "";
		for(int i = 1; i <= 5; i++) {
			for(int j = 1; j <=i; j++) {
				result += "*";
				}
			result += "\n";
		}
		return result;
	}

	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("enter any two values");
	System.out.println(getStarProgram(sc.nextInt(),sc.nextInt()));

	}

}
