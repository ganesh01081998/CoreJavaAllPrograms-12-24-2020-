package patterns;

public class NestedStarBox {
	static String getNestedStarBox() {
		String result = "";
		for(int i = 1; i <= 5; i++) {
			for(int j = 1; j <=5; j++) {
				if((j==1)||(j==5)||(i==1)||(i==5)) {
					result += "*";
				}
				else
					result += " ";
			}

			result += "\n";
		}
		return result;
	}
	public static void main(String[] args) {
		System.out.println(getNestedStarBox());

	}

}
