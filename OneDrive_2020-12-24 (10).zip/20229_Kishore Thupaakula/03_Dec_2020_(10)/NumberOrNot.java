package dec_03_2020;

import java.util.Scanner;

public class NumberOrNot {
    static String numberOrNot(String str) {
        String result = "";
        for(int i = 0 ; i < str.length(); i++){
            if(Character.isLetter(str.charAt(i))){
                result = "Given String Not a Number";
                break;
            }
            else {
                result = "Given String is number";
               
            }
        }
        return result ;
    }
   public static void main(String[] args) {
       Scanner scr = new Scanner(System.in);
       System.out.println("enter a String");
           String str = scr.next();
       System.out.println(numberOrNot(str));    
   }



}