package dec_03_2020;

import java.util.Scanner;

public class NumberOfCharOccurence {
	static int getCharOccurence(String str,char ch) {
		//String count = "";
		int count = 0;
		for(int  i = 0;i < str.length();i++) {
			char ch1 = str.charAt(i);
			if(ch1 == ch) {
				count ++;	
			}

		}

		return count;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter Word");
		String str = sc.next();
		System.out.println("enter the charecter");
		String str1 = sc.next();
		char ch = str1.charAt(0);
		System.out.println(getCharOccurence(str, ch));
	}

}
