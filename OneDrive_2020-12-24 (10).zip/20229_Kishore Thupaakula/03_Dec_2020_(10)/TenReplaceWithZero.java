package dec_03_2020;

import java.util.Scanner;

public class TenReplaceWithZero {
	public static int [] shiftNum(int array[]) {
	    int k = 0;
	    int arr[] = new int[array.length];
	    for (int i = 0; i < array.length; i++) {
	        if(array[i] != 10) {
	            arr[k] = array[i];
	            k++;
	        }
	        else {
	            arr[k] = 0;
	        }
	    }
	    return arr;
	    
	}

	 

	    public static void main(String[] args) {
	    Scanner scanner = new Scanner(System.in);
	    System.out.println("enter size");
	    int size = scanner.nextInt();
	    System.out.println("enter elments");
	    int arr[] = new int[size];
	    for (int i = 0; i < arr.length; i++) {
	        arr[i] = scanner.nextInt();
	    }
	    int[] res = shiftNum(arr);
	    for (int i = 0; i < res.length; i++) {
	        System.out.println(res[i]);
	    }
	    } 
	    
	}