package dec_03_2020;

import java.util.Scanner;

public class CountWords {
	static int count =0;
	static void getCountWords(String str) {
		String[] str1 = str.split(" "); 
		for(int i = 0;i < str1.length;i++) {
			char ch = str.charAt(i);
			count = str1.length;
		}
		System.out.println(count);
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter sentence");
		String str = sc.nextLine();
		getCountWords(str);
	}
}
