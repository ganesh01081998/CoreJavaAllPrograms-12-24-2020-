package dec_03_2020;

import java.util.Scanner;

public class FindWord {
    static void getFindWord(String str,String find) {
    	String result = "";
    	String []str1 = str.split(" ");
    	for(int i = 0; i < str1.length;i++) {
    		
    		if(find.equals(str1[i])) {
    			result += find;
    			
    		}
    			
    		
    	}
    	System.out.println("found :"+  result);
    }
	public static void main(String[] args) {
	  Scanner sc = new Scanner(System.in);
	  System.out.println("enter any sentence");
      String str = sc.nextLine();
      String find = sc.next();
      getFindWord(str, find);
	}

}
