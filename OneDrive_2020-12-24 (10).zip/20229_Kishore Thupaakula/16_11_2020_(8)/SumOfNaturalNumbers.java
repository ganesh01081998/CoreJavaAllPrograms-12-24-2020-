package javaprograms;

import java.util.Scanner;

public class SumOfNaturalNumbers {
	static String sumOfNaturalNumbers(int num ) {
		int sum = 0;String result = "";
		for(int i = 1;i<=num;i++) {
	    sum = sum + i;
	    
		}
		result = sum +"sum of naturalnumbers";
		return result;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc =  new Scanner(System.in);
		System.out.println(sumOfNaturalNumbers(sc.nextInt()));

	}

}
