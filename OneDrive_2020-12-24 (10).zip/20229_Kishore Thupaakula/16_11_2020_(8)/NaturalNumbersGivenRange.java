package javaprograms;

import java.util.Scanner;

public class NaturalNumbersGivenRange {
	static boolean isNatural(int num) {
	
		boolean b = false;
		
		for(int i = 1;i<=num;i++) {
			b = true;
		}
		return b;
	}
	static String isNaturalGivenRange(int num1, int num2) {
	String str = "";
		for(int i = num1;i <=num2;i++) {
			if(isNatural(i)) {
				str = str +" "+ i +"\n";
			
			}
		}
		return str ;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the two values");
		System.out.println(isNaturalGivenRange(sc.nextInt(),sc.nextInt()));
	}

}
