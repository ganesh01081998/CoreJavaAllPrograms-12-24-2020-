package javaprograms;

import java.util.Scanner;

public class PrimeNumber1 {
	
	static boolean isPrime(int num) {
		boolean b = false;
		int count = 0;
		for(int i = 2;i<=num;i++){
			if(num % i == 0){
				count++ ;
			}
		}
		
		if(count == 1) {
			System.out.println(num+ "is prime number");
		}
	/*	else {
			System.out.println(num+ "is not prime number");
		}
	*/	return b;
	
	}
	static void primeGivenRange(int num1,int num2){
		
		for(int i = num1;i<=num2;i++){
				if(isPrime(i)){
		}
		}
	
		
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   Scanner sc = new Scanner(System.in);
   System.out.println("enter the start value");
   int num1 = sc.nextInt();
   System.out.println("enter the end value");
   int num2 = sc.nextInt();
   primeGivenRange(num1, num2);
	}

}
