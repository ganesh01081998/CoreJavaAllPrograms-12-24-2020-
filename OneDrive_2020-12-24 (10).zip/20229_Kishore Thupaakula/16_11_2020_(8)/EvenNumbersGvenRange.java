package javaprograms;


import java.util.Scanner;

public class EvenNumbersGvenRange {
	static boolean isEven(int number) {
		boolean b = false;
		if(number % 2 == 0) {
			b = true;
		}
		return b;
	}
	static String getRangeOfEven(int number1,int number2) {
		String result = "";
		while(number1 <= number2) {
			if(isEven(number1)) {
				result += number1 +" ";
			}
			number1++;
		}
		return result;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter two values");
		System.out.println(getRangeOfEven(sc.nextInt(),sc.nextInt()));
	}

}
