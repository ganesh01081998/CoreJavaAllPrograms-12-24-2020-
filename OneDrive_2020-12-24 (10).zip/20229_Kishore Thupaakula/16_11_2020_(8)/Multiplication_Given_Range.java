package javaprograms;

import java.util.Scanner;

public class Multiplication_Given_Range {
	static boolean isMultiGivenRange(int num){
		boolean b = false;
		int range = 10,i = 1; 
		while(i<=range){
			System.out.println(num+"*"+i+"="+(num*i));
			i++;
		}
		return b;
	
	}
	static void rangeMulti(int firstvalue,int endvalue){
		for(int i =firstvalue;i<=endvalue;i++){
			if(isMultiGivenRange(i)){
				
			}
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("given multi range:");
	Scanner sc = new Scanner(System.in);
	int firstvalue = sc.nextInt();
	int endvalue = sc.nextInt();
	rangeMulti( firstvalue, endvalue);
	}

}
