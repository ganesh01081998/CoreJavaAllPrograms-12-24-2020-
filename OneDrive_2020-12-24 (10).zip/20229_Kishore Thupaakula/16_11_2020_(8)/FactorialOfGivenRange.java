package javaprograms;

public class FactorialOfGivenRange {
	static boolean isFactorial(int num) {
		boolean b = false;
		int fact = 1,sum = 0;
		for(int i = 1;i <=num;i++) {
			fact = fact * i;
			System.out.println(fact);
			
		}
		
		return b;
	
	}
	public static void main(String[] args) {
		isFactorial(8);
	}

}
