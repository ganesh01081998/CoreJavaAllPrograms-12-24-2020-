package javaprograms;

import java.util.Scanner;

public class ArmstrongNumber {
	static boolean isArmstrong(int num) {
		boolean b = false;
		int rem,sum=0,temp = num;
		while(num > 0){
			rem = num % 10;
			sum = sum + (rem * rem * rem);
			num = num / 10;
			
		}
		if(temp == sum) {
			System.out.println("is strong");
		}
		else {
			System.out.println("is not Strong");
		}
		
		return b;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Scanner scanner = new Scanner(System.in);
   
    isArmstrong(153);
	}

}
