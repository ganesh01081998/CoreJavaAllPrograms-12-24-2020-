package dec_14;

enum ManagerType {
	HR,SALES;
}
public class Manager extends Employee {
	 ManagerType mt;

		public ManagerType getMt() {
			return mt;
		}

		public void setMt(ManagerType mt) {
			this.mt = mt;
		}
		
		public Manager() {
			
		}
		
		 public Manager(ManagerType mt) {
			super();
			this.mt = mt;
		}

		public void setSalary() {
			 switch(mt) {
			 case HR :
				 salary += 10000;
				 break;
				 
			 case SALES : 
				 salary += 5000;
				 break;
			 }
		 }

		@Override
		public String toString() {
			return "Manager [mt=" + mt + "]";
		}

		
	}