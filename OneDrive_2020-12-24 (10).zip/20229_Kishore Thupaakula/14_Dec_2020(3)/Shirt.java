package dec_14;

import java.util.Scanner;

enum ShirtMaterial {
     
        COTTON,LINEN,POLYESTER
}

 

public class Shirt {
    
    float collarSize;
    float length;
    String material;
    ShirtMaterial sm;
    
    public float getCollarSize() {
        return collarSize;
    }
    public void setCollarSize(float collarSize) {
        this.collarSize = collarSize;
    }
    public float getLength() {
        return length;
    }
    public void setLength(float length) {
        this.length = length;
    }
    public String getMaterial() {
        return material;
    }
    public void setMaterial(String material) {
        this.material = material;
    }

 

    public Shirt(float length,String material) {
        this.length = length;
        this.material = material;
    }
    
    public Shirt(float collarSize, float length, String material,ShirtMaterial sm) {
        this(length,material);
        this.collarSize = collarSize;
        this.length = length;
        this.material = material;
        this.sm = sm;
    }
    
    @Override
    public String toString() {
        return "Shirt [collarSize=" + collarSize + ", length=" + length + ", material=" + material + ", sm = " + sm + "]";
    }
    
    public String display() {
        return toString();
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter CollarSize And Length And Material....");
        Shirt s = new Shirt(sc.nextFloat(),sc.nextFloat(),sc.next(),ShirtMaterial.LINEN);
        System.out.println(s.display());
    }

 

}