package javaprograms;

public class multiple_JavaCmm {
	static void isMultiple(int num) {
		
		
		int quo,result;
		quo = num / 100;
		result = (quo + 1) * 100;
		System.out.println(result);
		
	}
	public static void main(String[] args) {
		int num = Integer.parseInt(args[3]);
    isMultiple(num);
	}

}
