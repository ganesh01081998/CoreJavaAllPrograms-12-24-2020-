package javaprograms;

public class AdditionFourOfOneVariable {
	// TODO Auto-generated method stub
	static void isAddition(String[] args) {
    int num = Integer.parseInt(args[0]);
        num += Integer.parseInt(args[1]);
        num += Integer.parseInt(args[2]);
        num += Integer.parseInt(args[3]);
    System.out.println("sum " +num);
	}
	
	public static void main(String[] args) {
	isAddition(args);
}
}