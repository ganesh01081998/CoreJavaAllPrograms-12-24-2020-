package javaprograms;

public class SwapCmm {
	static void isSWapTwoNum(int num1,int num2) {
		num1 = num1 + num2;
		num2 = num1 - num2;
		num1 = num1 - num2;
		System.out.println(num1 + " " + num2);	
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1 = Integer.parseInt(args[0]);
		int num2 = Integer.parseInt(args[1]);
		isSWapTwoNum(num1, num2);
	}
}
