package dec_21;

import java.util.Scanner;

public class executable {

	public static void main(String[] args) throws LeaveQuotaExceededException {
	Scanner sc = new Scanner(System.in);
	System.out.println("enter leaves");
	LeaveSystem ls = new LeaveSystem(sc.nextInt());
	ls.exceedLeaves();
	}

}
