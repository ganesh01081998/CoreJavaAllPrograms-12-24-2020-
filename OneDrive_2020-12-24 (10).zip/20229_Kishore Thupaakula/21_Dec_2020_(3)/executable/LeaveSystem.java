package dec_21;

public class LeaveSystem {
	int leaves; 
	int totalleaves = 20;
	public LeaveSystem(int leaves) {
		super();
		this.leaves = leaves;
		
	}
    void exceedLeaves() throws LeaveQuotaExceededException {  
			if(leaves > totalleaves) {
    			throw new LeaveQuotaExceededException("leaves not granted"); 
    		}
			else {
				System.out.println("leave granted");
			}
    	
    	    }
	
	
}
