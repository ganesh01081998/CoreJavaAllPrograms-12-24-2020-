package dec_21;

public class LeaveQuotaExceededException extends Exception {

	public LeaveQuotaExceededException(String leaves) {
		super(leaves);
	}

}
