package dec_21;

public class InsufficientFundsException extends Exception {
      double amount;
      
      

	public InsufficientFundsException(String string) {
		// TODO Auto-generated constructor stub
	}

	void getAmount(double amount) {
    	  
      }
}
