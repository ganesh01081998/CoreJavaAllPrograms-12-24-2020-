package dec_21;

import java.util.Scanner;

public class BankDemo {
	static String dis() {
		String res = "  1.deposit \n 2. withdraw ";
		return res;
	}
  public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter account number");
         int account1 = sc.nextInt();
		CheckingAccount ch = new CheckingAccount(1000, 1234);
		ch.accountNumber(account1);
	    System.out.println(dis());
	System.out.println("enter aany number");
	switch(sc.nextInt()) {
	
	case 1: 
		System.out.println("enter deposit amount" );
		ch.deposit(sc.nextDouble());
	break;
	case 2:
		System.out.println("enter withdraw amount");
		int withdraw =sc.nextInt();
		ch.withdraw(withdraw);
		
		break;
		
	}
	}
	
}
