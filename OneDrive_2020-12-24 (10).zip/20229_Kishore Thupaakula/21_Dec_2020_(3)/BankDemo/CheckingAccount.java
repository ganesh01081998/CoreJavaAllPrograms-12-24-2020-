package dec_21;

public class CheckingAccount {
     double balance ;
     double account ;
  
     
     public CheckingAccount(double balance, double account) {
		super();
		this.balance = balance;
		this.account = account;
		
	}
	boolean accountNumber(int account1) {
    	 if(account1 == account) {
    		 System.out.println("valid account number");
    	 }
    	 else {
    		 System.out.println("in valid account Number please cheack  ");
    	 }
		return false;
     }
	
    	  void deposit(double amount) { 
    		 balance = amount + balance;
			System.out.println(balance);
			 
    	 }
    	  void withdraw(int withdraw) {
    		  try {
    			 
				if(balance < withdraw) {
    			  throw new InsufficientFundsException("unsufficient balance");
    			  }
				else {
					balance = balance - withdraw;
					System.out.println(balance);
					System.out.println("withdraw success");
				}
				
    			  }
    		  catch(InsufficientFundsException e) {
					System.out.println(e);
				}
    		  
    	  }
    	 
    	 
    	 
     
}
