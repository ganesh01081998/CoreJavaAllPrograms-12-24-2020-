package Arrays;

public class RangeValue {

}
