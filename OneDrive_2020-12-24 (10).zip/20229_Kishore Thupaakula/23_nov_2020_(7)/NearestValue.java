import java.util.Scanner;

public class NearestValue {
	static int isNearestvalue(int num1, int num2) {
		int result = 0;
		int nearestvalue = num1 - 10;
		int nearvalue = num2 - 10;
		if(nearestvalue < nearvalue ) {
			result = num1;
		}
		else if(nearestvalue > nearvalue ) {
			result = num2;
		}
		else if(nearestvalue == nearvalue ) {
			result = 0;
		}
		return result;
	}

	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("enter two values");
	int num1 = sc.nextInt();
	int num2 = sc.nextInt();
    System.out.println(isNearestvalue(num1, num2));
	}

}
