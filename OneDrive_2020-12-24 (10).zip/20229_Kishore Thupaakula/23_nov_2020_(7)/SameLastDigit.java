import java.util.Scanner;

public class SameLastDigit {
	static boolean isSameLastDigit(int num1,int num2) {
		boolean b = false;
		int rem =num1 % 10;
		int rem2 = num2 % 10;
		if(rem == rem2) {
			b = true;
		}
		return b;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter two values");
		int num1 = sc.nextInt();
		int num2 = sc.nextInt();
		System.out.println(isSameLastDigit(num1, num2));

	}

}
