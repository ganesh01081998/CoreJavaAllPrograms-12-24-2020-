package dec_07_2020;

import java.util.Scanner;

public class SumOfDigits {
	static int getSumOfDigits(String str){
		int sum = 0;
     for(int i = 0;i < str.length();i++) {
    	 char ch = str.charAt(i);
    	 boolean b = Character.isDigit(ch);
    	 if(b) {
    		 sum +=Character.getNumericValue(ch); 
    	 }
     }
	return sum;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter string");
		String str = sc.next();
		System.out.println(getSumOfDigits(str));

	}

}
