package dec_07_2020;

import java.util.Scanner;

public class AddBefore13 {
	static int luckySum(int num1,int num2,int num3) {
	int sum =0;
		if(num1 != 13 && num2 != 13 && num3 != 13) {
		sum = num1 + num2 + num3;
	}
		else if(num1 == 13 && num2 != 13 && num3 != 13 ) {
			sum = num2 + num3;
		}
		else if(num1 != 13 && num2 == 13 && num3 != 13 ) {
			sum = num1 + num3;
		}
		else if(num1 != 13 && num2 == 13 && num3 == 13 ) {
			sum = num1 ;
		}
		else {
			sum = 0;
		}
		
	return sum;
}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter first value");
		int num1 = sc.nextInt();
		System.out.println("enter sec value");
		int num2 = sc.nextInt();
		System.out.println("enter thrid value");
		int num3 = sc.nextInt();
		System.out.println(luckySum(num1, num2, num3));
	}

}
