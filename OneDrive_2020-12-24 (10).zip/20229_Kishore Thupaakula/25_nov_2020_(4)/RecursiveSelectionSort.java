

	import java.util.Scanner;

	public class RecursiveSelectionSort {
		
		static void recurSelectionSort(int[] arr, int num, int index) { 
			if (index == num) { 
				return; 
			}
			int k = minIndex(arr, index, num - 1); 
			if (k != index) {
				int temp = arr[k]; 
				arr[k] = arr[index]; 
				arr[index] = temp; 
			} 
			recurSelectionSort(arr, num, index + 1); 
		} 
		
		static int minIndex(int[] arr, int in, int out) { 
			if (in == out) {
				return in;
				} 
			int value = minIndex(arr, in + 1, out); 
			return (arr[in] < arr[value]) ? in : value; 
		} 
		
		public static void main(String[] args) { 
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter Array Size...");
			int size = sc.nextInt();
			int[] arr = new int[size];
			System.out.println("Enter Array Elements...");
			for (int i = 0; i < arr.length; i++) {
				arr[i] = sc.nextInt();
			}
			recurSelectionSort(arr, arr.length, 0); 
			for (int i = 0; i < arr.length; i++) {
				System.out.print(arr[i] + " "); 
			}
		} 
	}


