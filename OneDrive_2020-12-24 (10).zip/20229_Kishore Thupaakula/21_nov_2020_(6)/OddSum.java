package Arrays;

import java.util.Scanner;

public class OddSum {
	static Scanner sc = new Scanner(System.in);
	static int getOddSum(int size){
		int sum = 0;
		if(size == 10){
		int arr[] = new int[size];
		System.out.println("enter elements ");
		for(int i = 0;i < arr.length;i++) {
			arr[i] = sc.nextInt();
		}
		for(int i = 0;i < arr.length;i++){
		if(arr[i] % 2 != 0) {
			sum += arr[i];
		} 
		
		}
		System.out.println(sum);
		}else {
			return -1;
		}
		return sum;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the size");
		int size = sc.nextInt();
		getOddSum(size);
	}

}
