package Arrays;

import java.util.Scanner;

public class MultiplicationOfTwoDimensional {
static Scanner scan = new Scanner(System.in);
	
	static void additionOfArrays(int[][] array, int[][] array1, int[][] sum) {
		for (int i = 0; i < sum.length; i++) {
			for (int j = 0; j < sum.length; j++) {
				for (int k = 0; k < sum.length; k++) {
					sum[i][j] += array[i][k]+array1[k][j];
				}
				
			}
		}
	}
	static void displayArray(int[][] sum) {
		for (int i = 0; i < sum.length; i++) {
			for (int j = 0; j < sum.length; j++) {
				System.out.print(sum[i][j] +" ");
			}
			System.out.println();
		}

	}
	static void insertArray(int[][] array) {
		System.out.println("Enter the elements in the array");
		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array.length; j++) {
				array[i][j] = scan.nextInt();
			}
		}
	}
	
	public static void main(String[] args) {
		System.out.println("Enter the size of array");
		int size = scan.nextInt();
		int array[][] = new int [size][size];
		insertArray(array);
		int array1[][] = new int [size][size];
		insertArray(array1);
		int sum[][] = new int [size][size];
		scan.close();
		additionOfArrays(array, array1, sum);
		displayArray(sum);
	}


}
