import java.util.Scanner;

public class MinArray {
	static Scanner sc = new Scanner(System.in);
	static int isMinArray(int size) {
		int min = 0;
		int arr[] = new int[size];
		System.out.println("enter the elements");
		for(int i = 0;i < arr.length;i++) {
		arr[i] = sc.nextInt(); 
		}
		if(size != 10) {
			return -1;
		}
		else {
			for(int i = 0;i < arr.length;i++) {
				min = arr[0];
				if(arr[i] < min) {
					min = arr[i];
				}
			}
		}
		
		return min;
		
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the size");
		int size = sc.nextInt();
		System.out.println(isMinArray(size));
	}

}
