import java.util.Scanner;

public class additionAndMultiplicationArray {
	static String isSum(int arr1[][],int arr2[][]) {
		String result = "";
		int sum =0;
		for(int i = 0;i < arr1.length;i++) {
			for(int j = 0;j < arr1[i].length;j++) {
				sum = arr1[i][j]+arr2[i][j];
				result += sum + " ";
		}
			result += "\n";
		}
		
		return result;
		
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the rows");
		int row = sc.nextInt();
		System.out.println("enter the coml");
		int cols = sc.nextInt();
		int arr1[][] = new int[row][cols];
		int arr2[][] = new int[row][cols];
		System.out.println("enter first array elements ");
		for(int i = 0;i < arr1.length;i++) {
			for(int j = 0;j < arr1[i].length;j++) {
			arr1[i][j] = sc.nextInt();
		}
		}
		System.out.println("enter sec array elements");
		for(int i = 0;i < arr1.length;i++) {
			for(int j = 0;j < arr1[i].length;j++) {
			arr2[i][j] = sc.nextInt();
		}
		}
		for(int i = 0;i < arr1.length;i++) {
			for(int j = 0;j < arr1[i].length;j++) {
			System.out.print(arr1[i][j]+" ");
		}
			System.out.println();
		}
		for(int i = 0;i < arr1.length;i++) {
			for(int j = 0;j < arr1[i].length;j++) {
			System.out.print(arr2[i][j]+" ");
		}
			System.out.println();
		}
		
		System.out.println();
		System.out.println(isSum(arr1, arr2));
	/*	int sum [][] = new int[row][cols];
		for(int i = 0;i < arr1.length;i++) {
			for(int j = 0;j < arr2.length;j++) {
				sum [i][j] = arr1[i][j] + arr2[i][j];
			}
		}
		System.out.println(sum [i][j]);*/
	}

}
