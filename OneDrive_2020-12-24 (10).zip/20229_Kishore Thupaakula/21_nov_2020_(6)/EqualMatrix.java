package Arrays;

import java.util.Scanner;

public class EqualMatrix {



	static String printArray(int array1[][],int array2[][]){
		String result = "";
		for(int i = 0 ; i < array1.length ; i++){
			for(int j = 0 ; j < array1.length ; j++){
				result += array1[i][j] +" ";

			}
			result += "\n";
		}
		result += "\n";
		for(int i = 0 ; i < array2.length ; i++){
			for(int j = 0 ; j < array2.length ; j++){
				result += array2[i][j] + " ";

			}
			result += "\n";
		}
		return result ;
	}
	static int equalOrNot(int array1[][],int array2[][]){
		int result = 0;
		for(int i = 0 ; i < array1.length ; i++){
			for(int j = 0 ; j < array1.length ; j++){
				if(array1[i][j] == array2[i][j]) {
					result = 1;
				}
				else {
					result = 0;
				}

			}
		}    
		return result;
	}
	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		int array1[][] = new int [3][3];
		int array2[][] = new int [3][3];
		System.out.println("enter a array1 elements:");
		for(int i = 0 ; i < array1.length ; i++){
			for(int j = 0 ; j < array1.length ; j++){
				array1[i][j] = scr.nextInt();
			}
		}
		System.out.println("enter a array1 elements:");
		for(int i = 0 ; i < array2.length ; i++){
			for(int j = 0 ; j < array1.length ; j++){
				array2[i][j] = scr.nextInt();
			}
		}

		System.out.println(printArray(array1,array2));
		System.out.println(equalOrNot(array1,array2));
	}



}


