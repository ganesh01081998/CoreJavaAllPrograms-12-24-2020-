import java.util.Scanner;

public class MaxNum {
	static Scanner sc = new Scanner(System.in);
	static int getMaxNum(int size) {
		int max = 0;
		 
		int arr[] = new int[size];
		if(size == 10){
			System.out.println("enter the elements");
			for(int i = 0;i <arr.length;i++) {
				arr[i] = sc.nextInt();
			}

		
		}
		int big = 0;

		for(int i =0;i <arr.length;i++){
			if(arr[i] > max ) {
				max = arr[i];
			}
			
		}
		System.out.println(max);

		return max;

	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("emter the size");
		int size = sc.nextInt();
       getMaxNum(size);
	}

}
