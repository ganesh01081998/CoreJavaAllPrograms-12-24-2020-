package dec_18;

import java.util.Scanner;

public class TestCalculator {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		MyCalculator obj = new MyCalculator();
		System.out.println("Enter the number");
		System.out.println(obj.divisorSum(sc.nextInt()));
	}

}
