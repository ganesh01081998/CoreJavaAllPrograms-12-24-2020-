package dec_18;

public class Soccer extends Sports {

	String  getName(String sports) {
		super.sports = sports;
		return sports;

	}
	String getNumberOfTeamMembers()  {

		return "In" +super.getName(sports)+ "\n each team has 11 players.";


	}

}
