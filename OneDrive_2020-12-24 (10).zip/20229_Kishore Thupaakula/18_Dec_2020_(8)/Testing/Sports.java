package dec_18;

public class Sports {
	String sports ;

	String  getName(String sports) {
		return sports;

	}

	String getNumberOfTeamMembers()  {

		return "Each team has 11 players in Sports";

	}

}
