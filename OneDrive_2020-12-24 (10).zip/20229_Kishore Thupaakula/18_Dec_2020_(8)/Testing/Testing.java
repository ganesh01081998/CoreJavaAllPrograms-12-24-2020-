package dec_18;

import java.util.Scanner;

public class Testing {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the Sports name");
		Sports s = new Soccer();
		s.getName(sc.nextLine());
		System.out.println(s.getNumberOfTeamMembers());



	}

}
