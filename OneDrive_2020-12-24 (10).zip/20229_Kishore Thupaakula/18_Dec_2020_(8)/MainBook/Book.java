package dec_18;

public abstract class Book {
	  String title;
	  abstract  void setTitle(String title); 
	  String gettitle() {
		return title;
			 
		  
	  }
}
