package dec_18;


import java.util.Scanner;

public class TestBatsman {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Batsman bat = new Batsman();
		System.out.println("Enter Statistics Of The Batsman like\n name\n run\n matches");
		String name = sc.next();
		int run = sc.nextInt();
		int matches = sc.nextInt();
		if((run <= 0 && matches <= 0) || (run > 0 && matches <=0)) {
			System.out.println("ERROR");
		}
		else {
			bat = new Batsman(name, run, matches);
			System.out.println(bat.getStatistics() + "\n\n Name = " + name +  "\n batting Average = " + bat.computeBattingAverage());
		}
	}

}