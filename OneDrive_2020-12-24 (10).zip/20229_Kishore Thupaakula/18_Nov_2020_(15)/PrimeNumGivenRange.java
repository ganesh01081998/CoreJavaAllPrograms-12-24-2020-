package javaprograms;

import java.util.Scanner;

public class PrimeNumGivenRange {
	static boolean isPrime(int num) {
		boolean b = false;
		int count = 0;
		for(int i = 2;i<= num;i++) {
			if(num % i == 0) {
				count++;
			}
		}
		if(count == 1) {
			System.out.println(num+" is prime");
		}
		else {
			System.out.println(num+ "is not prime");
		}
		return b;
		
		} 
	static void primeRange(int num1,int num2) {
		for(int i = num1;i<=num2;i++) {
			if(isPrime(i)) {
				
			}
		}
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the two values");
		primeRange(sc.nextInt(),sc.nextInt());
	}
	}


