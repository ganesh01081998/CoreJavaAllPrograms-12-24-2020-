package javaprograms;

import java.util.Scanner;

public class PattrenEx {

	static String getPattern(int number) {
		String result = "";
//		int count = 1;
		for(int i = 1; i <= number; i++) {
			int num = i;
			for(int j = 1; j <= i; j++) {
//				System.out.print(num + " ");
				result += num + " ";
//				count++;
				num++;
			}
//			System.out.println();
			result += "\n";
		}
		return result;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any Number : ");
		int number = sc.nextInt();
		System.out.println(getPattern(number));
	}

}

