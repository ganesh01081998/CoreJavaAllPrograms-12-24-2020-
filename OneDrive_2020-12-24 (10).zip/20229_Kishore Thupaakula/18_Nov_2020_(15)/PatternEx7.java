package javaprograms;

public class PatternEx7 {
	static String getPattern() {
		String result = "";
		char ch = 'A';
		for(int i = 1;i <= 5;i++) {
			for(int j = 1;j <= i;j++) {
				 
				result += ch +"";
				ch ++;
			}
			result +="\n"; 
		}
		return result;
		
	}
	public static void main(String[] args) {
		System.out.println(getPattern());
	}

}
