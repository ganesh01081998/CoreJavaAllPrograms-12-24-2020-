package javaprograms;
import java.util.Scanner;



public class MultiplicationTable2 {
        static String multiplicationTable2 (int num , int range) {
            String result = "" ;
            
            for(int i = num ; i <= range ; i++) {
                for(int j = 1 ; j <= 10 ; j++ ) {
                    result  +=(i +"*"+j+"="+ (i * j) )+"\n";
                    
                }
                result += "\n";
            }
            return result ;
        }
    public static void main(String[] args) {
        Scanner scr = new Scanner (System.in );
        System.out.println(multiplicationTable2(scr.nextInt(),scr.nextInt()));

 
    }
    }

