package javaprograms;

public class PatternEx9 {
	static String getPattern() {
		String result = "";
		for(int i = 1;i <= 5;i++ ) {
			for (int j = 1;j <= 5 - i + 1;j++) {
				result += " ";
			}
			for(int j = 1;j <= 2 * i - 1;j++) {
				result += "*";
			}
			result += "\n";
		}
		return result;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    System.out.println(getPattern());
	}

}
