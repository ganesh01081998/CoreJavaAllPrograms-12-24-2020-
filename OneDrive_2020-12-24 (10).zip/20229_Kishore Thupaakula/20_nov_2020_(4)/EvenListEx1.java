package Arrays;

import java.util.Scanner;

public class EvenListEx1 
{
	static void disEvenList(int arr[]) 
	{
		if (arr.length != 10) 
		{
			System.out.println("null");
		}
		else 
		{
			System.out.println("array even numbers");
			
			for (int i = 0; i < arr.length; i++) 
			{
				if (arr[i] % 2 == 0) 
				{
					System.out.println(arr[i]);
				} else 
				{
					//System.out.println();
				}
			}
		}
	}

	public static void main(String[] args) {
		//int a[]={1,2,3,4,5};
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the size");
		int size = sc.nextInt();
		int arr[] = new int[size];
		System.out.println("enter the elements");
		for (int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}
		disEvenList(arr);

	}

}
