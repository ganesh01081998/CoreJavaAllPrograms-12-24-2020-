package strings;

import java.util.Scanner;

public class OddCounter {

	static String result = "";
	static Scanner sc = new Scanner(System.in);

	/*static String isSize(int size) {
		if(size != 10) {
			System.out.println("Array Size Must give 10...");
		}
		else {
			getOddCount(size);
		}
		return result;
	}*/

	static String getOddCount(int size) {
		if(size == 10) {
			int[] arr = new int[size];
			System.out.println("Enter Array Elements....");
			for (int i = 0; i < arr.length; i++) {
				try {
				arr[i] = sc.nextInt();
				}
				catch(Exception e) {
					System.out.println("InputMismatch");
					result = "-1";
				}
			}
			for (int i = 0; i < arr.length; i++) {
				if(arr[i] % 2 != 0) {
					result += arr[i] + " ";
				}
			}
		}
		else {
			return "-1";
		}
		
		return result;
	}

	public static void main(String[] args) {

		System.out.println("Enter Array Size : ");
		int size =  sc.nextInt();
//		isSize(size);	
		System.out.println(getOddCount(size));
	}

}
