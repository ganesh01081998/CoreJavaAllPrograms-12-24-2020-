import java.util.Scanner;

public class FillMultiple {
     String fillMultiple(int num) {
        int arr [] = new int[10];
        String result = "";
        for(int i = 1 ; i < arr.length ; i++){
            arr[i]= num * i;
            //result += arr[i];
        }
        for(int i = 0 ; i < arr.length ; i++){
            result += arr[i] + "\n";
        }
        return result;
    }

 

    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        
        System.out.println("enter a number=");
        int num = scr.nextInt();
        FillMultiple fm = new FillMultiple();
        System.out.println(fm.fillMultiple(num));
    }

 

}
