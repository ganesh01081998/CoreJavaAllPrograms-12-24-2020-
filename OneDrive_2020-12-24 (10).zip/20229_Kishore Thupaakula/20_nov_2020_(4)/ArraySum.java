import java.util.Scanner;

public class ArraySum {
	static String isDisplyElements(int arr []) {
		String result = "";
		for(int i = 0;i < arr.length;i++) {
			result +=arr[i] +" ";
		}
		 
		return result;
		
	}
	static int arraySum(int arr[]) {
		int sum = 0;
		for(int i = 0;i < arr.length;i++) {
			sum +=arr[i];
		}
		return sum;
		
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the size");
		int size = sc.nextInt();
		System.out.println("enter elements");
		int arr[] = new int[size];
		for(int i = 0;i < arr.length;i++) {
			arr[i] = sc.nextInt();
		}
		System.out.println(isDisplyElements(arr));
		System.out.println(arraySum(arr));
	}

}
