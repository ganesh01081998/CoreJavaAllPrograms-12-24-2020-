
import java.util.Scanner;

public class OccurenceCounter {
static String Arrayelements(int arr[],int size) {
String result = "";
for (int i=0 ; i < size ; i++) {
result += arr[i];
}
return result ;
}
static String Duplicates(int arr[],int num) {
String result = "";
int count = 0,i;
for(i=0 ; i < arr.length ; i++) {
//for ( int j = 0 ; j < size ; j++){
if(arr[i] == num) {
count++ ;
}

}
if(count > 0) {
result = num + "=" + count + "\n" ;
}
return result ;
}

 public static void main(String[] args) {
Scanner scr = new Scanner(System.in);
System.out.println("enter a size");
int size =scr.nextInt();
System.out.println("enter array elements");
int arr[] = new int[size];
try{
for(int i = 0 ; i < size ; i++) {
arr[i] =scr.nextInt();
}
System.out.println("enter a Integer number");
int num = scr.nextInt();
System.out.println(Arrayelements (arr, size));
System.out.println(Duplicates( arr,num));
}
catch(Exception e) {
System.out.println("mismatch exception");
}
}

}


