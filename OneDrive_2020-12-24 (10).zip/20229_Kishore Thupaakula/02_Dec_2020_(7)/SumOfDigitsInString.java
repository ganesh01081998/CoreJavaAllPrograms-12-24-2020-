package StringsExamples;

import java.util.Scanner;

public class SumOfDigitsInString {
    static int getSumOfDigitsInString(String str) {
		String str1 = "";
		int sum = 0;
		char ch[] = str.toCharArray();
		for(int i = 0;i < ch.length;i ++ ){
		 if(Character.isLetter(ch[i])) {
			// Character.getNumericValue(ch[i]);
		 }
		 else {
			 str1 = "" + ch[i];
			 int num = Integer.parseInt(str1);
			 sum +=num; 
		 }
		}
    	return sum;
    	
    }
	public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("enter string");
    String str = sc.next();
    System.out.println(getSumOfDigitsInString(str));
	}

}
