package StringsExamples;

import java.util.Scanner;

public class WavedString {
	static String getwavedString(String str,String str1) {
		String result = "";
		if(str.length() > str1.length()) {
			System.out.println(str + str + str1);
		}
		else if(str.length() < str1.length()) {
			System.out.println(str +str1 +str);
		}
		else {
			char ch1[] = new char[str.length()];
			char ch2[] = new char[str1.length()];
			for(int i = 0;i < str.length();i++) {
				ch1[i] = str.charAt(i);
				ch2[i] = str1.charAt(i);
			}
			for(int i = 0;i < str.length();i++){
					int count = 0;
				for(int j = 0; j <= i;j++){
					if(ch1[i] == ch2[j]) {
					 
						count ++;
					}
					

				}
				if(count <= 1) {
					System.out.println(ch1[i]+ "" + ch2[i]);
				}
				
			}
		}
		
		return result;

	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter two Strings");
		String str = sc.next();
		String str1 = sc.next(); 		
		getwavedString(str, str1);
	} 

}
