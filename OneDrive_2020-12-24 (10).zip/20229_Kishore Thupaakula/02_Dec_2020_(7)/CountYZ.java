package StringsExamples;

import java.util.Scanner;

public class CountYZ {
	static int getCountYZ(String str) {
	 int result = 0;
		String[] str1 = str.split(" ");
		int count = 0;
		for(int i = 0;i < str1.length;i++) {
			String str2 = str1[i];
			char ch = str2.charAt(str2.length() - 1); 
				if(ch == 'z' || ch == 'y') {
					count ++;
				}
				if(count  == 1) {
					result += count;
				}
				count = 0;
			}
			
	
		return result;
	
	}
  public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("enter the String");
	String str = sc.nextLine();
	System.out.println(getCountYZ(str));
}
}
