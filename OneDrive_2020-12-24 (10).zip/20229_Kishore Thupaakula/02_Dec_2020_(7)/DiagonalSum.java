package StringsExamples;

import java.util.Scanner;

public class DiagonalSum {
	static int getDiagonalSum(int [][]arr) {
		int result = 0;
		for(int i = 0;i < arr.length;i++){
			for(int j = 0;j< arr.length;j++) {
				if(i == j) {
					result +=arr[i][j];
				}
			}

		}
		return result;
	}
	static String DispalyMatrix(int [][]arr) {
		String result = "";
		for(int i = 0;i < arr.length;i++){
			for(int j = 0;j< arr.length;j++) {
				result += arr[i][j] + " ";
			}
			result +="\n";

		}
		return result;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter rows");
		int rows = sc.nextInt();
		System.out.println("enter cols");
		int cols = sc.nextInt();

		int [][]arr = new int[rows][cols];
		if(rows < 3) {
			System.out.println("-1");
		}else if(cols <3){
			System.out.println("-1");
		}
		else{
			for(int i = 0;i < arr.length;i++) {
				for(int j = 0;j < arr.length;j++) {
					arr[i][j] = sc.nextInt(); 
				}

			}System.out.println(arr.length);
			System.out.println("Matrix");
			System.out.println(DispalyMatrix(arr));
			System.out.println("sum of diagonal");
			System.out.println(getDiagonalSum(arr));
		}
	}
}
