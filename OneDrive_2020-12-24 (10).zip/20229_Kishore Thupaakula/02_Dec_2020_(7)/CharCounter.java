package StringsExamples;

import java.util.Scanner;

public class CharCounter {
	
	static int getCharCounter(String name, char find) {
		//String result = "";
		String str = "" + find;
		
         if(name.length() == 0){
        	 return -1;
         }
         else {
		int count = 0;
		for(int i = 0;i < name.length();i++) {
			char ch1 = name.charAt(i);
			if(ch1 == find ) {
				count = count + 1;
			}

		}
		
         
		System.out.println(count);
         return count;
         }

	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter name");
		String name = sc.nextLine();
		System.out.println("enter charecter");
		char find = sc.next().charAt(0);
		getCharCounter(name, find);
	}

}
