package StringsExamples;

import java.util.Scanner;

public class GetCount {
	static String getCount(int num,int arr[]) {
		String result = "";
		int count = 0;
		for(int i = 0;i < arr.length;i++) {
			if(arr[i] == num) {
				count ++;
			}
		}
		if(count > 0) {
			result = num + " count is " + count;
		}
		return result;
		
	}

	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("enter the size");
	int size = sc.nextInt();
	System.out.println("enter elements");
	int arr[] = new int[size];
    for(int i = 0;i < arr.length;i++) {
    	arr[i] = sc.nextInt();
    }
    System.out.println("enter any element");
     int num = sc.nextInt();
     System.out.println(getCount(num, arr));
	}

}
