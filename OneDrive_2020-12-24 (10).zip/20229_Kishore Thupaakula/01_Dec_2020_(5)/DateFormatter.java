package StringsExamples;

import java.util.Scanner;

public class DateFormatter {
	
	static String check(String str) {
		String date ="", month ="", year ="";
		String[] months = {"jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec"};
		String[] months1 = {"january","february","march","april","may","june","july","august","september","october","november","december"};
		for (int i = 0; i < str.length(); i++) {
			if(i < 2) {
				date += str.charAt(i);
			}
			else if((i > 1) && (i < str.length() - 4) ) {
				month += str.charAt(i);
			}
			else if(i >= str.length() - 4) {
				year += str.charAt(i);
			}
		}
		if(month.length() > 4) {
			for (int i = 0; i < months1.length; i++) {
				if(month.equals(months1[i])) {
					month = "-" + (i + 1) + "-";
					break;
				}
			}
		}
		else {
			for (int i = 0; i < months.length; i++) {
				if(month.equals(months[i])) {
					month = "-" + (i + 1) + "-";
					break;
				}
			}
		}
		str = year + month + date;
		return str;
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Date");
		String str = sc.nextLine().toLowerCase();
        str = str.replaceAll(",", "");
        str = str.replaceAll(" ", "");
		if(str.length() == 0) {
			System.out.println("NULL");
		}
		else {
			System.out.println(check(str));
		}
	}
}

