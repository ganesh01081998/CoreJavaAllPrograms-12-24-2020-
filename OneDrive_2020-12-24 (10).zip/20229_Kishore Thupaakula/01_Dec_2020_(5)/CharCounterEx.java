package StringsExamples;
import java.util.Scanner;

public class CharCounterEx {
	
	static String Checker(String result, char find) {
		String str = "" + find;
		int count = 0;
		for (int i = 0; i < result.length(); i++) {
			String str1 = "" + result.charAt(i);
			boolean b = str1.equalsIgnoreCase(str);
			if(b) {
				count++;
			}
		}
		if(count > 0) {
			return str + " : " + count;
		}
		else {
			return str + "Null";
		}
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any String...");
		String result  = sc.nextLine();
		System.out.println("Enter Any Character to search...");
		String ch = sc.next();
		char find = ch.charAt(0);
		if(result.length() != 0) {
			System.out.println(Checker(result, find));
		}
		else {
			System.out.println("-1");
		}
	}

}
