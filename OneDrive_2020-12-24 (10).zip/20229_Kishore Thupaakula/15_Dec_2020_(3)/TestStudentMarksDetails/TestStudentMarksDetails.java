package dec_15;

import java.util.Scanner;

public class TestStudentMarksDetails {
	
		static String res = "\n 1.ScienceStudent \n 2.History \n";
	
	public TestStudentMarksDetails(String next, String next2) {
			// TODO Auto-generated constructor stub
		}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter Student name");
		
		TestStudentMarksDetails t = new TestStudentMarksDetails(sc.next(),sc.next());
		
		System.out.println("enter " +res);
		switch(sc.nextInt()) {
		
		case 1 : 
			System.out.println("enter student marks ");
			ScienceStudent s = new ScienceStudent(sc.nextInt(),sc.nextInt(),sc.nextInt());
			System.out.println(s.getPersentage());
			break;
		case 2:
			System.out.println("enter student marks ");
			HistoryStuden h = new HistoryStuden(sc.nextInt(),sc.nextInt());
			System.out.println(h.getPersentage());
		}
		
		
	}

}
