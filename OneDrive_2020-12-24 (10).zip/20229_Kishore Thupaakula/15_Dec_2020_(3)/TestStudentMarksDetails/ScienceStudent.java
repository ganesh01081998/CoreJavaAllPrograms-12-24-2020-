package dec_15;

public class ScienceStudent extends Student1 {
    int physicsMark;
    int chemistryMark;
    int mathsMarks;
	public ScienceStudent() {
		// TODO Auto-generated constructor stub
	}
	
    public ScienceStudent(int physicsMark, int chemistryMark, int mathsMarks) {
		super();
		this.physicsMark = physicsMark;
		this.chemistryMark = chemistryMark;
		this.mathsMarks = mathsMarks;
	}

	@Override
	public String toString() {
		return "ScienceStudent [physicsMark=" + physicsMark + ", chemistryMark=" + chemistryMark + ", mathsMarks="
				+ mathsMarks + "]";
	}

	@Override
	int getPersentage() {
		
			int total = physicsMark +chemistryMark +mathsMarks;
			int total1 = total/3;
		
		return total1;
	}

	
	

}
