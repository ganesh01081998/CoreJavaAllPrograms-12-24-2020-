package dec_15;

public class HistoryStuden extends Student1{
    int historyMark;
    int civicsMarks;
    public HistoryStuden() {
		// TODO Auto-generated constructor stub
	}
	public HistoryStuden(int historyMark, int civicsMarks) {
		super();
		this.historyMark = historyMark;
		this.civicsMarks = civicsMarks;
	}

	@Override
	public String toString() {
		return "HistoryStuden [historyMark=" + historyMark + ", civicsMarks=" + civicsMarks + "]";
	}
	@Override
	int getPersentage() {
		int total = historyMark + civicsMarks;
		int total1 = total/2;
		return total1;
	}
}
