package dec_15;

public abstract class Student1 {
     String studentName;
     String studentClass;
    static int totalnumofStudents;
    abstract int getPersentage();
    static int getTotalNoStudents( ) {
		return totalnumofStudents;
    	
    }
    public Student1() {
		// TODO Auto-generated constructor stub
	}
	public Student1(String studentName, String studentClass) {
		super();
		this.studentName = studentName;
		this.studentClass = studentClass;
	
	}
	@Override
	public String toString() {
		return "Student1 [studentName=" + studentName + ", studentClass=" + studentClass + "]";
	}
    
}
