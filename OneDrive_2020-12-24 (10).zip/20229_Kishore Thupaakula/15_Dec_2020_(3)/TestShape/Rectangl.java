package dec_15;

public class Rectangl extends Shape {
	float length;
	float width;
	public float getLength() {
		return length;
	}
	public void setLength(float length) {
		this.length = length;
	}
	public float getWidth() {
		return width;
	}
	public void setWidth(float width) {
		this.width = width;
	}
	public Rectangl() {
		// TODO Auto-generated constructor stub
	}
	public Rectangl(float length, float width) {
		super();
		this.length = length;
		this.width = width;
	}
	@Override
	double getArea() {
		double area = length * width;
		return area;
	}
	@Override
	double getPerimeter() {
		double per = 2 * (length + width);
		return per;
	}
	

}
