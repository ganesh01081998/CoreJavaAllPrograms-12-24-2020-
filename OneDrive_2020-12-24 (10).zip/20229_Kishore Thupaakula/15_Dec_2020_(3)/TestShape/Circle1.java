package dec_15;

public class Circle1 extends Shape {
    int radius ;
    
	public int getRadius() {
		return radius;
	}

	public void setRadius(int radius) {
		this.radius = radius;
	}
public Circle1() {
	// TODO Auto-generated constructor stub
}
	public Circle1(int radius) {
		super();
		this.radius = radius;
	}

	@Override
	double getArea() {
		double Area = (22/7) * radius*radius;
		return Area;
	}

	@Override
	double getPerimeter() {
		double Perimeter = 2 *(22/7) * radius;
		return Perimeter;
	}
	
}
