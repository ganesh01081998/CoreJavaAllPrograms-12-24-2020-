package dec_15;

public abstract class Shape {
abstract double getArea();
abstract double getPerimeter();
}
