package dec_15;

public class TestShape {

	public static void main(String[] args) {
	Circle1 c = new Circle1(2);
	System.out.println("Area of circle");
	System.out.println(c.getArea());
    System.out.println("perimeter of circle");
    System.out.println(c.getPerimeter());
    Square s = new Square(2);
    System.out.println(" Area Squar  ");
    System.out.println(s.getArea());
    System.out.println("perimeter of Squar");
    System.out.println(s.getPerimeter());
    Rectangl r = new Rectangl(2.2f, 3.3f);
    System.out.println("area of rectangle");
	System.out.println(r.getArea());
	System.out.println("peri of rectangle");
	System.out.println(r.getPerimeter());
	}

}
