package dec_15;

public class Square extends  Shape {
     int side;
     
	public int getSide() {
		return side;
	}

	public void setSide(int side) {
		this.side = side;
	}
public Square() {
	// TODO Auto-generated constructor stub
}
	public Square(int side) {
		super();
		this.side = side;
	}

	@Override
	double getArea() {
		double squar = side * side;
		return squar;
	}

	@Override
	double getPerimeter() {
		double perimeter = 4 * side;
		return perimeter;
	}

}
