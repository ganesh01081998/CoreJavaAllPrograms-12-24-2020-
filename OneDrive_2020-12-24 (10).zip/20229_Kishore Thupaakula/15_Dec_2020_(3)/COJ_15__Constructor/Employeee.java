package dec_15;

public class Employeee {

	
	int id;
	String name;
	double basicSalary;
	double hraper;
	double daper;
	Employeee() {
		this.id = 0;
		this.name = null;
		this.basicSalary = 0.0;
		this.hraper = 0.0;
		this.daper = 0.0;
	}
	public Employeee(int id, String name, double basicSalary, double hraper, double daper) {
		this.id = id;
		this.name = name;
		this.basicSalary = basicSalary;
		this.hraper = hraper;
		this.daper = daper;
	}
	public double calculateGrossSalary() {
		return basicSalary +hraper +daper;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", basicSalary=" + basicSalary + ", hraper=" + hraper + ", daper="
				+ daper + "]";
	}
	}
