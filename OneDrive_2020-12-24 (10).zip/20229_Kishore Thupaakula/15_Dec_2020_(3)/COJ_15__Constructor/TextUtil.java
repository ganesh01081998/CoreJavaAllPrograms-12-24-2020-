package dec_15;

import java.util.Scanner;

public class TextUtil {

	

		public double calculateTaxEmployee(Scanner sc, double grossSalary) {
			double taxAmount;

			if (grossSalary > 30000.0) {
				taxAmount = 0.2 * grossSalary;
			} else {
				taxAmount = 0.05 * grossSalary;
			}

			return taxAmount;

		}

		public double calculateTaxManager(Scanner sc, double grossSalary) {
			double taxAmount;

			if (grossSalary > 30000.0) {
				taxAmount = 0.2 * grossSalary;
			} else {
				taxAmount = 0.05 * grossSalary;
			}

			return taxAmount;

		}

		public double calculateTaxTrainer(Scanner sc, double grossSalary) {
			double taxAmount;

			if (grossSalary > 30000.0) {
				taxAmount = 0.2 * grossSalary;
			} else {
				taxAmount = 0.05 * grossSalary;
			}

			return taxAmount;

		}

		public double calculateTaxSourcing(Scanner sc, double grossSalary) {
			double taxAmount;

			if (grossSalary > 30000.0) {
				taxAmount = 0.2 * grossSalary;
			} else {
				taxAmount = 0.05 * grossSalary;
			}

			return taxAmount;

		}
	}
