package dec_15;

import java.util.Scanner;

public class COJ_15__Constructor {
		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			TextUtil tax = new TextUtil();
			System.out.println("please Choose One option");
			System.out.println("1.Employee");
			System.out.println("2.Manager");
			System.out.println("3.Trainee");
			System.out.println("4.Sourcing");
			int option = sc.nextInt();
			switch (option) {
			case 1:
				System.out.println("enter your id, name, basicSalary ,drape,hraper");
				Employeee employee = new Employeee(sc.nextInt(), sc.next(), sc.nextDouble(), sc.nextDouble(),
						sc.nextDouble());
				double grossSalary = employee.calculateGrossSalary();
				double tax1 = tax.calculateTaxEmployee(sc, employee.calculateGrossSalary());
				System.out.println("Gross Salary is   : " + employee.calculateGrossSalary());
				System.out.println("The tax Amount is : " + tax1);
				System.out.println(employee);
				break;
			case 2:
				System.out.println("enter your id, name, basicSalary ,drape,hraper,project Allowance");
				Manager m = new Manager(sc.nextInt(), sc.next(), sc.nextDouble(), sc.nextDouble(), sc.nextDouble(),
						sc.nextDouble());
				double grossSalary1 = m.calculateGrossSalary();
				double tax2 = tax.calculateTaxEmployee(sc, m.calculateGrossSalary());
				System.out.println("Gross Salary is   : " + m.calculateGrossSalary());
				System.out.println("The tax Amount is : " + tax2);
				System.out.println(m);
				break;
			case 3:
				System.out.println(
						"enter your id, name, basicSalary ,drape,hraper,project Allowance,batchCount,perkPerBatch");
				Trainer t = new Trainer(sc.nextInt(), sc.next(), sc.nextDouble(), sc.nextDouble(), sc.nextDouble(),
						sc.nextDouble(), sc.nextInt(), sc.nextDouble());
				double grossSalary2 = t.calculateGrossSalary();
				double tax3 = tax.calculateTaxEmployee(sc, t.calculateGrossSalary());
				System.out.println("Gross Salary is   : " + t.calculateGrossSalary());
				System.out.println("The tax Amount is : " + tax3);
				System.out.println(t);
				break;
			case 4:
				System.out.println(
						"enter your id, name, basicSalary ,drape,hraper,project Allowance,enrollmentReached,perkPerEnrollment");
				Sourcing s = new Sourcing(sc.nextInt(), sc.next(), sc.nextDouble(), sc.nextDouble(), sc.nextDouble(),
						sc.nextInt(), sc.nextInt(), sc.nextDouble());
				double grossSalary3 = s.calculateGrossSalary();
				double tax4 = tax.calculateTaxEmployee(sc, s.calculateGrossSalary());
				System.out.println("Gross Salary is   : " + s.calculateGrossSalary());
				System.out.println("The tax Amount is : " + tax4);
				System.out.println(s);
				break;
			}
		}
}
