package javaprograms;

public class ProductOfTwoRussian {
    static String getProductOfTwo(int number1,int number2) {
    String result = "";
    int temp = 0;
    if(number1 % 2 != 0) {
    temp = temp + number2;
    }
    while(number1 > 1) {
    	number1 = number1 / 2;
    	number2 = number2 * 2;
    	result += " " + number1 + " " + number2 +"\n";
  
    if(number1 % 2 != 0) {
    	temp = temp + number2;
    }
    }
    result += +temp + " ";
    return result;
}
    public static void main(String[] args) {
		System.out.println(getProductOfTwo(11,7));
	}
}
    
