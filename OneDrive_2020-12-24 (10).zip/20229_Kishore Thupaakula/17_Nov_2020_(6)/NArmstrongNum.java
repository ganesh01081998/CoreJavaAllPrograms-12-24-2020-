package javaprograms;

public class NArmstrongNum {
	static String nArmstrongNum(int num) {
		String result = "";
		int rem,sum = 0,total = 1;
		int temp = num;
		result += num;
		int len = result.length();
		while(num > 0) {
			rem = num % 10;
			for(int i =1;i <= len;i++) {
				total = total * rem;
			}
			sum = sum + total;
			num = num /10;
		    total = 1;
		    
		}
		if(sum == temp) {
			result +="is armstrong";
		}
		else {
			result +="is not armstrong";
		}
		
		return result;
	}
	public static void main(String[] args) {
		System.out.println(nArmstrongNum(15));
	}
  
}
