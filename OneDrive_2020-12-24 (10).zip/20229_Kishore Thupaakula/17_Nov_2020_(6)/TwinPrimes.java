package javaprograms;

import java.util.Scanner;

public class TwinPrimes {
	static boolean isPrime(int number) {
		boolean b = false;
		int flag = 0,i = 2;
		while(i < number) {
			if(number % i == 0) {
				flag++;
				break;
			}
			i++;
		}
		if(flag == 0) {
			b = true;
		}
		return b;
	}
	
	static String rangeOfPrimeNumbers(int number1,int number2) {
		String result = "";
		for(int i = number1;i <= number2;i++) {
			if(isPrime(i) && isPrime(i+2)) {
				result += i + " " + (i+2) + "\n";
			}
		}
		return result;			
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Two Values?");
		System.out.println(rangeOfPrimeNumbers(sc.nextInt(),sc.nextInt()));

	}

}



