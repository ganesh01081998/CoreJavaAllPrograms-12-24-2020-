package progarms;

import java.util.Scanner;

public class PositionOfElements {
	
	static String getElepositions(int search, int[] arr, int count) {
		String result = "";
		if(arr.length == 0) {
			result = "-2";
		}
		else if(count > 0) {
			result ="-4";
		}
		else if( search <= 0) {
			result = "-3";
		}
		else {
			for (int i = 0; i < arr.length; i++) {
				if(search == arr[i]) {
					result = " The position of the elements is: "+ (i+1);
				}
			}
		}
		return result;
	}
	
	public static void main(String[] args) {
		int count = 0, search;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter The Size Of Array");
		int [] arr = new int[sc.nextInt()];
		System.out.println("Enter Elements in Array");
		for (int i = 0; i < arr.length; i++) {
			int temp = sc.nextInt();
			if(temp <= 0) {
				count++;
			}
			arr[i] = temp;
		}
		System.out.println("Enter the search number");
		search = sc.nextInt();
		System.out.println(getElepositions(search,arr,count));
	}
}
