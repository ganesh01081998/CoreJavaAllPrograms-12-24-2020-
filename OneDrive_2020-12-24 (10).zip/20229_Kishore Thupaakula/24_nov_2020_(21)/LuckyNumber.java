package strings;

import java.util.Scanner;

public class LuckyNumber {
	static void getLuckyNumber(String month) {
		int monthnumber =0;
		String replace = month.replace('/', '-');
		String replace1 = month.replace('-', '/');
		String dofb[] = month.split("-");
		String date = dofb[0];
		String month1 = dofb[1];
		String year = dofb[2];
		String month2[] = {"jan","feb","mar","apr","may"};
		for(int i = 0;i < month2.length;i++) {
			if(month1.equals(month2[i])){
			  monthnumber = i + 1;
			}
		}
		String total =date + monthnumber + year;
			System.out.println(total);
			int total1 = Integer.parseInt(total);
			while(total1 > 9) {
				int rem = total1 % 10;
				total1 =total1 / 10;
				total1 = rem + total1;
				
				
			}
			System.out.println(total1);
	}
	

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter month");
        String month = sc.next();
        getLuckyNumber(month);
	}

}
