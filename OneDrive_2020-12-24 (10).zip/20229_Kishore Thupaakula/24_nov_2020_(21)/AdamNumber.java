package progarms;

import java.util.Scanner;

public class AdamNumber {
	
	static boolean isAdamnumber(int num) {
	boolean b = false;
		int squ = num * num;
		System.out.println(squ);
	int rnum = getReverse(num);
	System.out.println(rnum);
	   int squ1 = rnum * rnum;
	int rnum1 = getReverse(squ1);
	System.out.println(rnum1);
	if(squ == rnum1) {
		b = true;
	}
	return b;
	
	}
    static int getReverse(int num) {
		String result = "";
		int rem;
		int sum = 0;
		while(num > 0) {
			rem = num % 10;
			sum = (sum * 10) + rem;
			num = num / 10;
		}
    	return sum;
    }
	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter value");
	int num = sc.nextInt();
    System.out.println(isAdamnumber(num));
	}

}
