package strings;
import java.util.Scanner;
public class SumOfDigitDecimalPoint {
	static String isSumOfDigitDecimalPoint(String str) {
		String result = "";
		Scanner sc = new Scanner(System.in);
		String str1[] = str.split("[.]");
		String str2 = str1[0];
		String str3 = str1[1];
		int num1 = Integer.parseInt(str2);
		int num2 = Integer.parseInt(str3);
		result += sum(num1);
		result += ":";
		result +=sum(num2);
		return result;
	}
	static int sum(int num) {
		int rem, sum =0;
		while(num > 0) {
			rem = num % 10;
			sum +=rem;
			num = num / 10;
		}

		return sum;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter any number");
		String str = sc.next();
		System.out.println(isSumOfDigitDecimalPoint(str));

	}

}
