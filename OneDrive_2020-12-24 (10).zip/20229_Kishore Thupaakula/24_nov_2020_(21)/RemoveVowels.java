package strings;

import java.util.Scanner;

public class RemoveVowels {
	static String isRemoveVowels(String name) {
		String result = name.toLowerCase();
		String result1 ="";
		for(int i = 0;i < result.length();i++) {
			char ch = result.charAt(i);
			if(ch == 'i' || ch == 'e' || ch == 'a' || ch == 'o' || ch == 'u') {
				
			}
			else {
				result1 += result.charAt(i); 
			}
		}
		return result1;
		
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter any name");
		String name = sc.nextLine();
     System.out.println(isRemoveVowels(name));
	}

}
