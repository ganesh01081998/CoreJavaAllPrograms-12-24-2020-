package javaprograms;

public class Colladz2 {
	static void isColladz(int num1){
		while(num1 > 1){
			if(num1 % 2 == 0){
				num1 = num1 / 2;
				System.out.println(num1);
			}
			else{
				num1 = (num1 * 3) + 1;
				System.out.println(num1);
			}
		}
	}
public static void main(String[] args) {
	isColladz(5);
}
}
