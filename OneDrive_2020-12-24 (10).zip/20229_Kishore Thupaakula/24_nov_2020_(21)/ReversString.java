package javaprograms;

import java.util.Scanner;

public class ReversString {
       static void isReversString(String str){
    	   String str1 = "";
    	   for(int i = str.length()-1;i>=0;i--){
    		   str1 =str1 + str.charAt(i);
    	   }
    	   System.out.println(str1);
       }
       
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the String");
		String str = sc.nextLine();
		isReversString(str);
		

	}

}
