package javaprograms;

import java.util.Scanner;

public class LCM_Of_TwoNum {
	static void lcmOfNumbers(int num1,int num2){
		int lcm ;
		//find the greatest number first 
		lcm = (num1 > num2) ? num1 :num2;
		while(true){
			//if must be true then print the lcm
		if(lcm % num1 == 0 && lcm % num2 == 0) {
			System.out.println(lcm);
			break;
			}
		lcm++;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Scanner sc = new Scanner(System.in);
     System.out.println("enter the two numbers:");
     int num1 = sc.nextInt();
     int num2 = sc.nextInt();
     lcmOfNumbers( num1, num2);
     
	}

}
