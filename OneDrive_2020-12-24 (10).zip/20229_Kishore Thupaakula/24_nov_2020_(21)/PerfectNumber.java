package progarms;

import java.util.Scanner;

public class PerfectNumber {
	static String getPerfectNumber(int num) {
		String result = "";
		int sum = 0;
		for(int i = 1;i <= num; i++) {
			if(num % i == 0) {
				result += i;
				sum +=i;
			}
			
		}
		System.out.println(sum);
		/*if(num == sum) {
			System.out.println("is perfect");
		}
		else {
			System.out.println("is not perfect");
		}*/
		return result;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter any number");
		int num = sc.nextInt();
		System.out.println(getPerfectNumber(num));

	}

}
