package strings;

import java.util.Scanner;

public class MaskEmail {
	static String isMaskEmail(String name) {
		String maskmail = name.replaceAll(name.substring(2,5), "XXX");
				
		return maskmail;
		
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter any mail");
        String name = sc.next();
        System.out.println(isMaskEmail(name));
	}

}
