package strings;

import java.util.Scanner;

public class Consonents {
	static String Vowels(String name) {
		String result = name.toLowerCase();
		String vowel ="";

		for(int i =0;i < result.length();i++) {
			char ch = result.charAt(i);
			if( ch == 'a' || ch == 'i' || ch == 'e' || ch == 'o' || ch == 'u') {

			}
			else {
				vowel += ch + "";
			} 
		}
		return vowel;

	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter any name");
		String name = sc.next();
		System.out.println(Vowels(name));
	}

}
