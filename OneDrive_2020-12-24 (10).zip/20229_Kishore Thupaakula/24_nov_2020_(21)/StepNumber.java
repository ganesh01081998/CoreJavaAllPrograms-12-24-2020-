package Arrays;

import java.util.Scanner;

public class StepNumber {
	
	static boolean ans= true;
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter any number");
		int num = sc.nextInt();
		isGenerateSteps(num);
		System.out.println(ans);
	}
	
	static void isGenerateSteps(int num) {
		int temp, count = 0, rev = 0;

		temp = num;
		while (temp > 0) {
			rev = temp % 10;
			count++;
			temp = temp / 10;
		}
		int [] arr = new int[count];
		temp = num;
		while(temp > 0) {
			arr[count-1] = temp % 10;
			temp = temp / 10;
			count --;
		}
		stepNumber(arr, rev);
	}
	
	static void stepNumber(int[] arr, int rev) {
		if(arr[0] > arr[arr.length-1]) {
			rev = arr[0] -1;
			for (int i = 1; i < arr.length; i++) {
				if(rev != arr[i]) {
					ans = false;
				}
				rev = arr[i] - 1;
			}
		}
		else {
			rev = arr[0] +1;
			for (int i = 1; i < arr.length; i++) {
				if(rev != arr[i]) {
					ans = false;
				}
				rev = arr[i] + 1;
			}
		}
	}

}
