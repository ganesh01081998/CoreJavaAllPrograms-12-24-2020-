package javaprograms;

import java.util.Scanner;

public class CountOccurence {
	
	static int count = 0;
	
	static int countChar(int count,String str) {
		count = 0;
		String temp = "";
		for (int i = 0; i < str.length(); i++) {
			char ch = str.charAt(i);
			for (int j = 0; j < str.length(); j++) {
				char ch1 = str.charAt(j);
				if(ch == ch1 && temp.indexOf(ch) == -1) {
					count = count + 1;
				}
			}
			if(temp.indexOf(ch) == -1) {
				temp = temp + ch;
				System.out.println(ch + " : " + count );
			}
			count = 0;
		}
		return count;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any String...");
		String str = sc.next();
		countChar(count,str);
	}

}
