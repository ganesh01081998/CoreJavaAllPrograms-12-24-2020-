import java.util.Scanner;
public class NameScore {
	static int getNameScore(String name) {

		int result = 0;

		for(int i =0;i < name.length();i++) {
			boolean b;
			char ch = name.charAt(i);
			b = Character.isLowerCase(ch);
			if(b == true) {
				result += ch - 96;
			}
			else {
				result += ch - 64;
			}
		}
		System.out.println(result);
		return result;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter any name");
		String name = sc.next();
		getNameScore(name);


	}

}
