package exampledec_10;

import java.util.Scanner;
public class Account {
	public static Customer customer;
	public int accountnum;
	public float intrest;
	public double balance;
	public Account(Customer customer, int accountnum, float intrest, double balance) {
		super();
		this.customer = customer;
		this.accountnum = accountnum;
		this.intrest = intrest;
		this.balance = balance;
	}
	public boolean vadlidAccount(int account) {
		boolean b = false; 
		if(accountnum == account) {
			b = true;
			System.out.println("account number passed");
		}
		else {
			System.out.println("check your account is not valid");
		}
		return b;
	}
	double deposite(float dep) {
		double amtdep = this.balance + dep; 
		return amtdep;
	}
	void withdraw(double withdraw,double amtdep) {
		
		double withdrawamt = amtdep - withdraw; 
		System.out.println(withdrawamt);
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Customer c = new Customer("kishore","thupaaki");
		Account a = new Account(customer, 1234, 1, 1000);
		System.out.println("enter account number");
		int account = sc.nextInt();
		a.vadlidAccount(account);
		System.out.println(c);
		System.out.println("enter the amount  to deposite");
		float dep = sc.nextFloat();
		double amtdep=a.deposite(dep);
		System.out.println(amtdep);
		//a.deposite(dep);
		System.out.println("enter the amount  for withdraw");
		float withdraw = sc.nextFloat();
		
		a.withdraw(withdraw,amtdep);
	}
}

