package exampledec_10;

import java.util.Scanner;

import StringsExamples.GetCount;

public class Courses {
	public Address address;
	public int price;
	

	public Courses(Address address, int price) {
		super();
		this.address = address;
		this.price = price;
	}
	 
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter name");
		String str = sc.next();
		System.out.println("enter hno,colony,city");
	Address a = new Address(sc.next(), sc.next(), sc.next());
    
	Courses c = new Courses(a, 200);
	 String menu1 = "enter any courses \n";
	 menu1 += "1.java \n";
	 menu1 += "2.pythan \n";
	 menu1 += "3.html \n";
	 menu1 += "4.idm \n";
	 
	 System.out.println(menu1);
	System.out.println("enter any corses");
	 int choice = sc.nextInt(); 
	 String res = "";
	 while(true) {
	 switch(choice) {
	 case 1: 
	 res +="java price" + 15000; 
	 break;
	 case 2:
		 res +="pythan price" + 2000;
		 break;
	 case 3:
		 res +="html price" + 2500;
		 break;
	 case 4:
		 res +="idm price" + 1500;
		 break;
	
	 }
	 
	 
	 System.out.println(res);
	System.out.println(a);
	break;
	 }
	 
	}
	
}
