package exampledec_10;

public class Address {
	
	private String houseno;
	private String colonyname;
    private String cityname;
	public Address(String houseno, String colonyname, String cityname) {
		
		
		this.houseno = houseno;
		this.colonyname = colonyname;
		this.cityname = cityname;
	}
	@Override
	public String toString() {
		return "Address [houseno=" + houseno + ", colonyname=" + colonyname + ", cityname="
				+ cityname + "]";
	}
    
}
