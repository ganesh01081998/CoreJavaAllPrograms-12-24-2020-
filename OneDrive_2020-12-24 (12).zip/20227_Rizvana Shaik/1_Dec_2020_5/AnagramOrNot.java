package com.abc.Programs1122020;

import java.util.Arrays;
import java.util.Scanner;

public class AnagramOrNot {
	
	static String isAnagram(String str1, String str2) {
		String res = "";
		if(str1.length() -1 == str2.length()-1) {
			char ch1[] = str1.toCharArray();
			char ch2[] = str2.toCharArray();
			 Arrays.sort(ch1);
			  Arrays.sort(ch2);
			  boolean status = Arrays.equals(ch1, ch2);
			  if(true) {
				  res +=  str1 + " " +  str2 + " " + "are anagrams";
			  }
			  else {
				  res = "Not an anagram";
			  }
		}
		return res;
	}

	public static void main(String[] args) {
	Scanner scn = new Scanner(System.in);
	System.out.println("Enter the string");
	String str1 = scn.next().toLowerCase();
	
    System.out.println("Enter the another String");
    String str2 = scn.next().toLowerCase();
   System.out.println(isAnagram(str1, str2));
   
	}

}
