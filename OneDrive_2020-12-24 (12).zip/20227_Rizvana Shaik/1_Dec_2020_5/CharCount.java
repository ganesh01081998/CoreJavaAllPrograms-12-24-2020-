package com.abc.Programs1122020;

import java.util.Scanner;

public class CharCount {

	static String countOccurances(String str, char ch1){
		String res ="";
		int temp = -1;
		int count = 0;
		for(int i = 0; i < str.length(); i++ ){
			char ch = str.charAt(i);  
			if(ch== ch1 ){
				count++;
			}
		}
		if(count > 0) {
			return Integer.toString(count);
		}

		return Integer.toString(temp);
	}
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter  the String");
		String str = scn.nextLine().toLowerCase();	
		if(str.length() == 0) {
			System.out.println("null");
		}
		else {
			System.out.println("enter the searching character");
			char ch1 =scn.next().charAt(0);
			System.out.println(countOccurances(str,ch1));
		}
	}
}
