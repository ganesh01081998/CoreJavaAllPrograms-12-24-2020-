package com.abc.Programs1122020;

import java.util.Scanner;

public class VowelPrinter {
	
	static String  removeVowels(String input) {
		String res = "";
		for (int i = 0; i < input.length(); i++) {
			char ch = input.charAt(i);
			 if(ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
				 res +=ch;
			}
		}
		return res;
	}
    
	public static void main(String[] args) {
	Scanner scn = new Scanner(System.in);
    System.out.println("enter any string");
    String str = scn.nextLine();
    if(str.length()== 0) {
    	System.out.println("null");
    }
    else {
    System.out.println(removeVowels(str));
	}
	}

}
