package com.ojas.Programs;

import java.util.Scanner;

public class CollatzSequenceNo {

	static void collatzSequence(int num) {
		while(num > 1) {
			if(num % 2 == 0)    {
				num = num / 2;
				System.out.println(num);

			}
			else    {
				num = (num * 3) + 1;
				System.out.println(num);
			}
		}
	}



	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter Any Number :  ");
		int num = scn.nextInt();
		collatzSequence(num);
	}

}

