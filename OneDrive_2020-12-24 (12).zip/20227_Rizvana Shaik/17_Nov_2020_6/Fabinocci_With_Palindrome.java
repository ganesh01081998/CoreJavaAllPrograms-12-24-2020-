package com.ojas.Programs;

import java.util.Scanner;

public class Fabinocci_With_Palindrome {
	
	static int num3;
	static void isFabinocci(int num, int num1,  int num2) {
		
		for(int i = 1; i <= num;i++) {
			    num3 = num1 + num2;
			        num1 = num2;
			        num2 = num3;
			        
			    	System.out.println("The Fabinocci series are:"+ num3 +" ");
			    	isPalindrome(num3);
			}
	}
	static void isPalindrome(int num3) {
		 int temp = num3;
		 int rem, sum = 0;
		 while(num3 > 0) {
			 rem = num3 % 10;
			 sum = (sum * 10)+ rem;
			 num3 = num3 / 10;
		 }
		 if( temp == sum) {
			 System.out.println(sum + "Palindome");
		 }
		 else {
			 System.out.println(sum + "Not a Palindome");
		 }
	}
	


	public static void main(String[] args) {
	Scanner scn =  new Scanner(System.in);	
    System.out.println("enter the n value");
    int num =  scn.nextInt();
    System.out.println("enter the a value");
    int num1 = scn.nextInt();
    System.out.println("enter the b value");
    int num2 = scn.nextInt();
    isFabinocci(num, num1, num2);
    
    
	}

}
