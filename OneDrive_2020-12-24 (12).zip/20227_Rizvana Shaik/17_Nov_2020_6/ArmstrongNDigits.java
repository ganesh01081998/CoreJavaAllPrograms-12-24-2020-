package com.ojas.Programs;

public class ArmstrongNDigits {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
