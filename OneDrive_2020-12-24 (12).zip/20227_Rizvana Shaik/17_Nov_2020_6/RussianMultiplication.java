package com.ojas.Programs;

import java.util.Scanner;

public class RussianMultiplication {

	static String getProductOfRussian(int num1, int num2) {
		String result = "" +  num1 + " : " +num2 + "\n ";

		int sum = 0;
		if(num1 % 2 != 0) {
			sum += num2;
		}
		while(num1 > 1) {
			num1 = num1 / 2;
			num2 = num2 * 2;
			result  += "" + num1 + ":" + num2 + "\n";
			if(num1 % 2 != 0) {
				sum +=num2;
			}
		}
		result += "Product of two numbers = " + sum;
		return result;
	}



	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("enter the Two values");
		int num1 = scn.nextInt();
		int num2 = scn.nextInt();
		System.out.println(getProductOfRussian( num1, num2));
	}



}
