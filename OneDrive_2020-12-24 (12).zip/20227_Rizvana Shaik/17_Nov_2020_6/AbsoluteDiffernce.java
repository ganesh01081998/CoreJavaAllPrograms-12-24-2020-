package com.ojas.Programs;

import java.util.Scanner;

public class AbsoluteDiffernce {
	
static int isDifference(int num) {
        
        int temp = 21;
        if(num <= temp) {
            num = temp - num;    
        }
        else if(num < 0) {
            num = num * -1;
            num += temp;
        }
        else if(num > temp) {
            num = (num - temp) * 2;
        }
        return num;
    }

 

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Any Number :");
        int num = sc.nextInt();
        System.out.println(isDifference(num));

 

    }

}
