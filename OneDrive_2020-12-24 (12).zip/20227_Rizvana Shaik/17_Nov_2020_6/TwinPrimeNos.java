package com.ojas.Programs;

import java.util.Scanner;

public class TwinPrimeNos {

static boolean isPrime(int nNum) {
	        boolean  b= false;
	        int count = 0;
	        for(int i = 2 ;i <= nNum; i++) {
	            if(nNum % i == 0) {
	                count++;
	                break;
	            }
	            if(count == 0) {
	                b = true;
	            }
	        }
	        return b;
	    }

	 static String isRange(int startVal, int endVal) {
	        String result ="";
	        for(int i = startVal;i <= endVal;i++) {
	            if(isPrime(i) && isPrime(i + 2)) {
	                result +=  i + " " + (i+2) + " \n ";
	            }
	        }
	        return result;
	        }
         public static void main(String[] args) {
	        Scanner scn = new Scanner(System.in);
	        System.out.println("Enter two values");
	        System.out.println(isRange(scn.nextInt(),scn.nextInt()));

	 

	    }
	}




