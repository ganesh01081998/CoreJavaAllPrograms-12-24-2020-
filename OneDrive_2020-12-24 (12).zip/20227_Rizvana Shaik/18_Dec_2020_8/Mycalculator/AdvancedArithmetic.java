package com.ojas.Arithmetic;

abstract class AdvancedArithmetic {
	public abstract int divisorSum(int n);
	}

