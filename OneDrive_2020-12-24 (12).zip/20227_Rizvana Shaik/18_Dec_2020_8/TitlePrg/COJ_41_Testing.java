package com.ojas.programs18122020;

import java.util.Scanner;

public class COJ_41_Testing {

	public static void main(String[] args) {
		COJ_41_Book t = new  COJ_41_MyBook();
		Scanner scn = new Scanner(System.in);
		System.out.println("enter the title");
		String title = scn.nextLine();
		
		t.setTitle(title);
		System.out.println("The title of my book is :"+(t.getTitle()));

	}

}
