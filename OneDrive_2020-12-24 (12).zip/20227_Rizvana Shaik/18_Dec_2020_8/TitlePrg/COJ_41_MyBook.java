package com.ojas.programs18122020;

public class COJ_41_MyBook extends COJ_41_Book{

	@Override
	void setTitle(String title) {
		//System.out.println("A tale of two cities");
		super.title = title;
		
	}

}
