package com.ojas.programs18122020;

abstract class COJ_41_Book {

	String title;
	abstract void setTitle(String title);
	String getTitle() {
		return title;
	}
}
