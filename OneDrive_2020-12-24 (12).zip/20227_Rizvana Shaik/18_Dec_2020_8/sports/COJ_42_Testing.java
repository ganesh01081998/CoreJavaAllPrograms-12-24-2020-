package com.ojas.sports;

import java.util.Scanner;

public class COJ_42_Testing {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("enter the sports");
		COJ_42_Sports s = new  COJ_42_Soccer();
		s.getName(scn.nextLine());
		System.out.println( s.getNumberOfTeamMembers());

	}

}
