package com.ojas.sports;

public class COJ_42_Sports {

	String sports;
	public String	getName(String sports) { 
	return sports;
	}
	public 	String	getNumberOfTeamMembers() {
			return "Each team has n players in Sports";
		}
	
}
