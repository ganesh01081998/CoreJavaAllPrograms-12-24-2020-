package com.ojas.circles1;

import java.util.Scanner;

public class Testing {

	

		public static void main(String[] args) {
			Scanner scan = new Scanner(System.in);
			System.out.println("Enter Radius And Height...");
			Cylinder cylender = new Cylinder(scan.nextDouble(),scan.nextDouble());
			System.out.println("Area Of Circle : " + cylender.getArea());
			System.out.println("Volume Of Cylender : " + cylender.getVolume());
		}
	}


