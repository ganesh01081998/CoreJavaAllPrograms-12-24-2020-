package com.ojas.StringLowecase;

import java.util.Scanner;

public class ArrangeString {
	 static String  res;
	static void setArrangeString(String s1, String s2) {
		String str ="";
		int num1 = s1.length();
		int num2 = s2.length();
		int n = num1 + num2;
		if(s1.length() > s2.length()) {
			str =  "YES";
		}
		else {
			str = "NO";
		}

		String fLet = s1.substring(0, 1);
		fLet = fLet.toUpperCase();
		//System.out.println(fLet);
        String remainLetter1 = s1.substring(1, s1.length());
        fLet +=remainLetter1;
        //System.out.println(fLet);

		String lLet = s2.substring(0, 1);
		lLet = lLet.toUpperCase();
		//System.out.println(lLet);
		String remainLetter2 = s2.substring(1, s2.length());
        lLet +=remainLetter2;
        //System.out.println(lLet);
        
       
    res =  "" + n + "    " + str + "    " +fLet + " "+lLet;
    System.out.println(res);

}


public static void main(String[] args) {
	Scanner scn = new Scanner(System.in);
	System.out.println("enter  the String s1");
	String s1 = scn.nextLine();
	System.out.println("Enter the String s2");
	String s2 = scn.nextLine();
	setArrangeString(s1,s2);
}

}
