package com.ojas.Programs;

import java.util.Scanner;

public class EvenNosGivenRange {


	static boolean isEven(int num) {
		boolean b=false;
		if(num % 2 == 0)
		{
			b=true;
		}
		return b;
	}

	static String rangeEvenNos(int startval, int endval) {
		String str = " ";
		for(int i = 1; i <= endval; i++)
		{
			if(isEven(i)) {
				str += i + " ,";
			}
		}
		return str.substring(0, str.length()-1);
	}

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("enter the start and endvalue");

		System.out.println( rangeEvenNos( scn.nextInt(),scn.nextInt())	);
	}

}






