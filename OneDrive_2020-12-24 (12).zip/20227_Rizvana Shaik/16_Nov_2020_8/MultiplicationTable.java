package com.ojas.Programs;

import java.util.Scanner;

public class MultiplicationTable {


	static void isMultiplication(int num) {
		int i = 1;
		while(i <= 10) {
			System.out.println(num + "*" + i + "=" + (num * i));
			i++;
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any Number : ");
		int num = sc.nextInt();
		isMultiplication(num);
	}



}

