package com.ojas.Programs;

import java.util.Scanner;

public class PrimeOrNot {
	
	static boolean isPrime(int nNum) {
		boolean b = false;
		int count=0;
		for(int i = 2;i <= nNum;i++ ) {
			if(nNum % i ==0) {
				count++;

			}
		}
		if(count == 1) {
			System.out.println(nNum + "is a prime no");
		}
		else {
			System.out.println(nNum + "is not a prime no");
		}

		return b;
	}


	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("enter any value");
		int nNum = scn.nextInt();
		isPrime(nNum);


	}

}
