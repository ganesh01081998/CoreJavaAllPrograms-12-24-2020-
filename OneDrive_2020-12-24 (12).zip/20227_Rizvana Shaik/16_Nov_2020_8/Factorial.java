package com.ojas.Programs;

import java.util.Scanner;

public class Factorial {

	static void isFactorial(int num) {
	        int fact= 1;
	        while(num >= 1) {
	            fact = fact * num;
	            num--;
	        }
	        System.out.println(fact);
	    }

	 

	    public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);
	        System.out.println("Enter Any Number : ");
	        int num = sc.nextInt();
	        isFactorial(num);

	 

	    }
	}


