package com.ojas.Programs;

import java.util.Scanner;

public class NaturalNosInTheGivenRange {
	
 /*    static boolean isNatural(int nNum) {
	boolean b = false;
    for(int i = 0;i <= nNum;i++) {
    	b=true;
    }
	return b;
	}     */
	
	static String rangeNaturalNos(int startval, int endval) {
		String str = " ";
		for(int i = startval;i <= endval;i++) {
			// for(int j = 0;j <= nNum;j++) {
			//if(isNatural(j)) {
			   str += i + " ,";
			}
	//	}
	//	}
		return str.substring(0, str.length()-1);
	}


	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("enter the start Value");
		int startval = scn.nextInt();
		System.out.println("enter the endVal");
		int endval = scn.nextInt();
		System.out.println(rangeNaturalNos(startval, endval));
	}

}
