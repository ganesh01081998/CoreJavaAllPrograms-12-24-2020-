package com.ojas.Programs;

import java.util.Scanner;

public class SumOfNaturalNos {
	
	static String isSumofNaturalNos(int nNum) {
		String result = "";
		int sum = 0,rem;
		for(int i = 0 ;i <= nNum;i++) {
			sum = sum + i;
		}
		System.out.println(sum);
		return result;
		
	}

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("enter any value");
        int nNum = scn.nextInt();
        System.out.println(isSumofNaturalNos(nNum)); 
	}

}
