package com.ojas.rectangle;

import java.util.Scanner;

public class Rectangle {
	
	static int x1,y1,x2,y2;
static int length, width;
	
public Rectangle(int x1, int y1, int x2, int y2)  {
		
		this.x1 = x1;
		this.y1 = y1;
		this.x2 = x2;
		this.y2 = y2;
	}
	
public Rectangle() {
	
	}
public Rectangle(int length, int width) {
	this.width = width;
	this.length = length;
}

static int area(int length, int width) {
	return  length * width;
}

static int perimeter(int length, int width) {
	return 2 * (length + width);
}

 static void move(int deltax, int deltay) {
    x1 = deltax;
    y1 = deltay;
    x2 = length + x1;
    y2 = width + y1;
    System.out.println("x1 is :" + x1+"\n"+ "y1 is :" + y1+"\n"+  "x2 is :" + x2+"\n"+   "y2 is :" + y2);
}

static void isPointInside(int deltax, int deltay) {
	   if (deltax > x1 && deltax < x2 && deltay > y1 && deltay < y2) {
	        System.out.println("points are inside the Trainlgle ");
	    } else {
	        System.out.println("points are outside the Triangle");
	    }
}
public static void main(String[] args) {
		
   Scanner scn = new Scanner(System.in);
   System.out.println("enter the length");
   int length = scn.nextInt();
   System.out.println("enter the width");
   int width = scn.nextInt();
  System.out.println("The area of the rectangle is :"+area(length,width));
   System.out.println("The perimeter of the rectangle is :"+perimeter(length, width));
   
   Rectangle r = new Rectangle();
   r.x1 = 0;
   r.y1 = 0;
   
  
   
   r.x2 = r.length+ r.x1;
   r.y2 = r.width + r.y1;
   System.out.println("The Rectangle lower left corner : (" + r.x1 + "," + r.y1 + ")");
   System.out.println("The Rectangularupper right corner is : (" + r.x2 + "," + r.y2 + ")");



   Rectangle r1 = new Rectangle(r.x1, r.x2, r.y1, r.y2);



   area(length,width);
  perimeter(length, width);
  isPointInside(4, 8);
  move(8, 10); 



}
		
		
	
   
   
	}


