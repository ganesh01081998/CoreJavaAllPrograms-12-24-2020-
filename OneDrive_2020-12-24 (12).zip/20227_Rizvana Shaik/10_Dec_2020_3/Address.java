package com.ojas.StudentCourse;

public class Address {
    private String hno;
    private String colName;
    private String cityName;
    public Address(String hno, String colName, String cityName) {
        this.hno = hno;
        this.colName = colName;
        this.cityName = cityName;
    }
    @Override
    public String toString() {
        return "Address[hno=" + hno + ", colName=" + colName + ", cityName=" + cityName + "]";
    }
    
}


