package com.ojas.StudentCourse;

import java.util.Scanner;

public class Course {
	   String cname;
	   String cDuration;
	   Double cost;
	public Course(String cname, String cDuration, Double cost) {
	    this.cname = cname;
	    this.cDuration = cDuration;
	    this.cost = cost;
	}
	@Override
	public String toString() {
	    return "Course [cname=" + cname + ", cDuration=" + cDuration + ", cost=" + cost + "]";
	}
	    
	    
	    
	}