package com.ojas.BankAccount;

import java.util.Scanner;

public class Account {

	Customer cust;
	double balance;
	int accountNo;
	float rate;
	public Account(Customer cust, double balance, int accountNo, float rate) {
		this.cust = cust;
		this.balance = balance;
		this.accountNo = accountNo;
		this.rate = rate;
	}

	@Override
	public String toString() {
		return "Account [cust=" + cust + ", balance=" + balance + ", accountNo=" + accountNo + ", rate=" + rate + "]";
	}

	public  void dispMenu() {
		System.out.println("choose your option");
		String menu = "1.Deposit \n 2.Withdraw \n 3.exit";
		System.out.println(menu);
	}

	public void depositAmt(int accno,double amountdep) {
		Scanner sc = new Scanner(System.in);
		System.out.println("confirm your account Number");
		if(accno == sc.nextInt()) {
			balance +=amountdep;    
			System.out.println(amountdep+" rs Credited Successfully.The available balance"+balance);

		}
		else {
			System.out.println("Invalid account number");

		}

	}

	public void withdrawAmt(int accno,double amountwd) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Confirm your account Number");
		if(accno == sc.nextInt()) {
			balance = balance - amountwd;
			System.out.println(amountwd+" rs Debited Successfully.The available balance"+balance);

		}
		else {
			System.out.println("Invalid account number");

		}

	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println(" Enter FirstName & LastName");
		Customer c = new Customer(sc.next(),sc.next());
		System.out.println("Enter the Account Number");
		int accno = sc.nextInt();
		Account ac = new Account(c,10000,accno,7);
		System.out.println(ac);
		while(true) {
			ac.dispMenu();
			int choice = sc.nextInt();
			switch(choice) {
			case 1: 
				System.out.println("Enter the deposit amount");
				double amountdep = sc.nextDouble();
				ac.depositAmt(accno,amountdep);
				break;
			case 2:
				System.out.println("Enter the withdraw amount");
				double  amountwd = sc.nextDouble();
				ac.withdrawAmt(accno,amountwd);
				break;
			case 3:
				System.out.println("Enter Valid input");
				System.exit(0);

			}
		}
	}
}
