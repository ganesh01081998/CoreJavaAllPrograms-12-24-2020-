package com.ojas.Arrays;

import java.util.Scanner;

public class MinArray {

	static int  isMax(int size) {
	
       int min; 
		if(size == 10) {
			Scanner scn = new Scanner(System.in);
			System.out.println("enter the array elements");
			int odd[] = new int[size];
			for(int i = 0;i < odd.length;i++) {
				odd[i] = scn.nextInt();
			}
			min = odd[0];  // min = odd.length;
			for(int i = 0;i <odd.length;i++) {
				if(odd[i] < min) {
					min =odd[i];
				}
			}	
		}
		else {
			System.out.println("input mismatch");
			min= -1;
		}
		return min;
	}

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("enter the array size");
		int size = scn.nextInt();
		System.out.println(isMax(size));

	}

}
