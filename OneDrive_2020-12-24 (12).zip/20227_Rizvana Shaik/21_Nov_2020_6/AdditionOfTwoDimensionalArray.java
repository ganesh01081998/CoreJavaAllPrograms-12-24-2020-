package com.ojas.Arrays;

import java.util.Scanner;

public class AdditionOfTwoDimensionalArray {
	
	
	static void getAddition(int arr1[][], int arr2[][],int rows,int cols) {
		int add[][] = new int[rows][cols];
		for(int i = 0;i < rows;i++) {
			for(int j = 0;j < cols;j++) {
				add[i][j] = arr1[i][j] + arr2[i][j];
			}
		}
		System.out.println("sum of two matrices");
		for(int i = 0;i < rows;i++) {
			System.out.println(" ");
			for(int j = 0;j < cols;j++) {
			System.out.print(add[i][j] + " ");
			}
		}
	}
	
	/*static void isDisplay(int arr1[][], int arr2[][]) {
		for(int i = 0;i < arr1.length;i++) {
			for(int j = i;j < arr1.length;j++) {
				System.out.println(arr1[i][j] + " ");
			
			}
		}
		for(int i = 0;i < arr2.length;i++) {
			for(int j = i;j < arr2.length;j++) {
				System.out.println(arr2[i][j] + " ");
			
			}
		}
	}
*/
	public static void main(String[] args) {
	Scanner scn = new Scanner(System.in);
	System.out.println("enter row size");
	int rows = scn.nextInt();
	System.out.println("enter the column size");
	int cols = scn.nextInt();
	System.out.println("enter the first array elements");
	int arr1[][] = new int[rows][cols];
	for(int i = 0;i < rows;i++) {
		for(int j = 0;j < cols;j++){
			arr1[i][j] = scn.nextInt();
		}
	}
	System.out.println("enter the second array elements");
	int arr2[][] = new int[rows][cols];
	for(int i = 0;i < rows;i++) {
		for(int j = 0;j < cols;j++)	{
			arr2[i][j] = scn.nextInt();
		}
	}
	getAddition(arr1,arr2,rows,cols);
//	isDisplay(arr1, arr2);
	
	}

}
