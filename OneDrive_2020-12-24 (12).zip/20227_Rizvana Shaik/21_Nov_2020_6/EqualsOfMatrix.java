package com.ojas.Arrays;

import java.util.Scanner;

public class EqualsOfMatrix {

	static boolean getAddition(int arr1[][], int arr2[][],int rows,int cols) {
		boolean b = false;
		int add[][] = new int[rows][cols];
		for(int i = 0;i < rows;i++) {
			for(int j = 0;j < cols;j++) {
				if(arr1[i][j] == arr2[i][j]) {
					b = true;
				}
				
			}
   
		}
		return b;
	}
	
	public static void main(String[] args) {
	Scanner scn = new Scanner(System.in);
	System.out.println("enter row size");
	int rows = scn.nextInt();
	System.out.println("enter the column size");
	int cols = scn.nextInt();
	System.out.println("enter the first array elements");
	int arr1[][] = new int[rows][cols];
	for(int i = 0;i < rows;i++) {
		for(int j = 0;j < cols;j++){
			arr1[i][j] = scn.nextInt();
		}
	}
	System.out.println("enter the second array elements");
	int arr2[][] = new int[rows][cols];
	for(int i = 0;i < rows;i++) {
		for(int j = 0;j < cols;j++)	{
			arr2[i][j] = scn.nextInt();
		}
	}
	System.out.println(getAddition(arr1,arr2,rows,cols));
//	isDisplay(arr1, arr2);
	
	}


}
