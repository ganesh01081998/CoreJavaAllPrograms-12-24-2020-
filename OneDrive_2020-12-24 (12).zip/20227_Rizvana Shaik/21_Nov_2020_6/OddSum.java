package com.ojas.Arrays;

import java.util.Scanner;

public class OddSum {

	static int  isSize(int size) {
		int sum = 0;

		if(size == 10) {
			Scanner scn = new Scanner(System.in);
			System.out.println("enter the array elements");
			int odd[] = new int[size];
			for(int i = 0;i < odd.length;i++) {
				odd[i] = scn.nextInt();
			}

			for(int i = 0;i <odd.length;i++) {
				if(odd[i] % 2 != 0) {
					sum += odd[i];

				}
			}	
		}
		else {
			System.out.println("input mismatch");
			sum= -1;
		}
		return sum;
	}

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("enter the array size");
		int size = scn.nextInt();
		System.out.println(isSize(size));

	}
}
