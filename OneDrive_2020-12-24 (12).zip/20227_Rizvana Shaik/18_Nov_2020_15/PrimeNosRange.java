package com.ojas.Programs;

import java.util.Scanner;

public class PrimeNosRange {

	static boolean isPrime(int num) {
		boolean b = false;
		int count=0;
		for(int i = 2;i <= num;i++ ) {
			if(num % i ==0) {
				count++;

			}
		}
		if(count == 1) {
			System.out.println(num + "is a prime no");
		}
		else {
			System.out.println(num + "is not a prime no");
		}

		return b;
	}

	static String primeRange(int startVal, int endVal) {
		String result = "";
		for(int i = startVal; i<= endVal;i++) {
			if(isPrime(i)) {
				result += i + ",";
			}
		}
		return result;
	}

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("enter the start value");
		int startVal = scn.nextInt();
		System.out.println("enter the end value");
		int endVal = scn.nextInt();
		primeRange(startVal, endVal);

	}

}
