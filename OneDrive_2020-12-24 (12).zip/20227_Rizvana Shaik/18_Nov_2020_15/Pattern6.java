package com.ojas.Patterns;

import java.util.Scanner;

public class Pattern6 {

	static String isPattern(int nNum) {
        String result = "";
       int count = 1;
        
        for(int i =1; i <=nNum; i++) {
            for(int j =1 ;j<=i;j++) {
            	
                result += count +" ";
              count++;
            }
           result += "\n ";
        }
        return result;
    }

    public static void main(String[] args) {
    Scanner scn = new Scanner(System.in);
    System.out.println("enter any value");
    int nNum = scn.nextInt();
    System.out.println(isPattern(nNum));
    }		
}
