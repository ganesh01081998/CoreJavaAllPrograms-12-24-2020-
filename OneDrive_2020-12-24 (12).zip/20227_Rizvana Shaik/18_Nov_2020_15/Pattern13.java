package com.ojas.Patterns;

import java.util.Scanner;

public class Pattern13 {

	static String getPattern(int number) {
        String result = "";
        
        for(int i = 1; i <= number; i++) {
            for(int k = 1; k <= number - i + 1; k++) {
                result += "  ";
            }
            for(int j = 1; j <= 2 * i - 1; j++) {

 

                result += "*";
            }
            result += "\n";
        }
        return result;
    }

 

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Any Number : ");
        int number = sc.nextInt();
        System.out.println(getPattern(number));
    }
}
