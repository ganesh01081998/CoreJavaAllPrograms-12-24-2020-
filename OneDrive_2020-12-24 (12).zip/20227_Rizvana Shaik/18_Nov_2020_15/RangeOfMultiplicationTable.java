package com.ojas.Programs;

import java.util.Scanner;

public class RangeOfMultiplicationTable {

	static boolean isMultiplication(int num) {
		boolean b=false;
		for(int i = 1; i <= 10;i++) {
			System.out.println(num + "*" + i + "=" + (num * i));
			
		}
		System.out.println();
		return b;
		
	}

	static String rangeMultiplicationNos(int startval, int endval) {
		String str = " ";
		for(int i = 1; i <= endval; i++)
		{
			if(isMultiplication(i)) {
				str += i + " ,";
				
			}
		}
		return str.substring(0, str.length()-1);
	}

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("enter the start and endvalue");

		 rangeMultiplicationNos( scn.nextInt(),scn.nextInt());
	
	}


}
