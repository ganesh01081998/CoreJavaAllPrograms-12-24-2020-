package com.ojas.Patterns;

import java.util.Scanner;

public class Pattern10 {

	static String isPattern(int nNum) {
		String result = "";

		for(int i =1; i <= nNum; i++) {
			for(int j =1 ;j<= nNum;j++) {
				result +=  " * ";
			}

			result += "\n ";
		}

		return result;
	}

public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("enter any value");
		int nNum = scn.nextInt();
		System.out.println(isPattern(nNum));
	}
	

}
