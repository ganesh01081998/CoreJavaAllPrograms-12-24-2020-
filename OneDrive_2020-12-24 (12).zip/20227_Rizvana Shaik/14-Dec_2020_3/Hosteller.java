package com.ojas.StudentHosteller;

import java.util.Scanner;

public class Hosteller  extends Student{

	
		 double hostelFee;

		 public Hosteller() {

		 }

		 public Hosteller(int sid,String sname,Double sfee,double hostelFee) {
		super(sid,sname,sfee);
		this.hostelFee = hostelFee;
		}
		double payFee(double balance) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter how much amount u want to pay");
		double amount = sc.nextDouble();
		System.out.println(amount+" paid Successfully");
		return balance - amount;
		}

		 @Override
		public String toString() {
		return "Hosteller [hostelFee=" + hostelFee + "]";
		}



	}
