package com.ojas.StudentHosteller;

import java.util.Scanner;

public class DayScholar extends Student {

	 static Scanner scn = new Scanner(System.in);

	  double transport;
	    
 public DayScholar() {
	 

	    }
	    public DayScholar(int sid,String sname,Double sfee,double transport) {
	        super(sid,sname,sfee);
	        this.transport = transport;
	    }
	     double payFee(double balance) {
	          System.out.println("enter how much amount u want to pay");
	           double amount = scn.nextDouble();
	           System.out.println(amount+" paid Successfully");
	          return balance - amount; 
	     }
	    @Override
	    public String toString() {
	        return "DayScholar [transport=" + transport + "]";
	    }

	 

}
