package com.ojas.ShirtProgram;

import java.util.Scanner;

enum Material{
		Cotton, Linen, Polyester
	}
	public class Shirt{
		float collarSize;
		float length;
		String material;
		public Shirt() {
			this.collarSize = 0;
			this.length =0;
			this.material = "Cotton";
		}
		public static void main(String[] args) {
			Scanner scan = new Scanner(System.in);
			System.out.println("Enter the Collar Size and Length and material");
			Shirt shirt = new Shirt();
			shirt.setCollarSize(scan.nextFloat());
			shirt.setLength(scan.nextFloat());
			shirt.setMaterial(scan.next());
			if(shirt.material.isEmpty()) {
				shirt.setMaterial("Cotton");
			}
			shirt.display();
		}
		public float getCollarSize() {
			return collarSize;
		}
		public void setCollarSize(float collarSize) {
			this.collarSize = collarSize;
		}
		public float getLength() {
			return length;
		}
		public void setLength(float length) {
			this.length = length;
		}
		public String getMaterial() {
			return material;
		}
		public void setMaterial(String material) {
			this.material = material;
		}
		void display() {
			System.out.println("ShirtMaterial [collarSize=" + getCollarSize() + ", length=" + getLength() + ", material=" + getMaterial() + "]");

		}
	
}
