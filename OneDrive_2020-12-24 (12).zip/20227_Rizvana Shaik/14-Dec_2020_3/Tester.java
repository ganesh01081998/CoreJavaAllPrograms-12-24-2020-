package com.ojas.StudentHosteller;

import java.util.Scanner;

public class Tester {

static double sfee = 2000;
    
    public static void main(String[] args) {
    Scanner scn = new Scanner(System.in);    
    System.out.println("Enter the student id and student Name name");
    int sid = scn.nextInt();
    String sname = scn.next();
    Student s = new Student(sid,sname,sfee);
    System.out.println(s);
    System.out.println("1. Dayscholar \n 2.Hosteller");
    while(true ) {
    System.out.println("enter your choice");
    int choice = scn.nextInt();
    switch(choice){
    case 1 : 
        System.out.println("Enter Your Transport fee");
         double transFee = scn.nextDouble();
        DayScholar ds = new DayScholar(sid,sname,sfee,transFee);
        double due = sfee + transFee;
        double amount=ds.payFee(due);
        System.out.println(" Remaining Due "+amount);
        break;
    case 2 :
        System.out.println("Enter your Hostel fee");
        double hostelFee = scn.nextDouble();
        Hosteller h = new Hosteller(sid,sname,sfee,hostelFee);
        double due1 = sfee + hostelFee;
        Double amount1=h.payFee(due1);
        System.out.println("Remaining Due "+amount1);
        break;
        
        default :
            System.out.println("enter valid input ");
      }
    
    System.out.println("Thank you");
    
    }
    }
}
