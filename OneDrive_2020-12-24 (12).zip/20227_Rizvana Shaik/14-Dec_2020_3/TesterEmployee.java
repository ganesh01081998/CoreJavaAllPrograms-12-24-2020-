package com.ojas.EmployeeClerk;

import java.util.Scanner;

public class TesterEmployee {

	
		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter Your Details...");
			Employee e = new Employee(sc.next(),sc.nextInt(),sc.nextDouble());
			System.out.println("Enter the option \n 1. Manager\n 2. Clerk \n Enter the option");
			switch (sc.nextInt()) {
			case 1:
				Manager m = new Manager(ManagerType.HR);
				m.setSalary();
				break;
			case 2:
				System.out.println("Enter Speed And Accuracy....");
				Clerk c = new Clerk(sc.nextInt(),sc.nextInt());
				c.setSalary();
			default:
				break;
			}
			System.out.println(e);
		}
	}


