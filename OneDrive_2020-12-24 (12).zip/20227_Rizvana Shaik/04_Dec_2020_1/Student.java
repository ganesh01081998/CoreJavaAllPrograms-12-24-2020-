package com.ojas.Programs4122020;

import java.util.Scanner;

public class Student {
	public int studentId;
	public String studentName;
    private int marks;
    private char grade;
    
	public Student(int studentId, String studentName, int marks) {
		this.studentId = studentId;
		this.studentName = studentName;
		this.marks = marks;
		calcGrade(marks);
	}

public String dispDetails() {
	String res ="";
	res = "student [ name  = " + studentName + " ,"+ "Student id = " + studentId +" , " + "marks = " + marks +  " , " + " grade  =  " + grade + " ]";
return res;
}


private void calcGrade(int marks) {
	
	if(marks > 90) {
		 this.grade = 'A';
	}
	else if(marks >= 80 && marks <= 90 ) {
		this.grade = 'B';
	}
	else if(marks >= 70 && marks <= 80) {
		this.grade ='C';
	}
	else if(marks >= 60 && marks <= 70)  {
		this.grade = 'D';
	}
	else if(marks < 60) {
		this.grade ='E';
	}
}


    
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("enter the student details");
		Student s = new Student(scn.nextInt(),scn.next(),scn.nextInt());
		System.out.println(s.dispDetails());

	}

}
