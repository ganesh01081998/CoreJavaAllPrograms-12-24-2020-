package com.ojas.programs7122020;

import java.util.Scanner;

public class LuckySum {
	
	static void isLucky(int nNum1, int nNum2, int nNum3) {
		int sum = 0;
		if(nNum1 == 13) {
			sum = sum;
		}
		else if(nNum2 == 13) {
			sum +=nNum1;
			
	}
		else if(nNum3 == 13) {
			sum += nNum1 + nNum2;
		}
		System.out.println(sum);
		
	}

	public static void main(String[] args) {
	Scanner scn = new Scanner(System.in);
	System.out.println("Enter the 3 numbers");
	int nNum1 = scn.nextInt();
	int nNum2 = scn.nextInt();
	int nNum3 = scn.nextInt();
isLucky(nNum1, nNum2, nNum3);
	

	}

}
