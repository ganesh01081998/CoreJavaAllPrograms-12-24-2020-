package com.ojas.programs7122020;

import java.util.Scanner;

public class SumOfDigits {

	static String digits(String name) {
		String result = "";
		if (name.length() < 0) {
			return  "0";
		}
		int sum = 0;
		for (int i = 0 ; i < name.length(); i++) {
			char ch = name.charAt(i);
			if (Character.isDigit(ch)) {

				int num = Character.getNumericValue(ch);
				sum = sum + num;
			}
		}

		return sum + "";
	}
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("enter the string");
		String name = scn.next();
		System.out.println(digits(name));
	}

}
