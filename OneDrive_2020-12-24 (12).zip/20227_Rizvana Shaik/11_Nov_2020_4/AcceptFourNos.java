package com.ojas.Programs;

public class AcceptFourNos {
	
	static void isAdditionOfTwo(String[] args) {
		if(args.length != 4) {
			System.out.println("Invalid Arguments");
			System.out.println("Enter 4 values?");
			return;
		}
		int num = Integer.parseInt(args[0]);
		num += Integer.parseInt(args[1]);
		num += Integer.parseInt(args[2]);
		num += Integer.parseInt(args[3]);
		System.out.println("Sum = " + num);
	}
	public static void main(String[] args) {
		isAdditionOfTwo(args);
	}



	}


