package com.ojas.Programs;

public class ThreePalindrome_CommandPrompt {
	
	static boolean isPalindrome(int nNum) {
		boolean b = false;
		int rem,sum = 0;
		int temp = nNum;
		
		while(nNum > 0) {
			rem = nNum%10;
			sum = (sum *10) + rem;
			nNum = nNum /10;
		
		}
		if(temp == sum ) {
			b = true;
		}
		return b;
	}

	public static void main(String[] args) {
		int nNum = Integer.parseInt(args[0]);
		System.out.println(isPalindrome(nNum));;

	}

}
