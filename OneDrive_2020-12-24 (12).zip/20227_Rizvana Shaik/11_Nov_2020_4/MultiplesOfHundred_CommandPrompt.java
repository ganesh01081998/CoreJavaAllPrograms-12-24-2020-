package com.ojas.Programs;

public class MultiplesOfHundred_CommandPrompt {
	
	static  void isMultiples(String args[]) {
	int result, quo;
	int nNum = Integer.parseInt(args[0]);
	quo = nNum /100;
		result= (quo + 1) * 100;
		System.out.println(result);
			
	}

	public static void main(String[] args) {
  isMultiples(args);
	}

}
