package com.ojas.Payroll;

public class COJ_15_Employee {

	int id;
	String name;
	double basicSalary;
	 double HRAPer;
	 double DAPer;
	
	 public COJ_15_Employee() {
		
	}

	public COJ_15_Employee(int id, String name, double basicSalary, double hRAPer, double dAPer) {
		this.id = id;
		this.name = name;
		this.basicSalary = basicSalary;
		HRAPer = hRAPer;
		DAPer = dAPer;
	}
	 
	double calculateGrossSalary()  {
		double grossSalary = basicSalary +HRAPer +DAPer;
		return grossSalary;
	}

	@Override
	public String toString() {
		return "COJ_15_Employee [id=" + id + ", name=" + name + ", basicSalary=" + basicSalary + ", HRAPer=" + HRAPer
				+ ", DAPer=" + DAPer + "]";
	}
	
	
	 
	 
}
