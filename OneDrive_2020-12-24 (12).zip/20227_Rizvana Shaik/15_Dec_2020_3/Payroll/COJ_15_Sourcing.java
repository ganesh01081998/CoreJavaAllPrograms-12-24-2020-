package com.ojas.Payroll;

public class COJ_15_Sourcing {

	 int id;  
	 String name;
	 double basicSalary; 
	 double HRAPer;
	 double DAPer; 
	 int enrollmentTarget; 
	 int enrollmentReached; 
	 double perkPerEnrollment;
	public COJ_15_Sourcing() {
		
	}
	public COJ_15_Sourcing(int id, String name, double basicSalary, double hRAPer, double dAPer, int enrollmentTarget,
			int enrollmentReached, double perkPerEnrollment) {
		super();
		this.id = id;
		this.name = name;
		this.basicSalary = basicSalary;
		this.HRAPer = hRAPer;
		this.DAPer = dAPer;
		this.enrollmentTarget = enrollmentTarget;
		this.enrollmentReached = enrollmentReached;
		this.perkPerEnrollment = perkPerEnrollment;
	}
	
	double calculateGrossSalary()  {
		double grossSalary = basicSalary +HRAPer +DAPer+(((enrollmentReached/enrollmentTarget)*100)*perkPerEnrollment);
		return grossSalary;
	}
	@Override
	public String toString() {
		return "COJ_15_Sourcing [id=" + id + ", name=" + name + ", basicSalary=" + basicSalary + ", HRAPer=" + HRAPer
				+ ", DAPer=" + DAPer + ", enrollmentTarget=" + enrollmentTarget + ", enrollmentReached="
				+ enrollmentReached + ", perkPerEnrollment=" + perkPerEnrollment + "]";
	}
	
	 
	 
}
