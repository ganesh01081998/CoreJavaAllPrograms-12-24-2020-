package com.ojas.Payroll;

import java.util.Scanner;

import com.ojas.EmployeeClerk.Employee;

public class COJ_15_TaxUtilTaxUtil {
	
	double tax;
	
	double calculateTax(double grossSalary) {
		if(grossSalary > 30000) {
			tax = (grossSalary * 20)/100;
		}
		else {
			tax = (grossSalary * 5) / 100;
		}
		return tax;
	}


	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		COJ_15_TaxUtilTaxUtil  tu = new COJ_15_TaxUtilTaxUtil ();
		System.out.println("Enter the Employee id, Name, Basic Salary,HRAPer,DAPer");
		COJ_15_Employee e = new COJ_15_Employee(scn.nextInt(),scn.next(),scn.nextDouble(),scn.nextDouble(),scn.nextDouble());
		System.out.println("Employee tax :"+tu.calculateTax(e.calculateGrossSalary()));
		System.out.println("Enter the  Manager  id,Name,BasicSalary, HRAPer,DAPer,projectAllowance");
		COJ_15_Manager m = new COJ_15_Manager(scn.nextInt(),scn.next(),scn.nextDouble(),scn.nextDouble(),scn.nextDouble(),scn.nextDouble());
		System.out.println("Manager tax :"+tu.calculateTax(m.calculateGrossSalary()));
		System.out.println("Enter the Sourcing  id,name,basicSalary,HRAPer, DAPer,enrollmentTarget, enrollmentReached,perkPerEnrollment;");
		COJ_15_Sourcing s = new COJ_15_Sourcing(scn.nextInt(),scn.next(),scn.nextDouble(),scn.nextDouble(),scn.nextDouble(),scn.nextInt(),scn.nextInt(),scn.nextDouble());
		System.out.println("Sourcing tax :"+tu.calculateTax(s.calculateGrossSalary()));
		System.out.println("Enter the  Trainer id, name,basicSalary,HRAPer, DAPer,batchCount,perkPerBatch");
		COJ_15_Trainer t = new COJ_15_Trainer(scn.nextInt(),scn.next(),scn.nextDouble(),scn.nextDouble(),scn.nextDouble(),scn.nextInt(),scn.nextDouble());
		System.out.println("Trainer tax :"+tu.calculateTax(t.calculateGrossSalary()));
	}

}
