package com.ojas.Payroll;

public class COJ_15_Manager {

	 int id; 
	 String name; 
	 double basicSalary;
	 double HRAPer; 
	 double DAPer; 
	 double projectAllowance;
	
	 public COJ_15_Manager() {
		
	}

	public COJ_15_Manager(int id, String name, double basicSalary, double hRAPer, double dAPer,double projectAllowance) {
		super();
		this.id = id;
		this.name = name;
		this.basicSalary = basicSalary;
		this.HRAPer = hRAPer;
		this.DAPer = dAPer;
		this.projectAllowance = projectAllowance;
	}
	
 double calculateGrossSalary()  {
		double grossSalary = basicSalary +HRAPer +DAPer+ projectAllowance;
		return grossSalary;

	}

@Override
public String toString() {
	return "COJ_15_Manager [id=" + id + ", name=" + name + ", basicSalary=" + basicSalary + ", HRAPer=" + HRAPer
			+ ", DAPer=" + DAPer + ", projectAllowance=" + projectAllowance + "]";
}
 
	
	 
	 
	 
	 
}
