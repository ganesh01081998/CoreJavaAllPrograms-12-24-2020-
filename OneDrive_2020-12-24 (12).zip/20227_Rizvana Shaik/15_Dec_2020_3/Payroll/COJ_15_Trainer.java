package com.ojas.Payroll;

public class COJ_15_Trainer {

	int id;  
	String name;  
	double basicSalary; 
	double HRAPer; 
	double DAPer; 
	int batchCount;
	double perkPerBatch;
	
	public COJ_15_Trainer() {
		
	}

	public COJ_15_Trainer(int id, String name, double basicSalary, double hRAPer, double dAPer, int batchCount,double perkPerBatch) {
		super();
		this.id = id;
		this.name = name;
		this.basicSalary = basicSalary;
		this.HRAPer = hRAPer;
		this.DAPer = dAPer;
		this.batchCount = batchCount;
		this.perkPerBatch = perkPerBatch;
	}
	
	
	double calculateGrossSalary()  {
		double grossSalary = basicSalary +HRAPer +DAPer+(batchCount * perkPerBatch);
		return grossSalary;
	}

	@Override
	public String toString() {
		return "COJ_15_Trainer [id=" + id + ", name=" + name + ", basicSalary=" + basicSalary + ", HRAPer=" + HRAPer
				+ ", DAPer=" + DAPer + ", batchCount=" + batchCount + ", perkPerBatch=" + perkPerBatch + "]";
	}
	
	
}
