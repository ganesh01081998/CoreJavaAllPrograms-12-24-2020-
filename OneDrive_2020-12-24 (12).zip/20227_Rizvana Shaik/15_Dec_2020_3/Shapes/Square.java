package com.ojas.shapes;



	public class Square extends Shape {
        float side ;
        
        public Square(float side) {
            this.side = side ;
        }
        
        public Square() {
            // TODO Auto-generated constructor stub
        }
        
        @Override
        void getArea() {
            double Area = (side * side) ;
            System.out.println(Area);
        }
        @Override
        void getPerimeter() {
            double perimeter = 4 * side ;
            System.out.println(perimeter);
            
        }
}

