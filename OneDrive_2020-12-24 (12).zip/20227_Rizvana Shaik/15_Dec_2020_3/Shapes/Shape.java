package com.ojas.shapes;


	abstract class Shape {
        abstract void getArea();
        abstract void getPerimeter();
    
}

