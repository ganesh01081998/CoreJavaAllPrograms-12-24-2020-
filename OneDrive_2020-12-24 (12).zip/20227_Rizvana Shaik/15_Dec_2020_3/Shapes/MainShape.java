package com.ojas.shapes;

public class MainShape {



		 public static void main(String args []) {
	         System.out.println("CIRCLE");
	         Shape sh = new Circle(20f);
	         System.out.println("area of Circle");
	         sh.getArea();
	         System.out.println("perimeter of Circle");
	         sh.getPerimeter();
	         System.out.println("RECTANGLE");
	         Rectangle rect = new  Rectangle (10f , 20f);
	         System.out.println("Area of rectangle");
	         rect.getArea();
	         System.out.println("perimeter of rectangle");
	         rect.getPerimeter();
	         System.out.println("SQUARE");
	         Square squ = new Square(10f);
	         squ.getArea();
	         squ.getPerimeter();
	     
	}
	}


