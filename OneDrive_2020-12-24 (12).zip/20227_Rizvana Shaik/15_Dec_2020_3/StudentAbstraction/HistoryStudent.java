package com.ojas.studentAbstraction;

import java.util.Scanner;

public class HistoryStudent extends Student {

		int historyMarks;
		int civicsMarks;
		int percentage;
		public HistoryStudent() {

		}

		public HistoryStudent(String studentName, String studentClass,int historyMarks, int civicsMarks) {
           super(studentName,studentClass);
			this.historyMarks = historyMarks;
			this.civicsMarks = civicsMarks;
		}

		@Override
		void getPercentage() {
			Scanner scn = new Scanner(System.in);
			System.out.println("Enter the History Marks");
			historyMarks = scn.nextInt();
			System.out.println("Enter the Civics Marks");
			 civicsMarks = scn.nextInt();
			Student.getTotalNoStudents();
			int  totalMarks= historyMarks + civicsMarks;
			System.out.println("The 2 subjects total marks are :"+totalMarks);
			 percentage =( totalMarks )/5;
			System.out.println("The percentage of 2 subjects are :"+percentage);
		}

		@Override
		public String toString() {
			return "HistoryStudent [historyMarks=" + historyMarks + ", civicsMarks=" + civicsMarks + ", studentName="
					+ studentName + ", studentClass=" + studentClass + "]";
		}
		public String display() {
			return toString();
		}
	}



