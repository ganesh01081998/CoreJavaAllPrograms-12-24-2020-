package com.ojas.programs3122020;

import java.util.Scanner;

public class FizzArray {

static String isFizzArray(int start, int end) {
		String result = "";
		if(start > end) {
			int temp = start;
			start = end;
			end = temp;
		}
		int [] array = new int[end - start];
		//index
		for (int i = 0; i < array.length; i++) {
			array[i] = start ++;
			result += array[i] +" ";
		}
		return result;
	}

public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	System.out.println("Enter the start and End numbers");
	int start = scan.nextInt();
	int end = scan.nextInt();
	System.out.println(isFizzArray(start, end));
}
}
