package com.ojas.programs3122020;

import java.util.Scanner;

public class ShiftingElement {


	private static void isCheck(int[] array) {
		int num = 0;
		int array2 [] = new int [array.length];
		for (int i = 0; i< array.length; i++) {
			if(array[i] % 10 == 0) {
				array[i] = 0;
			}
			else {
				array2[num] = array[i];
				num++;
			}
		}
		for (int check : array2) {
			System.out.println(check);
		}

	}
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the size of array");
		int [] array = new int[scan.nextInt()];
		System.out.println("Enter the array elements");
		for (int i = 0; i < array.length; i++) {
			array[i] = scan.nextInt();
		}
		isCheck(array);
	}

}
