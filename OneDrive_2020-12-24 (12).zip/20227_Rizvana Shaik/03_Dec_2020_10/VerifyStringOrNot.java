package com.ojas.programs3122020;

import java.util.Scanner;

public class VerifyStringOrNot {

	static String isVerifyString(String num) {
		int count = 0;
		String result = "";
		for (int index = 0; index < num.length(); index++) {
			char ch = num.charAt(index);
			boolean flash = Character.isDigit(ch);
			if(flash) {
				count ++;
			}
		}
		if(count == num.length()) {
			result = "The given String contain only integer values.";
		}
		else {
			result = "The given String does not contain only integer values.";
		}
		return result;
	}
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the number");
		String num = scan.next();
		System.out.println(isVerifyString(num));
	}

}
