package com.ojas.programs3122020;

import java.util.Scanner;

public class EvenArray {

	static int isEvenArray(int size,int arr[]) {
		int count= 0;
		for(int i = 0;i < arr.length;i++) {
			if(arr[i] % 2 ==0 ) {
				count++;
			}
		}
		return count;
	}
	public static void main(String[] args) {
	Scanner scn = new Scanner(System.in);
	System.out.println("Enter the size of the array");
	int size = scn.nextInt();
	System.out.println("enter the array elements");
	int arr[] = new int[size];
	for(int i = 0;i <arr.length;i++) {
		arr[i] = scn.nextInt();
	}
	System.out.println(isEvenArray(size, arr));

	}

}
