package com.ojas.programs3122020;

import java.util.Scanner;

public class FindWordInSentence {

	static String isFindWord(String str,String str1) {
		String res = "";
		String str2[] = str.split(" ");
		for(int i = 0;i<str2.length;i++) {
			if(str1.equals(str2[i])) {
				res += str1 +  " is found ";
			}

		}

		return res;
	}

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter any sentence");
		String str = scn.nextLine();
		System.out.println("Enter a searching element");
		String str1 = scn.next();
		System.out.println(isFindWord(str,str1));
	}

}
