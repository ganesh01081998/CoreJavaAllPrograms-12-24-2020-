package com.ojas.programs3122020;

import java.util.Scanner;

public class CountNoOfWordsInASentence {
	
	static String isCountWords(String str) {
		String res = "";
		int count = 1;
		for(int i = 0;i<str.length();i++) {
			char ch = str.charAt(i);
			if(ch  == ' ') {
				count++;
			}
		}
		return Integer.toString(count);
	}


	public static void main(String[] args) {
	Scanner scn = new Scanner(System.in);
	System.out.println("Enter the sentence");
	String str = scn.nextLine();
	System.out.println(isCountWords(str));
	}
}
