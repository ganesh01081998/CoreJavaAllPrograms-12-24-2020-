package com.ojas.programs3122020;

import java.util.Scanner;

public class CharacterOccurance {
	
	static String isCountChar(String str,char ch) {
		String res = "";
		int count = 0;
		for(int i = 0;i < str.length();i++) {
			char ch1 = str.charAt(i);
			if(ch1 == ch) {
				count++;
			}
		}
		return Integer.toString(count);
	}

	public static void main(String[] args) {
	Scanner scn = new Scanner(System.in);
	System.out.println("Enter any string");
	String str = scn.next();
	System.out.println("Enter the searching character of a  string");
	char ch = scn.next().charAt(0);
    System.out.println(isCountChar(str, ch));
	}

}
