package com.ojas.programs3122020;

import java.util.Scanner;

public class ReverseStringWithoutMethod {

	static String isReverse(String str) {
		String str1 = "";
		for(int i =str.length()-1; i >=0; i--) {
			str1 +=str.charAt(i);
		}
		return str1;
	}

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter a string");
		String str = scn.next();
		System.out.println(isReverse(str));
	}

}
