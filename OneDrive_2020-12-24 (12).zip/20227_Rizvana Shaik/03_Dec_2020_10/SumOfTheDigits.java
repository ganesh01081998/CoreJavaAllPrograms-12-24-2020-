package com.ojas.programs3122020;

import java.util.Scanner;

public class SumOfTheDigits {

	
	static int isSumOfDigit(int num) {
		int sum = 0,rem;
		while(num > 0) {
			rem = num % 10;
			sum = sum + rem;
			num = num / 10;
		}
		return sum;
	}
	public static void main(String[] args) {
	Scanner scn =new Scanner(System.in);
	System.out.println("Enter any number");
	int num = scn.nextInt();
System.out.println(isSumOfDigit(num));
	}

}
