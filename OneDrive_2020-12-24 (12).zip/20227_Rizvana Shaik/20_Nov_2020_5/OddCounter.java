package com.ojas.Arrays;

import java.util.Scanner;

public class OddCounter {
	
	static String isSize(int size) {
		String result = "";
		if(size == 10) {
			Scanner scn = new Scanner(System.in);
			System.out.println("enter the array elements");
			int odd[] = new int[size];
			for(int i = 0;i < odd.length;i++) {
				odd[i] = scn.nextInt();
			}
			for(int i = 0;i <odd.length;i++) {
				if(odd[i] % 2 != 0) {
					result += odd[i]+" ";
				}
			}	
		}
		else {
			System.out.println("input mismatch");
			return "-1";
		}
		return result;
	}

	public static void main(String[] args) {
	Scanner scn = new Scanner(System.in);
	System.out.println("enter the array size");
	int size = scn.nextInt();
	System.out.println(isSize(size));

	}

}
