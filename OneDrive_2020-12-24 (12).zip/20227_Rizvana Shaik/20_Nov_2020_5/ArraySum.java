package com.ojas.Arrays;

import java.util.Scanner;

public class ArraySum {
	
	static int isArray(int size) {
		int sum = 0;
		Scanner scn = new Scanner(System.in);
		System.out.println("eneter the array elements");
		int arr[] = new int[size];
		for(int i = 0;i <arr.length;i++) {
			arr[i] = scn.nextInt();
		}
		for(int i = 0;i<arr.length;i++) {
			sum += arr[i];
		}
		return sum;
	}

	public static void main(String[] args) {
	Scanner scn = new Scanner(System.in);
	System.out.println("enter the array size");
	int size = scn.nextInt();
System.out.println("sum of array elements are :"+isArray(size) );
	}

}
