package com.ojas.program24122020;

import java.util.Scanner;

public class MaximumArray {

	static int findMax(int[] arr) {
        int max = arr[0];
        for (int check = 1; check < arr.length; check++) {
            if(max < arr[check]) {
                max = arr[check];
            }
        }
        return max;
        
    }
    
    public static void main(String[] args) {
        int count = 0;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the array size");
        int size = sc.nextInt();
        int [] arr = new int[size];
        System.out.println("Enter the array elements");
        for (int insert = 0; insert < arr.length; insert++) {
            size = sc.nextInt();
            if(size < 0) {
                count++;
            }
            arr[insert] = size;
        }
        if(count >= 3) {
            System.out.println("The Max Value in the Array "+ findMax(arr));            
        }
        else {
            System.out.println("The Array consist Negitive or zeros -3");
        }
    }
}
