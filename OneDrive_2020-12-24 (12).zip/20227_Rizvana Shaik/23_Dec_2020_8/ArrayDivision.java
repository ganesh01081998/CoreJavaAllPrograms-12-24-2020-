package com.ojas.program24122020;

import java.util.Scanner;

public class ArrayDivision {

	public boolean isSum(int a[],int size) {
		boolean b = false;
		int fHalf = 0,sHalf = 0;
		for(int index = 0;index < a.length;index++) {
			int length = size /2;
				if(index <= length) {
					fHalf += a[index];
				}
				else if(index >= length) {
					sHalf += a[index];
				}

			}
			if(fHalf == sHalf) {
				b = true;
			}
			else {
				return b;
			}
		

		return b;
	}

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("enter the array size");
		int size = scn.nextInt();
		System.out.println("Enter the array elements");
		int a[] = new int[size];
		
		ArrayDivision ad = new ArrayDivision();
		for(int index = 0;index < a.length;index++) {
			a[index]=scn.nextInt();
		}
		System.out.println(ad.isSum(a,size));

	}

}
