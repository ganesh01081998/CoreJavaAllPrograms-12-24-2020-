package com.ojas.program24122020;

import java.util.Scanner;

public class CountOccurances {

	
		 static void findChar(String word,char search) {
		        int count = 0;
		        for (int check = 0; check < word.length(); check++) {
		            if(search == word.charAt(check)) {
		                count++;
		            }
		        }
		        System.out.println("The Character " + search + " is Repeted for: " + count);
		    }

		 

		    public static void main(String[] args) {
		        Scanner sc = new Scanner(System.in);
		        System.out.println("Enter Any String...");
		        String word= sc.next().toLowerCase();
		        System.out.println("Enter Which Charcter You Want....");
		        char search = sc.next().charAt(0);
		        findChar(word, search);
		    }
		        

	}


