package com.ojas.program24122020;

import java.util.Scanner;

public class Centered {


	public void isCentered(int a[]) {
		int center = 0;
		for(int index =0;index<=a.length/2;index++) {

			center =a[index];
		}
		System.out.println(center);

	}

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter the array size");
		int size = scn.nextInt();
		System.out.println("Enter the array elements");
		int a[] = new int[size];
		Centered c = new Centered();
		for(int index=0;index<a.length;index++) {
			a[index]=scn.nextInt();
		}
		c.isCentered(a);

	}

}
