package com.ojas.programs2122020;

import java.util.Scanner;

public class EndOfTheWordYZ {

	
	static String countYZ(String str) {
	String res = "";
	int count = 0;
    String arr[] = str.split(" ");
    str = arr[0];
    String str2 = arr[1];
    for (int i = 0; i < arr.length; i++) {
    	if(!Character.isLetter(arr[i].length()-1) ||arr[i].charAt(arr[i].length()-1) == 'z' || arr[i].charAt(arr[i].length()-1 )== 'y') {
    		res +=arr[i];
    		count++;
    	}
		
	}
	return Integer.toString(count);
	}
	public static void main(String[] args) {
	Scanner scn = new Scanner(System.in);
	System.out.println("Enter Any string");
	String str = scn.nextLine();
System.out.println(countYZ(str));
	}

}
