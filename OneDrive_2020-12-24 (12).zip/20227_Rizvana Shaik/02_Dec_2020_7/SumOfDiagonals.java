package com.ojas.programs2122020;

import java.util.Scanner;

public class SumOfDiagonals {
	
	static int getDiagonalSum(int arr[][]) {
		int count = 0;
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr.length; j++) {
				if(i == j) {
					count +=arr[i][j];
				}
			}
			
		}
		return count;
	}

	public static void main(String[] args) {
	Scanner scn = new Scanner(System.in);
	System.out.println("Enter the array size");
	int size = scn.nextInt();
	System.out.println("enter the row size");
	int rows = scn.nextInt();
	System.out.println("enter the columns size");
	int cols = scn.nextInt();
	System.out.println("enter the array elements");
	int arr[][] = new int[rows][cols];
   for (int i = 0; i < arr.length; i++) {
	   for (int j = 0; j < arr.length; j++) {
		arr[i][j] = scn.nextInt();
	}
	
}
   System.out.println(getDiagonalSum(arr));
	}

}
