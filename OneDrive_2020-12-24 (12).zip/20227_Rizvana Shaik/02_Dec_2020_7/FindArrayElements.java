package com.ojas.programs2122020;

import java.util.Scanner;

public class FindArrayElements {

	static int getCount(int arr[],int searchNo) {
		int res = 0;
		for(int i = 0;i<arr.length;i++) {
			if(arr[i] == searchNo) {
				res++;
			}
		}
		return res;
	}

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("enter the array size");
		int size = scn.nextInt();
		if(size == 0) {
			System.out.println("null");
		}
		else {
		System.out.println("enter the array elements ");
		int arr[] = new int[size];
		for (int i = 0; i < arr.length; i++) {
			arr[i] = scn.nextInt();	
		}
		System.out.println("enter the searching elements");
		int searchNo = scn.nextInt();
		System.out.println("The searching elements are occur " + " " + getCount(arr, searchNo) + " times");
	}
	}
}
