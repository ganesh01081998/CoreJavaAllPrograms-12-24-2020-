package com.ojas.programs2122020;

import java.util.Scanner;

public class RepeatedCharacters {
	
	static int  isBlock(String str) {
		int count,temp = 0;
		
		for(int i = 0;i < str.length();i++) {
			char ch = str.charAt(i);
			 count = 0;
			for(int j = 0;j <str.length();j++) {
				if(ch == str.charAt(j)) {
					count++;
				}
			}
			if(temp < count) {
				temp = count;
			}
		}
		return temp;
	}

	public static void main(String[] args) {
	Scanner scn = new Scanner(System.in);
	System.out.println("enter the String");
	String str = scn.next();
	System.out.println(isBlock(str));
	}
}
