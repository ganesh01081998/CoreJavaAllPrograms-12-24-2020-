package com.ojas.aprograms23;

import java.util.Scanner;

public class SumTheValue {
	
	static int isSumDouble(int num1,  int  num2) {
		 int sum = 0;
		 if(num1 !=num2) {
			sum = num1 + num2;
		 }
		 else if(num1 == num2) {
			 sum = (num1 + num2) * 2;
		 }
		 return sum;
	}

	public static void main(String[] args) {
	Scanner scn = new Scanner(System.in);
	System.out.println("enter the n1 value");
	int num1 =  scn.nextInt();
	System.out.println("enter the n2 value");
	int num2 = scn.nextInt();
	System.out.println(isSumDouble(num1, num2));
	}

}
