package com.ojas.aprograms23;

import java.util.Scanner;

public class LastDigitSame {
	
	static boolean isLastDigit(int digit1, int digit2) {
		 boolean b =  false;
		 int num1 = digit1 % 2;
		 int num2 = digit2 % 2;
		 if(num1 == num2) {
			 b =  true;
		 }
		 return b;
		 
		
	}

	public static void main(String[] args) {
	Scanner scn = new Scanner( System.in);
	System.out.println("enter the n1 Value");
	int  digit1= scn.nextInt();
	System.out.println("enter the n2 value");
	int digit2 = scn.nextInt();
	System.out.println(isLastDigit(digit1, digit2));
	}

}
