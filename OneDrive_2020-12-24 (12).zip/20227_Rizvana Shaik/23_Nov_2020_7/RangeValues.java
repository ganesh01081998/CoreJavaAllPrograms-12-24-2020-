package com.ojas.aprograms23;

import java.util.Scanner;

public class RangeValues {

	static boolean isRangeValue(int first, int sec) {
        boolean b = false;
        if ((first >= 30 && first <= 40)&&(sec >= 30 && sec <= 40)) {
            b = true;
        }
        else if ((first >= 40 && first <= 50)&&(sec >= 40 && sec <= 50) ) {
            b = true;
        }
        return b;
    }

 

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Any Two Numbers..");
        int firstNum = sc.nextInt();
        int secNum = sc.nextInt();
        System.out.println(isRangeValue(firstNum,secNum));

 

    }

 
}
