package com.ojas.aprograms23;

import java.util.Scanner;

public class NearestValueForTheGivenNo {

	
	static int isNearest(int num1, int num2) {
		int diff = 0;
		int nearest = 10 - num1;
		int near = 10 - num2;
		nearest = Math.abs(nearest);
		near = Math.abs(near);
		if(nearest  < near) {
			diff = num1;
		}
		else if(nearest > near) {
			diff = num2;
		}
		else if( nearest == near) {
			diff = 0;
		}
		return diff;
	}
	public static void main(String[] args) {
	Scanner scn = new Scanner(System.in);
	System.out.println("enter the n1 value");
	int num1 = scn.nextInt();
	System.out.println("enter the n2 value");
	int num2 = scn.nextInt();
	System.out.println(isNearest(num1, num2));
	}

}
