package com.ojas.programs24;

import java.util.Scanner;

public class NameScore {

	static String result = "";
	
 static String ScoreOfTheName(String name) {
     int sum = 0;
     boolean b1;
     for (int i = 0; i < name.length(); i++) {
         char c = name.charAt(i);
      b1 = Character.isUpperCase(c);
      if(b1 == true) {
          sum += c - 64;
      }
      else if(b1 == false){
          sum += c - 96;
      }
      else {
          System.out.println("Dont Enter the spaces");
      }
     }
     result += sum;
     return result;
}
 
 public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
	     System.out.println("Enter the name ");
	     String name = scan.next();
	     ScoreOfTheName(name);   
	     System.out.println(result);
	}
	 
}
