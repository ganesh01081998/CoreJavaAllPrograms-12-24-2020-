package com.ojas.Programs;

import java.util.Scanner;

public class OddPalindrome {

	static boolean isPalindrome(int num) {
		boolean b= false;
		int temp=num, rem,sum=0;
		while(num > 0) {
			rem=num % 10;
			sum=sum*10+rem;
		    num = num/10;
	}
	
		if(temp==sum && sum % 2==1) {
		System.out.println(sum+ "palindrome");
	}
	return b;
}

static String rangePalindrome(int startValue, int endValue) {
	String result = "";
	for(int i=startValue;i<=endValue;i++) {
		if(isPalindrome(i)) {
			result += i + " ";
		}
	} 
	return result;
}

public static void main(String[] args) {

Scanner scn	=new Scanner(System.in);
System.out.println("enter the start value");
int num1=scn.nextInt();
System.out.println("enter the end value");
int num2=scn.nextInt();
rangePalindrome(num1,num2);

}


	}


