package com.ojas.programs24;

import java.util.Scanner;

public class PalindromeRecursion {

	static void isReverse(int num) {
		int sum = 0, rem, temp = num;
		while(num > 0) {
			rem = num % 10;
			sum = sum * 10 + rem;
			num = num / 10;
		}
		System.out.println(sum);
		isPalindrome(sum, temp);
	}
	
	static String isPalindrome(int sum1, int temp1) {
		String res = "";
		int  num = sum1;
		int result = 0;
		if(num == temp1) {
			System.out.println(num + " is a Palindrome");
		}
		else {
			result = num + temp1;
			System.out.println(result);
			isReverse(result);
		}
		return  res;
	}

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("enter any number");
		int num = scn.nextInt();
		isReverse(num);
	}

}
