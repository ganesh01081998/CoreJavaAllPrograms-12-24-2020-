package com.ojas.programs24;

import java.util.Scanner;

public class PerfectNum {
	
	  static int sumOfProperDivisors(int num) {
	        int result = 0;
	        
	        if(num < 0) {
	        	return -2;
	        }
	        else if(num ==0){
	        	return -3;
	        }
	        for (int i = 1; i < num; i++) {
	            if(num % i == 0) {
	             //   System.out.print(i + " ,");
	                result += i;    
	            }
	        }
	        if(result == num) {
	           result = 0;
	        	//System.out.println(result + " is Perfect Number...");
	        }
	        else if(result < num ) {
	           // System.out.println(result + " is Deficent Number...");
	        	result = -1;
	        }
	        else if(result > num) {
	           // System.out.println(result + " is Abunant Number..."); 
	        	result = 1;
	        }    
	        return result;
	    }

	 

	    public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);
	        System.out.println("Enter Any Number...");
	        int num = sc.nextInt();
	        System.out.println(sumOfProperDivisors(num));
	    }

}
