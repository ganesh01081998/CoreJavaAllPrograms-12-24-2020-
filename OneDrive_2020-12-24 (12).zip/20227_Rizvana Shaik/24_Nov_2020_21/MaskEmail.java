package com.ojas.Strings;

import java.util.Scanner;

public class MaskEmail {
	static String result ="";
	   
    static void doThis(String Email) {
        for (int i = 2; i < Email.length(); i++) {
            if(Email.charAt(i) == '@') {
                doAgain(i,Email);
                break;
            }
            else {
                result+="x";
            }
        }
    }
    static void doAgain(int i, String Email) {
        for (int j = i; j < Email.length(); j ++) {
            result+= Email.charAt(j);
        }
    }
   
    public static void main(String[] args) {
        String Email;
        System.out.println("Enter you Email id");
        Scanner scan = new Scanner(System.in);
        Email =scan.next();
        result += ""+Email.charAt(0)+Email.charAt(1);
        doThis(Email);
        System.out.println(result);
    }

}
