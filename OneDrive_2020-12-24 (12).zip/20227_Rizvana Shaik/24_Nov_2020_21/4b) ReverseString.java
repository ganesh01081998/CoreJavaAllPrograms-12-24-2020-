package com.ojas.programs24;

import java.util.Scanner;

public class ReverseString {
	
	static String getReversedString(String str) {
		String res = "";
		for(int i = str.length()-1;i >=0;i--) {
			res +=str.charAt(i);
		}
		return res;
	}

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("enter the String");
		String str = scn.next();
		System.out.println(getReversedString(str) );
	}

}
