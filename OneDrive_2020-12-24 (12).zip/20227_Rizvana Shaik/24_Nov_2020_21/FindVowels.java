package com.ojas.Strings;

import java.util.Scanner;

public class FindVowels {
	
	static String isVowel(String str) {
		String res = "";
	//	char ch[] = str.toCharArray();
		for(int i = 0;i <=str.length()-1;i++) {
			char ch = str.charAt(i);
			if(ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
				 res += ch + " ";
			}
		}
		
		return res;
	}

	public static void main(String[] args) {
   Scanner scn = new Scanner(System.in); 
   System.out.println("enter the String");
   String str = scn.nextLine();
 System.out.println( isVowel(str));

	}

}
