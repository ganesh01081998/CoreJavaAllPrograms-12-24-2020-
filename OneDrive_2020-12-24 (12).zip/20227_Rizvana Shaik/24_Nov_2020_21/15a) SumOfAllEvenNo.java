package com.ojas.programs24;

import java.util.Scanner;

public class SumOfAllEvenNo {
	
	static int getSumOfEvenNumbers( int arr[],int size) {
		int result = 0;
		for (int i = 0; i < arr.length; i++) {
			if(arr[i] == 0) {
				return -2;
			}
			else if(arr[i] % 2 == 0) {
				result +=arr[i];
			}
			
			else if(size == 0) {
				return -3;
			}
			else if(arr[i] < 0) {
				return -1;
			}
			
		}
		return result;
	}

	public static void main(String[] args) {
	Scanner scn =new Scanner(System.in);
	System.out.println("enter array size");
	int size =  scn.nextInt();
	System.out.println("enter the array elements");
	int arr[] =  new int[size];
	for(int i = 0;i < arr.length;i++) {
		arr[i] = scn.nextInt();
	}
    System.out.println(getSumOfEvenNumbers(arr, size));

	}

}
