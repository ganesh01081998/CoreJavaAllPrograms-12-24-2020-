package com.ojas.programs24;

import java.util.Scanner;

public class ReverseAnArray {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter array size");
		int [] array = new int [scan.nextInt()];
		System.out.println("Enter the array elements");
		for (int index = 0; index < array.length; index++) {
			array[index] = scan.nextInt();
		}
		is_ReverseArray(array);
	}

	static void is_ReverseArray(int[] array) {
		for (int  index = array.length-1;index >= 0; index--) {
			System.out.println(array[index]);
		}
		
	}
}
