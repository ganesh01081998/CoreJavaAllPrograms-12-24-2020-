package com.ojas.programs24;

import java.util.Scanner;

public class DuplicateArray {

	
	public static void main(String[] args) {      
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter array size");
		int [] array = new int [scan.nextInt()];
		System.out.println("Enter the array elements");
		for (int index = 0; index < array.length; index++) {
			array[index] = scan.nextInt();
		}
        is_DublicateElements(array);
    }

	static void is_DublicateElements(int[] array) {
		System.out.println("Duplicate elements in given array: ");   
        for(int i = 0; i < array.length; i++) {  
            for(int j = i + 1; j < array.length; j++) {  
                if(array[i] == array[j])  
                    System.out.println(array[j]);  
            }  
        }  
		
	}  
}
