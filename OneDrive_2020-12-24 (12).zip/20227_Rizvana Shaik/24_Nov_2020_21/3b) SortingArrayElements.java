package com.ojas.programs24;

import java.util.Scanner;

public class SortingArrayElements {
	
	static int isSorted(int arr[],int size) {
		int temp = 0;
		for (int i = 0; i <arr.length; i++) {
			for (int j = i + 1; j <arr.length; j++) {
				if(arr[i] > arr[j]) {
					temp = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
				}
			}
			
		}
		return temp;
	}

	public static void main(String[] args) {
	Scanner scn = new Scanner(System.in);
	System.out.println("enter the array size");
	int size = scn.nextInt();
	System.out.println("enter the array elements");
	int arr[] = new int[size];
	for (int i = 0; i < arr.length; i++) {
		arr[i] =  scn.nextInt();
	}
	System.out.println(isSorted(arr,size));
	for (int i = 0; i < arr.length; i++) {
		System.out.println(arr[i] + " ");
		
	}

	}

}
