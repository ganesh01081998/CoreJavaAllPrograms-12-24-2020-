package com.ojas.programs24;

import java.util.Scanner;

public class AdamNumber {

	static boolean  isReverse(int num) {
		boolean b = false;
		int temp = num;
		int sum = 0,rem;
		int number = num * num;
		System.out.println(number);
		while(num > 0) {
			rem = num % 10;
			sum = sum * 10 + rem;
			num = num /10;
		}

		System.out.println(sum);
		int rem1 ,sum1 = 0;
		int num1 = sum * sum;
		System.out.println(num1);
		while(num1> 0) {
			rem1 = num1 % 10;
			sum1 = sum1 * 10 + rem1;
			num1 = num1  / 10;	
		}
		System.out.println(sum1);
		if(number == sum1) {
			b = true;
		}
		else {
	          b = false;
		}
		return b;
		
	}


	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("enter any value");
		int num = scn.nextInt();
		System.out.println(isReverse(num));
	}
}
