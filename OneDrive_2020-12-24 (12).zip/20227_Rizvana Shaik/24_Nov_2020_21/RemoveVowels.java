package com.ojas.programs24;

import java.util.Scanner;

public class RemoveVowels {
	
	static String removeVowels(String str){
		String result = "";
		for (int i = 0; i < str.length(); i++) {
			char ch = str.charAt(i);
			if(ch == 'a' || ch == 'e' || ch == 'i' ||ch == 'o' || ch == 'u') {
				
			}
			else {
				result += str.charAt(i);
			}
			
		}
		return result;
	}

	public static void main(String[] args) {
	Scanner scn = new Scanner(System.in);
	System.out.println("enter the String");
	String str = scn.nextLine();
	System.out.println( removeVowels(str));

	}

}
