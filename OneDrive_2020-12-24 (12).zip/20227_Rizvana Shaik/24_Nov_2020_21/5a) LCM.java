package com.ojas.programs24;

import java.util.Scanner;

public class LCM {
	static int res;
	static int isLcm(int num1, int num2) {
		int lcm = 0;
		if(num1 < 0 || num2 < 0) {
			return -1;
		}
		else {
		for(int i = 1;i <=num1 && i <= num2;i++) {

			if(num1 % i==0 && num2 % i==0) {
				res=i;

			}
		}
		lcm = (num1 * num2) / res;
		}
		return lcm;
	}

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("enter the values");
		int firstNum =  scn.nextInt();
		int secNum = scn.nextInt();
		System.out.println("LCM of the Two numbers:" + isLcm(firstNum, secNum));
	}
}
