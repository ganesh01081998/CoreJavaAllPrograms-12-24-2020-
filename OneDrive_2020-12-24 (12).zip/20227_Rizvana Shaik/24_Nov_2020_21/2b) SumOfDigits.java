package com.ojas.programs24;

import java.util.Scanner;

public class SumOfDigits {

	
	static int getSumOfDigits(int nNum) {
		int sum = 0,rem;
		while(nNum > 0) {
			rem = nNum % 10;
			sum = sum + rem;
			nNum = nNum / 10;
		}
		return sum;
		
	}
	public static void main(String[] args) {
	Scanner scn = new Scanner(System.in);
	System.out.println("enter any number");
	int nNum = scn.nextInt();
	System.out.println(getSumOfDigits(nNum));

	}

}
