package com.ojas.programs24;

import java.util.Scanner;

public class MonthNames {
	
	static String isMonths(String[] months, String mon,int days[]) {
		String result = "";
        for (int i = 0; i < months.length; i++) {
			if(mon.equals(months[i])) {
				result +=days[i];
			}
		}
		return result;
	}

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
        String months[] = {"jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec"};
        int days[] = {31,28,31,30,31,30,31,31,30,31,30,31};
        String  mon= scn.next().toLowerCase();
       System.out.println(isMonths(months,  mon,days));
	}
	

}
