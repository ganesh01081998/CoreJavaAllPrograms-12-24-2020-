package com.ojas.programs21122020;

import java.util.Scanner;

public class Executable {

	public static void main(String[] args) {
		
		Scanner scn = new Scanner(System.in);
		System.out.println("enter how many leaves do u want");
		LeaveSystem ls = new LeaveSystem(scn.nextInt());
		ls.exceedLeaves();

	}

}
