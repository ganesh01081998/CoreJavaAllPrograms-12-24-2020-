package com.ojas.programs21122020;

public class LeaveSystem {

	int leaves;
	int totalNoOfLeaves = 25;
	
	public LeaveSystem(int leaves) {
		
		this.leaves = leaves;
		
	}
	
	
	void exceedLeaves() {

		try { 
               if(leaves > totalNoOfLeaves) {
            	   throw new LeaveQuotaExceededException("Your  leaves are exceeded");
               }
               else {
            	   System.out.println("Your leave sanctioned");
               }
		}
               catch(LeaveQuotaExceededException lq) {
            	   System.out.println(lq);
               }
			
		}
	}
	


