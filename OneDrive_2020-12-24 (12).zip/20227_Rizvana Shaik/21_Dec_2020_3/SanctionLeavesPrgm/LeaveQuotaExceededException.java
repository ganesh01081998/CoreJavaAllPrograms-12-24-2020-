package com.ojas.programs21122020;

public class LeaveQuotaExceededException extends Exception {
   public LeaveQuotaExceededException(String leaves) {
	   super(leaves);
   }
}
