package com.ojas.AccountException;

public class InsufficientFundsException extends Exception {

	double amount;
	
	
	
	public InsufficientFundsException(String amount) {
		super(amount);
	}



	double getAmount() {
	 return amount;	
	}
	

}
