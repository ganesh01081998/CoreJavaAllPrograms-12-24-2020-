package com.ojas.AccountException;

import java.util.Scanner;

public class BankDemo {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter the account no");
		CheckingAccount ca = new CheckingAccount(scn.nextInt());
        ca.checkAccount();

	}

}
