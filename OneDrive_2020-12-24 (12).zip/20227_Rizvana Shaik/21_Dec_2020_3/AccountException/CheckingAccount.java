package com.ojas.AccountException;

import java.util.Scanner;

public class CheckingAccount {

	static Scanner scn = new Scanner(System.in);
	int accno;
	double balance = 20000;
	
	

	public CheckingAccount(int accno) {
		this.accno = accno;
	}

	public void disp() {
		while(true) {
		System.out.println("1. Deposit \n 2. Withdraw \n 3.exit");
	System.out.println("Enter the option u want to perform");
			int choice = scn.nextInt();
			switch(choice) {
			case 1:deposit(scn.nextDouble());
			break;
			case 2 : withDraw(scn.nextDouble());
			break;
			default : System.exit(0);
			}

		}
	}

	public void checkAccount() {
		System.out.println("enter the acc no");
		int accNo = scn.nextInt();
		if(this.accno == accNo) {
		     disp();
		}
		else {
		System.out.println("Plz check u r account no u entered");
		}
		
	}



	public void deposit(double amount) {
		
		
		balance =balance +  amount;
		System.out.println(amount+"Successfully credited in your account. your total balance is:"+balance);

	}

	public void withDraw(double amount) {
		try {
			if(amount > balance) {
				throw new InsufficientFundsException("InsufficientFundException");
			}
			else {
				balance = balance - amount;

			}
		}
		catch(InsufficientFundsException e){
			System.out.println(e);
		}
		System.out.println("Tha avaliable balance is:"+balance);

	}
}
