package com.ojas.sports;

public class Sports {
	String sportsNames;
	String getName(String sportName){
		sportsNames=sportName;
		
		return sportsNames;
		
	}
	 String getNumberOfTeamMembers(){
		
		return "Each team has n players in Sports";
		
	}

}
