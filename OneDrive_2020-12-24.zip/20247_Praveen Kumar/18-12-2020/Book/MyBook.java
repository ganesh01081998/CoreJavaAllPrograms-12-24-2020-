package com.ojas.book;

public class MyBook extends Book {

	@Override
	void setTitle(String booktitle) {
		title = booktitle;

	}

}
