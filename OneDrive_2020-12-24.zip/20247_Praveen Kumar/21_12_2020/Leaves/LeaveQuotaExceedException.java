package com.ojas.Exception;

public class LeaveQuotaExceedException extends Exception {
	public LeaveQuotaExceedException(String mess) {
		super(mess);
	}

}
