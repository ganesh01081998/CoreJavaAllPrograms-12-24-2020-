package com.ojas.Exception;

public class NameNotValidException extends Exception{
	public NameNotValidException(String mess) {
		super(mess);
		
	}

}
