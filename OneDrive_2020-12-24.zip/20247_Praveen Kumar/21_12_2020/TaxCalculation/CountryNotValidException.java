package com.ojas.Exception;

public class CountryNotValidException extends Exception {
	public CountryNotValidException(String mess) {
		super(mess);
		
	}

}
