package com.ojas.Exception;

public class NotEligibleForTaxException extends Exception{
	public NotEligibleForTaxException(String mess) {
		super(mess);
	
	}

}
