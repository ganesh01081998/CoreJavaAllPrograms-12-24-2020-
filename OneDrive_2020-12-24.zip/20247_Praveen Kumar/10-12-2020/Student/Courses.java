package com.ojas;

import java.util.Arrays;

public class Courses {
	
	String course[] = { "1.java", "2.dotNet", "3.phyton", "4.salesforse", "5.datascience", "6.manframes","7.exit"};
	int prises[] = { 5000, 4000, 6000, 8000, 15000, 3000 };
	@Override
	public String toString() {
		return "Courses [course=" + Arrays.toString(course);
	}
	

}

