package com.ojas;

public class Pattern10 {
	public static void main(String[] args) {
		isPattern();
		}

	private static void isPattern() {
		for(int rows=1;rows<=5;rows++) {
			for(int coloms=1;coloms<=5;coloms++) {
				System.out.print("* ");
			}
			System.out.println();
		
	}
	}

}
