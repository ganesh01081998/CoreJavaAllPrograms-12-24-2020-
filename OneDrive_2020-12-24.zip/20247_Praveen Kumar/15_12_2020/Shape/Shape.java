package absractDemo_Shape;

public abstract class Shape {
	abstract void getArea();

	abstract void getParameter();

}
