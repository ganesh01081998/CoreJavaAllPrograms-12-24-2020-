package dec5_12;

public class Manager {
	int empId;
	String empName;
	double basicSalary;
	double HRAper;
	double DAper;
	double  projectAllowance;
	public Manager(int empId, String empName, double basicSalary, double hRAper, double dAper,
			double projectAllowance) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.basicSalary = basicSalary;
		HRAper = hRAper;
		DAper = dAper;
		this.projectAllowance = projectAllowance;
	}
	@Override
	public String toString() {
		return "Manager [empId=" + empId + ", empName=" + empName + ", basicSalary=" + basicSalary + ", HRAper="
				+ HRAper + ", DAper=" + DAper + ", projectAllowance=" + projectAllowance + "]";
	}
	Double calculateGrossSalary(){
		return  basicSalary +HRAper +DAper + projectAllowance;
	}
	

}
