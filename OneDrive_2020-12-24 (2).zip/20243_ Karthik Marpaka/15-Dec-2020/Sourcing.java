package dec5_12;

public class Sourcing {
	int empId;
	String empName;
	double basicSalary;
	double HRAper;
	double DAper;
	int enrollmentTarget;
	int enrollmentReached;
	double perkPerEnrollment;
	public Sourcing(int empId, String empName, double basicSalary, double hRAper, double dAper, int enrollmentTarget,
			int enrollmentReached, double perkPerEnrollment) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.basicSalary = basicSalary;
		HRAper = hRAper;
		DAper = dAper;
		this.enrollmentTarget = enrollmentTarget;
		this.enrollmentReached = enrollmentReached;
		this.perkPerEnrollment = perkPerEnrollment;
	}
	@Override
	public String toString() {
		return "Sourcing [empId=" + empId + ", empName=" + empName + ", basicSalary=" + basicSalary + ", HRAper="
				+ HRAper + ", DAper=" + DAper + ", enrollmentTarget=" + enrollmentTarget + ", enrollmentReached="
				+ enrollmentReached + ", perkPerEnrollment=" + perkPerEnrollment + "]";
	}
	double calculateGrossSalary(){
return basicSalary +HRAper +DAper +(((enrollmentReached/enrollmentTarget)*100)*perkPerEnrollment);
}}
