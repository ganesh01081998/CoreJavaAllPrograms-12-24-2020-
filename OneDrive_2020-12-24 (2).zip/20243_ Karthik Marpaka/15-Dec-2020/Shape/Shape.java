package com.ojas.dec15;

abstract public class Shape {
	
	abstract void getArea();
	
	abstract void getPerimeter();
	
}
