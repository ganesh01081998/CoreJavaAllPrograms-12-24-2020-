package com.ojas.dec15;

public class Square extends Shape {
	
	float side;
	double area;
	double perimeter;
	
	public float getSide() {
		return side;
	}

	public void setSide(float side) {
		this.side = side;
	}

	public Square() {
		
	}
	
	public Square(float side) {
		super();
		this.side = side;
	}

	@Override
	void getArea() {
		area = side * side;
		System.out.println("Square Of Area : " + area);
	}

	@Override
	void getPerimeter() {
		perimeter = 4 * side;
		System.out.println("Square Of Perimeter : " + perimeter);
		
	}

}
