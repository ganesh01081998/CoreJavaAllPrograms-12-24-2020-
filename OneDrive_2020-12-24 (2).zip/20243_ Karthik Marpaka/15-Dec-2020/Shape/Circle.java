package com.ojas.dec15;

public class Circle extends Shape {
	
	float radius;
	double area;
	double perimeter;

	public float getRadius() {
		return radius;
	}

	public void setRadius(float radius) {
		this.radius = radius;
	}

	public Circle() {
		
	}
	
	public Circle(float radius) {
		super();
		this.radius = radius;
	}

	@Override
	void getArea() {
		area = 3.14 * (radius * radius);
		System.out.println("Area Of The Circle : " + area);
		
	}

	@Override
	void getPerimeter() {
		perimeter = 2 * (3.14 * radius);
		System.out.println("Perimeter Of The Perimeter : " + perimeter);
	}

}
