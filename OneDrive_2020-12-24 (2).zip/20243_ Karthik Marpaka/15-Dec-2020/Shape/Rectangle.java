package com.ojas.dec15;

public class Rectangle extends Shape {
	
	float length;
	float breadth;
	double area;
	double perimeter;
	
	public float getLength() {
		return length;
	}

	public void setLength(float length) {
		this.length = length;
	}

	public float getBreadth() {
		return breadth;
	}

	public void setBreadth(float breadth) {
		this.breadth = breadth;
	}

	public Rectangle() {
		
	}
	
	public Rectangle(float length, float breadth) {
		super();
		this.length = length;
		this.breadth = breadth;
	}

	@Override
	void getArea() {
		area = length * breadth;
		System.out.println("Rectangle Of Area : " + area);
	}

	@Override
	void getPerimeter() {
		perimeter = 2 *  (length + breadth);
		System.out.println("Rectangle Of Perimeter : " + perimeter);
	}

}
