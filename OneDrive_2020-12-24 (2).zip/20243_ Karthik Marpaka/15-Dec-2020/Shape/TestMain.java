package com.ojas.dec15;

import java.util.Scanner;

public class TestMain {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("The Shapes Are...\n 1. Circle\n 2. Square\n 3. Rectangle");
		System.out.println("Enter Circle Of Radius....");
		Circle c = new Circle(sc.nextFloat());
		c.getArea();
		c.getPerimeter();
		System.out.println("Enter Square Of Side...");
		Square s = new Square(sc.nextFloat());
		s.getArea();
		s.getPerimeter();
		System.out.println("Enter Rectangle Of Length And Breadth...");
		Rectangle r = new Rectangle(sc.nextFloat(),sc.nextFloat());
		r.getArea();
		r.getPerimeter();

	}

}
