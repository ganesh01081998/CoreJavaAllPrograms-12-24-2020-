package dec5_12;

public class Employee {
	int empId;
	String empName;
	double basicSalary;
	double HRAper;
	double DAper;
	public Employee(int empId, String empName, double basicSalary, double hRAper, double dAper) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.basicSalary = basicSalary;
		HRAper = hRAper;
		DAper = dAper;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", basicSalary=" + basicSalary + ", HRAper="
				+ HRAper + ", DAper=" + DAper + "]";
	}
	double calculateGrossSalary(){
		return  basicSalary + HRAper +DAper;
		
	}
	

}