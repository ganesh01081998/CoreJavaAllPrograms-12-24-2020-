package dec5_12;

import java.util.Scanner;

public class TaxUtil {
	double tax;
	double calculateTaxEmployee(Scanner sc, double grossSalary){
		if (grossSalary > 30000)
		{
			tax = 0.2*grossSalary;
			
		}
		else{
			tax=0.05*grossSalary;
			
		}
		return tax;
		
	}
	double calculateTaxManager(Scanner sc, double grossSalary ){
		if (grossSalary > 30000)
		{
			tax = 0.2*grossSalary;
			
		}
		else{
			tax=0.05*grossSalary;
			
		}
		return tax;
		
		
	}
	double calculateTaxTrainee(Scanner sc, double grossSalary){
		if (grossSalary > 30000)
		{
			tax = 0.2*grossSalary;
			
		}
		else{
			tax=0.05*grossSalary;
			
		}
		return tax;
		
		
	}
	double calculateTaxSorcing(Scanner sc, double grossSalary){
		if (grossSalary > 30000)
		{
			tax = 0.2*grossSalary;
			
		}
		else{
			tax=0.05*grossSalary;
			
		}
		return tax;
		
		
	}
}
