package dec5_12;

public class Trainer {
	int empId;
	String empName;
	double basicSalary;
	double HRAper;
	double DAper;
	int batchCount;
	double perkperBatch;
	
		


	public Trainer(int empId, String empName, double basicSalary, double hRAper, double dAper, int batchCount,
			double perkperBatch) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.basicSalary = basicSalary;
		HRAper = hRAper;
		DAper = dAper;
		this.batchCount = batchCount;
		this.perkperBatch = perkperBatch;
	}
	@Override
	public String toString() {
		return "Trainer [empId=" + empId + ", empName=" + empName + ", basicSalary=" + basicSalary + ", HRAper="
				+ HRAper + ", DAper=" + DAper + ", batchCount=" + batchCount + ", perkperBatch=" + perkperBatch + "]";
	}
	double calculateGrossSalary(){
		return basicSalary +HRAper +DAper +(batchCount * perkperBatch);
	}
	
	
	}
	
