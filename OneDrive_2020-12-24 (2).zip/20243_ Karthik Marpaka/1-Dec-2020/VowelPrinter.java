package Pract18;

import java.util.Scanner;

public class VowelPrinter {

 

    static String findVowels(String name) {
        
        String vowels = "";
        if(name.length() == 0) {
            vowels = null;
        }
        else {
            for (int i = 0; i <name.length(); i++) {
                char ch = name.charAt(i);
                if(ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u'||ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='U' ) {
                    vowels += ch ;
                }
            }
        }
        return vowels;
    }

 

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Any String...");
        String name = sc.nextLine();
        name = name.replaceAll("[^A-Za-z0-9]", "");
        System.out.println(findVowels(name));
    }

 

}

