package Pract18;

import java.util.Scanner;

public class StringManupluator {
	public class StringManipulator {
String removeVowels(String name) {
	        String result = name.toLowerCase();
	        String vowels = "";
	        if(result.length() == 0) {
	            vowels = null;
	        }
	        else {
	            for (int i = 0; i < result.length(); i++) {
	                char ch = result.charAt(i);
	                if(ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' ) {
	                    
	                }
	                else {
	                vowels += ch ;
	                }
	            }
	        }
	        return vowels;
	    }
public void main(String[] args) {
	        Scanner sc = new Scanner(System.in);
	        System.out.println("Enter Any String...");
	        String name = sc.nextLine();
	        name = name.replaceAll("[^A-Za-z0-9]", "");
	        System.out.println(removeVowels(name));
	    }
	}
	

}
