package dec5_12;

import java.util.Scanner;

public class SumOfDigitsInString {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter any string");	
		String str = sc.nextLine();
		System.out.println(findDigits(str));
	}

	static int findDigits(String str) {
		int num=0;
		for(int i=0;i<str.length();i++){
			char ch = str.charAt(i);
			boolean b = Character.isDigit(ch);
			if(b) {
				num += Character.getNumericValue(ch);
			}
		}
		return num;
	}



}


