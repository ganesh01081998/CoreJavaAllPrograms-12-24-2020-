package dec5_12;

import java.util.Scanner;

public class LuckySum {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter any three numbers");
		int firstNum = sc.nextInt();
		int secoundNum=sc.nextInt();
		int thirdNum=sc.nextInt();
		LuckySum(firstNum,secoundNum,thirdNum);

	}
  static void LuckySum(int firstNum, int secoundNum, int thirdNum) {
		int sum=0;
		
		if(firstNum != 13 && secoundNum != 13 && thirdNum!= 13){
			sum = firstNum + secoundNum + thirdNum;
		}
		else if(firstNum == 13) {
			sum = sum;
		}
		else if(secoundNum == 13) {
			sum = firstNum;
		}
		else if(thirdNum == 13) {
			sum = firstNum + secoundNum;
		}
		System.out.println(sum);
	}
			
		
		
	}


