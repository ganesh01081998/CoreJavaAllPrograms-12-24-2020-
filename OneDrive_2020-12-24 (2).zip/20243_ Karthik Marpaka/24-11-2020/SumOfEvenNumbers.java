package com.ojas.programs;

import java.util.Scanner;

public class SumOfEvenNumbers {
	
	 static int getSumOfNumbers(int[] arr) {
		int sum = 0;
		for (int i = 0; i < arr.length; i++) {
			if(arr[i] == 0) {
				sum = -2;
			}
			else if(arr[i] < 0) {
				sum = -1;
			}
			else if(arr[i] % 2 == 0) {
				sum += arr[i];
			}
		}
		return sum;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Array Size...");
		int size = sc.nextInt();
		int[] arr = new int[size];
		System.out.println("Enter Array Elements...");
		for (int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		System.out.println(getSumOfNumbers(arr));
	}
}
