package com.ojas.programs;

import java.util.Scanner;

public class PerfectNumber {
	
	static int sumOfProperDivisors(int num) {
		int result = 0;
		for (int i = 1; i < num; i++) {
			if(num % i == 0) {
				System.out.print(i + " ,");
				result += i;	
			}
		}
		if(result == num) {
			System.out.println(result + " is Perfect Number...");
		}
		else if(result < num ) {
			System.out.println(result + " is Deficent Number...");
		}
		else if(result > num) {
			System.out.println(result + " is Abunant Number...");
		}	
		return result;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any Number...");
		int num = sc.nextInt();
		System.out.println(sumOfProperDivisors(num));
	}

}
