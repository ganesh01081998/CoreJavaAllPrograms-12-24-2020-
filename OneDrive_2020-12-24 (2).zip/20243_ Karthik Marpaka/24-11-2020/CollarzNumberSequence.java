import java.util.Scanner;

public class CollarzNumberSequence {
	static String result ="";

	 static String isCollarzNumberSequence(int num) {
		 while(num!=1){
			 result =result+num+"";
			 if((num&1)==1){
				 num = (3*num)+1;
				 
			 }
			 else{
				 num=num/2;
				  }
				  }
		 result=result+num;
		 return result;
	 }

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		System.out.println("Enter any number");
		int num=sc.nextInt();
		if (num>0){
			result ="Error";
		}
			else {
				isCollarzNumberSequence(num);	
		}
		System.out.println(result);
		
	}
	}
	
