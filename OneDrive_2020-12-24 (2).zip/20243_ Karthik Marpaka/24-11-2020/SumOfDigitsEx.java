package Pract18;

import java.util.Scanner;

public class SumOfDigitsEx {
	static int sumOfDigits( int num) {
		int rem,sum =0;
		while (num>0){
			rem =num%10;
			num=num/10;
			sum =+rem;
		}
		return sum;
	}
	String result = "";

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		System.out.println("Enter a Value");
		int num = sc.nextInt();
		System.out.println("sum of digits :"+sumOfDigits(num));
		
		

	}

}
