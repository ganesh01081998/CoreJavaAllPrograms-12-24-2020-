package practise;


import java.util.Scanner;
public class MonthsAndDate {
   static void getDays(String mon[], int date[],String month) {
       String result = "";
       for(int i =0; i < mon.length;i++) {
           if(month.equals(mon[i])){
               result +=date[i] + "";
           }
       }
       System.out.println(result);
   }
 public static void main(String[] args) {
   Scanner sc = new Scanner(System.in);
   System.out.println("enter the month");
   String month =sc.next();
   String mon[] = {"jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec"};
   int date[] = {31,28,31,30,31,30,31,30,31,31,30,30,31};
   getDays(mon, date,month);
   
   }



}


