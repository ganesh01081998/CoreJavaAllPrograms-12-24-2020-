package com.ojas.programs;

import java.util.Scanner;

public class FindMaxElementArray {
	
	static int result;
	
	static int getFindMax(int[] arr) {
		if(arr.length > 0) {
			result = 0;
		}
		int count = 0, temp = 0; 
		for (int i = 0; i < arr.length; i++) {
			if(arr[i] < 0) {
				count++;
			}
			if(temp < arr[i]) {
				temp = arr[i];
			}
		}
		if(count >= 3) {
			result = temp ;
		}
		else {
			result = -1;
		}
		return result;
	}
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the size of array");
		int arr[] = new int[scan.nextInt()];
		System.out.println("Enter The Array Elements");
		for (int i = 0; i < arr.length; i++) {
			arr[i] = scan.nextInt();
		}
		getFindMax(arr);
		System.out.println(result);
	}
}
