package com.ojas.programs;

import java.util.Scanner;

public class QuadraticSequence {

	static int isQuadraticSequence(int num) {
		int sum = 1;
		for (int i = 2; i <= num; i++) {
			sum += i;
		}
		return sum;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any Number..");
		int num = sc.nextInt();
		System.out.println(isQuadraticSequence(num));
	}

}
