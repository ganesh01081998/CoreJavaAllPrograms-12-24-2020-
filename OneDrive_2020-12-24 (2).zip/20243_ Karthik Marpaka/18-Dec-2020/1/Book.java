package dec5_12;

abstract public class Book {
	String title;
	abstract void setTitle(String title);
	public String getTitle() {
		return title;
	}
	
	

}
