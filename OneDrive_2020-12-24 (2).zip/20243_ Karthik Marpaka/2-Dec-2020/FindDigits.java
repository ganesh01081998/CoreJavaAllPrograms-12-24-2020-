package Pract18;

import java.util.Scanner;

public class FindDigits {
	static int findDigits(String str) {
		int num=0;
		for(int i=0;i<str.length();i++){
			char ch=str.charAt(i);
			  boolean b = Character.isDigit(ch);
			  if(b) {
	                num += Character.getNumericValue(ch);
	            }
	        }
	        return num;
	    
		}
	

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter any value");
		String str =sc.nextLine();
		System.out.println(findDigits(str));
		

	}

}
