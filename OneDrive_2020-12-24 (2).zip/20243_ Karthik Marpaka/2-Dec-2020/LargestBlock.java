package com.ojas.dec02;

import java.util.Scanner;

public class LargestBlock {

	static void maxBlock(String str) {
		int count,temp = 0;
		for (int i = 0; i < str.length(); i++) {
			char ch = str.charAt(i);
			count = 0;
			for (int j = 0; j < str.length(); j++) {
				if(ch == str.charAt(j)) {
					count++;
				}
			}
			if(temp < count) {
				temp = count;
			}
		}
		System.out.println(temp);
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any String...");
		String str = sc.nextLine();
		maxBlock(str);
	}
}
