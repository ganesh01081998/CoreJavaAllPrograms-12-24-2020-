package com.ojas.sortings;

import java.util.Scanner;

public class BinarySearch {

	static int isbinarySearch(int[] arr, int find, int low, int high) {
		
		while (low <= high) {
			int mid = low + (high - low) / 2;
			if (arr[mid] == find) {
				return mid;
			}
			if (arr[mid] < find) {
				low = mid + 1;
			}
			else {
				high = mid - 1; 
			}
		}
		return -1;
	}

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Array Size...");
		int size = sc.nextInt();
		int[] arr = new int[size]; 
		System.out.println("Enter Array Elements...");
		for (int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		int len = arr.length;
		System.out.println("Enter Search Element...");
		int find = sc.nextInt();
		int result = isbinarySearch(arr, find, 0, len - 1);
		if (result == -1) {
			System.out.println(find + "Element Not found");
		}
		else {
			System.out.println(find + " Element found at " + result + " index ");
		}
	}

}
