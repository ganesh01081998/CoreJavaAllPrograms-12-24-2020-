package training;

import java.util.Scanner;

public class mcSumOfNaturalNumbers {
	static String result = "";
	public static void main(String[] args) {
		System.out.println("Enter number in range order");
		Scanner sc = new Scanner(System.in);
		is_SumOfNaturalNumbers(sc.nextInt(),sc.nextInt());
		sc.close();
		System.out.println(result);
	}
	static void is_SumOfNaturalNumbers(int starting,int ending){
		if(starting>0){
			int sum = 0;
			for (int count = starting; count <= ending; count++) {
				sum = sum + count ;			
			}
			result = result + sum;
			
		}
		else {
			result = "Starting number must be greater then zero";
		}
		}
		
		

	}


