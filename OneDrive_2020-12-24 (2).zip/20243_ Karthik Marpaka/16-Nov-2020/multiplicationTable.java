package training;

import java.util.Scanner;

public class multiplicationTable {static int num;
public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter any value");
		 num=sc.nextInt();
		
		
		int i =1;
		while( i<=10 )
		{
			
			
				System.out.println(num + " * " + i + " = " + (num * i));
				i++;
			
			
		
	}
	}

}
