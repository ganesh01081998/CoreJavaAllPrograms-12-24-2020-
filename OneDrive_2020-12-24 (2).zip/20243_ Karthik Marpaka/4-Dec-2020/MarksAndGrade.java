package dec5_12;

import java.util.Scanner;

public class MarksAndGrade {
	public static class Student {

		public  int studentId;

		public  String studentName;

		private int marks;

		private  char grade;

		Student(int studentId,String studentName,int marks) {

			this.studentId = studentId;
			this.studentName = studentName;
			this.marks = marks;
			calculateGrade(marks);

		}

		private void calculateGrade(int marks) {

			if(marks > 90) {
				this.grade = 'A';
			}
			else if(marks > 80 && marks <= 90 ) {
				this.grade = 'B';
			}
			else if(marks > 70 && marks <= 80 ) {
				this.grade = 'C';
			}
			else if(marks >= 60 && marks <= 70 ) {
				this.grade = 'D';
			}
			else  {
				this.grade = 'E';
			}
		}

		public String dispDetails() {
			String result = "";
			result = "Student [ name : " + studentName + " Student ID : " + studentId +" Student Marks : " + marks + " Student Grade : " + grade +" ]";
			return result;
		}

		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter the StudentId and StudentName and Student marks");
			Student s = new Student(sc.nextInt(),sc.next(),sc.nextInt());
			System.out.println(s.dispDetails());
		}

	}


}
