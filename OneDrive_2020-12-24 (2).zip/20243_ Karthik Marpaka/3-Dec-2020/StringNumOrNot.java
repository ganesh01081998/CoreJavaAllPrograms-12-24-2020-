package dec5_12;

import java.util.Scanner;

public class StringNumOrNot {
	static void isNumOrNot(String num){
		int count=0;
		for(int i=0;i<num.length();i++){
			char ch =num.charAt(i);
			boolean b =Character.isDigit(ch);
			if(b){
				count++;
			}
			if (count ==num.length())
			{
				System.out.println("the give string is intiger");
			}
			else
			{
				System.out.println("it is string");
			}
		}
		
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number");
		String num=sc.next();
		isNumOrNot(num);
		

	}

}
