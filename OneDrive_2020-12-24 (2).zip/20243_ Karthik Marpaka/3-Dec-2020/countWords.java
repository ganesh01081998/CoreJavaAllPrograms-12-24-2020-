package dec5_12;

import java.util.Scanner;

public class countWords {
	
		
		static void getCountWords(String str) {
			int count = 0;
			String[] str1 = str.split(" ");
			for (int i = 0; i < str1.length; i++) {
				if(str1[i] == " ") {
					
				}
				else {
					count++;
				}
			}
			System.out.println(count);
		}

		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter Any Sentence...");
			String str  = sc.nextLine();
	       getCountWords(str);
		}

	}


