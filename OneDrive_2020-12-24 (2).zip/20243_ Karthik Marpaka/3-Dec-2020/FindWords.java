import java.util.Scanner;

public class FindWords {
	static void getFindWord(String str,String str1){
		String [] str3 =str.split("");
		for(int i=0;i<str3.length;i++){
			System.out.println(str1+"is found");
		}
	}

public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter any sentence");
	String str =sc.nextLine().toLowerCase();
	getFindWord(str,str);
	
	
}

	
}

