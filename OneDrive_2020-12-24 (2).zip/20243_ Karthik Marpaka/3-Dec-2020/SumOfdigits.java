package dec5_12;

import java.util.Scanner;

public class SumOfDigits {
	private static void sumOfDigits(int num) {
		int rem,sum=0;
		while(num>0){
		rem=num%10;
		sum=sum+rem;
		num=num/10;
	}
		System.out.println("sum of digits:"+sum);
	
}
		

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Ener any number");
		int num=sc.nextInt();
		sumOfDigits(num);
		

	}	
	}


