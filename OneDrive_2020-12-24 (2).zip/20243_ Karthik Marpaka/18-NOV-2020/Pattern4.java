import java.util.Scanner;

public class Pattern4 {
	static String result = "";
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter number of rows and coloum");
		int num1 = scan.nextInt();
		int num2 = scan.nextInt();
		is_Patten(num1, num2);
		System.out.println(result);
	}static String is_Patten(int num1, int num2) {
		for (int row = 1; row <= num1; row++) {
			for (int col =1; col <= row; col++) {
				result += row + " ";
			}
			result += "\n";
		}
		return result;
	}
}

