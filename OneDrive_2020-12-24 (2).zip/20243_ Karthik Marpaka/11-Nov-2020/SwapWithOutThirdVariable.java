package com.ojas.sample;

import java.util.Scanner;

public class SwapWithOutThirdVariable {
	
	static void isSwap(int firstNum,int secNum) {
		
		System.out.println("Before Swapping firstNum : " + firstNum + " secNum : " + secNum);
		firstNum = firstNum + secNum;
		secNum = firstNum - secNum;
		firstNum = firstNum - secNum;
		System.out.println("After Swapping firstNum : " + firstNum + " secNum : " + secNum);
	}
		
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter firstNum value :  ");
		int firstNum = sc.nextInt();
		System.out.println("Enter secNum value :  ");
		int secNum = sc.nextInt();
		isSwap(firstNum,secNum);
		
	}

}
