package com.ojas.sample;

public class AdditionFourOfOneVariable {

	static void isAdditionOneVariable(String[] args) {

		if(args.length != 4) {
			System.out.println("Invalid Arguments...");
			System.out.println("Enter 4 Values ? ");
			return;
		}
		int num = Integer.parseInt(args[0]);
			  num += Integer.parseInt(args[1]);
			  num += Integer.parseInt(args[2]);
			  num += Integer.parseInt(args[3]);

		System.out.println("Sum = " + num);

	}

	public static void main(String[] args) {

		isAdditionOneVariable(args);
	}

}
