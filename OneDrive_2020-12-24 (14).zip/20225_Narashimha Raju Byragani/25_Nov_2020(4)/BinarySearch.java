package nov_25_2020;

public class BinarySearchTree {
	static int binarySearch(int array[], int lower, int high, int search) { 
		if (high >= lower) { 
			int middel = (high + lower) / 2; 
			if (array[middel] == search) {
				return middel; 
			}
			else if (array[middel] > search) {
				return binarySearch(array, lower, middel-1, search); 
			}
			else if(array[middel] < search) {
				return binarySearch(array, middel+1, high, search); 
			}
		} 
		return -1; 
	} 

	public static void main(String args[]) { 
		int array[] = { 2, 3, 4, 10, 40 };  
		int searchElement = 10; 
		int result = binarySearch(array, 0, array.length-1, searchElement); 
		if (result == -1) 
			System.out.println("Element not present"); 
		else
			System.out.println("Element found at index " + result); 
	} 
	
}
