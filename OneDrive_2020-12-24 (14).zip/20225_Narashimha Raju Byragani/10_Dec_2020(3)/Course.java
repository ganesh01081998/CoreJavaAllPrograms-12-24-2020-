package dec_10_2020;

import java.util.Scanner;

public class Course {
		Student std ;
		Address address ;
		void dispmenu () {
			String menu = "1.java \n 2.python \n 3.salesPoint \n 4.Oracle \n 5.c \n 6.AWS" ;
			System.out.println(menu);
		}
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in) ;
			Course crs = new Course();
			Student std = new Student ("Narasimha" , 20225);
			System.out.println(std);
			Address address = new Address("2/90" , "Gurappagari palle" ,"KADAPA");
			System.out.println(address);
		while(true) {
			crs.dispmenu();
			System.out.println("enter a any choice");
			int choice = scan.nextInt();
			switch(choice) {
			case 1 :
				System.out.println("JAVA \n Fee IS 10000");
				break;
			case 2 :
				System.out.println("python \n Fee IS 5000");
				break;
			case 3 :
				System.out.println("salesPoint \n fee is 10000");
				break;
			case 4 :
				System.out.println("oracle \n fee is 11000");
				break;
			case 5 :
				System.out.println("c language \n fee is 5000");
				break;
			case 6 :
				System.out.println("AWS language \n fee is 20000");
				break;
			default :
				System.out.println("Invalid Choice");
				System.exit(0);
			}
			
		}
	}

}
