package dec_10_2020;

public class Address {

	private String doorNo ;
	private String villageName;
	private String District ;
	
	public Address(String doorNo , String villageName , String District) {
		this.doorNo = doorNo;
		this.villageName = villageName ;
		this.District = District ;
	}
	
	@Override
	public String toString() {
		return "Address [doorNo=" + doorNo + ", villageName=" + villageName + ", District=" + District + "]";
	}

	public String getDoorNo() {
		return doorNo;
	}
	public void setDoorNo(String doorNo) {
		this.doorNo = doorNo;
	}
	public String getVillageName() {
		return villageName;
	}
	public void setVillageName(String villageName) {
		this.villageName = villageName;
	}
	public String getDistrict() {
		return District;
	}
	public void setDistrict(String district) {
		District = district;
	}

}
