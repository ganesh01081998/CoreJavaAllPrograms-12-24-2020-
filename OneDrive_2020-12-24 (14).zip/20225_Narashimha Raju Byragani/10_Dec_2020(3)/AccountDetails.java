package dec_10_2020;

import java.util.Scanner;

public class AccountDetails extends Custumer {
	 int accountNo ;
	 double salary ;
	 float intrestRate ;

 public AccountDetails (Custumer  firstName , Custumer secondName , int accountNo , double salary , float intrestRate) {
	
	 this.accountNo = accountNo;
	 this.salary = salary;
	 this.intrestRate = intrestRate;
 }


@Override
public String toString() {
	return "AccountDetails [accountNo=" + accountNo + ", salary=" + salary + ", intrestRate=" + intrestRate
			+ ", getFirstName()=" + getFirstName() + ", getSecondName()=" + getSecondName() + ", getClass()="
			+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
}


	public static void main (String args[]) {
		Scanner scan = new Scanner (System.in);
		Custumer cust = new Custumer ("Narasimha", "raju");
		AccountDetails accd = new AccountDetails( cust , cust ,123456, 10000, 2);
		
	
	System.out.println("Please Enter Your Account number");
	int acno = scan.nextInt();
	if (accd.accountNo == acno) {
		System.out.println("Please Proceed for your Operations");
		System.out.println();
	} else {
		System.err.println("Please check your  accno once again");
	}
	if (accd.accountNo == acno) {
	System.out.println(cust);
	System.out.println(accd);
	System.out.println("The Available Balance In your Account is :: "+accd.salary);
	System.out.println();
	System.out.println("enter the amount to deposite");
	
	
	float amountToDeposite = scan.nextFloat();
	accd.deposite1(accd.salary, amountToDeposite);
	System.out.println("enter the amount to withDraw");
	float amountforWithdraw = scan.nextFloat();
	accd.withdraw(accd.salary, amountforWithdraw);
	
	}
}


	private void withdraw(double salary2, float amountforWithdraw) {
		// TODO Auto-generated method stub
		salary = this.salary - amountforWithdraw;
		System.out.println(salary);
	}


	private void deposite1(double salary2, float amountToDeposite) {
		// TODO Auto-generated method stub
		salary = this.salary + amountToDeposite;
		System.out.println(salary);
	}
}
