package dec_10_2020;

public class Student {
	private String name ;
	private int Id ;
	
	public Student(String name , int Id) {
		this.name = name ;
		this.Id = Id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	@Override
	public String toString() {
		return "Student [name=" + name + ", Id=" + Id + "]";
	}
	
}
