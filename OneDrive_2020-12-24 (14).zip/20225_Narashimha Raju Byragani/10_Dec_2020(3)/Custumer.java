package dec_10_2020;

class Custumer {
	private String firstName ; 
	private  String SecondName ;
	
	public Custumer(String firstName, String secondName) {
		this.firstName = firstName;
		this.SecondName = secondName;
	}
	@Override
	public String toString() {
		return "Custumer [firstName=" + firstName + ", SecondName=" + SecondName + "]";
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getSecondName() {
		return SecondName;
	}
	public void setSecondName(String secondName) {
		SecondName = secondName;
	}
	public Custumer() {
		
	}
}
