package dec_1_2020;

import java.util.Scanner;

public class DateFormate {
	
	
		public static void main(String[] args) {
			Scanner scan = new Scanner(System.in);
			System.out.println("Enter the Date");
			String str = scan.nextLine().toLowerCase();
	        str = str.replaceAll(",", "");
	        str = str.replaceAll(" ", "");
	        scan.close();
			if(str.length() == 0) {
				System.out.println("NULL");
			}
			else {
				System.out.println(Checker(str));
			}
		}
		static String Checker(String str) {
			String date ="", month ="", year ="";
			String [] months1 = {"jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec"};
			String [] months2 = {"january","february","march","april","may","june","july","august","september","october","november","december"};
			for (int i = 0; i < str.length(); i++) {
				if(i < 2) {
					date += str.charAt(i);
				}
				else if((i > 1) && (i < str.length()-4) ) {
					month += str.charAt(i);
				}
				else if(i >= str.length()-4) {
					year += str.charAt(i);
				}
			}
			if(month.length() > 4) {
				for (int i = 0; i < months2.length; i++) {
					if(month.equals(months2[i])) {
						month = "-" + (i+1) + "-";
						break;
					}
				}
			}
			else {
				for (int i = 0; i < months1.length; i++) {
					if(month.equals(months1[i])) {
						month = "-" + (i+1) + "-";
						break;
					}
				}
			}
			str = year + month + date;
			return str;
		}
}

