package dec_1_2020;

import java.util.Scanner;

public class VowelPrinter {

	static String stringManupulator(String str) {
		String result = "";
		
		for(int i = 0 ; i < str.length();i++){
			char ch = str.charAt(i);
			if(ch == 'a' || ch =='e' || ch == 'i' || ch == 'o' || ch == 'u') {
				result += ch;
			}
			
		}
		return result ;
	}
public static void main(String[] args) {
	Scanner scr = new Scanner(System.in);
	System.out.println("enter a String");
	String str = scr.nextLine();
	String str2 = str.toLowerCase();
	String str3 = str2.replaceAll("[^a-zA-Z0-9]","");
	int len =str.length();
	
	if(str.equals("")) {
		System.out.println("null");
	}
	System.out.println(stringManupulator(str3));
}


}
