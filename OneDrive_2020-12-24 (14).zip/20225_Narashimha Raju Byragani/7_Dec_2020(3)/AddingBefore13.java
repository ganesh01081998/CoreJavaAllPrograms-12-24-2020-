package dec_7_2020;

import java.util.Scanner;

public class AddingBefore13 {
	static int luckySum(int number1 , int number2 , int number3) {
		int result = 0;
		if(number3 == 13  && number1 != 13 && number2 != 13) {
			result = number1 + number2;
		}
		else if(number2 == 13  && number1 != 13 && number3 != 13) {
			result = number1 ;
		}
		else if(number1 == 13  && number2 != 13 && number3 != 13) {
			result = 0;
		}
		else if(number1 != 13 && number2 != 13 && number3 != 13) {
			result = number1 + number2 + number3 ;
		}
		else if(number1 == 13 && number2 == 13 && number3 == 13) {
			result = 0 ;
		}
		else {
			result = 0;
		}
		
		return result ;
	}
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("enter three number");
		int number1 = scan.nextInt();
		int number2 = scan.nextInt();
		int number3 = scan.nextInt();
		System.out.println(luckySum(number1, number2, number3));

	}

}
