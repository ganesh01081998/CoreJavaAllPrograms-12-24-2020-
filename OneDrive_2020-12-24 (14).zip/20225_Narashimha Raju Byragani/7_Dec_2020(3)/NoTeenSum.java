package dec_7_2020;

import java.util.Scanner;

public class NoTeenSum {
		static int Fixed(int number) {
			if(number >= 13 && number <= 14 || number >=17 && number <= 19) {
				return 0;
			}
			else {
				return number ;
			}
		}

	
		static int noTeenSum(int number1 , int number2 , int number3) {
			int result = 0;
			result += Fixed(number1);
			result += Fixed(number2);
			result += Fixed(number3);
			
			return result ;
		}
		public static void main(String[] args) {
			Scanner scan = new Scanner(System.in);
			System.out.println("enter three number");
			int number1 = scan.nextInt();
			int number2 = scan.nextInt();
			int number3 = scan.nextInt();
			System.out.println(noTeenSum(number1, number2, number3));

		}

}

