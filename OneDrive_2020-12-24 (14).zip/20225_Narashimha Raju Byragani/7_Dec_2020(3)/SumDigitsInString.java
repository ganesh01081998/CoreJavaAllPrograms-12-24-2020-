package dec_7_2020;

import java.util.Scanner;

public class SumDigitsInString {
	static int sumDigits(String String1) {
		int result = 0;
		for(int index = 1 ; index < String1.length() ; index++ ) {
			char ch = String1.charAt(index);
			if(Character.isLetter(ch)) {
				
			}
			else {
				String str =""+ ch;
				int number = Integer.parseInt(str);
				result += number ;
			}
		}
		return result ;
	}

	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("enter a String");
		String String1 = scan.next(); 
		System.out.println(sumDigits(String1));
	}

}
