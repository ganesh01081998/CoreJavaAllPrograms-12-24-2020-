package dec_2_2020;

import java.util.Scanner;

public class MaxBlock {
	static int maxBlock(String str) {
		int result = 0, count = 1,temp = 0;
		char ch[] = str.toCharArray();
		for (int i = 0; i < ch.length-1; i++) {
			if (ch[i] == ch[i + 1]) {
				count++;
				
			}
			else {
				if(temp < count){
				temp = count ;
				
				count = 1;
				}
				
			}
			
			
		}
		if(temp == 0 || temp <count) {
			result += count;
		}
		else {
			result +=temp;
		}
		
		return result;
	}

	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		System.out.println("enter a number=");
		String str = scr.next();
		System.out.println(maxBlock(str));

	}

}
