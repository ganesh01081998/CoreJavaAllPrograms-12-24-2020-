package dec_2_2020;



import java.util.Scanner;

public class WeavedString {
	static String getWeavedString(String str1 , String str2) {
		String result = "";
		if(str1.length() > str2.length()){
			System.out.println(str2 + str1 + str2);
		}
		else if(str1.length() < str2.length()){
			System.out.println(str1 + str2 + str1);
		}
		else {
			int i,j=0;
			char ch1[] = new char[str1.length()];
			char ch2[] = new char[str2.length()];
			for( i = 0 ; i < str1.length() ; i++){
				ch1 [i] = str1.charAt(i);
				ch2 [i] = str2.charAt(i);
			}
		
			for( i = 0 ; i < str1.length() ; i++) {
					int count = 0;
				for( j = 0 ; j <= i; j++) {
						if(ch1[i] == ch2[j])  {
							count ++;
						}
				}
				if(count == 1){
					
					System.out.println( ch1[i]+""+ ch2[i]) ;
				}
			
			}
		}
			
		
		return result ;
	}
	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		System.out.println("enter Two Strings=");
		String str1 = scr.next();
		String str2 = scr.next();
		System.out.println(getWeavedString(str1, str2));
	}

}
