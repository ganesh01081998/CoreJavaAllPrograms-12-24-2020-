package dec_2_2020;

import java.util.Scanner;

public class CountYZ {
		static int countYZ(String str) {
			int result = 0;
			
			int count = 0;
//			String str1[] = new String[str1.length];
			 String str1[] = str.split(" ");
			 //System.out.println(str1);
			for(int i = 0 ; i < str1.length ; i++) {
					String str2= str1[i];
					char ch = str2.charAt(str2.length()-1);
					if(ch == 'y' || ch =='z'){
						count++;
					}
				
				if(count == 1) {
					result += count;
				}
				count = 0 ;
			}
			return result;
		}
	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		System.out.println("enter a String =");
		 	String str = scr.nextLine();
		System.out.println(countYZ(str));
	}

}
