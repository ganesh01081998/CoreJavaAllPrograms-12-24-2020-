package dec_2_2020;

import java.util.Scanner;

public class DiagonalSumMatrix {
	static int diagonalSum(int array[][]){
		int result = 0;
		for(int i = 0 ; i < array.length ; i++) {
			   for(int j = 0 ; j < array.length ; j++) {
				   if(i == j)
				   result += array[i][j] ;
			   }
		   }
		return result ;
	}
	static String DisplayMatrix(int array[][]) {
		String result = "";
		for(int i = 0 ; i < array.length ; i++) {
			   for(int j = 0 ; j < array.length ; j++) {
				   result += array[i][j] + " " ;
			   }
			   result +="\n";
		   }
		return result;
	}
	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		System.out.println("enter a size =");
		   int size = scr.nextInt();
		 int array[][] = new int[size][size];
		 if(array.length == 3) {
			   System.out.println("-1");
		   
		   }
		 else {
			 System.out.println("enter a array elements");
			 for(int i = 0 ; i < array.length ; i++) {
			   for(int j = 0 ; j < array.length ; j++) {
				   array[i][j] = scr.nextInt();
			   }
		    }
		   
		   System.out.println("Matrix =");
		   System.out.println(DisplayMatrix(array));
		   System.out.println("Sum of diagonal elements=");
		   System.out.println(diagonalSum(array));
	
		}
	}

}
