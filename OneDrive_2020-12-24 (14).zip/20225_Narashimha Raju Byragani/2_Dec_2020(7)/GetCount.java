package dec_2_2020;

import java.util.Scanner;

public class GetCount {
		static String getCount(int array[] , int num) {
			String result = "";
			int count = 0,i;
			for( i = 0 ; i < array.length ; i++) {
				if (array[i] == num) {
					count++;
				}
			}
			if (count > 0) {
				result += num +" " + "is repeated"+" " + count + " "+ "times" ;
			}
			else {
				result += "Given number is not exist in array";
			}
			return result ;
		}
	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		
		System.out.println("enter array size");
			int size = scr.nextInt();
		int array [] = new int[size];
		if(array.length == 0) {
				System.out.println("-1");
		}
		else {
		
		System.out.println("enter array elemnets=");
		
		
			for(int i = 0 ; i < array.length; i++) {
				array[i] = scr.nextInt();
			}
			System.out.println("enter a search element=");
			int searchElement = scr.nextInt();
			System.out.println(getCount(array, searchElement));
		}
	}

}
