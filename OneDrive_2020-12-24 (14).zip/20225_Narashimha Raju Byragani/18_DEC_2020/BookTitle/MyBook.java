package dec_18_2020;

public class MyBook extends Book {

	@Override
	void setTitle(String title) {
		super.title = title;
		
	}
	
}
