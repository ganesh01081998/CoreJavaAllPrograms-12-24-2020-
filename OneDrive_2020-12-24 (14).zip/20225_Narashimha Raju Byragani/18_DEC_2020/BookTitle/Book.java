package dec_18_2020;

abstract class Book {
	String title ;
	abstract void setTitle(String title);
	String getTitle() {
		return title;
	}
	
}
