package dec_18_2020;

import java.util.Scanner;

public class MainBook {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in) ;
		Book b =new MyBook();
		System.out.println("enter a title of book" );
			String title = scan.nextLine();
		b.setTitle(title);
		System.out.println("BOOK TITLE = " +  b.getTitle());
	}

}
