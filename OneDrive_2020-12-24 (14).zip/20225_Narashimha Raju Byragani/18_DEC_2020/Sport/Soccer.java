package dec_18_2020;

public class Soccer extends Sports {

	public String getName(String sport) {
		super.sport = sport;
		return sport ;
	}
	 public String getNumberOfTeamNumbers() {
		return  "in Sports " + getName(sport)  + "each team has 11 palyers";
		
	 
	 }
}
