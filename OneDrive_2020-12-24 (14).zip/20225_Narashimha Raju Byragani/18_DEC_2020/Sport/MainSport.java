package dec_18_2020;

import java.util.Scanner;

public class MainSport {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		Sports s = new Soccer();
		String sport = scan.next();
		s.getName(sport);
		System.out.println(s.getNumberOfTeamNumbers());

	}

}
