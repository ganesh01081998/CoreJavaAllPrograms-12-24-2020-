package dec_18_2020;

public class Sports {
	 String sport ;
	public String getName(String sport2){
		return sport;
		
	}
		
	
	public  String getNumberOfTeamNumbers() {
		return "Each team has n players in Sports";
		
	}


	
	

}
