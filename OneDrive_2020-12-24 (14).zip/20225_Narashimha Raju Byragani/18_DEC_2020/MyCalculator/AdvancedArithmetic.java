package dec_18_2020;

public interface AdvancedArithmetic {
	public abstract int divisorSum(int n);
}
