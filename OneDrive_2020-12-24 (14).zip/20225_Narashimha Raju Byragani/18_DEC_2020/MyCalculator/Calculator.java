package dec_18_2020;

import java.util.Scanner;

public class Calculator {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		MyCalculator obj = new MyCalculator();
		System.out.println("Enter the number");
		System.out.println(obj.divisorSum(scan.nextInt()));
	}
}