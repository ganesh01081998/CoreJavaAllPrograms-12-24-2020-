package javapphanimamclass;

import java.util.Scanner;

public class NArmstrong {
		static void nArmstrong (int num){
			int temp = num ;
			String result = "";
				result = "" + num ;
					
				int rem = 0  ,total = 1,sum = 0;
				int len = result.length();
				while(num > 0){
					rem = num % 10 ;
					for( int i = 1 ; i <= len ; i++) {
						
						total = total * rem ;
						
					}
					sum =sum + total;
					num = num / 10 ;
					total = 1;
				}
				if(sum == temp) {
					System.out.println("given number is armstrong");
				}
				else {
					System.out.println("given number is Not ArmStrong");
				}
				
				
		}
	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
			nArmstrong(scr.nextInt());
		
	}

}
