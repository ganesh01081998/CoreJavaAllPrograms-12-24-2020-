package javapphanimamclass;

public class DifferenceOf21AndN {
		static int  differenceOf21AndN(int num){
			int result = 0;
			if(num <= 21 )
			{
				result = 21 - num ;
				return result ;
			}
			else {
				result = (21 - num) * -2 ;
				return result ;
			}
		
		}
	public static void main(String[] args) {
		System.out.println(differenceOf21AndN(-21));

	}

}
