package javapphanimamclass;
import java.util.Scanner;
public class RussianMultiplication2 {
	static String russianMultiplication(int num1,int num2) {
        String result = "" + num1 + ":" + num2 + "\n" ;
        int sum = 0;
        if(num1 %2 != 0) {
            sum += num2 ;
        }
        while(num1 > 1) {
             num1 = num1 / 2;
             num2 = num2 * 2;
             result =result +"" + num1 + ":" + num2 + "\n" ;
             if(num1 % 2 != 0) {
            	 sum += num2 ;	
             }
            
             
        }
        result = result + "product of two numbers = " + sum ;
		return result;
        
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Product Of Two Values : ");
        int num1 = sc.nextInt();
        int num2 = sc.nextInt();
       System.out.println( russianMultiplication(num1,num2));
    }
}