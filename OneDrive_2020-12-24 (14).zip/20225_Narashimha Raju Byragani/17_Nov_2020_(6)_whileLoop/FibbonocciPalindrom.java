package javapphanimamclass;

public class FibbonocciPalindrom {
		
	public static void main(String args[]) {
		int n1=0,n2=1,n3=0,n=10;
		//System.out.println(n1+ "\n"+n2);
		for (int i=2;i<=n;i++) {
			n3=n1+n2;
			n1=n2;
			n2=n3;
			//System.out.println(n3);
		

			int  temp=n3;
			int rem=0,rev=0;
			while(n3 > 0) {

				rem=n3%10;
				rev=(rev*10)+rem;
				n3=n3/10;
		}
		if(temp==rev) {
			System.out.println(temp+"is a palindrome");

		}
		else {
			System.out.println(temp+"is not a polyndrome"); 
		}
		}
	

	}

}


