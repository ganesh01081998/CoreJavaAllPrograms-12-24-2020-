package javapphanimamclass;

import java.util.Scanner;
public class Twin_Prime {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the Range to get Twin Prime : ");
        int intial = scanner.nextInt(),finalRange = scanner.nextInt(),flag = 0,primeCount =0;
        int [] prime =new int [finalRange];
        for(int i = intial;i<=finalRange;i++) {
            for(int j = 1;j <= finalRange;j++) {
                if(i % j == 0) {
                    flag++;
                }
            }
            if(flag == 2) {
                prime[primeCount]=i;
                primeCount++;
            }
            flag=0;
        }

        System.out.println("Twin Primes");
        for(int a = 0;a < finalRange-1 ;a++) {
            if(((prime[a + 1]) - prime[a]) == 2) {
                System.out.println("(" + prime[a] + "," + (prime[a + 1]) +")" );
            }
        }
    }

 

    }