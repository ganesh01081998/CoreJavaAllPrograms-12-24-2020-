package javapphanimamclass;

import java.util.Scanner;

public class EvenNumbersInArray {
		 String result = "";
		static String givenArray(int arr[]){
			System.out.println("array elements= ");
			 String result = "";
			for(int i =0 ; i < arr.length ; i++){
				result += arr[i] + "\n";
			}
			return result ; 
		}
		static String Size(int size){
			String result = "";
			if(size != 10 ){
				result = "null";
			}
		return result;	
		}
		static String isEven(int arr[]) {
			System.out.println("even number in array=");
			String result = "";
			int count = 0;
			int arr2[] = new int[10];
			// arr2 = arr;
			for(int i = 0 ; i < arr.length ; i++ ) {
				if(arr[i] % 2 == 0 ) {
					count ++;
					arr2[i] = arr[i];
					result += arr[i] + "\n";
				}
			}
			if(count == 0 ) {
				result += "EMPTY ARRAY";
			}
			
				
				 
		            
				
			
		return result;
		}
	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		System.out.println("enter  a size");
		int size  = scr.nextInt();
		System.out.println( Size(size));
		System.out.println("enter a array elements");
		
		int[] arr = new int[size];
		for(int i = 0 ; i < arr.length ; i++) {
			arr[i] = scr.nextInt();
		}
		System.out.println(givenArray(arr));
		System.out.println(isEven(arr));
	}

}
