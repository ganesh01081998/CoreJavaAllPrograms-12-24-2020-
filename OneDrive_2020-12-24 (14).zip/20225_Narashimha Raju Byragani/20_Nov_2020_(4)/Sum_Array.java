package nov_20_2020;

import java.util.Scanner;

public class Sum_Array {
		static String DisplayArrayElements(int arr1[]){
			String result = "";
			for(int i = 0 ; i < arr1.length ; i++){
				result += arr1[i];
			}
			return result ;
		}
		static int SumOfArrayElements(int arr1[]){
			int result = 0;
			for(int i = 0 ; i < arr1.length ; i++){
				result += arr1[i];
			}
			return result ;
		}
	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		int arr1[] = new int[5];
		for(int i = 0 ; i < arr1.length ; i++){
				 arr1[i] =scr.nextInt();
		}
	
		System.out.println(DisplayArrayElements(arr1));
		System.out.println(SumOfArrayElements(arr1));

	}

}
