package javapphanimamclass;

import java.util.Scanner;

public class OddNumberArray {
	static String arrayElements(int arr[],int size){
		String result = "";
		for (int i=0 ; i < size ; i++){
			result += arr[i]+ "\n";
		}
		return result ;
		}
	static String oddelements(int arr[] , int size){
		
		String result ="";
		for (int i = 0 ; i < size ; i++){
			if(arr[i] % 2 != 0) {
				result += arr[i] + "\n";
				
			}
		}
		return result;
	}
	public static void main(String[] args) {
		Scanner scr = new Scanner (System.in);
		try{
		System.out.println("enter a size");
		int size =scr.nextInt();
		int arr[] = new int [size];
		System.out.println("enter a elements:");
		for (int i = 0 ; i < size ; i++){
			arr[i] = scr.nextInt();
			
		}
		System.out.println("Given array elements=");
		System.out.println(arrayElements(arr,size));
		System.out.println("Odd elements in array");
		System.out.println(oddelements(arr,size));
		}
		catch(Exception e){
			System.out.println("input mismatch exception");
		}
	}

}
