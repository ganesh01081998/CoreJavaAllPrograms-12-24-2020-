package nov_30_2020;
import java.util.Arrays;
import java.util.Scanner;

public class RecursiveInsertionSort {
	static void recursiveInsertionSort(int array[],int n) {
		if(n <= 1)
			return;
		recursiveInsertionSort(array, n-1);
			int last = array[n-1] ;
			int j = n-2;
			while(j >= 0 && array[j] > last) {
				array[j+1] = array[j];
				j--;
			}
			array[j+1] = last ;
		
	}
	public static void main(String args[]) {
		Scanner scr = new Scanner (System.in);
		System.out.println("enter array size=");
		int size = scr.nextInt();
		System.out.println("enter array values=");
		int array[] = new int[size];
		for(int i = 0 ; i < size ; i++) {
			array[i] = scr.nextInt();
		}
		recursiveInsertionSort(array,size);
		 System.out.println(Arrays.toString(array));
		
	}
}
