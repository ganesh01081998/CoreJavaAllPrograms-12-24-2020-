package dec_3_2020;

import java.util.Scanner;

public class ReverseWord {
	static String reverseWord(String str) {
		String result = "";
		char[] str1 =str.toCharArray();
		for(int i = str1.length-1 ;  i >= 0 ;i--){
			result += str1[i];
		}
		return result ;
	}
	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		System.out.println("enter a word");
			String word = scr.next();
		System.out.println(reverseWord(word));
	}

}
