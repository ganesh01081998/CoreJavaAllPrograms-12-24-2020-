package dec_3_2020;

import java.util.Scanner;

public class NoOfWordsInASentence {
	static int noOfWordsInASentence(String sentence) {
		int count = 0;
		String[] str = sentence.split(" ");
			count = str.length;
		return count ;
	}
	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		System.out.println("enter a sentence"); 
			String sentence = scr.nextLine();
		System.out.println(noOfWordsInASentence(sentence));
	}

}
