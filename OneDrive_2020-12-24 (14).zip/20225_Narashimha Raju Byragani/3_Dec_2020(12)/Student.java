package dec_3_2020;



import java.util.Calendar;
import java.util.Scanner;

public class Student {
	public int studentId;
	public String studentName;
	private int marks;
	private char grade;
	public String displayDetails() {
		return "Student [name = " + studentName + " ,  studentId = " + studentId + " , marks = " + marks + " , grade = " + grade + "]";				
	}
	
	private void calculateGrade() {		
		
		if(marks > 90) {
			grade = 'A';
			System.out.println(displayDetails());
		}
		else if(marks < 90 && marks >80 ) {
			grade = 'B';
			System.out.println(displayDetails());
		}
		else if(marks < 80 && marks > 70) {
			grade = 'c';
			System.out.println(displayDetails());
		}
		else if(marks < 70 && marks > 60) {
			grade = 'd';
			System.out.println(displayDetails());
		}
		else {
			grade = 'E';
			System.out.println(displayDetails());
		}
	}
	
	public Student(int studentId,String studentName,int marks) {
		this.studentId = studentId;
		this.studentName = studentName;
		this.marks = marks;
	}
		
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);	
		System.out.println("Enter the How many records u gave :");
		int size = scanner.nextInt();
		Student student[] = new Student[size];
		for(int record = 0; record < size;record++) {
			System.out.println("Enter the record " + (record + 1) + " Id,name,marks :" );
			student[record] = new Student(scanner.nextInt(), scanner.next(), scanner.nextInt());								
		}
		for (int i = 0; i < student.length; i++) {
			student[i].calculateGrade();
		}		
	}
}