package dec_3_2020;

import java.util.Scanner;

public class OccureenceAInString {
		static int occurenceAInString(String str) {
			int count = 0;
			char ch[] =str.toCharArray();
			for(int i = 0 ; i < str.length() ; i++) {
				
					if('a' == ch[i]) {
						count++;
					}
			}
					
			return count;
		}
	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		System.out.println("enter a String="); 
			String str = scr.next();
				str = str.toLowerCase();
		System.out.println(occurenceAInString(str));	
		
	}

}
