package dec_3_2020;

import java.util.Scanner;

public class FizzArray {
	static  void fizzArray(int num1 , int num2){
		for(int index = num1 ; index <= num2 ; index++) {
			System.out.println(index);
		}
	}
	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		System.out.println("enter two numbers");
			int num1 = scr.nextInt();
			int num2 = scr.nextInt();
		fizzArray(num1, num2);	
	}

}
