package dec_3_2020;

import java.util.Scanner;

public class NumberOrNot {
	 static String numberOrNot(String str) {
		 String result = "";
		 for(int index = 0 ; index < str.length(); index++){
			 if(Character.isLetter(str.charAt(index))){
				 result = "Given String Not a Number";
				 break;
			 }
			 else {
				 result = "Given String is number";
				
			 }
		 }
		 return result ;
	 }
	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		System.out.println("enter a String");
			String str = scr.next();
		System.out.println(numberOrNot(str));	
	}

}
