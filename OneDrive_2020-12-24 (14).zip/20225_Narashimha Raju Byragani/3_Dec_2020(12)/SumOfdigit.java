package dec_3_2020;

public class SumOfdigit {
		static void sumOfDigit(int num){
			int rem=0,sum=0;
			while(num >0) {
				rem = num % 10;
				sum = sum + rem;
				num = num / 10;
			}
			System.out.println("Sum of the digit is=" + sum);
		
		}
	public static void main(String[] args) {
			sumOfDigit(227);
	}

}
