package dec_3_2020;

import java.util.Scanner;

public class WordOccurence {
	static String wordOccurence(String sentence , String str) {
		String result = "";
			String Array[] = sentence.split(" ");
			for(int i =0 ; i < Array.length ; i++) {
				if(str.equalsIgnoreCase(Array[i])) {
					result += "word is found at"+ " " + i + " " +"index";
				}
				
			}
			
		return result ;
	}
	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		System.out.println("enter a sentence");
			String str = scr.nextLine();
		System.out.println("enter a word");
		 	String word = scr.next();
		 System.out.println(wordOccurence(str, word));
	}

}
