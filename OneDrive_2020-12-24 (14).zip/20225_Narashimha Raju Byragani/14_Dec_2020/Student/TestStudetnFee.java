package dec_14_2020;

import java.util.Scanner;

public class TestStudetnFee  {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		//System.out.println("enter student details");
		Student std = new Student(20225 , "narasimha" , 1000);
		System.out.println("choose any option : \n 1.DaySchooler \n 2.Hosteler ");
		 
		switch(scan.nextInt()) {
		case 1 :
			System.out.println("enter any details");
			DaySchooler ds = new DaySchooler(scan.nextDouble() , scan.nextInt() ,scan.next() , scan.nextDouble()) ;
			System.out.println(ds.displayDetails());
			ds.payFee();
			break;
		
		case 2 :
			System.out.println("enter hosteler details");
			Hosteler hs = new Hosteler(scan.nextDouble() , scan.nextInt() ,scan.next() , scan.nextDouble());
			System.out.println(hs.displayDetails());
			hs.payFee();
			break;
		
		default:
			System.out.println("please enter choose valid number");
			break;
		}
		//System.out.println(std);
	}

}
