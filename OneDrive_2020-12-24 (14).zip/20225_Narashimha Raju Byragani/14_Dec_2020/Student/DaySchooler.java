package dec_14_2020;

public class DaySchooler extends Student {
	 double transportFee ;
	 
	 public DaySchooler(double transportFee , int id , String name , double examfee) {
		 super(id , name , examfee);
		 this.transportFee = transportFee ;
	}
	 public DaySchooler() {
		// TODO Auto-generated constructor stub
	}
	 

	public double getTransportFee() {
		return transportFee;
	}

	public void setTransportFee(double transportFee) {
		this.transportFee = transportFee;
	}


	 
	
	 public void payFee1() {
	        double totalFee = 10000;
	          
	         if((examfee + transportFee) == totalFee) {
	             System.out.println("Amount Paid Successfully...");
	         }
	         else if((examfee + transportFee) < totalFee) {
	             System.out.println("Due Amount : " + (totalFee - (examfee + transportFee)) );
	         }
	         else if((examfee + transportFee) > totalFee) {
	             System.out.println("Return Amount : " + ((examfee + transportFee) - totalFee) );
	         }
	        
	    }
	 
		@Override
		public String toString() {
			return "DaySchooler [transportFee=" + transportFee + "]";
		}
	public String displayDetails () {
		return toString();
	}
	void payFee() {
		
	}
	
}
