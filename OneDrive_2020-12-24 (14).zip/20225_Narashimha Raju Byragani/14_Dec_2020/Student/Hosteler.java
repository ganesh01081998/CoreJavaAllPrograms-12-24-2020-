package dec_14_2020;

public class Hosteler extends Student {
	double hostelfee ;
	
	public Hosteler(double hostelfee , int id , String name , double examfee ) {
		super(id , name , examfee);
		this.hostelfee  = hostelfee ;
	}
	public Hosteler() {
		// TODO Auto-generated constructor stub
	}

	public double getHostelfee() {
		return hostelfee;
	}

	public void setHostelfee(double hostelfee) {
		this.hostelfee = hostelfee;
	}
	
	
	 public void payFee() {
	        double totalFee = 15000;
	          
	         if((examfee + hostelfee) == totalFee) {
	             System.out.println("Amount Paid Successfully...");
	         }
	         else if((examfee + hostelfee) < totalFee) {
	             System.out.println("Due Amount : " + (totalFee - (examfee + hostelfee)) );
	         }
	         else if((examfee + hostelfee) > totalFee) {
	             System.out.println("Return Amount : " + ((examfee + hostelfee) - totalFee) );
	         }
	        
	    }
	
	 @Override
		public String toString() {
			return "Hosteler [hostelfee=" + hostelfee + "]";
		}
	 
	public String displayDetails () {
		return toString();
		
	}
	
}
