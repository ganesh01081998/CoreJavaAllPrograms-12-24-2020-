package dec_14_2020;

public class Student {
    int id ;
    String name ;
    double examfee ;
    
    public Student( int id , String name , double examfee) {
    	super();
    	this.id = id;
    	this.name = name ;
    	this.examfee = examfee ;
	}
    public Student() {
		
	}

	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getExamfee() {
		return examfee;
	}

	public void setExamfee(double examfee) {
		this.examfee = examfee;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", examfee=" + examfee + "]";
	}
    
	String displayDetails() {
		return toString();
	}
	
    
}
