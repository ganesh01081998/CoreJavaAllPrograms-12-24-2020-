package dec_14_2020;
enum Material {
	COTTON , LENIN , POLYSTER
}


public class StrichingShirt {
	float collarSize ;
	 float length ; 
	 Material material ;
	
	
	 public StrichingShirt(float collarSize , float length , Material material) {
		 	this.collarSize = collarSize ;
		 	this.length = length;
		 	this.material = material ;
		}
	 public StrichingShirt() {
		 
	 }
	

	


	@Override
	public String toString() {
		return "StrichingShirt [collarSize=" + collarSize + ", length=" + length + ", materrial=" + material + "]";
	}



	public float getCollarSize() {
		return collarSize;
	}



	public void setCollarSize(float collarSize) {
		this.collarSize = collarSize;
	}



	public float getLength() {
		return length;
	}



	public void setLength(float length) {
		this.length = length;
	}



	public Material getMaterial() {
		return material;
	}



	public void setMaterail(Material material) {
		this.material = material;
	}



	public static void main(String[] args) {
		
		 StrichingShirt ss = new StrichingShirt(1.0f, 2.0f , Material.COTTON);
		 StrichingShirt ss1 = new StrichingShirt(1.0f, 2.0f , Material.LENIN);
		 StrichingShirt ss2 = new StrichingShirt(1.0f, 2.0f , Material.POLYSTER);
		 System.out.println(ss + "\n" + ss1 + "\n" + ss2);
	}

}
