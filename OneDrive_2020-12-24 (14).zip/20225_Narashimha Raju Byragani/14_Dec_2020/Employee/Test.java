package dec_14_2020;

import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("enter employee details = ");
		Employee employee = new Employee(scan.next(),scan.nextInt(),scan.nextDouble());
		System.out.println("enter option = \n 1.Manager \n 2.clerk \n enter option");
		switch(scan.nextInt()) {
		case 1 :
			Manager mg = new Manager(ManagerType.HR, "raju", 20225, 1000) ;
			mg.setSalary();
			break;
		case 2 :
			Clerk cl = new Clerk (scan.nextInt(), scan.nextInt() , "raju" , 20225 , 10000 );
			cl.setSalary();
			break;
		default:
			System.out.println("please enter choose valid number");
			break;
		}
		System.out.println(employee);
 	}

}
