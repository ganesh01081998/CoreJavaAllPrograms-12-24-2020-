package dec_14_2020;

import java.util.Scanner;

public class Clerk extends Employee {
	
	int speed ;
	int accuracy ;
	
	public  Clerk(int speed , int accuracy ,String name , int id , double salary) {
		super(name , id , salary);
		this.speed = speed ;
		this.accuracy = accuracy;
	}
	
	
	@Override
	public String toString() {
		return "Clerk [speed=" + speed + ", accuracy=" + accuracy + "]";
	}
	
	public int getSpeed() {
		return speed;
	}
	public void setSpeed(int speed) {
		this.speed = speed;
	}
	public int getAccuracy() {
		return accuracy;
	}
	public void setAccuracy(int accuracy) {
		this.accuracy = accuracy;
	}
	
	// Condtion checking speed and accuracy
	void setSalary() {
		double salary1 = 0 ;
		salary1  = salary;
		if(speed > 70 && accuracy > 80 ) {
			salary1 += 1000;
		}
		else {
		
		}
	}
}
