package dec_14_2020;

public class Manager extends Employee {
	ManagerType mt;
	
	
	public Manager(ManagerType mt, String name ,int id , double salary ) {
		super(name, id, salary);
		this.mt = mt ;
	}
	
	

	public ManagerType getMt() {
		return mt;
	}



	public void setMt(ManagerType mt) {
		this.mt = mt;
	}



	@Override
	public String toString() {
		return "Manager [mt=" + mt + "]";
	}
	 
	
	
	void setSalary() {
		System.out.println(salary);
		salary = salary ;
		switch(mt) {
		case HR : 
			salary += 10000 ;
			break;
		case SALES :
			salary += 5000;
			break;
		}
	}

	
	
}
