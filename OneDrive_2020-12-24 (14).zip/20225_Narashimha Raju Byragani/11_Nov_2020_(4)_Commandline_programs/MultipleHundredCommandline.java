package javapphanimamclass;

public class MultipleHundredCommandline {
		static int multipleHundredCommandline(int num) {
			int quo = num / 100 ;
				num = (quo + 1) * 100 ;
			return num ;
		}
	public static void main(String[] args) {
		int num = Integer.parseInt(args[0]);
		System.out.println(multipleHundredCommandline(num));
	}

}
