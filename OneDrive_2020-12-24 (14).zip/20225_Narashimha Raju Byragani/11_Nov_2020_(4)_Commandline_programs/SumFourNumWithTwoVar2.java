package javapphanimamclass;

public class SumFourNumWithTwoVar2{
	
	
	public static void main(String args[]) {
		//int num = Integer.parseInt(args[0]);
		/*int num = Integer.parseInt(args[0]);
	 	 	num += Integer.parseInt(args[1]);
	 	 	num += Integer.parseInt(args[2]);
	 	 	num += Integer.parseInt(args[3]); 
	 	 	System.out.println(num);*/
		int sum = 0;
		int num = Integer.parseInt(args[0]);
		sum = sum + num;
		num = Integer.parseInt(args[1]);
		sum = sum + num;
		num = Integer.parseInt(args[2]);
		sum = sum + num;
		num = Integer.parseInt(args[3]);
		sum = sum + num;
		num = Integer.parseInt(args[4]);
		sum = sum + num;
		System.out.println(sum);
	}

}
