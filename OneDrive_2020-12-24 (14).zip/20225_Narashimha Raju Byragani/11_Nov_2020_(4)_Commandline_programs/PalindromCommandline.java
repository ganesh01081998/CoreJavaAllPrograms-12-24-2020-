package javapphanimamclass;

public class PalindromCommandline {
	 static int palindromCommandline(int num) {
		 
		 int rem=0 , pal=0 ;
		 	int temp = num ;
		 	rem = num % 10 ;
		 	pal = (pal * 10) + rem ;
		 	num = num / 10;
		 	rem = num % 10 ;
		 	pal = (pal *10) + rem ;
		 	num = num / 10;
		 	rem = num % 10 ;
		 	pal = (pal * 10) + rem ;
		 	num = num / 10;
		 if(temp == pal) {
			System.out.println("is palindrom");
		 }
		 else {
		 System.out.println("not a palindrom");
		 }
		return pal ;
	}
		
	public static void main(String[] args) {
		int num =Integer.parseInt(args[0]);
		System.out.println(palindromCommandline(num));
	}

}
