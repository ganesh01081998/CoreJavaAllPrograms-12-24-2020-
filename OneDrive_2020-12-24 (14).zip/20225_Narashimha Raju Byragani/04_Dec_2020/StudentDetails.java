package dec_4_2020;

import java.util.Scanner;


public class StudentDetails {
	int studentId;
	String studentName;
	private int studentMarks;
	private char studentGrade;
	StudentDetails(int studentId , String studentName , int studentMarks ) {
		this.studentId = studentId;
		this.studentName = studentName;
		this.studentMarks = studentMarks;
		CalStudentGrade(studentMarks);
	}
	public void Display() {
		 System.out.println("StudentName= "+studentName+"\n" + "StudentId= " + studentId +"\n"+ "StudentMarks= "+ studentMarks +"\n"+ "StudentGrade= "+studentGrade);
	 }
	private void CalStudentGrade(int studentMarks) {
		if(studentMarks > 90) {
			this.studentGrade = 'A';
		}
		else if(studentMarks <= 90 && studentMarks > 65) {
			this.studentGrade = 'B';
		}
		else if(studentMarks <= 65 && studentMarks > 45) {
			this.studentGrade = 'C';
		}
		else {
			this.studentGrade = 'D';
		}
		
	}
	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		System.out.println("enter Studentid and name and marks ");
		StudentDetails std = new StudentDetails(scr.nextInt(),scr.next(),scr.nextInt());
		std.Display();

	}

}
