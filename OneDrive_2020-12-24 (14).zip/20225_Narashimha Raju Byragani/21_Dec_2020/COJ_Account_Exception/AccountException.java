package dec_21_2020;

public class AccountException {
	int balance = 0;
	int accountNumber = 12345;
	
	public AccountException(int accountNumber) {
		this.accountNumber = accountNumber ;
	}
	 
	public boolean CheckerAccountNum(int accNo) {
		boolean b = false ;
		if(accountNumber == accNo) {
			b = true;
		}
		return b ;
	}
	
	public String Deposit(int accountNo , int depositAmount) {
		if(accountNumber == accountNo) {
			balance = balance + depositAmount ;
			return "Diposited Balance" + balance ; 
		}
		else {
			return "please enter valid account number";
		}
	}
	
	public String Withdraw(int accountNo , int withdrawAmount) {
		int balance1;
		try { 
		if(accountNumber == accountNo) {
			
			 balance1 = balance - withdrawAmount ;
			if(balance  < withdrawAmount ) {
				throw new InssuficiatBalance("no suugffient balance"); 
			}
			return "balance " + balance1;
		}
		else {
			return "please enter valid account number";
		}
	}
	catch(InssuficiatBalance ae) {
		System.out.println("please enter suffient balance" + ae);
	}
		return null;
	} 
	

}
