package dec_21_2020;

import java.util.Scanner;

public class MainAccountNumber  {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("enter account number");
		int accountnumber = scan.nextInt();
		AccountException ae = new AccountException(accountnumber);
		System.out.println("enter account number and deposit amount"); 
		System.out.println(ae.Deposit(scan.nextInt() , scan.nextInt()));
		System.out.println("enter account number and withdraw amount "); 
		System.out.println(ae.Withdraw(scan.nextInt(), scan.nextInt()));
		

	}

}
