package dec_21_2020;

public class InssuficiatBalance extends Exception {
	public InssuficiatBalance(String i) {
		super(i);
	}
}
