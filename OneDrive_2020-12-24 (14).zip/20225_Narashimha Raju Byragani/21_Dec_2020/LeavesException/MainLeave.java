package dec_21_2020;

import java.util.Scanner;

public class MainLeave {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("enter total number of leaves");
		int totalleaves = scan.nextInt();
		System.out.println("enter your leaves");
		int myLeaves = scan.nextInt();
		LeaveSystem le = new LeaveSystem(totalleaves);
		System.out.println(le.CheckLeaves(totalleaves,myLeaves));
		
	}

}
