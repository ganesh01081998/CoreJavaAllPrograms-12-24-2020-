package dec_21_2020;

public class LeaveSystem {
	int totalLeaves ;
	public LeaveSystem(int totalLeaves) {
		this.totalLeaves = totalLeaves ;
	}
	
	public String CheckLeaves(int totalLeaves , int myLeaves) {
			try {
			if(totalLeaves < myLeaves) {
				throw new LeaveQuotaExceededException("You have no leaves");
			}
			else {
				return "Granting a leave";
			
			}
			}
			catch(LeaveQuotaExceededException le) {
				return "You dont have leaves";
			}
			
		
	}
}
