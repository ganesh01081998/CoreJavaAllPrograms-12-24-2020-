package javapphanimamclass;

public class NumberList {

	
		static String diplayNaturalNum(String str) {
			String result = "";
			str = str.replaceAll("-",",");
			String nums[] = str.split(",");
			int values[] = new int [nums.length];
			for (int i = 0 ; i < nums.length ; i++) {
				values[i] = Integer.parseInt(nums[i]);
			
			}
			for (int i = findSmallest(values); i <= findbiggest(values);i++) {
				result += i ;
				if(i < findSmallest(values)) {
					result += ",";
				}
			}
			return result ;
		}
		static int findbiggest(int nums[] ) {
			int big = nums[0];
			for (int i = 1 ; i < nums.length ; i++) {
				if(nums[i] > big ) {
					big = nums[i];
				}
			}
			return big ;
		}
		static int findSmallest(int nums[] ) {
			int small = nums[0];
			for (int i = 1 ; i < nums.length ; i++) {
				if(nums[i] < small ) {
					small = nums[i];
				}
			}
			return small ;
		}
		public static void main(String[] args) {
			String str = "1-2-3-5,3";
			System.out.println(diplayNaturalNum(str) );
			
		}

	}

