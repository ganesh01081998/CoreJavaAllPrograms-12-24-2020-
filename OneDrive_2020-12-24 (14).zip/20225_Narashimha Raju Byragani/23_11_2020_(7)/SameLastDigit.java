package nov_23_2020;

import java.util.Scanner;

public class SameLastDigit {
	static boolean sameLastDigit(int num1 , int num2){
		boolean b = false;
		if((num1 % 10) == (num2 % 10)){
			b = true;
		}
		return b;
	}

	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		System.out.println("enter two values");
		 int num1 = scr.nextInt();
		 int num2 = scr.nextInt();
		 System.out.println(sameLastDigit(num1 , num2));

	}

}
