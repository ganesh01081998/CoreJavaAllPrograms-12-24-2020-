package nov_23_2020;

import java.util.Scanner;

public class SumDouble {
	static int sumDouble(int num1 , int num2) {
		int sum = 0;
		if (num1 == num2){
			sum += (num1+num2) * 2 ;
		}
		else {
			sum += num1 + num2 ;
		}
		return sum ;
	}

	public static void main(String[] args) {
		Scanner scr = new Scanner (System.in) ;
			System.out.println("enter two values=");
			int num1 = scr.nextInt();
			int num2 = scr.nextInt();
			System.out.println(sumDouble(num1 ,num2));

	}

}
