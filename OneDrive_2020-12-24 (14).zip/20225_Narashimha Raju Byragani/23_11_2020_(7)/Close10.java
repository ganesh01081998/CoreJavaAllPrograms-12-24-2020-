package nov_23_2020;

import java.util.Scanner;

public class Close10 {
	static String close10(int num1 , int num2) {
		String  result = "";
		int sub1 = Math.abs(10 - num1) ;
		int sub2 = Math.abs(10 - num2) ;
			
		if (sub1 < sub2 ) {
			result += num1 +"num1 is near 10";
		}
		else if(sub1 > sub2) {
			result += num2 +"num2 is near 10 ";
		}
		else {
			result += "both are same";
		}
		return result ;
	}

	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		System.out.println("enter two values");
		int num1 = scr.nextInt();
		int num2 = scr.nextInt();
		System.out.println(close10(num1 ,num2));
	}

}
