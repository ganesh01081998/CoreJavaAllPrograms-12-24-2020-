package nov_24_2020;

import java.util.Scanner;

public class ConsonentsString {
		
		static String consonentsString (String str) {
			int len =str.length();
		String result = "";
		for (int i=0 ; i < len ; i++){
			char ch = str.charAt(i);
			if(ch == 'a' ||ch == 'e' ||ch == 'i'||ch == 'o'||ch == 'u'){
				result += "" ;
			}
			else {
				result += ch;
			}
		}
		return result ;
		}

	public static void main(String[] args) {
		Scanner scr = new Scanner (System.in);
		System.out.println("enter a String");
		String str = scr.next();
		System.out.println(consonentsString (str));
	}

}
