package nov_24_2020;

import java.util.Scanner;

public class ReverseSentence {
	static String getReverse(String str) {
		StringBuffer sb = new StringBuffer(str);
		return sb.reverse().toString();
	}

	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		System.out.println("enter a Sentence");
		String str = scr.nextLine();
		String array[] = str.split(" ");
		for(int i = 0 ; i < array.length;i++){
		System.out.println(array[i]);
		}
		String reverse[] = new String [array.length];
		String result = "";
		for(int i = 0 ; i < array.length ; i++){
			
				reverse[i] = getReverse(array[i] +" ");
				result += reverse[i];
		}
		System.out.println(result);
	}

}
