package nov_24_2020;

import java.util.Scanner;

public class QuadraticSequence {
	static int quadraticSequence(int num) {
		int sum = 0;
		for(int i = 0 ; i <= num ; i++) {
			sum = sum + i;
	}
		return sum ;
}
	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		System.out.println("enter a number=");
		int num = scr.nextInt();
		System.out.println(quadraticSequence(num));
	}

}
