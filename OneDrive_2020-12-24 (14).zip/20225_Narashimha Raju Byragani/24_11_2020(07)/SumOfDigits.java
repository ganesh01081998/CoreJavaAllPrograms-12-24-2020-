package nov_24_2020;

import java.util.Scanner;

public class SumOfDigits {
		static int sumOfDigits(int num) {
			
				int rem = 0 , sum = 0;
				while(num > 0){
					rem = num % 10 ;
					sum = sum + rem ;
					num = num / 10 ;
				}
				//System.out.println(sum);
				return sum;
		}
		

	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		System.out.println("enter a number");
		int num = scr.nextInt();
		System.out.println(sumOfDigits(num));

	}

}
