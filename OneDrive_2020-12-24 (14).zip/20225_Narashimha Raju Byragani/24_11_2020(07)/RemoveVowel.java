package nov_24_2020;

import java.util.Scanner;

public class RemoveVowel {
	static String removeVowel(String str) {
		String result ="";
		int len = str.length();
		for(int i = 0 ; i < len ; i++) {
			char ch = str.charAt(i);
			if(ch == 'a'|| ch == 'e' || ch == 'i' || ch == 'o'|| ch == 'u'){
				
			}
			else{
				result += ch ;
			}
		}
		return result ;
	}

	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		System.out.println("enter a String ");
		String str = scr.next();
		System.out.println(removeVowel(str));
	}

}
