package javapphanimamclass;

public class Arrayduplicates {
		static int temp;
	public static void main(String[] args) {
		int arr[] = {5,2,2,3,1,5,4,4,2,3,4,5,6,6,6,6} ;
		int arr1[] = new int [5];
		int n = arr.length,j,k=0;
		;
		for (int i = 0 ; i <= n-1 ;i++) {
			for ( j=i + 1 ; j<= n-1 ; j++) {
				if(arr[i] == arr[j] ) {
					arr1[k++] = arr[i] ;
					
					}
					
				
			}
				
		}
		 arr[k++] = arr[n-1];     
		
		
		}
		
		}
		
	
	


