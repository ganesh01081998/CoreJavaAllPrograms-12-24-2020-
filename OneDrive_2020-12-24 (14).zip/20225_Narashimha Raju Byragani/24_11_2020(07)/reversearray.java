package nov_24_2020;

public class reversearray {
public static void main(String args[])
{
	int arr1[]={1,2,3,4,5,6,7,8,9,0};
	for(int i=0;i<arr1.length;i++)
	{
		System.out.println(arr1[i]);
	}
	System.out.println();
	int len=arr1.length;
	for(int i=len-1;i>=0;i--)
	{
		System.out.print(arr1[i]+" ");
	}
}
}
