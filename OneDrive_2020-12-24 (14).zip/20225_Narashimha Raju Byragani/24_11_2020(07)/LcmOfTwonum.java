package nov_24_2020;

public class   LcmOfTwonum {
		static void lcmOfTwonum(int num1 , int num2 ){
			int lcm = (num1 > num2 ) ? num1 : num2 ;
			while(true){
		
		 if (lcm % num1 == 0 && lcm % num2 == 0) {
			 System.out.println(lcm);
			 break;
		 }
		 lcm++;
		}
	
		}
	public static void main(String[] args) {
		lcmOfTwonum(10,20);
	}

}
