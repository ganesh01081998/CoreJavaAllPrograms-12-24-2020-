package nov_24_2020;

import java.util.Scanner;

public class LukeyNumber {
	static int lukeyNumber(String str){
		int result =  0,monNumber=0;
		String repalce1 = str.replaceAll("-","/");
		String replace2 = str.replaceAll("/", "-");
		String split[] = str.split("-") ;
		
		for (int i = 0 ; i < split.length ; i++) {
			System.out.println(split[i]);
		}
		String date = split[0];
		System.out.println(date);
		String month = split[1];
		System.out.println(month);
		String year = split[2];
		System.out.println(year);
		String monthName[] = {"jan","feb","mar","apr","may","jun","jul","aug","sep","act","nov","dec"} ;
		//int monthNumber [] = {1,2,3,4,5,6,7,8,9,10,11,22}; 
		int len = monthName.length;
		System.out.println(len);
		for (int i = 0 ; i < len - 1 ; i++){
			if(month.equalsIgnoreCase(monthName[i]));{
				 monNumber= i + 1;
				 
			}
			
		}
		System.out.println(monNumber);
		String total = date + monNumber + year;
		System.out.println(total);
		int totalNumber = Integer.parseInt(total);
		int rem = 0 ,sum=0;
		while(totalNumber > 9) {
			rem = totalNumber % 10 ;
			totalNumber = totalNumber / 10 ;
			totalNumber = rem + totalNumber;
			
		}
		
		return totalNumber ;
	}

	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		System.out.println("enter a date");
		String str = scr.nextLine();
		System.out.println(lukeyNumber(str));
	}

}
