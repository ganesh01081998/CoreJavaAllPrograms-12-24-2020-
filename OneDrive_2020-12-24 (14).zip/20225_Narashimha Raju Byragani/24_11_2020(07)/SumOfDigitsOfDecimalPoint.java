package nov_24_2020;

import java.util.Scanner;

public class SumOfDigitsOfDecimalPoint {
	static String  sumOfDigitsOfDecimalPoint(String str2 , String str3){
		String result = "";
		int num1 = Integer.parseInt(str2);
		int num2 = Integer.parseInt(str3);
		result +=sumNumber(num1);
		result += ":";
		result +=sumNumber(num2);
		
		return result;
	}
	
	static int  sumNumber(int num){
		int rem = 0 , sum = 0;
		while(num > 0){
			rem = num % 10 ;
			sum = sum + rem ;
			num = num / 10 ;
		}
		System.out.println(sum);
		return sum;
	}

	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in) ;
			System.out.println("enter a String as digits");
			String str = scr.next();
			String str1[] = str.split("[.]");
			String str2 = str1[0];
			String str3 = str1[1];
			System.out.println( sumOfDigitsOfDecimalPoint(str2 , str3));
			
	}

}
