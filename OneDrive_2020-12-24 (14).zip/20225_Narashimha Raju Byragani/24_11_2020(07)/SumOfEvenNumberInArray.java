package nov_24_2020;

import java.util.Scanner;

public class SumOfEvenNumberInArray {
	static int result = 0,count = 0,temp = 0;
	static int sumOfEvenNumberInArray(int array[]) {
		
		for (int i = 0 ; i < array.length ; i++) {
			if (array[i] == 0) {
				count++;
			}
		}
		
		for (int j = 0 ; j < array.length ; j++) {
			if (array[j] < 0) {
				temp++;
			}
		}
		//int sum = 0;
		for(int i = 0 ; i < array.length ; i++) {
			if (count > 0) {
				result = -3 ;
			}
			else if( temp > 0) {
				result = -2 ;
			}
			else if(array[i] <= 0) {
				result = -1 ;
			}
			else {
				if(array[i] % 2 == 0) {
					result += array[i];
					
				}
			}
		}
		return result ;
	}

	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		System.out.println("enter array elements");
		int array[] = new int[5];
		for(int i = 0 ; i < array.length ; i++){
			array[i] = scr.nextInt();
		}
		System.out.println(sumOfEvenNumberInArray(array));
	}

}
