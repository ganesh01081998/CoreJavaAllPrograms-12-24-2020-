package nov_24_2020;

public class StringPalindrom {

	public static void main(String[] args) {
		String pal = "AMMA";
		int n = pal.length();
		char ch1 = pal.charAt(0);
		char ch2 = pal.charAt(n-1);
		if (ch1 == ch2) {
			System.out.println("is palindrom");
		}
		else {
			System.out.println("not a palindrom");
		}
	}

}
