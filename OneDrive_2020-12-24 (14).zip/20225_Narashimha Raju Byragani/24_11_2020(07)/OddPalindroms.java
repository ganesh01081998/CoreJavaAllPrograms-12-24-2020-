package nov_24_2020;

import java.util.Scanner;

public class OddPalindroms {
	static String  oddPalindrom(int firstNum , int endNum ) {
		String result = "";
			int num = 0 ;
		for(int i = firstNum ; i <= endNum ; i++) {
			num = i ;
			
			int rem = 0 , rev = 0 , temp = num ;
			while(num > 0) {
				rem = num % 10 ;
				rev =( rev * 10 ) + rem ;
				num = num / 10 ;
			}
			if(temp == rev) {
				if(rev % 2 != 0) {
					result += rev +"\n" ;
				}
				
			}
			
		}
		return result ;
	}

	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		System.out.println("enter two numbers=");
		int firstNum = scr.nextInt();
		int endNum   = scr.nextInt();
		System.out.println(oddPalindrom(firstNum, endNum));

	}

}
