package narasimhaRaju;

import java.util.Scanner;

public class StringOccurenceCounter {
	static int CharacterCount(String str) {
		//String charArray[] = new String[str.length()];
		int count = 0;
		for(int i = 0 ; i < str.length();i++ ){
			
			char ch= str.charAt(i);
			for(int j = 0 ; j < str.length(); j++){
				char ch1 = str.charAt(j);
				if(ch == ch1) {
					count++;
					
				}
				
				
			}
			
		}
		System.out.println(count);
		count = 0;
		return count ;
		
	}
	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		System.out.println("enter any String");
		String str = scr.next();
		System.out.println(CharacterCount(str)); 
	}

}
