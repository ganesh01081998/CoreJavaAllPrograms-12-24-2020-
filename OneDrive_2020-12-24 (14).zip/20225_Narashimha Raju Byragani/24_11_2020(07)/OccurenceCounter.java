package nov_24_2020;

import java.util.Scanner;

public class OccurenceCounter {

	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		System.out.println("enter a String");
		String str = scr.next();
		
	}

}
