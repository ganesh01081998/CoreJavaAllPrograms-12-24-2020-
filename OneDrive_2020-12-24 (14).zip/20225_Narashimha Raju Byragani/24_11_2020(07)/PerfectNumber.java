package nov_24_2020;

import java.util.Scanner;

public class PerfectNumber {
	static String perfectNumber(int num) {
		int result = 0;
		String result1 ="";
		for(int i = 1 ; i < num ; i++)
		if(num % i == 0) {
			System.out.println(i);
			result += i ;
		}
		System.out.println("result num"+result);
		if(num == result) {
			result1 = "given num is perfect";
		}
		else {
			result1 = "given number is not a perfect";
		}
		return result1;
		
	}
	public static void main(String[] args) {
		Scanner scr = new Scanner (System.in);
		System.out.println("enter a number=");
		int num = scr.nextInt();
		System.out.println(perfectNumber(num));
	}

}
