package nov_24_2020;

public class SortingArray {

	static void sortingArray(int array[]){
		//String result ="";
		int temp;
		//int big = array[0];
		for(int i = 0 ; i < array.length-1 ; i++) {
			for(int j=i+1 ;j <= array.length-1 ; j++ ){
				if (array[i] > array[j]) {
					//result += array[i];
					temp = array[i];
					array[i] = array[j];
					array[j] = temp;
					
				}
			}
		}
		System.out.println("Sorting of array elements=");
		for (int i = 0 ; i <= array.length-1 ; i++) {
			System.out.println(array[i]);
		}
		
	}

	public static void main(String[] args) {
		int array[]={1,2,3,4,5,6,-1,-6,-7} ;
		System.out.println("array elements are:");
		for (int i=0 ; i < array.length; i++) {
			
			System.out.println(array[i]);
		}
		sortingArray(array);
	}

}
