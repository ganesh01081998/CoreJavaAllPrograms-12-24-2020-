package nov_24_2020;

import java.util.Scanner;

public class PositionOfElements {
	static int  positionOfElements(int num , int array[]){
		//boolean b = false;
		
		int result = 0,count  = 0;
		
		for (int i = 0 ; i < array.length ; i++){
			if (array[i] < 0) {
				
				count ++ ;
			
			}
		}
		
		
		for(int i = 0 ; i < array.length ; i++) {
			if(array.length == 0) {
				System.out.println("array length is zero");
				result = -2;
				break;
			}
			else if(count > 0) {
				System.out.println("array elements has negative elements");
				result = -3 ;
				break;
			}
			else if (num != array[i]) {
				System.out.println("there is no searching elements in array");
				result = -1 ;
				break;
			}
			else {
				if(num == array[i]) {
					System.out.println("searching array element");
					result = i + 1 ;
					break;
				}
			}
		}
		
		return result ;
	}

	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		System.out.println("enter a searching element");
		int num = scr.nextInt();
		int array[] = new int [5];
		System.out.println("enter array elements");
		for(int i = 0 ; i < array.length ; i++) {
			array[i] = scr.nextInt();
		}
		for(int i = 0 ; i < array.length; i++) {
			System.out.println(array[i]);
		}
		System.out.println(positionOfElements(num, array));

	}

}
