package dec_15_2020;

public class Sourcing {
	
		int id;
		String name;
		double basicSalary;
		double hraper;
		double daper;
		int enrollmentTarget;
		int enrollmentReached;
		double perkPerEnrollment;
		Sourcing() {
			this.id = 0;
			this.name = null;
			this.basicSalary = 0;
			this.hraper = 0;
			this.daper = 0;
			this.enrollmentTarget = 0;
			this.enrollmentReached = 0;
			this.perkPerEnrollment = 0;
		
		}
		public Sourcing(int id, String name, double basicSalary, double hraper, double daper, int enrollmentTarget,
				int enrollmentReached, double perkPerEnrollment) {
			this.id = id;
			this.name = name;
			this.basicSalary = basicSalary;
			this.hraper = hraper;
			this.daper = daper;
			this.enrollmentTarget = enrollmentTarget;
			this.enrollmentReached = enrollmentReached;
			this.perkPerEnrollment = perkPerEnrollment;
		}

		public double calculateGrossSalary() {
			return basicSalary + hraper + daper + ((enrollmentReached / enrollmentTarget) * 100) * perkPerEnrollment;
		}

		@Override
		public String toString() {
			return "Sourcing [id=" + id + ", name=" + name + ", basicSalary=" + basicSalary + ", hraper=" + hraper
					+ ", daper=" + daper + ", enrollmentTarget=" + enrollmentTarget + ", enrollmentReached="
					+ enrollmentReached + ", perkPerEnrollment=" + perkPerEnrollment + "]";
		}
	}

