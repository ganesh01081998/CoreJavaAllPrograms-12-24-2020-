package dec_15_2020;

public class Manager {

	
		int id;
		String name;
		double basicSalary;
		double hraper;
		double daper;
		double projectAllowance;

		Manager() {
			this.id = 0;
			this.name = null;
			this.basicSalary = 0;
			this.hraper = 0;
			this.daper = 0;
			this.projectAllowance = 0;
		}

		public Manager(int id, String name, double basicSalary, double hraper, double daper, double projectAllowance) {
			this.id = id;
			this.name = name;
			this.basicSalary = basicSalary;
			this.hraper = hraper;
			this.daper = daper;
			this.projectAllowance = projectAllowance;
		}

		public double calculateGrossSalary() {
			return basicSalary + hraper + daper + projectAllowance;
		}

		@Override
		public String toString() {
			return "Manager [id=" + id + ", name=" + name + ", basicSalary=" + basicSalary + ", hraper=" + hraper
					+ ", daper=" + daper + ", projectAllowance=" + projectAllowance + "]";
		}
	}


