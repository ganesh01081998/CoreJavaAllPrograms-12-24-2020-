package dec_15_2020;

import java.util.Scanner;

public class ScienceStudent extends Student{

		int physicsMarks;
	    int chemistryMarks;
	    int mathsMarks;

	    public ScienceStudent() {

	
	    }

	    public ScienceStudent(int physicsMarks, int chemistryMarks, int mathsMarks) {
	        this.physicsMarks = physicsMarks;
	        this.chemistryMarks = chemistryMarks;
	        this.mathsMarks = mathsMarks;
	    }
	    
	    @Override
	    void getPercentage() {
	    	
	        Student.getTotalNoStudents();
	        int totalMarks= physicsMarks + chemistryMarks + mathsMarks;
	        System.out.println("The 3 subjects total marks are :"+totalMarks);
	        int percentage =( totalMarks )/5;
	        System.out.println("The percentage of 3 subjects are :"+percentage);
	    }

		@Override
		public String toString() {
			return "ScienceStudent [physicsMarks=" + physicsMarks + ", chemistryMarks=" + chemistryMarks
					+ ", mathsMarks=" + mathsMarks + "]";
		}
		
		String displayDetails() {
			return toString();
			
		}
	    
	}


