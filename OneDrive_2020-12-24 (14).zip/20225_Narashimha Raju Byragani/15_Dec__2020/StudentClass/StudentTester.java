package dec_15_2020;

import java.util.Scanner;

public class StudentTester {

	 

    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Enter How many Student Marks you want");
        int n = scn.nextInt();
        for(int i = 1; i <= n; i++) {
        System.out.println("Enter the "+i+" student name");
        String studentName = scn.next();
        System.out.println("Enter the student class");
        String studentClass =  scn.next(); 
        System.out.println("1.Science Student \n 2. History Student \n Select Any one Option");
        int choice = scn.nextInt();
        switch(choice) {
        case 1:
        	System.out.println("enter Student physics marks ,chemistry marks , MathsMArsk=");
        ScienceStudent ss = new ScienceStudent(scn.nextInt(),scn.nextInt(),scn.nextInt());
        ss.getPercentage();
        System.out.println(ss.displayDetails());
        break;
        case 2:
            HistoryStudent hs = new HistoryStudent();
            hs.getPercentage();
            System.out.println(hs.displayDetails());
            break;
        default:
            System.out.println("Enter Valid option");
            break;
        }
    
        }
    System.out.println(n+" Students Marks Updated");
    }
}
