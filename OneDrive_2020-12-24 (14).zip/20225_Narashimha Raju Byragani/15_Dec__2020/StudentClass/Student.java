package dec_15_2020;

 abstract  class Student {
	
	    
	    static int count = 0;
	    String studentName;
	    String studentClass;
	  protected static int totalNoOfStudents;
	  
	  abstract void getPercentage();

	    static void getTotalNoStudents() {
	        count++;
	        System.err.println(count+" Student Marks :");
	    }

	    public Student() {

	    }
	    public Student(String studentName, String studentClass) {
	        this.studentName = studentName;
	        this.studentClass = studentClass;
	    }

		@Override
		public String toString() {
			return "Student [studentName=" + studentName + ", studentClass=" + studentClass + "]";
		}
	     
		String dispalyDetails() {
			return toString();
		}
}
