package dec_15_2020;

abstract class Shape {
		abstract void getArea();
		abstract void getPerimeter();
	
}
