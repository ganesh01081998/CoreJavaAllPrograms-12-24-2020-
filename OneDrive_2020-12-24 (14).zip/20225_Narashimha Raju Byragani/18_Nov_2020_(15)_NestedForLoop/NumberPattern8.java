package patterns;

import java.util.Scanner;

public class NumberPattern8{
	static String pattern(int rows,int columns) {
		String result = "";
		for(int i = rows ; i > 0; i--) {
			for(int j = columns; j > 0;j--) {
				result += i + " ";
			}
			result += "\n";
		}
		return result;
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the rows and columns number");
		int initial = scanner.nextInt(),finalValue = scanner.nextInt();
		System.out.println(pattern(initial,finalValue));	
	}
}
