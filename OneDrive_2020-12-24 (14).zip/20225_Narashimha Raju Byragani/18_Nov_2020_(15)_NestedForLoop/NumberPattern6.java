package patterns;

import java.util.Scanner;

public class NumberPattern6 {
	static String numbersPattern2(int rows , int column){
		String result = "" ;
		int i , j,num=1;
		for( i = 1 ; i <= rows ; i++) {
			for( j = 1 ; j <= i ; j++){
				result += num + " ";
				num++;
			}
			
			result += "\n";
		}
		
		return result ;
		
	}
public static void main(String[] args) {
	System.out.println("enter two numbers");
	Scanner scr = new Scanner (System.in);
	System.out.println(numbersPattern2(scr.nextInt(),scr.nextInt()));
}
}
