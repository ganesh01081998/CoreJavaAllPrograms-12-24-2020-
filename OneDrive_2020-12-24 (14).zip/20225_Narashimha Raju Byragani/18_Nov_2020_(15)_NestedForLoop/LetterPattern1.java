package patterns;

import java.util.Scanner;

public class LetterPattern1 {
	static String letterPattern1(int rows , int columns){
		String result = "" ;
		char num = 'A';
		for(int i = 1 ; i <= rows ; i++) {
			for(int j = 1 ; j <= i ; j++){
				result += num + " ";
				num++;
			}
			
			result += "\n";
		}
		return result ;
		
	}
public static void main(String[] args) {
	System.out.println("enter two numbers");
	Scanner scr = new Scanner (System.in);
	System.out.println(letterPattern1(scr.nextInt(),scr.nextInt()));
}
}
