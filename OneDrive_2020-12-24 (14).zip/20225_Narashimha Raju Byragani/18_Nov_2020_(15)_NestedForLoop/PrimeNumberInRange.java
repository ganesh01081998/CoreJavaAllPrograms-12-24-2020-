package patterns;

import java.util.Scanner;

public class PrimeNumberInRange {

	
		static int flag = 0;
		public static void main(String[] args) {
			Scanner scanner = new Scanner(System.in);
			System.out.println("Enter the Range of the Prime : ");
			int intialRange = scanner.nextInt();
			int finalrange = scanner.nextInt();
			System.out.println(getPrimeInRange(intialRange, finalrange));
		}
		
		
		static String getPrimeInRange(int intialRange,int finalrange) {
			System.out.println("--Prime Numbers--");
			String result = "";
			for(int i = intialRange; i <= finalrange;i++) {
				for(int j = 2;j < i;j++) {
					if(i % j ==0) {
						flag ++;
					}
				}
				if(flag == 0) {
					 result +=i + " ";
				}
				flag = 0;
			}
			return result;
		}

	}



