package patterns;

import java.util.Scanner;

public class NumberPattern2 {
	static String numbersPattern1(int firstnum , int endnum){
		String result = "" ;
		for(int i = firstnum ; i <= endnum ; i++) {
			for(int j = endnum ; j >= 1 ; j--){
				result += j + " ";
			}
			result += "\n";
		}
		return result ;
		
	}
public static void main(String[] args) {
	System.out.println("enter two numbers");
	Scanner scr = new Scanner (System.in);
	System.out.println(numbersPattern1(scr.nextInt(),scr.nextInt()));
}

}
	


