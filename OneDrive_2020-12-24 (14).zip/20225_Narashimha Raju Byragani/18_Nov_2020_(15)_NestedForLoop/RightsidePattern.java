package patterns;

import java.util.Scanner;

public class RightsidePattern {


	static String  rightSideStarPattern(int rows , int columns){
		int i , j ;
		String result = "" ;

		for( i = 1 ; i <= rows ; i++) {
			for( j=1  ; j <= columns-i ; j++){

				result += " ";

			}

			for(j = 1 ; j <=  i  ; j++){
				result += "*";
			}
			result += "\n";

		}
		return result;
	}
	public static void main(String[] args) {
		System.out.println("enter two numbers");
		Scanner scr = new Scanner (System.in);
		System.out.println( rightSideStarPattern(scr.nextInt(),scr.nextInt()));
	}

}


