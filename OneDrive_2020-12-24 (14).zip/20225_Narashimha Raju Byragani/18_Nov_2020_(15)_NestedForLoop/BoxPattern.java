package patterns;

import java.util.Scanner;

public class BoxPattern {
	static String  boxPattern(int rows , int columns){
		int i , j ;
		String result = "" ;
		
		for( i = 1 ; i <= rows ; i++) {
			for( j=1 ; j <= columns ; j++){
				if(i == 1 || j == 1 || i == rows || j == columns){
					result += "*" + " ";
				}
				else {
					result += " " + " ";
				}
				
			}
			result += "\n";
		}
		return result ;
		
	}
public static void main(String[] args) {
	System.out.println("enter two numbers");
	Scanner scr = new Scanner (System.in);
	System.out.println( boxPattern(scr.nextInt(),scr.nextInt()));
}

	
}
