package nov_21_2020;

import java.util.Scanner;

public class OddSum {
	static String oddsum(int array[]) {
		String result= "";
		int sum = 0 ;
		for(int i=0 ; i < array.length ; i++) {
			if(array[i] % 2 != 0) {
				
				result += array[i] + " ";
				
			}
			
		}
		result += "\n";
		for(int i=0 ; i < array.length ; i++) {
			if(array[i] % 2 != 0) {
				sum += array[i];
				
				
			}
			
		}
		result += sum + " ";
		return result ;
	}

	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
	int array[] = new int[5];
	for (int i=0 ; i < array.length ; i++) {
		array[i] = scr.nextInt(); 
	}
	System.out.println(oddsum(array));
	}

}
