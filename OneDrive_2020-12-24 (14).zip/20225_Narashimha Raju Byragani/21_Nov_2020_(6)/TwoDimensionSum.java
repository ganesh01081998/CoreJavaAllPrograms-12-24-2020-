package nov_21_2020;

import java.util.Scanner;

public class TwoDimensionSum {
	static String result = "";
	static String multiDimensionArray(int arr1[][],int arr2[][]){
		
		for (int i = 0 ; i < arr1.length ; i++){
			for(int j = 0 ; j < arr1.length ; j++){
				result += arr1[i][j] + " ";
				}
			result += "\n";
		}
		
		result += "\n";
	for (int i = 0 ; i < arr2.length ; i++){
		
		for(int j = 0 ; j < arr2[i].length ; j++){
			result += arr2[i][j] + " ";
			}
		result += "\n";
	}
	return result;
}
	
	static void twoDimensionSum(int arr1[][],int arr2[][],int sum[][]){
		//String result = "" ;
		
		int i,j;
		for ( i = 0 ; i < arr2.length ; i++){
			
			for( j = 0 ; j < arr2[i].length ; j++){
				
				
					 sum[i][j] = arr1[i][j] + arr2[i][j];
					// result += sum + " ";
			}
			
		}
		///return result;
	}
	static String dispalySum(int sum[][]){
		String result = "" ;
		//int sum[][] = new int [2][2];
		int i,j;
		for ( i = 0 ; i < sum.length ; i++){
			
			for( j = 0 ; j < sum[i].length ; j++){
				
				
					result += sum[i][j] + " ";
			}
			result += "\n";
		}
		return result;
	}
		
	
	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		int arr1[][] = new int[2][2];
		int arr2[][] = new int[2][2];
		int sum[][] = new int [2][2];
		for (int i = 0 ; i < arr1.length ; i++){
			for(int j = 0 ; j < arr2.length ; j++){
				arr1[i][j] = scr.nextInt();
				
			}
			
		}
		
		for (int i = 0 ; i < arr1.length ; i++){
			for(int j = 0 ; j < arr1.length ; j++){
				arr2[i][j] = scr.nextInt();
				
			}
			
		}
		System.out.println(multiDimensionArray(arr1,arr2));
		twoDimensionSum(arr1,arr2,sum);
		System.out.println((dispalySum(sum)));
	}

}
