package nov_21_2020;

import java.util.Scanner;

public class MaxArray {

	static int maxArray(int array1[]){
		int big = 0;
		 big = array1[0];
			for(int i = 0 ; i < array1.length ; i++){
				
				if (array1[i] > big) {
					big = array1[i];
				}
			
			}
		
		return big;
}

public static void main(String[] args) {
	Scanner scr = new Scanner(System.in);
	int array1[] = new int [5];
	System.out.println("enter a array elements:");
		for(int i = 0 ; i < array1.length ; i++){
				array1[i] = scr.nextInt();
		}
		System.out.println("MAXIMUM VALUE");
		System.out.println(maxArray(array1));
}


}
