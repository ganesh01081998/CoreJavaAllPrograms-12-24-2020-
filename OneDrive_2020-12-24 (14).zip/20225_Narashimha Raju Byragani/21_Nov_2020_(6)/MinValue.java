package nov_21_2020;

import java.util.Scanner;

public class MinValue {

	static int maxArray(int array1[]){
		int small = 0;
		small = array1[0];
			for(int i = 0 ; i < array1.length ; i++){
				 
				if (array1[i] < small) {
					small = array1[i];
				}
			
			}
		
		return small;
}

public static void main(String[] args) {
	Scanner scr = new Scanner(System.in);
	int array1[] = new int [5];
	System.out.println("enter a array elements:");
		for(int i = 0 ; i < array1.length ; i++){
				array1[i] = scr.nextInt();
		}
		System.out.println("MINIMUM VALUE");
		System.out.println(maxArray(array1));
}
}
