package javapphanimamclass;
import java.util.Scanner;
public class Evennumbers {
	
	static boolean isEven(int num)  {
		boolean b=false;
		if(num % 2 == 0) {
			b=true;
		}
	return b;	
	}
	
	static String rangeEvenNumbers(int num1,int num2) {
		String result= " " ;
		
		for(int i = num1 ; i <= num2 ; i++ ) {
			if(isEven(i)){
				result = result + i + " ";  
			}
		}
		return result;
		
	}
	
public static void main(String args[]) {
	System.out.println("enter two values=");
	Scanner sc=new Scanner(System.in);
	System.out.println(rangeEvenNumbers(sc.nextInt(),sc.nextInt()));
}
}
