package javapphanimamclass;

public class MultiplicationTable {
		static int multiplicationTable(int num) {
			
			for (int i=1 ; i <= 5 ; i++){
				
				int j=1, mul=0, range = 10;
				while(j <= range) {
					mul = num * j ;
					System.out.println(num + "* " + j + "=" +mul);
					j++;
					
			}
				num = num+1 ;
				
				System.out.println();
			}
			
		return num;
		}
	public static void main(String[] args) {
		multiplicationTable(5);
	}

}
