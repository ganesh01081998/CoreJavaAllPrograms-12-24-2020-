package javapphanimamclass;

public class PrimeNumber {
		static void primeNumber(int num ,int range){
			int count =0,i,j;
			for( i=num; i<=range ; i++) {
				for(j=num; j<=range ; j++){
					 if(i % j == 0){ 
						count= count + 1 ;
					 }
					 
					 }
			if(count == 2) {
				System.out.println( i);
			
			}
			count = 0;
			}
			
		}			 
	
	public static void main(String[] args) {
		primeNumber(1,10);
	}

}
