package javapphanimamclass;

public class SumOfNatruals {
	static int natural(int num) {
		int i=1,sum=0;
		System.out.println("natural numbers");
		while(i<=num) {
			System.out.print(" " + i);
			sum = sum + i;
			i++;
		}
		 System.out.println();
		 System.out.println("sum of natural numbers=" + sum);
		return num;
	}
public static void main(String[] args) {
	natural(10);
}


}
