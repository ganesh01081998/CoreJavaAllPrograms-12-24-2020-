package javapphanimamclass;
// import java.util.Scanner;
public class naturalNumbers {
	static void getNatural(int num) {
		int i=1;
		while(i<=num)
			{
			System.out.print(i +" ");
			i++;
			}
		}

	public static void main(String[] args) {
		
		getNatural(10);
	}

}
