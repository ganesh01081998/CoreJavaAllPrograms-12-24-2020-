package javapphanimamclass;

import java.util.Scanner;

public class ArmstrongOrNot {

	public static void main(String[] args) {
		System.out.println("Enter a number ");
		 Scanner scr = new Scanner (System.in);
		 int num =scr.nextInt(),rem = 0 , result = 0 , temp = num ;
		 while(num > 0) {
			 rem = num % 10 ;
			 result = result +(rem * rem * rem);
			 num = num / 10 ;
		 }
		 if (temp == result)  {
			 System.out.println("Given number is armstrong");
		 }
		 else {
			 System.out.println("Given number is Not a armstrong");
		 }
	}

}
