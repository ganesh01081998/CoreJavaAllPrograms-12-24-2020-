package javapphanimamclass;

import java.util.Scanner;

public class Factorial {

	public static void main(String[] args) {
		System.out.println("enter a number");
		Scanner scr = new Scanner(System.in) ;
		int num = scr.nextInt();
		int fact = 1 ,i=1;
		while(i <= num) {
			fact = fact * i ;
			i++;
		}
		System.out.println(fact);

	}

}
