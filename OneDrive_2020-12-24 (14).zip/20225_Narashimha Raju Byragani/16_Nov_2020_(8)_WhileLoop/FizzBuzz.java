package javapphanimamclass;
import java.util.Scanner;
public class FizzBuzz {
	static String Display(int num){
		String result=" ";
		
		
		if(num>0){
		
		if(num % 3 == 0 && num % 5 !=0) {
			result="fizz";
		}
		
			else if(num % 5 == 0 && num % 3 !=0) {
				result="Buzz";
			}
				else if(num % 5== 0 && num % 3 == 0) {
						result = "fizzBuzz";
				}
					 else if(num % 3 !=0 && num % 5 != 0){
						 result += num;
					 }
		}
		else 
		{
			result += "error";
		}
		
		return result;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter a number");
		Scanner sc=new Scanner(System.in);
		System.out.println(Display(sc.nextInt()));
}

}
