package _7org.ojas.exercise_23_nov_2020;

import java.util.Scanner;

/*Given 2 int values, return true if they are both in the range 30..40 inclusive, or they are both in the range 40..50 inclusive.
	in3050(30, 31) → true
	in3050(30, 41) → false
	in3050(40, 50) → true
	in3050(50, 39) → false
	in3050(40, -50) → false*/

public class _7BothInRange {
	static boolean is3050(int number1,int number2) {
		if(number1 >= 30 && number1 <=40 && number2 >= 30 && number2 <= 40 ) {
			return true;
		}
		else if (number1 >= 40 && number1 <=50 && number2 >= 40 && number2 <= 50 ) {
			return true;
		}
		return false;
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter two inputs : ");
		int number1 = scanner.nextInt(),number2 = scanner.nextInt();
		System.out.println(is3050(number1,number2));
	}
}
