package _7org.ojas.exercise_23_nov_2020;

import java.util.Scanner;

/*.Given two non-negative int values, return true if they have the same last digit, such as with 27 and 57*/

public class _6LastDigitSame {
	static boolean isLastDigitSame(int number1,int number2) {
		if(number1 % 10 == number2 % 10){
			return true;
		}
		return false;
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter two input values : ");
		int number1 = scanner.nextInt(),number2 = scanner.nextInt();
		System.out.println(isLastDigitSame(number1,number2));
	}
}
