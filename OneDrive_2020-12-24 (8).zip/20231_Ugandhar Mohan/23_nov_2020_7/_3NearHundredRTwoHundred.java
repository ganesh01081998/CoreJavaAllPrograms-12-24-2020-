package _7org.ojas.exercise_23_nov_2020;

import java.util.Scanner;

public class _3NearHundredRTwoHundred {
	static boolean nearHundred(int number) {		
		if(Math.abs(100 - number) <= 10 && Math.abs(100 - number) >= 1  ) {
			return true;
		}
		else if(Math.abs(200 - number) <= 10 && Math.abs(200 - number) >= 1  ) {
			return true;
		}
	return false;	
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the input : ");
		int number = scanner.nextInt();
		System.out.println(nearHundred(number));
	}
}
