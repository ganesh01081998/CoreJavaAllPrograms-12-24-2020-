package _7org.ojas.exercise_23_nov_2020;

import java.util.Scanner;

public class _2NumberList {
	static Scanner scanner = new Scanner(System.in);
	static String result = "";
		static String getNumberList() {
			try {
			String result = "";
			System.out.println("Enter the input : ");
			String str = scanner.next();
			str = str.replace(",", "-");			
			String [] strintarr = str.split("-");			
			int [] intarr = new int[strintarr.length];
			for(int i = 0;i < strintarr.length;i++) {
			intarr[i] = Integer.parseInt(strintarr[i]);
			}		
			int max = findMaxString(intarr);
			int min = findMinString(intarr);
			
			for(int i = min; i <= max;i++) {
				result += i + ",";
			}		
			return result.substring(0 , result.length()-1);
			}
			catch(Exception e) {
				return result  +="null";
				
			}
		}	
	
	
		static int findMaxString(int [] intarr) {
		int index = 0,result,i,max = intarr[index];
		for( i = 0;i < intarr.length;i++) {
			if(intarr[i] > max) {
				max = intarr[i];
			}
		}
		return max;
	}
	
	
	static int findMinString(int [] intarr) {
		int index = 0,result,i,min = intarr[index];
		for( i = 0;i < intarr.length;i++) {
			if(intarr[i] < min) {
				min = intarr[i];
			}
		}
		return min;
	}
	
	public static void main(String[] args) {
		System.out.println(getNumberList());
		
	}
	
	

		
		
}

