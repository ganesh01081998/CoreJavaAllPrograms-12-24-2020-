package _7org.ojas.exercise_23_nov_2020;

import java.util.Scanner;

/*Given 2 int values, return whichever value is nearest to the value 10, or return 0 in the event of a tie. Note that Math.abs(n) returns the absolute value of a number.
		close10(8, 13) → 8
		close10(13, 8) → 8
		close10(13, 7) → 0*/

public class _4NearestTo10 {
	static int close10(int number,int number1) {
		int compare = Math.abs(number -10);
		int compare1 = Math.abs(number1 -10);
		if(compare == compare1) {
			return 0;
		}
		else if(compare < compare1) {
			return number;
		}
		else {
			return number1;
		}
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the two inputs : ");
		int number = scanner.nextInt(),number1 = scanner.nextInt();
		System.out.println(close10(number,number1));
		
	}
}
