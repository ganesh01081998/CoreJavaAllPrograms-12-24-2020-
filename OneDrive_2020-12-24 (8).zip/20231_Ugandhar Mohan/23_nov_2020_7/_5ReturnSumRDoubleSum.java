package _7org.ojas.exercise_23_nov_2020;

/*Given two int values, return their sum. Unless the two values are the same, then return double their sum.
	sumDouble(1, 2) → 3
	sumDouble(3, 2) → 5
	sumDouble(2, 2) → 8*/

import java.util.Scanner;

public class _5ReturnSumRDoubleSum {
	static int sumDouble(int number,int number1) {
		int sum = number + number1;
		if(number == number1) {
			return sum*2 ;
		}
		else if (number != number1) {
			return sum;
		}
		return 0;
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the two input values : ");
		int number = scanner.nextInt(),number1 = scanner.nextInt();		
		System.out.println(sumDouble(number, number1));
	}
}
