package _7org.ojas.exercise_23_nov_2020;

import java.util.Scanner;

public class _1RussianMultiplication {
	
		static int sum = 0;
		public static void main(String[] args) {
			Scanner scanner = new Scanner(System.in);
			System.out.println("Enter the two numbers for Russian Multipliaction : ");
			int halving = scanner.nextInt();
			int doubling = scanner.nextInt();
			getProduct(halving, doubling);
		}


		static void getProduct(int halving,int doubling) {
			if(halving > 0 && doubling > 0) {
				while(halving > 0) {
					if(halving > 1) {
						if(halving % 2 != 0) {
							sum += doubling;
							halving = halving/2;
							doubling = doubling * 2;
							System.out.print(halving + " ");
							System.out.println(doubling);
						}
						else {
							halving = halving / 2;
							doubling = doubling * 2;
							System.out.print(halving + " ");
							System.out.println(doubling);
						}
					}
					else {
						System.out.println("--Russian Multiplication--");
						System.out.println(sum += doubling);
						break;
					}
				}
			}
			else {
				System.out.println("-1");
			}
	}
}

