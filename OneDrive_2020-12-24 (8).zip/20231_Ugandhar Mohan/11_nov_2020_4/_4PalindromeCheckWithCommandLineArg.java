package org.ojas.exercises_1;

/*Write a program ThreeDPalindrome.java
    In this program accept a 3 digit integer as a command line argument and return the String true      if the integer is a Palindrome or the String false otherwise*/

public class _4PalindromeCheckWithCommandLineArg {
	static String palindromeCheck(int number1) {
		int onesDigit,hundredsDigit;
			onesDigit = number1 % 10;
			hundredsDigit = number1 / 100;
		if(onesDigit == hundredsDigit) {
			return "true";
		}
		return "false";
	}
	
	
	public static void main(String[] mainarr) {
		int number1 =Integer.parseInt(mainarr[0]) ;
		System.out.println(palindromeCheck(number1));
	}
	
}
