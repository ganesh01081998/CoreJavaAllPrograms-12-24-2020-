package org.ojas.padmamam.assignmentPrograms;

//Write a program to accept 4 numbers from command prompt add them using two variables. 

public class AdditionUsingTwoVarBycmdlnarg {
	static int sum = 0;
	static int getAdditionUsingTwoVarBycmdlnarg(int number) {
		sum += number;	
		return sum;
	}
		
		
	public static void main(String[] args) {
		if(args.length < 4) {
			System.out.println("please enter the four input values in commandline arguments");
		}
		else {
			for(int i = 0;i < 4;i++) {
				int number = Integer.parseInt(args[i]);
				sum = getAdditionUsingTwoVarBycmdlnarg(number);
			}
		System.out.println("Sum = " + sum );
		}
	}
	
}
