package org.ojas.padmamam.assignmentPrograms;

import java.util.Scanner;

// 1.Write a program to swap given two numbers without temporary variable 

public class Swapping {
	static void swap(int number1,int number2) {
		System.out.println("Before The Swap number1 = " + number1 + "," + "number2 = " + number2);
		number1 = number1 + number2;
		number2 = number1 - number2;
		number1 = number1 - number2;
		System.out.println("After The Swap number1 = " + number1 + "," + "number2 = " + number2);
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter two numbers : ");
		int number1 = scanner.nextInt();
		int number2 = scanner.nextInt();
		swap(number1, number2);
		
	} 
}
