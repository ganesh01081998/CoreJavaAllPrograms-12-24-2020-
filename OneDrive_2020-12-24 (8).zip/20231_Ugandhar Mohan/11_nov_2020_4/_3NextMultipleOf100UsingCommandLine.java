package org.ojas.padmamam.assignmentPrograms;
/*.Write a program Multiple.java, which accepts an int values as command line argument and           print the next multiple of 100.
    Ex: Input: 35
    Output: 100
    Input: 435
    Output: 500*/
public class NextMultipleOf100UsingCommandLine {
	static int getNextMultipleOf100(int number) {
		if(number > 0) {
			return number = ((number / 100) + 1 )* 100;
		}
		return number;		
	}
	
	
	public static void main(String[] args) {
		int number = Integer.parseInt(args[0]);
		System.out.println("Next Multiple Of 100 for  " + args[0] + " is --> " + getNextMultipleOf100(number));
	}
}
