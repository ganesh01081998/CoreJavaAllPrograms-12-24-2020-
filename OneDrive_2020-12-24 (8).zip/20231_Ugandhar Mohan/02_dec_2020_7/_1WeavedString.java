package _11org.ojas.exercise_2_dec_2020;

import java.util.Scanner;

public class _1WeavedString {
	String getWeavedString(String input1,String input2) {
		String result = "";
		if(input1.length() >= input2.length()) {
			for(int loop = 0;loop < input2.length() ;loop++) {
				result += "" + input2.charAt(loop) + "" +  input1.charAt(loop);
			}
			result += input1.substring(input2.length(),input1.length());
		}
		else {			
				for(int loop = 0;loop < input1.length() ;loop++) {
					result += "" + input1.charAt(loop) + "" +  input2.charAt(loop);
				}
				result += input2.substring(input1.length(),input2.length());			
		}
		return result;
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		_1WeavedString ws = new _1WeavedString();
		System.out.println("Enter the String input : ");
		String input1 = scanner.next();
		input1 = removeDuplicates(input1);
		if(input1 .equals("")) {
			System.out.println("-1");
			System.exit(0);
		}
		System.out.println("Enter the Secound String input : ");
		String input2 = scanner.next();
		input2 = removeDuplicates(input2);
		if(input1 .equals("")) {
			System.out.println("-1");
			System.exit(0);
		}
		System.out.println(ws.getWeavedString(input1,input2));
	}
	
	
	static String removeDuplicates(String str) {
		String str1 = "" ; int flag = 0;
		for(int i = 0;i < str.length();i++) {
			for(int j = i + 1;j < str.length();j++) {
				if(str.charAt(i) == str.charAt(j)) {
					flag++;
				}				
			}
			if(flag == 0) {
				str1 +="" + str.charAt(i);
				}
			flag = 0;
		}
		return str1;
	}
}
