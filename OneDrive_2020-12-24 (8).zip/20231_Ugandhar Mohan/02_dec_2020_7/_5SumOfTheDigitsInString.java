package _11org.ojas.exercise_2_dec_2020;

import java.util.Scanner;

public class _5SumOfTheDigitsInString {
	int getAdditionInString(String str) {
		int result = 0;		
		int number = Integer.parseInt(str);
		while(number > 0) {
			int lastDigit = number % 10;
			result += lastDigit;
			number /= 10;		
		}
		return result;
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		_5SumOfTheDigitsInString sds = new _5SumOfTheDigitsInString();
		System.out.println("Enter the String with or without Numbers");
		String str = scanner.next().toLowerCase();
		str = str.replaceAll("[^0-9]", "");
		System.out.println("Sum Of The Digits In String count = " + sds.getAdditionInString(str));
	}
}
