package _11org.ojas.exercise_2_dec_2020;

import java.util.Scanner;

public class _4WordsEndsWithYorZ {
	int getCountOfYAndZ(String [] strarr) {
		int count = 0;
		for(int loop = 0;loop < strarr.length;loop++) {
			String temp = strarr[loop];
			char character = temp.charAt(temp.length() - 1);
			if(Character.isLetter(character)) {
			if(character == 'y' || character == 'z') {
				count++;
			}
			}
		}
		return count;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		_4WordsEndsWithYorZ wewyz = new _4WordsEndsWithYorZ();
		System.out.println("Enter the Sentence");
		String str = scanner.nextLine().toLowerCase();
		String [] strarr = str.split(" ");
		System.out.println("Words Ends With YorZ count = " + wewyz.getCountOfYAndZ(strarr));		
	}
}
