package _11org.ojas.exercise_2_dec_2020;

import java.util.Scanner;

public class _3PalindromicNumber {
	static String result = "";
	static int add = 0; 
	static String getPalindromeList(int number) {
		
		if(isPalindrome(number)) {
			return result;
		}
		else {
			 add += number;
			 result += add + ",";
			int  listElements = getReverse(add);			
			result += listElements + ",";
			getPalindromeList(listElements);			
		}		
		return result.substring(0,result.length()-1);
	}
	
	
	 static int getReverse(int number) {
		 int reverse = 0,lastDigit = 0;
		 while(number > 0) {
				lastDigit = number % 10;
				reverse = (reverse * 10) + lastDigit;
				number /= 10;			
			}
		 return reverse;
	 }
	
	
	static boolean isPalindrome(int number) {
		int temp = number,reverse = 0,lastDigit = 0;
		while(number > 0) {
			lastDigit = number % 10;
			reverse = (reverse * 10) + lastDigit;
			number /= 10;			
		}
		if(temp == reverse) {
			return true;
		}
		return false;
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the number : ");
		int number = scanner.nextInt();
		if(number <= 100 || (number > 999) ) {
			System.out.println("Error");
			System.exit(0);
		}
		System.out.print(getPalindromeList(number) + "This is palindrome Number" );
	}

}
