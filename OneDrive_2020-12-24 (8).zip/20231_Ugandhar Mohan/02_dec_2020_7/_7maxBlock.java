package _11org.ojas.exercise_2_dec_2020;

import java.util.Scanner;

public class _7maxBlock {
	int result = 0,count = 1;
	 
	int getMaxBlockLength(String str) {
		 String strchar = new String();
		try{
		 for(int i = 0;i < str.length();i++) {
			 if(str.charAt(i) == str.charAt(i + 1)) {
				 strchar += "" + str.charAt(i);				 
			 }
		 }
		}
		catch(StringIndexOutOfBoundsException a) {
			count++;
			getMaxBlockLength(strchar);
			
		}
		
		return result = count - 1;
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		_7maxBlock maxblock = new _7maxBlock();
		System.out.println("Enter the String  : ");
		String str = scanner.next().toLowerCase();
		System.out.println(maxblock.getMaxBlockLength(str));
	}
}
