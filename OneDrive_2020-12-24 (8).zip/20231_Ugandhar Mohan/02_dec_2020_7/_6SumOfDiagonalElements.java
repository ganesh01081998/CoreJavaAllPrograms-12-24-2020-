package _11org.ojas.exercise_2_dec_2020;

import java.util.Scanner;

public class _6SumOfDiagonalElements {
	int getDiagonalSum(int [] [] twoDArray) {
		int sum = 0;
		for(int rowIndex = 0;rowIndex < twoDArray.length;rowIndex++) {
			for(int columnIndex = 0;columnIndex < twoDArray[rowIndex].length;columnIndex++) {				
				if(rowIndex == columnIndex) {
					sum += twoDArray[rowIndex][columnIndex];
				}
			}
		}
		return sum;
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		_6SumOfDiagonalElements sde = new _6SumOfDiagonalElements();
		System.out.println("Enter the rows and columns");
		int row = scanner.nextInt();
		int column = scanner.nextInt();
		if(row != 3 || column != 3) {
			System.out.println("-1");
			System.exit(0);
		}
		int [][] twoDArray = new int[row][column];
		System.out.println("Enter the Elements in elements for 3by3 Matrix");
		for(int rowIndex = 0;rowIndex < twoDArray.length;rowIndex++) {
			for(int columnIndex = 0;columnIndex < twoDArray[rowIndex].length;columnIndex++) {				
				twoDArray[rowIndex][columnIndex] = scanner.nextInt();
			}
		}
		System.out.println("Sum Of diagonal Elements = " + sde.getDiagonalSum(twoDArray));
	}
}
