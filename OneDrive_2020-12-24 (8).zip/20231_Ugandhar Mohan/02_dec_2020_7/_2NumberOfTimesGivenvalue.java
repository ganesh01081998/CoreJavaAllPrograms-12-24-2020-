package _11org.ojas.exercise_2_dec_2020;

import java.util.InputMismatchException;
import java.util.Scanner;

public class _2NumberOfTimesGivenvalue {
	static void getCount(int[] inputArray, int givenNumber) {
		int count = 0;
		for(int i = 0;i < inputArray.length;i++) {
			if(inputArray[i] == givenNumber) {
				count++;
			}
		}
		System.out.println("count of " + givenNumber + " is = " + count);
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter the Size :");
		int size = scanner.nextInt();
		if(size == 0) {
			System.out.println("-1");
			System.exit(0);
		}
		System.out.print("Enter " + size + " integer elements only  in array :");
		int [] inputarray = new int[size];			
			for(int i = 0;i < inputarray.length;i++ ) {
				inputarray[i] = scanner.nextInt();
			}
			System.out.print("Enter number for search of count : ");
			int givenNumber = scanner.nextInt();
			getCount(inputarray,givenNumber);						
			}								
}
