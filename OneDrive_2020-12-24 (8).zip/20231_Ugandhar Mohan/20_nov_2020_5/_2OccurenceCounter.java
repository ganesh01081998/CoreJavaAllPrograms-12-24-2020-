package _5org.ojas.exercises_11_nov_2020;

import java.util.InputMismatchException;
import java.util.Scanner;

public class _2OccurenceCounter {
	static void getCount(int[] inputArray, int givenNumber) {
		int count = 0;
		for(int i = 0;i < inputArray.length;i++) {
			if(inputArray[i] == givenNumber) {
				count++;
			}
		}
		System.out.println("Occurence of " + givenNumber + " is = " + count);
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter the Size :");
		int size = scanner.nextInt();
		System.out.print("Enter " + size + " elements in array :");
		int [] inputarray = new int[size];
			try {
			for(int i = 0;i < inputarray.length;i++ ) {
				inputarray[i] = scanner.nextInt();
			}
				System.out.print("Enter number for search of occurence : ");
				int givenNumber = scanner.nextInt();
				getCount(inputarray,givenNumber);						
			}	
			catch(InputMismatchException ime) {
				System.out.println("mismatch input  \n -1");			
			}
			
	}
}
