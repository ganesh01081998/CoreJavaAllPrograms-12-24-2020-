package _5org.ojas.exercises_11_nov_2020;

import java.util.Scanner;

public class _4ArraySum {
		static String getSum(int[] inputArray) {
			String result = "";int sum = 0;
			for(int i = 0;i < inputArray.length;i++) {
				sum += inputArray[i];
			}
			if(sum == 0) {
				return result += "-1";
			}
			return result += sum;
		}
		
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter the Size of an array :");
		int size = scanner.nextInt();
		int intarr[] = new int[size];
		System.out.print("Enter the " + size + " elements only :" );
		for(int i = 0;i < intarr.length;i++) {
			intarr[i] = scanner.nextInt();
		}
		System.out.println(getSum(intarr));
		
	}
}
