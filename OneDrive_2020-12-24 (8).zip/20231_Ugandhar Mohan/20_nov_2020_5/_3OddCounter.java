package _5org.ojas.exercises_11_nov_2020;

import java.util.InputMismatchException;
import java.util.Scanner;

public class _3OddCounter {
	static void getOddCount(int[] inputArray) {
		int count = 0;
		for(int i = 0;i < inputArray.length;i++) {
			if(inputArray[i] % 2 != 0) {
				count++;
			}
		}
		System.out.println("Odd numbers of given Number is = " + count);
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter the Size only 10 :");
		int size = scanner.nextInt();
		
				try {
					if(size == 10) {
						System.out.print("Enter " + size + " elements in array :");
						int [] inputarray = new int[size];
						for(int i = 0;i < inputarray.length;i++ ) {
							inputarray[i] = scanner.nextInt();
						}
						getOddCount(inputarray);					
					}
					else{System.out.println("-1");}
					
				}
				catch(InputMismatchException ime) {
					System.out.println("mismatch input  \n -1");			
				}
			}
			
	}
	

