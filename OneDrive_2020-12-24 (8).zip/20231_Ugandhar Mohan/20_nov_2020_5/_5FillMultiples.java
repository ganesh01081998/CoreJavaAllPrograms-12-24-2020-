package _5org.ojas.exercises_nov_20_2020;

import java.util.Scanner;

public class _5FillMultiples {
	static void getMultiplesArray(int number) {
	String result = "";
	int mularr[] = new int[10];
	int multiply = 1;
	for(int i = 0;i < mularr.length  ;i++) {
		mularr[i]= number * multiply  ;
		multiply++;
	}
		for(int variable : mularr) {
			System.out.println(variable);
		}
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Number for multiples : ");		
		int number = scanner.nextInt();
		if(number <= 0) {
			System.out.println("null");
		}
		else {			
			getMultiplesArray(number);
		}				
	}
}
