package _5org.ojas.exercises_11_nov_2020;

import java.util.Scanner;

public class _1Eventlist {
	static String result = "";
	
	 static void getEvenArray(int[] inputArray) {
		 int evenarry[] = new int[inputArray.length];
		 for(int a = 0;a < inputArray.length;a++) {
			 if(inputArray[a] % 2 == 0) {
				 evenarry[a] = inputArray[a];
			 }
		 }
		 for(int variable : evenarry) {
			 if(variable != 0){
			 result += variable + " ";
			 }			 
		 }		
		 if(evenarry[0] == 0) {			 
				result += "Empty array"; 
			 }
		 System.out.println(result);		
	 }
	
	 
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Size of an array as 10 only : ");
		int size = scanner.nextInt();	
		//If the input array size is not equal to 10, return null.
		if(size != 10) {
			System.out.println("null");
			System.exit(size);
		}
		else {
			 int intarray[] = new int[size];
				System.out.println("Enter the " + size + " elements  : ");
			for(int i = 0;i < intarray.length;i++) {
				intarray[i] = scanner.nextInt();
			}
			getEvenArray( intarray);
		
			
		}
	}

	
}
