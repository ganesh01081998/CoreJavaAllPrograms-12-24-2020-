package _19_org.ojas.exercise_21_dec_2020;

import java.util.Scanner;

class LeaveQuotaExceededException extends Exception {
		public  LeaveQuotaExceededException(String mess) {
			super(mess);
		}
}


public class _1a_OnlineLeaveManagement {
	int leaves;
	public _1a_OnlineLeaveManagement() {
		leaves = 20;
	}
	
	void timeOffCheck(int apllyLeavesNo) throws LeaveQuotaExceededException  {
		if(apllyLeavesNo < this.leaves) {
			System.out.println("Take Holidays");
		}			
		else {
			throw  new LeaveQuotaExceededException("Sorry You dont have That Much leaves");
		}		
	}
	
	public static void main(String[] args) throws LeaveQuotaExceededException {
		Scanner scanner = new Scanner(System.in);
		_1a_OnlineLeaveManagement obj = new _1a_OnlineLeaveManagement();
		System.out.println("Enter the How many Days Of TimeOFf :");
		obj.timeOffCheck(scanner.nextInt());
	}
	
	
}
