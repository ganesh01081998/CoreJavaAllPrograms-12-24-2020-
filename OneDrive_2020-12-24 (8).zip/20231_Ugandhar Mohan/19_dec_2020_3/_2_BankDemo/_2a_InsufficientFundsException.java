package _19_org.ojas.exercise_21_dec_2020;

public class _2a_InsufficientFundsException extends Exception {		
	public _2a_InsufficientFundsException(String mess) {
		super(mess);
	}
}
