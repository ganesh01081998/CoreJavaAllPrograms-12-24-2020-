package _19_org.ojas.exercise_21_dec_2020;

import java.util.Scanner;

public class _2c_BankDemo {
	public static void main(String[] args) throws _2a_InsufficientFundsException {			
	Scanner scanner = new Scanner(System.in);
	_2b_CheckingAccount checkingAccount = new _2b_CheckingAccount();
	System.out.println("Enter the account num : ");
	if(checkingAccount.checkAccount(scanner.nextInt())) {
	System.out.println("Enter the Deposit Amount :");
	checkingAccount.deposit(scanner.nextInt());
	System.out.println("Enter the withDraw Amount :");
	System.out.println("Your account is withdrawn currentbalance " + checkingAccount.withDraw(scanner.nextInt()));
	}
	else {
		System.out.println("Your account Num is wrong");
	}
	}
}
