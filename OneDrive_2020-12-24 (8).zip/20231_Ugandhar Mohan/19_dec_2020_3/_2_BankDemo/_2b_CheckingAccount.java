package _19_org.ojas.exercise_21_dec_2020;

public class _2b_CheckingAccount {
	int accountNo = 554455;
	double balance;	
	boolean checkAccount(int accountNo1) {
		if(this.accountNo == accountNo1) {
			return true;
		}
		return false;
		
	}
	void deposit(int amount) {
		balance += amount;
		System.out.println("Your "+ accountNo + " is deposited currentbalance " + balance );
	}
	
	double withDraw(int amount) throws  _2a_InsufficientFundsException{	
		if(balance > amount) {
			return balance -= amount;
		}
		else {
			throw new _2a_InsufficientFundsException("You dont have such amount in your account");
		}		
	}
}
