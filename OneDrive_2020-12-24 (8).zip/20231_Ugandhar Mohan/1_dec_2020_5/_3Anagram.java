package _10org.ojas.exercise_01_nov_2020;

import java.util.Arrays;
import java.util.Scanner;

public class _3Anagram {
	static String checkAnagrams(String input1,String input2) {
		String result = "Not Anagrams",sortInput1 = "",sortInput2 = "";
		char [] strarr1 = input1.toCharArray();
		char [] strarr2 = input2.toCharArray();
		Arrays.sort(strarr1);
		Arrays.sort(strarr2);
		for(int loop = 0;loop < strarr1.length;loop++) {
			sortInput1 += "" + strarr1[loop];
			sortInput2 += "" + strarr2[loop];
		}
		if(sortInput1.equals(sortInput2)) {
			return result = "Anagrams";
		}
		return result;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the first String : ");
		String str1 = scanner.nextLine().toLowerCase();
		if(str1.equals("")) {
			System.out.println("null");
			System.exit(0);			
		}
		System.out.println("Enter the Secound string : ");
		String str2 = scanner.nextLine().toLowerCase();
		if(str2.equals("")) {
			System.out.println("null");
			System.exit(0);
		}
		System.out.println(checkAnagrams(str1, str2));
	}
}
