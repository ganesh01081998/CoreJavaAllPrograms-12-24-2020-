package _10org.ojas.exercise_01_nov_2020;

import java.util.Scanner;

public class _1StringManipulator {
	static String removeVowels(String str) {
		String result = "";
			for(int i = 0;i < str.length();i++) {
				char ch = str.charAt(i);
				if(ch != 'a' && ch != 'e' && ch != 'i' && ch != 'o' && ch !='u') {
					result += ch + " "; 
				}
			}
			return result;
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter the inputstring : ");
		String str = scanner.nextLine();		
//		if(str.length() == 0)
//		{
//			System.out.println("null");
//		}
		if(str.equals("")) {
			System.out.println("null");
		}
		str = str.replaceAll("[^a-zA-Z0-9]","");				
		System.out.println(removeVowels(str).replace(" ", ""));
	}	   
}  

