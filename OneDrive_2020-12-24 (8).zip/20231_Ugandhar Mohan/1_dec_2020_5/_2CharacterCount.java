package _10org.ojas.exercise_01_nov_2020;

import java.util.Scanner;

public class _2CharacterCount {
	static void toFind(String str) {
		int count = 0;
		String str1 = "" ; int flag = 0;
		for(int i = 0;i < str.length();i++) {
			for(int j = i + 1;j < str.length();j++) {
				if(str.charAt(i) == str.charAt(j)) {
					flag++;
				}				
			}
			if(flag == 0) {
				str1 +="" + str.charAt(i);
				}
			flag = 0;
		}		
		for(int i = 0;i < str1.length();i++) {
			for(int j = 0; j< str.length();j++) {
				if(str1.charAt(i) == str.charAt(j)) {
					count ++;		
				}
			}
			System.out.println(str1.charAt(i) + " is occurred " + count + " Times ");
			count = 0;
			}
		}

	
	public static void main(String[] args) {		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the String : ");
		String str = scanner.nextLine().toUpperCase();
		if(str.equals("")) {
			System.out.println("-1");
		}
		str = str.replaceAll("[^a-zA-Z0-9]","");
		toFind(str);
		
	}
}
