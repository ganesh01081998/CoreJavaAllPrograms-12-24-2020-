package _10org.ojas.exercise_01_nov_2020;

import java.util.Scanner;

public class _5DateFormatter {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the DOB as DD-MonthName-YYYY : \n only using separators (,) and (space)");
		try {
		String str = scanner.nextLine().replaceAll(",", "").toLowerCase();
		str = str.replace(" ", "");
		String monthName = str.substring(2, str.length()-4);		
		int monthnum = getMonthNum(monthName);		
		System.out.println(str.substring(str.length() - 4, str.length()) + "-" + monthnum + "-" + str.substring(0,2));	
		}
		catch(Exception e) {
			System.out.println("null");
		}
	}
	
	
	static int getMonthNum(String str) {
		int result = 0;
		str = str.toLowerCase();		
		String [] mothFullname = {"january","febraury","march","april","may","june","july","august","september","october","november","december"};
		String [] monthNames = {"jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec"};
		int monthDaysarr [] = {01,02,03,04,05,06,07,8,9,10,11,12};
		if(str.length() > 3) {
			for(int i = 0;i < mothFullname.length;i++) {
				if(str .equals(mothFullname[i])) {
					return result = monthDaysarr[i]; 
				}
			}
		}
		else {
		for(int i = 0;i < monthNames.length;i++) {
			if(str .equals(monthNames[i])) {
				return result = monthDaysarr[i]; 
			}
		}
		}
		return result;
	}
}
