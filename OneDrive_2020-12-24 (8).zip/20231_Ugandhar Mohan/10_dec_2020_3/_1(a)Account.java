package _15org.ojas.exercise_10_dec_2020;

import java.util.Random;
import java.util.Scanner;

public class Account {
	static Scanner scanner = new Scanner(System.in);
	static Customer customer;
	static double balance;
	static int accoutNum;	
	static int accoutNumCheck;
	static double deposit(double amount) {
		System.out.println("Enter the Account Number : ");
		accoutNumCheck = scanner.nextInt();
		if(accoutNum == accoutNumCheck) {
			 balance += amount;
		}	
		else { 
			System.out.println("Soory Account Number incorrect");
		}
		return 	balance;	
	}
	
	static double withdraw(double amount) {
		System.out.println("Enter the Account Number : ");
		accoutNumCheck = scanner.nextInt();
		if(accoutNum == accoutNumCheck) {
			 balance -= amount;
		}	
		else { 
			System.out.println("Soory Account Number incorrect");
		}
		return 	balance;	
		    
	}
	
	public Account(double balance,int accoutNum,Customer customer) {
		this.accoutNum = accoutNum;
		this.balance = balance;
		this.customer = customer;
	}
	
	
	@Override
	public String toString() {
		return  "Hello " + customer.getFirstName()+customer.getLastName() + " Your account Opened with " +" balance=" + balance + ", accoutNum=" + accoutNum + "]";
	}

	
	static Account openingAccount() {
		System.out.println("Enter the Firstname and LastName : ");
		Customer customer = new Customer(scanner.next(),scanner.next());
		Random random = new Random();
		System.out.println("Enter Account openeing Balance : ");
		Account account = new Account(scanner.nextInt(),Math.abs(random.nextInt(99999999)), customer);	
		return account;		
	}
	
	public static void main(String[] args) {
		while(true)		{
			String str = "Welcome to Ojas Bank\n";
			str += "Select one Banking option\n";
			str += "1.Account open\n";
			str += "2.Deposit\n";
			str +="3.Withdrawl\n";
			str +="4.Exit";
			System.out.println(str);
			System.out.println("Enter the Selection ");
			int selection = scanner.nextInt();			
			switch (selection) {
			case 1: 			
					System.out.println(openingAccount()+"\n");
					System.err.println("--Select Banking option Apart Of Account opening--");
					break;
			case 2 :
					System.out.println("--Enter the Ammount -- ");
					int amount = scanner.nextInt();					 					 
					System.out.println("--Hello " + customer.getFirstName()+customer.getLastName()+ " " + amount + "/-Rs Deposited and  \nYour Current Balance : " + deposit(amount) + "/-Rs Only--");					 
					break;
			case 3 :
					System.out.println("--Enter the Ammount -- ");
					int amount1 = scanner.nextInt(); 
					System.out.println("--Hello " + customer.getFirstName()+customer.getLastName()+ " " + amount1 + "/-Rs Withdrawn and  \nYout Current Balance : " + withdraw(amount1) + "/-Rs Only--");	
					break;
			case 4 :
					System.out.println("Thank you");
					System.exit(4);
					}
			
			}
		}		
}

