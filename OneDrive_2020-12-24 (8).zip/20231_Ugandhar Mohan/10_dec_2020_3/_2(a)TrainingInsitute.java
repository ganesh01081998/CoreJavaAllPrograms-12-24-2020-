package _15org.ojas.exercise_10_dec_2020;

import java.util.Random;
import java.util.Scanner;

public class TrainingInsitute {
	static Scanner scanner = new Scanner(System.in);	
		int sId;
		String sName;
		StudentAddress studentAddress;
		public TrainingInsitute(int sId, String sName, StudentAddress studentAddress) {
			this.sId = sId;
			this.sName = sName;
			this.studentAddress = studentAddress;
		}
		
		@Override
		public String toString() {
			return "TrainingInsitute [sId=" + sId + ", sName=" + sName +" " + studentAddress + "]";
		}
		
		public static void main(String[] args) {			
			Random random = new Random();
			System.out.println("Enter the dNo , areaName , cityName , Name :");
			StudentAddress studentAddress = new StudentAddress(scanner.next(),scanner.next() ,scanner.next());
			TrainingInsitute trainingInsitute = new TrainingInsitute(Math.abs(random.nextInt(99999)), scanner.next(), studentAddress);
			System.out.println(trainingInsitute);
			System.out.println("Choose any Courses you want");
			CourseDetails courseDetails = new CourseDetails();
			int number = 1;
			for(String variable : courseDetails.courseNames ) {
				System.out.println(number + "." + variable);
				number++;
			}
			System.out.println("How many courses do you want : ");
			int numberOfCourses = scanner.nextInt();
			System.out.println("Enter the Courses you want : ");
			String selectedCoursenames[] = new String[numberOfCourses];
			for(int i = 0;i < selectedCoursenames.length;i++) {
				selectedCoursenames[i] = scanner.next();
			}
			int duration = 0,fee = 0;
			for(int i = 0;i < selectedCoursenames.length;i++) {
				for(int j = 0;j < courseDetails.courseNames.length;j++) {
				if(selectedCoursenames[i].equals(courseDetails.courseNames[j])) {
					System.out.println("--"+selectedCoursenames[i] + " Have fee " + courseDetails.coursefee[j] + "K/- Rs" +" and duration "+ courseDetails.duration[j] + "months--");
					duration += courseDetails.duration[j];
					fee += courseDetails.coursefee[j];
				}
				}
			}
			System.out.println("Total duration of the course : " + duration + "months");
			System.out.println("Total fee have To Pay : "  + fee + "K/- Rs");
		}
}
