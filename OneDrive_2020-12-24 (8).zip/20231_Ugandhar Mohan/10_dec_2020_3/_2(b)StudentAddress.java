package _15org.ojas.exercise_10_dec_2020;

public class StudentAddress {
	String dNo;
	String areaName;
	String cityName;
	
	
	public StudentAddress() {		
	}

	public StudentAddress(String dNo, String areaName, String cityName) {	
		this.dNo = dNo;
		this.areaName = areaName;
		this.cityName = cityName;
	}

	@Override
	public String toString() {
		return "StudentAddress [dNo=" + dNo + ", areaName=" + areaName + ", cityName=" + cityName + "]";
	}
	
	
}
