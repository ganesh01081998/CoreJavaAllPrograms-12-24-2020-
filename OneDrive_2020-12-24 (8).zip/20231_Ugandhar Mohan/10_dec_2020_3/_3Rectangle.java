package _15org.ojas.exercise_10_dec_2020;

import java.util.Scanner;

import javax.swing.plaf.basic.BasicInternalFrameTitlePane.MoveAction;

public class _3Rectangle {
	static Scanner scanner = new Scanner(System.in);
	int x1;
	int y1;
	int x2;
	int y2;
	int width;
	int height;
	public _3Rectangle(int x1,int y1,int height,int width) {
		this.x1 = x1;
		this.y1 = y1;
		this.x2 = height;
		this.y2 = width;		
	}			
		
	int getHeight() {
		return getPerimeter()/2 - y2;		
	}
	
	int getWidth() {
		return getPerimeter()/2 - x2;
	}
	
	int getPerimeter() {
		return 2*(x2 + y2);
	}
	
	int getArea() {
		return x2*y2;
	}
	
	boolean isPointInside(int xaxis,int yaxis) {
		if(xaxis >= x1 && yaxis >= y1 && xaxis <= x2 && yaxis <= y2) {
			return true;
		}
		return false;		
	}
	
	int[] move(int deltax, int deltay) {
		int [] newPoints = new int[4];
		newPoints[0] = deltax;
		newPoints[1] = deltay;
		newPoints[2] = deltax + x2;
		newPoints[3] = deltay + y2;
		return newPoints; 
	}
	
	public static void main(String[] args) {
		System.out.println("Enter the  Height And Width  Of Rectangle");		
		_3Rectangle rectangle = new _3Rectangle(0, 0, scanner.nextInt(), scanner.nextInt());
		String result = "(x1,y1) = " + "(" + rectangle.x1 + "," + rectangle.y1 +")\n" + "(x2,y2) = " + "(" + rectangle.x2 + "," + rectangle.y2 +")\n";
		result += "Perimeter of Rectangle : " + rectangle.getPerimeter() + "\n";
		result += "Height of Rectangle : " + rectangle.getHeight() + "\n";
		result += "Width of rectangle : " + rectangle.getWidth() + "\n";
		result += "Area of Rectangle : " + rectangle.getArea() + "\n";
		System.out.println(result);
		System.out.println("Enter the Points to check Inside of Rectangle");
		System.out.println("Is point Inside th Rectangle : " + rectangle.isPointInside(scanner.nextInt(), scanner.nextInt()));
		System.out.println("--Give New Points of x1,y1 only-- and o/p is x1,y1,x2,y2");
		for(int variable : rectangle.move(scanner.nextInt(), scanner.nextInt())) {
			System.out.print(variable + " ");
		}
	}
}
