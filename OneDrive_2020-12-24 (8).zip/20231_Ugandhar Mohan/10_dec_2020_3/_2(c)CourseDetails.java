package _15org.ojas.exercise_10_dec_2020;

public class CourseDetails {
		String courseNames[] = {"java","python","dataScience"};
		int coursefee[]  = {20,25,15};
		int duration[] = {4,5,3};		
		public CourseDetails(String[] courseNames, int[] coursefee, int[] duration) {		
			this.courseNames = courseNames;
			this.coursefee = coursefee;
			this.duration = duration;		
		}
		public CourseDetails() {
			// TODO Auto-generated constructor stub
		}
		
}
