package _8org.ojas.exercise_25_nov_2020;

import java.util.Scanner;

public class _3RecursiveSelectionSort {
	static Scanner scanner = new Scanner(System.in);
	static void swap(int [] arr,int min ,int baseIndex) {
		int temp = arr[min];
		arr[min] = arr[baseIndex];				
		arr[baseIndex] = temp;
	}
	
	
	static void selectionSort(int [] arr,int baseIndex,int length) {
		int min = baseIndex;
			for(int loop = baseIndex + 1;loop < length;loop++) {		
				if(arr[loop] < arr[min]) {
					min = loop;						
				}			
			}
			swap(arr,min,baseIndex);
			if(baseIndex + 1 < length){
				selectionSort(arr, baseIndex + 1, length);
			}
	}
	
		
	public static void main(String[] args) {
		System.out.println("Enter the size : ");
		int size = scanner.nextInt();
		int arr[] = new int[size];
		readArray(arr,size);	
		selectionSort(arr,0,size);
		System.out.println("--Sorted Array--");
		for(int variable : arr) {
			System.out.print(variable + " ");
		}
	}
	
	static void readArray(int arr[],int size) {
		System.out.print("Enter the Elements :");
		for(int i = 0;i < size;i++) {
			arr[i] = scanner.nextInt();
		}		
	}
}
