package _8org.ojas.exercise_25_nov_2020;

import java.util.Arrays;
import java.util.Scanner;

public class _1BinarySearch {	
	static int binarySearch(int arr[],int index,int length,int searchElement) {		
		if(length >=index) {
			int mid =  index + length - 1 / 2;		
		if(arr[mid] == searchElement) {
			return mid;
		}
		if(arr[mid] > searchElement) {
			return binarySearch(arr, index, mid - 1, searchElement);
		}		
			return binarySearch(arr, mid + 1, length , searchElement);		
		}
		return -1;
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Size : ");
		int size = scanner.nextInt();		
		int arr[] =new int[size];
		System.out.println("Enter only integer  elements : ");
		for(int i = 0;i < size;i++) {
			arr[i] = scanner.nextInt();
		}
		Arrays.sort(arr);		
		System.out.println("Enter the ELement you Want to Search : ");
		int searchElement = scanner.nextInt();
		System.out.println(binarySearch(arr,0,size - 1,searchElement));
	}
}
