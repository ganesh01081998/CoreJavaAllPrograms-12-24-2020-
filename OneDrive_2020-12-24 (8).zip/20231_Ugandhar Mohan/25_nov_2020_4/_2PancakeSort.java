package org.ojas.Prac.Arrays;

import java.util.Scanner;

public class _2PancakeSort {	
	static Scanner scanner = new Scanner(System.in);
	static void flip(int arr[], int index)
	{		
		int temp, start = 0;
			temp = arr[start];
			arr[start] = arr[index];			
			arr[index] = temp;			
	}

	
	static int pancakeSort(int arr[], int length)
	{		
		for (int curr_size = length; curr_size > 1; curr_size--)
		{			
			int index = findMax(arr, curr_size);
			if (index != curr_size-1)
			{		
				//For First flip it swaps the max element into 0 index
				flip(arr, index);				
				//for secound flip it swaps the element into current-size last index 
				flip(arr, curr_size-1);																								
			}
		}
		return 0;
	}
	

	static int findMax(int arr[], int curr_size)
	{
		int index = 0, i;
		for (i = 0; i < curr_size; i++) {
			if (arr[i] > arr[index]){
				index = i;
			}
		}
		return index;
	}
	
	static void readArray(int arr[],int size) {
		System.out.print("Enter the Elements :");
		for(int i = 0;i < size;i++) {
			arr[i] = scanner.nextInt();
		}		
	}
	
	
	static void printArray(int arr[], int arr_size)
	{
		for (int i = 0; i < arr_size; i++)
			System.out.print(arr[i] +" ");
	}
	
	public static void main (String[] args)
	{		
		System.out.println("Enter the size : ");
		int size = scanner.nextInt();
		int arr[] = new int[size];
		readArray(arr,size);			
		pancakeSort(arr, size);		
		System.out.println("--Sorted Array--");
		printArray(arr, size);
	}
	
	

}
