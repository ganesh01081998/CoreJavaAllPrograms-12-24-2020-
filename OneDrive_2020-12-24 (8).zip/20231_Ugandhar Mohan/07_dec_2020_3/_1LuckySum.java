package _14org.ojas.exercise_07_dec_2020;

/* Given 3 int values, a b c, return their sum. However, if one of the values is 13 then it does not count towards the sum and values to its right do not count. So for example, if b is 13, then both b and c do not count.
	luckySum(1, 2, 3) → 6
	luckySum(1, 2, 13) → 3
	luckySum(1, 13, 3) → 1
	luckySum(13,2,4) -> 0
	luckySum(13,13*/

import java.util.Scanner;

public class _1LuckySum {
	 int getSum(int number1,int number2,int number3) {
		int result = 0;
		if(number1 != 13) {
			result += number1;
		} 
		else {
			return result; 
		}
		if(number2 != 13) {
			result += number2;
		} 
		else {
			return result; 
		}
		if(number3 != 13) {
			result += number3;
		} 		
		return result;			
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		_1LuckySum ls = new _1LuckySum();
		System.out.println("Enter the Three Integer Inputs to LuckySum");
		int number1 = scanner.nextInt(),number2 = scanner.nextInt(),number3 = scanner.nextInt();
		System.out.println(ls.getSum(number1,number2,number3));
	}
}
