package _14org.ojas.exercise_07_dec_2020;

import java.util.Scanner;

/*.Given a string, return the sum of the digits 0-9 that appear in the string, ignoring all other characters. Return 0 if there are no digits in the string. 
 * (Note: Character.isDigit(char) tests if a char is one of the chars '0', '1', .. '9'. Integer.parseInt(string) converts a string to an int.)
	sumDigits("aa1bc2d3") → 6
	sumDigits("aa11b33") → 8
	sumDigits("Chocolate") → 0*/

public class _2SumDigits {
	int getSum(String str) {
		int result = 0;
		for(int i = 0;i < str.length();i++) {
			if(Character.isDigit(str.charAt(i))) {
				result += Integer.parseInt("" + str.charAt(i));
			}
		}
		return result;
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		_2SumDigits sd = new _2SumDigits();
		System.out.println("Give a string, return the sum of the digits 0-9 that appear in the string : ");
		String str = scanner.next();
		System.out.println("Sum of the Digits in Given String :" + sd.getSum(str));
	}
}
