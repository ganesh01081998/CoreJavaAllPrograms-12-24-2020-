package _12org.ojas.exercise._03_dec_2020;

import java.util.Scanner;

/*3. Program to count the number of words in a given sentence*/

public class _3NoOfWordsInGivenSentence {
	int getNoOfWordsInSentence(String [] str) {
		return str.length;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		_3NoOfWordsInGivenSentence nwgs = new _3NoOfWordsInGivenSentence(); 
		System.out.println("Enter the Sentence : ");
		String str = scanner.nextLine();
		String [] strarr = str.split(" ");
		System.out.println("Number of words in Given Sentence : " + nwgs.getNoOfWordsInSentence(strarr));
	}
}
