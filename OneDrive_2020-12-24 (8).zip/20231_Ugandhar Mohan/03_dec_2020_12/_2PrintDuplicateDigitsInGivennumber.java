package _12org.ojas.exercise._03_dec_2020;

import java.util.Scanner;

/*2. Program to print duplicate digits in a given number. For ex: 625345238*/

public class _2PrintDuplicateDigitsInGivennumber {
	String getDuplicateDigits(String numberString) {
		String result = "",removedDup = removeDup(numberString);		
		int flag = 0;
		for(int otloop = 0;otloop < removedDup.length();otloop++) {
			for(int inloop = 0 ;inloop < numberString.length();inloop++) {
				if(removedDup.charAt(otloop) == numberString.charAt(inloop)) {
					flag++;
				}
			}
			if(flag > 1) {
				result += removedDup.charAt(otloop);
			}
			flag = 0;
		}
		return result;
	}
	
	
	String removeDup(String numberString) {
		String remresult = "";
		int flag = 0,loop = 0;
		for( loop = 0 ;loop < numberString.length();loop++) {
			for(int loop1 = loop + 1;loop1 < numberString.length();loop1++) {
			if(numberString.charAt(loop) == numberString.charAt(loop1)) {
				flag++;
			}
			}
			if(flag == 0) {
				remresult += numberString.charAt(loop);
			}
			flag = 0;	
		}
			
		return remresult;
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		_2PrintDuplicateDigitsInGivennumber dg = new _2PrintDuplicateDigitsInGivennumber();
		System.out.println("Enter the Number : ");
		String numberString = scanner.next();
		System.out.println("Duplicate Digits : " + dg.getDuplicateDigits(numberString) );
	}
}
