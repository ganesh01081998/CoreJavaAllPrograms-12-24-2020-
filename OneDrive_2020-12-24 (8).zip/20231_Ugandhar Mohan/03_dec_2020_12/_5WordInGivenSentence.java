package _12org.ojas.exercise._03_dec_2020;

import java.util.Scanner;

/*5. Program to verify if a word is found in the given sentence*/

public class _5WordInGivenSentence {
	String searchWord(String [] strarr,String strword) {
		String result = "not found";
		for(int loop = 0;loop < strarr.length;loop++) {
			if(strword.equals(strarr[loop])) {
				return result = "found";
			}
		}
		return result;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		_5WordInGivenSentence wgs = new _5WordInGivenSentence();
		System.out.println("Enter the Sentence  : ");
		String strword = scanner.nextLine();
		String [] strarr = strword.split(" ");
		System.out.println("Enter the word which have to search in Sentence : ");
		strword = scanner.next();
		System.out.println(strword + " " + wgs.searchWord(strarr,strword) + " in given Sentence");
	}
}
