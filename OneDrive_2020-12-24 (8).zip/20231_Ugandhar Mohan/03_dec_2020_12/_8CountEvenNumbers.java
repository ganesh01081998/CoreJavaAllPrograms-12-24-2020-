package _12org.ojas.exercise._03_dec_2020;

import java.util.Scanner;

/*8.Return the number of even ints in the given array. 
	countEvens([2, 1, 2, 3, 4]) → 3
	countEvens([2, 2, 0]) → 3
	countEvens([1, 3, 5]) → 0 */

public class _8CountEvenNumbers {
	int getCountEvens(int [] intarr) {
		int count = 0;
		for(int loop = 0;loop < intarr.length;loop++) {
			if(intarr[loop] % 2 == 0) {
				count ++;
			}
		}
		return count;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		_8CountEvenNumbers cen = new _8CountEvenNumbers();
		System.out.println("Enter the number array size : ");
		int [] intarr = new int[scanner.nextInt()];
		System.out.println("Enter the Numbers : ");
		for(int loop = 0;loop < intarr.length;loop++) {
			intarr[loop] = scanner.nextInt();			
		}
		System.out.println("Even numbers in given array = " + cen.getCountEvens(intarr));		
	}
}
