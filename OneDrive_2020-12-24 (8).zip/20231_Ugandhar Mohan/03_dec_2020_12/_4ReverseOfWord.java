package _12org.ojas.exercise._03_dec_2020;

import java.util.Scanner;

/*4. Program to print the reverse of a word without using built in methods or libraries*/

public class _4ReverseOfWord {
	String getReversedword(char [] characterArray) {
		String result = "";
		for(int loop = characterArray.length - 1; loop >= 0 ;loop--) {
			result += characterArray[loop];
		}
		return result;
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		_4ReverseOfWord rw = new _4ReverseOfWord();
		System.out.println("Enter the String : ");		
		String str = scanner.next();
		char [] characterArray = str.toCharArray();
		System.out.println("Reversed word :" + rw.getReversedword(characterArray));
	}
}
