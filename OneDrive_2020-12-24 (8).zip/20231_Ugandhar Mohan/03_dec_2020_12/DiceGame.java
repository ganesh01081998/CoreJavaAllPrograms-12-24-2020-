package _12org.ojas.exercise._03_dec_2020;

import java.util.Random;
import java.util.Scanner;

public class DiceGame {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Dice d1 = new Dice();
		Dice d2 = new Dice();
		System.out.println("Enter the First player name");
		Player player1 = new Player(scanner.next());
		System.out.println("Enter  the Secound player name ");
		Player player2 = new Player(scanner.next());
		player1.throwDice(d1, d2);
		player2.throwDice(d1, d2);
		String res = "";
		if(player1.playerValue > player2.playerValue) {
			res = player1.playerName + " wins the Game";
		}
		else if (player2.playerValue > player1.playerValue) {
			res = player2.playerName + " wins the Game";
		}
		else {
			res = "Please re try";
		}
		System.out.println(res);
		
	} 

	}


	 class Player {
		String playerName;
		int playerValue;
		public  Player(String playerName) {
			this.playerName = playerName;
		}
		public void throwDice(Dice d1 ,Dice d2) {
			d1.roll();
			d2.roll();
			playerValue = d1.faceValue + d2.faceValue;
			System.out.println(playerName + " =" + playerValue );						
		}
	}

	 
	  class Dice {
			int faceValue;
			public void roll() {
				Random random = new Random();
				faceValue = random.nextInt(6) + 1;
			}
}
