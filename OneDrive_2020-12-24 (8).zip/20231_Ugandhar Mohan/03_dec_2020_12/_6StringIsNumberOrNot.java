package _12org.ojas.exercise._03_dec_2020;

import java.util.Scanner;

/*6. Program to verify if a given string is number or not
   	Ex: "356", "a785"  */

public class _6StringIsNumberOrNot {
	String isNumberOrNot(String str) {
		String result = "Not a Number";
		try {
			int number = Integer.parseInt(str);
			return result = "Given Input is number";
		}
		catch (NumberFormatException nfe) {
			
		}
		return result;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		_6StringIsNumberOrNot sinon = new _6StringIsNumberOrNot();
		System.out.println("Enter the input : ");
		String str = scanner.next();
		System.out.println(sinon.isNumberOrNot(str));
	} 	
}
