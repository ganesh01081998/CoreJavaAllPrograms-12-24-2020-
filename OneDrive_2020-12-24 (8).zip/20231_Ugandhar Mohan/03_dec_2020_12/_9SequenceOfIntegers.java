package _12org.ojas.exercise._03_dec_2020;

import java.util.Scanner;

/*9. Given start and end numbers, return a new array containing the sequence of integers from start up to but not including end, so start=5 and end=10 yields {5, 6, 7, 8, 9}. The end number will be greater or equal to the start number. Note that a length-0 array is valid.
	fizzArray3(5, 10) → [5, 6, 7, 8, 9]
	fizzArray3(11, 18) → [11, 12, 13, 14, 15, 16, 17]
	fizzArray3(1, 3) → [1, 2]*/

public class _9SequenceOfIntegers {
	int [] fizzArray(int[] intarr,int number1,int number2) {
		int index = 0;
		for(int loop = number1;loop < number2;loop++){
			intarr[index] = loop;					
			index++;
		}
		return intarr;
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		_9SequenceOfIntegers soi = new _9SequenceOfIntegers();
		System.out.println("Enter the range Of to Get Sequence of Integers");
		int number1 = scanner.nextInt(),number2 = scanner.nextInt();
		int [] intarr = new int [Math.abs(number1 - number2)];
		soi.fizzArray(intarr,number1,number2);
		for(int variable : intarr) {
			System.out.print(variable + " ");
		}
		
	}
}
