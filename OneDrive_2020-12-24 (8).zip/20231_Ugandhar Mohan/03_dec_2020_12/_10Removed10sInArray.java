package _12org.ojas.exercise._03_dec_2020;

import java.util.Arrays; 
import java.util.Scanner;

public class _10Removed10sInArray {
	static void getRemove10sInArray(int [] intarr) {
		int [] intarr1 = new int[intarr.length];
		for(int i = 0;i < intarr.length;i++) {
			if(intarr[i] == 10) {
				intarr[i] = 0;
			}
		}
		int index = 0;
		for(int i = 0;i < intarr.length;i++) {
			if(intarr[i] != 0) {
				intarr1[index] = intarr[i];
				intarr[i] = 0;
				index++;
			}
		}
		for(int i = 0;i < intarr1.length;i++) {
			intarr[i] = intarr1[i];
		}
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Size : ");
		int size = scanner.nextInt();
		int [] intarr = new int[size];
		System.out.println("Enter the Elements : ");
		for(int i = 0;i < intarr.length;i++) {
			intarr[i] = scanner.nextInt();
		}
		getRemove10sInArray(intarr);
		System.out.println(Arrays.toString(intarr));
	}
}
