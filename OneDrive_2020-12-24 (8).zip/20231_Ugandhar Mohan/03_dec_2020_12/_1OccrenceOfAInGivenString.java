package _12org.ojas.exercise._03_dec_2020;

/*Program to print the number of occurrences of the character 'a' in the given word 'paramahamsa'*/

import java.util.Scanner;

public class _1OccrenceOfAInGivenString {
	int occurenceOFA(String str) {
		int flag = 0;
		for(int loop = 0;loop < str.length();loop++) {
			if('a' == str.charAt(loop)) {
				flag++;
			}
		}		
		return flag;
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		_1OccrenceOfAInGivenString ogs = new _1OccrenceOfAInGivenString();
		System.out.println("Enter the String : ");
		String str = scanner.next().toLowerCase();
		System.out.println("Count Of 'A' in Given String is : " + ogs.occurenceOFA(str));
	}
}
