package _12org.ojas.exercise._03_dec_2020;

import java.util.Scanner;

/*7. Program to print the sum of the digits of the given number
	Ex: 259. 2 + 5 + 9 = 16 */

public class _7SumOftheDigits {
	int getSumOfGivenNumber(int number) {
		int result = 0,lastDigit;
		while(number > 0) {
			lastDigit = number % 10;
			result += lastDigit;
			number /= 10;			
		}
		return result;
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		_7SumOftheDigits sod = new _7SumOftheDigits();
		System.out.println("Enter the Number : ");
		int number = scanner.nextInt();
		System.out.println("Sum of the Given Number = " + sod.getSumOfGivenNumber(number));
	}
}
