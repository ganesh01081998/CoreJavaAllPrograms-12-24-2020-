package _3org.ojas.exercise;

import java.util.Scanner;

public class _6AbsoluteDiff {
	static String  getAbsoluteDiff(int number) {
		String result = "";
		if(number > 21) {
			result += ((number - 21) * 2);
		}
		else {
			result += (21 - number);
		}
		return result;
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the number : ");
		int number = scanner.nextInt();
		System.out.println(getAbsoluteDiff(number));
	}
}
