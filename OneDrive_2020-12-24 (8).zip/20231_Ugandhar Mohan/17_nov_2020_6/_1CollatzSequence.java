package _3org.ojas.exercise;

import java.util.Scanner;

public class _1CollatzSequence {
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("Enter the number for collatx sequence : ");
	int number = scanner.nextInt();
	System.out.println(getCollatzSequence(number));
}


	static String getCollatzSequence(int number) {
		String result = "";
		System.out.println("--collatz Sequence--");
		result += number + " ";
		while (number > 1) {
			
			if(number > 1) {
				if(number % 2 ==0) {
					number = number/2;
					result += number + " ";
				}
				else {
					number = (number * 3) + 1;
					result += number + " ";
				}
			}
		}
		return result;
	}
	 

}
