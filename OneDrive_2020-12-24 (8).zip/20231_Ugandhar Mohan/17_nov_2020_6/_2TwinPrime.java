package _3org.ojas.exercise;

import java.util.Scanner;

public class _4TwinPrime {
	static boolean isPrime(int number) {
		int flag = 0;
		for(int i = 2;i < number;i++) {
			if(number % i == 0) {
				flag++;
				break;
			}
		}
		if(flag ==0) {
			return true;
		}
	return false;
	}
	
	static String getRangeOfPrime(int number1,int number2) {
		String result = "";
		for(int i =  number1;i <= number2;i++) {
		if(isPrime(i) && isPrime(i + 2)) {
			result += i + " " + (i + 2) + "\n";
		}
		
		}
		return result;
	}
	
	
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("Enter the Range : ");
	System.out.println("--Twin Prime Numbers--\n" + getRangeOfPrime(scanner.nextInt(), scanner.nextInt()));
} 

}
