package _3org.ojas.exercise;

import java.util.Scanner;

public class _2RussianMul {
	static int sum = 0;
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("Enter the two numbers for Russian Multipliaction : ");
	int halving = scanner.nextInt();
	int doubling = scanner.nextInt();
	System.out.println(russianMultiplication(halving, doubling));
}


	static String russianMultiplication(int halving,int doubling) {
		String result = "";
	while(halving > 0) {
		if(halving > 1) {
			if(halving % 2 != 0) {
				sum += doubling;
				halving = halving/2;
				doubling = doubling * 2;
				result += halving + " ";
				result += doubling + "\n";
			}
			else {
				halving = halving / 2;
				doubling = doubling * 2;
				result += halving + " ";
				result += doubling + "\n";
			}
		}
		else {
			System.out.println("--Russian Multiplication--");
			result += (sum +=doubling);
			break;
		}
		
	}
	return result;
}
}
