package _3org.ojas.exercise;
import java.util.Scanner;


public class _4PalindromeInFibonacci {
	static String fibbonacciSeries(int start,int secound,int limit ){
		int temp;
		String result = "";
		limit =limit / 2;
		
		while( limit  >0) {
			
		result += palindrome(start);
		result += palindrome(secound);
			temp = start + secound;
			start = temp;
			secound = start + secound;	
			limit --;
			
		}
		System.out.println("--Palindrome in fibonacci--");
		return result ;
	}
	
	static String palindrome(int number) {
		String result = "";
		int reverse = 0, lastDigit = 0,temp;
		temp = number;
		while(number > 0) {
			lastDigit = number % 10;
			reverse = reverse*10 + lastDigit;
			number = number / 10;
		}
		if(temp == reverse) {
			 result += reverse + " ";
		}
		return result;
	}
	
	
	public static void main(String[] args) { 
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter Limit");
		int start = 0,secound = 1,limit = scanner.nextInt();
		System.out.println(fibbonacciSeries(start, secound, limit));

		
	}
	
	
}

	
	
	
	
	
	
	
	


