package _2org.ojas.exercise;

import java.util.Scanner;

public class _4SumOfNaturalNumbers {
	static int sum;
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Range of Natural Numbers");
		int initial = scanner.nextInt(),finalValue = scanner.nextInt();
		getNatural(initial,finalValue);
	}

	static void getNatural(int initial, int finalValue) {
		for(int i = initial;i <= finalValue;i++) {
			sum +=i; 
		
		}
		System.out.println("Sum of Natural numbers :" + sum);
		
	}
}
