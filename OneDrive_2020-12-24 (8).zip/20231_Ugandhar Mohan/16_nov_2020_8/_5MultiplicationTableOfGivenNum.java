package _2org.ojas.exercise;

//5.Wap to display multiplication table to the given number

import java.util.Scanner;

public class _5MultiplicationTableOfGivenNum {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the number for Multiplication table : "); 
		int number = scanner.nextInt();
		getMultiplcatioTable(number);
	}
	
	 static void getMultiplcatioTable(int number) {
		 	for(int i = 1;i <= 10; i++) {
		 		System.out.println(number + "*" + i + "=" + number*i); 
		 	}
		
	}
}
