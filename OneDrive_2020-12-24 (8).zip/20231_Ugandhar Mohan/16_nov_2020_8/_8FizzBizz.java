package _2org.ojas.exercise;

/*1)Write a program that prints "FIZZ" if the input is a multiple of 3 prints "BIZZ"
if the input is a multiple of 5 and prints "FIZZBIZZ" if the input is a multiple of 3 and 5.
Print the given input if it is multiple of neither 3 nor 5.
To implement this logic a class FizzBizz is given to you.
Implement the following method in that class: getOutputString(int num).
The �num� is the input number.
The input must be a positive number greater than Zero. If not, return the String �Error�.
Input:33
Output: Fizz
Input: 5
Output: Bizz*/

public class _8FizzBizz {
	
public static void main(String[] args) {
	if(args.length == 0) {
		System.out.println("--Please enter the input in command line arguments--");
	}
	else {
		String input = args[0];
		int num = Integer.parseInt(input);
	System.out.println(getOutputString(num));
	}
	
	
	
	
}

static String getOutputString(int num) {
	if(num % 3 == 0 && num % 5 ==0) {
		return "FIZZBIZZ";
	}
	 else if(num % 3 ==0) {
		return "FIZZ";
	}
	else if(num % 5 == 0) {
		return "BIZZ";
	}
	else {
		return "The Input is Not Multiple of 3 nor 5  :" + num;
	} 
	
}
}
