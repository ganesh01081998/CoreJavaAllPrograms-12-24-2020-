package org.ojas.exercise_2;

import java.util.Scanner;

// 1.Wap display natural numbers in the given range.

public class _1DispNaturalnum {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Range of Natural Numbers");
		int initial = scanner.nextInt(),finalValue = scanner.nextInt();
		getNatural(initial,finalValue);
	}

	
	static void getNatural(int initial, int finalValue) {
		for(int i = initial;i <= finalValue;i++) {
			System.out.print(i + " "); 
		
		}
		
	}

}
