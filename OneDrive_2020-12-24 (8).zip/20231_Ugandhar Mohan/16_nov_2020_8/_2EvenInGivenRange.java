package org.ojas.exercise_2;

import java.util.Scanner;

public class _2EvenInGivenRange {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Range of  Numbers for Even");
		int initial = scanner.nextInt(),finalValue = scanner.nextInt();
		getEven(initial,finalValue);
	}


	static void getEven(int initial, int finalValue) {
		System.out.println("--Even Numbers --");
		for(int i = initial;i <= finalValue;i++) {
			if(i % 2 == 0) {
				System.out.print(i + " ");
			}
		}
	
}
}
