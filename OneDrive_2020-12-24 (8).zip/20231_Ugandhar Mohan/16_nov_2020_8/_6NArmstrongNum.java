package _3org.ojas.exercise;

//7.Wap to check whether the given number is amstrong or not

import java.util.Scanner;

public class _5NArmstrongNum {
	static int mul = 1,lastDigit,sum = 0,temp;
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the  Number : ");
		int number1 = scanner.nextInt();
		ArmStrongRNot(number1);	
	}

	
	static int power(int lastDigit,int power) {
		int result =1;
		for (int i = 1; i <= power;i++) {
			result *= lastDigit; 
		}
		return result;		
	}

	
	 static void ArmStrongRNot(int number1) {
		 temp = number1;
		 String temp1 ="" + number1;
		 int power = temp1.length();		
			while(number1 >= 1) {
				lastDigit=number1 % 10;
				mul = power(lastDigit,power); 
				number1 = number1 / 10;
				sum += mul;
				mul = 1;
			}			
			if(sum == temp) {
				System.out.println("The Num is ArmStrong");
			}
			else {
				System.out.println("The num is not Armstrong");
			}		
	}
}
