package _2org.ojas.exercise;

import java.util.Scanner;

public class _3FactorialOfnumber {
	static int fact = 1;
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("Enter the Number For factorial :");
	int number = scanner.nextInt();
	 fact =getfactorial(number);
	 System.out.println("Factorial Of Given Number : " + fact);
}

 static int getfactorial(int number) {
	 for(int i = number;i > 0;i --) {
		 fact *=i; 
	 }
	return fact;
} 

}
