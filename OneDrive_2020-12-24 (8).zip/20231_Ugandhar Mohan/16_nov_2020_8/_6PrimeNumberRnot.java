package _2org.ojas.exercise;

//6.Wap to check whether the given number is prime or not

import java.util.Scanner;

public class _6PrimeNumberRnot { 
	static int flag;
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the  Number : ");
		int number = scanner.nextInt();
		primeOrNot(number);
	}


	static void primeOrNot(int number) {
		for(int i = 1;i < number;i++) {
			if(number % i == 0) {
				flag++;
			}	
		}
		if(flag == 1) {
			System.out.println("It is Prime NUmber");
		}
		else {
			System.out.println("It is Not a Prime number");
		}
	
}
}
