package _4org.ojas.PhaniMamShared.d18_nov_2020;

/*1 2 3 4 5 
1 2 3 4 5 
1 2 3 4 5 
1 2 3 4 5 
1 2 3 4 5 */

public class _1Pattern {
	static String getMypattern(int rows,int columns) {
		String result = "";
				for(int i = 1;i <= rows;i++) {
					for(int j = 1;j <= columns ; j++) {
						result += j + " "; 
					}
					result += "\n";
				}
				return result;

	}
	public static void main(String[] args) {
		System.out.println(getMypattern(5, 5));
	}
	
}
