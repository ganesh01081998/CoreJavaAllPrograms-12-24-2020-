package _4org.ojas.PhaniMamShared.d18_nov_2020;

/*1 
2 3 
4 5 6 
7 8 9 10 
11 12 13 14 15 */

import java.util.Scanner;

	public class _6Pattern {
		static String pattern(int rows,int columns) {
			String result = "";
			int number = 1;
			for(int i = 1;i <= rows;i++) {
				for(int j = 1;j <= columns ; j++) {
					if(i >= j) {
					result += number + " ";
					number ++;
					}
				}
				result += "\n";
			}
			return result;
			
			
		}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the rows and columns number");
		int initial = scanner.nextInt(),finalValue = scanner.nextInt();
		System.out.println(pattern(initial,finalValue));	
	}
	}
