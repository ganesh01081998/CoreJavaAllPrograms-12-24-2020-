package _4org.ojas.PhaniMamShared.d18_nov_2020;

import java.util.Scanner;

public class _10Pattern {
	static String getSquareStarPattern(int number1,int number2) {
		String result = "";
		char charcter = '*';
		for(int i = 1;i <= number1;i++ ) {
			for(int j = 1;j <= number2; j ++ ) {				
					result += charcter + " "; 									
			}
			result += "\n";
		}
		return result;
	}
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the rows and columns number");
		int initial = scanner.nextInt(),finalValue = scanner.nextInt();
		System.out.println(getSquareStarPattern(initial,finalValue));	
		
		}
}
