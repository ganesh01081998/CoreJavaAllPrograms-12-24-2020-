package _4org.ojas.PhaniMamShared.d18_nov_2020;

import java.util.Scanner;

public class _8Pattern {
	static String pattern(int rows,int columns) {
	String result = "";
	for(int i = 1;i <= rows;i++) {
		int increment = 0 ;
		for(int j = 1;j <= columns ; j++) {
			if(i >= j) {
			result += i + increment + " ";
			increment++;
			}
		}
		result += "\n";
	}
	return result;
	
	
}
	public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("Enter the rows and columns number");
	int initial = scanner.nextInt(),finalValue = scanner.nextInt();
	System.out.println(pattern(initial,finalValue));	
	
	}
}

