package _4org.ojas.PhaniMamShared.d18_nov_2020;

import java.util.Scanner;

public class _13Pyramid {
	static String getPyramid(int rows ,int columns) {
		String result = "";
		for(int i = 1; i <= rows;i++) {			
			for(int j = 1; j <= columns - i + 1;j++) {
			result += "  ";
			
			}			
			for(int k = 1; k <= 2 * i -1;k++) {
				result += "* ";				
			}
			result += "\n";
		}
		return result;
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter the rows and columns : ");
		System.out.println(getPyramid(scanner.nextInt(),scanner.nextInt()));
	}
}
