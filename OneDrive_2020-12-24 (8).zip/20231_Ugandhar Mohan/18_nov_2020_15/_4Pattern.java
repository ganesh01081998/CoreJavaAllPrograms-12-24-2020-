package _4org.ojas.PhaniMamShared.d18_nov_2020;

import java.util.Scanner;

/*1
 * 1 2
 * 1 2 3
 * 1 2 3 4
 * 1 2 3 4 5*/

public class _4Pattern {
	static String pattern(int rows,int columns) {
		String result = "";
		for(int i = 1;i <= rows;i++) {
			for(int j = 1;j <= columns ; j++) {
				if(i >= j) {
				result += j + " ";
				}
			}
			result += "\n";
		}
		return result;
		
		
	}
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("Enter the rows and columns number");
	int initial = scanner.nextInt(),finalValue = scanner.nextInt();
	System.out.println(pattern(initial,finalValue));	
}
}
