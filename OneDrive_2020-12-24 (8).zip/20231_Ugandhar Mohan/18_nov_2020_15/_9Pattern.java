package _4org.ojas.PhaniMamShared.d18_nov_2020;
/*A 
 * B C
 * D E F
 * G H I J
 * K L M N O */

import java.util.Scanner;

public class _9Pattern {
	static String getCharPattern(int number1,int number2) {
		String result = "";
		char charcter = 'A';
		for(int i = 1;i <= number1;i++ ) {
			for(int j = 1;j <= number2; j ++ ) {
				if(i >= j) {
					result += charcter + " "; 
					charcter ++;
				}
			}
			result += "\n";
		}
		return result;
	}
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the rows and columns number");
		int initial = scanner.nextInt(),finalValue = scanner.nextInt();
		System.out.println(getCharPattern(initial,finalValue));	
		
		}
}
