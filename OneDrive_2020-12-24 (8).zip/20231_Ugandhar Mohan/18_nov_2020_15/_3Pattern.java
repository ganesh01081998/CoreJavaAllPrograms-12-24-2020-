package _4org.ojas.PhaniMamShared.d18_nov_2020;

/*5 5 5 5 5 
4 4 4 4 4 
3 3 3 3 3 
2 2 2 2 2 
1 1 1 1 1 */

import java.util.Scanner;

public class _3Pattern {
	static String pattern(int rows,int columns) {
		String result = "";
		for(int i = rows ; i > 0; i--) {
			for(int j = columns; j > 0;j--) {
				result += i + " ";
			}
			result += "\n";
		}
		return result;
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the rows and columns number");
		int initial = scanner.nextInt(),finalValue = scanner.nextInt();
		System.out.println(pattern(initial,finalValue));	
	}
}
