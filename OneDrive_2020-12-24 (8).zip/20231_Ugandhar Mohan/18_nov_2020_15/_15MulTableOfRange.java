package _4org.ojas.PhaniMamShared.d18_nov_2020;

import java.util.Scanner;

//

public class _15MulTableOfRange {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the  Range : ");
		int intial = scanner.nextInt(),finalrange = scanner.nextInt();
		System.out.println(multiplication(intial,finalrange));
		
	}


	 static String multiplication(int intial, int finalrange) {
		 String result = "";
		 for(int i = intial;i <= finalrange;i++) {
				for(int j = 1;j < 11;j++){
				result += i + "*" + j + "=" + i * j;
				result += "\n";
				}
				result += "\n";
			}
		 return result;
	}
}
