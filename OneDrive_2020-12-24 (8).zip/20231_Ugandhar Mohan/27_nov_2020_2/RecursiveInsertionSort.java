package _9org.ojas.exercise_27_nov_2020;

import java.util.Arrays;
import java.util.Scanner;

public class RecursiveInsertionSort {
	static Scanner scanner = new Scanner(System.in);
	static void insertionSortRecursive(int arr[], int n) {   		
//	         Base case 
	        if (n <= 1){ 
	            return  ;
	        }
	        
	        // Sort first n-1 elements 
	        insertionSortRecursive( arr, n-1 ); 
	        int last = arr[n - 1]; 
	        int j = n - 2; 
	        while (j >= 0 && arr[j] > last) { 
	            arr[j+1] = arr[j]; 
	            j--; 
	        } 
	        arr[j+1] = last; 
	    } 
		
	
	public static void main(String[] args) {
			System.out.println("Enter the size : ");
			int size = scanner.nextInt();
			int arr[] = new int[size];
			readArray(arr,size);	 		 
	       insertionSortRecursive(arr, arr.length); 
	       System.out.println("--Sorted Array--");
			for(int variable : arr) {
				System.out.print(variable + " ");
			}
	}
	
	
	static void readArray(int arr[],int size) {
		System.out.print("Enter the Elements :");
		for(int i = 0;i < size;i++) {
			arr[i] = scanner.nextInt();
		}		
	}
}
