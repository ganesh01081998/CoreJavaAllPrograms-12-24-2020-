package _16org.ojas.exercise_14_dec_2020;

import java.util.Scanner;

public class _3d_InheritanceTesterForEmployee {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Select Employee is Manager Or clerk");
		String str = "1.Manager\n2.clerk";
		System.out.println(str);
		int selection = scanner.nextInt();
		switch(selection) {
		case 1 :		
			System.out.println("Enter the Name,Id,Salary");
			String str1 = "" + ManagerType.HR;
			_3b_Manager manager = new _3b_Manager(scanner.next(), scanner.nextInt(), scanner.nextDouble(), str1 );
			manager.setSalary();
			System.out.println(manager);
			break;
		case 2 :
			System.out.println("Enter the Name,Id,Salary,speed,accuracy");
			_3c_Clerk clerk = new _3c_Clerk(scanner.next(), scanner.nextInt(), scanner.nextDouble(), scanner.nextInt(), scanner.nextInt());
			clerk.getIncreSalary();
			System.out.println(clerk);
			break;
		}
	}
}
