package _16org.ojas.exercise_14_dec_2020;


class _1c_Hosteller extends _1d_Student {
	double hostelFee;
	_1a_InheritanceTester student;	
	public _1c_Hosteller() {
	}

	public _1c_Hosteller(int studentId,String name ,double examFee,double hostelFee) {
		this.studentId = studentId;
		this.name = name;
		this.examFee = examFee;
		this.hostelFee = hostelFee;
	}
	
	String disaplayDetails() {
		_1d_Student student = new _1d_Student();		
		return "Hosteller[hostel fee = " + hostelFee + ", studentId=" + studentId + ", name=" + name + ", examFee="
		+ examFee + "]";
	}
	
	double payFee(double amount) {
		return amount;
	}

}