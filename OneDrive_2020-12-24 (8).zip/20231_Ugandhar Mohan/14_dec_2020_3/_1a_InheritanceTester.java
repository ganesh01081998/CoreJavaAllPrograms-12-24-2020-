package _16org.ojas.exercise_14_dec_2020;

import java.util.Scanner;

class _1a_InheritanceTester {
	static Scanner scanner = new Scanner( System.in);
	double totalFee;
	public static void main(String[] args) {
		double balance,payFee;
		System.out.println("Enter the DayScholar details Id,Name,ExamFee,Transport fee");
		_1b_DayScholar dayScholar = new _1b_DayScholar(scanner.nextInt(), scanner.next(), scanner.nextDouble(), scanner.nextDouble());
		System.out.println(dayScholar.displayDetails());
		_1a_InheritanceTester inheritanceTester = new _1a_InheritanceTester();
		inheritanceTester.totalFee = dayScholar.examFee + dayScholar.transportFee;
		System.out.println("Enter the payfee  of dayScholar : ");
		payFee = dayScholar.payFee(scanner.nextDouble()); 
		if(payFee < inheritanceTester.totalFee) {
			 balance =  (inheritanceTester.totalFee) - ( payFee );
			System.out.println("Remaining Balance " + balance); 
		}
		else if(payFee > inheritanceTester.totalFee) {
			balance =  (inheritanceTester.totalFee) - ( payFee );
			System.out.println("Remaining Balance :" + balance);
		}
		
		System.out.println("Enter the Hosteller details Id,Name,ExamFee,hostel fee");
		_1c_Hosteller hosteller = new _1c_Hosteller(scanner.nextInt(), scanner.next(), scanner.nextDouble(), scanner.nextDouble());
		System.out.println(hosteller.disaplayDetails());
		inheritanceTester.totalFee = hosteller.examFee + hosteller.hostelFee;
		System.out.println("Enter the payfee  of Hosteller : ");
		payFee = hosteller.payFee(scanner.nextDouble()); 
		if(payFee < inheritanceTester.totalFee) {
			 balance =  (inheritanceTester.totalFee) - ( payFee );
			System.out.println("Remaining Balance " + balance); 
		}
		else if(payFee > inheritanceTester.totalFee) {
			balance =  (inheritanceTester.totalFee) - ( payFee );
			System.out.println("Remaining Balance : " + balance);
		}
		
		
	}
		
	
}
