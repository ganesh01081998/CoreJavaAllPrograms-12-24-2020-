package _16org.ojas.exercise_14_dec_2020;

enum ShirtMaterial {
	COTTON,LINNEN,POLYESTER;
}

public class _2a_Shirt {
	float collarSize;
	float length;
	String material;
	ShirtMaterial shirtMaterial;
	
	public _2a_Shirt() {
		this.collarSize = 0;
		this.length = 0;
		this.material= "COTTON";		
	}
	
	public _2a_Shirt(float collarSize,float length,ShirtMaterial shirtMaterial) {
		this.collarSize = collarSize;
		this.length = length;
		this.shirtMaterial = shirtMaterial;
	}

	public float getCollarSize() {
		return collarSize;
	}

	public void setCollarSize(float collarSize) {
		this.collarSize = collarSize;
	}

	public float getLength() {
		return length;
	}

	public void setLength(float length) {
		this.length = length;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(String material) {
		this.material = material;
	}

	@Override
	public String toString() {
		return "Shirt [collarSize=" + collarSize + ", length=" + length + ", material=" + shirtMaterial + "]";
	}
	
	
	
	
	
}
