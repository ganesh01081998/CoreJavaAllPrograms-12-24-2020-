package _16org.ojas.exercise_14_dec_2020;


/**
 * @author um20231
 *
 */
class _1b_DayScholar extends _1d_Student {
	double transportFee;	
	public _1b_DayScholar() {	
	}

	public _1b_DayScholar(int studentId,String name ,double examFee,double transportFee) {
		this.studentId = studentId;
		this.name = name;
		this.examFee = examFee;
		this.transportFee = transportFee;
	}
	
	
	String displayDetails() {
		_1d_Student student = new _1d_Student();
		return "DayScholar [transportFee=" + transportFee + ", studentId=" + studentId + ", name=" + name + ", examFee="
		+ examFee + "]"; 
	}

	double  payFee(double amount) {
		return amount;
	}


}