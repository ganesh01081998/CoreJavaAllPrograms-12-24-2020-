package _16org.ojas.exercise_14_dec_2020;

class _1d_Student {
	int studentId;
	String name ;
	double examFee;
	public _1d_Student() {		
	} 
	
	public _1d_Student(int studentId,String name,double examFee) {
	this.studentId = studentId;
	this.name = name;
	this.examFee = examFee;
	}
	
	String displayDetails() {
		return "Student [studentId=" + studentId + ", name=" + name + ", examFee=" + examFee + "]";
	}
	
	double payFee(double amount) {
		
		return 0.0;
	}

	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", name=" + name + ", examFee=" + examFee + "]";
	}
	
	
}
