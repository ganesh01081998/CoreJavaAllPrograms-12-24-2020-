package _16org.ojas.exercise_14_dec_2020;

import java.util.Scanner;

public class _2b_PolymorphismTester {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the ShirtCollarSize,length");		 		 	
		_2a_Shirt shirt = new _2a_Shirt(scanner.nextFloat(),scanner.nextFloat(),ShirtMaterial.LINNEN);		
		System.out.println( shirt);
	}
}
