package _16org.ojas.exercise_14_dec_2020;

public class _3b_Manager extends _3a_Employee{
	String  type;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public _3b_Manager() {
		super();		
	}

	public _3b_Manager(String name, int employeeId, double salary,String type) {
		this.name = name;
		this.employeeId = employeeId;
		this.salary = salary;
		this.type = type;
	}
	
	void setSalary() {
		if(type.equals("HR")) {
			this.salary += 10000.0;
		}
		if(type.equals("SALES")) {
			this.salary += 5000;
		}
	}
	
	@Override
	public String toString() {
		return "Manager [type " + type + "name=" + name + ", employeeId=" + employeeId + ", salary=" + salary + "]";
	}
	
	
	
}
