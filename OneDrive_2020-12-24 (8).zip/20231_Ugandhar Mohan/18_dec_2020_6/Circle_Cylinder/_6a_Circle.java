package _18_org.ojas.exercise_18_dec_2020;

class _6a_Circle {
	double radius;

	public _6a_Circle(double radius) {
		this.radius = radius;
	}

	public _6a_Circle() {
		radius = 0.0;
	}

	double getArea(double a) {
		a = Math.PI * (a * a);
		return a;
	}
}