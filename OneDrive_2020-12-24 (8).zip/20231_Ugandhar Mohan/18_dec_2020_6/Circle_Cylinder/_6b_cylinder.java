package _18_org.ojas.exercise_18_dec_2020;


class _6b_cylinder extends _6a_Circle {
	double height;

	public _6b_cylinder() {
		super();
	}

	public _6b_cylinder(double a, double height) {

		this.height = height;
	}

	double getVolume(double a, double b) {
		b = Math.PI * (a * a) * b;
		return b;
	}

}