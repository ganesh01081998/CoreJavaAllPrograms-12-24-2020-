package _18_org.ojas.exercise_18_dec_2020;

import java.util.Scanner;

public class _6c_Tester {
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("enter radius of circle");
		int a = sc.nextInt();
		_6a_Circle area = new _6a_Circle();
		System.out.println(area.getArea(a));
		System.out.println("enter  area and height for Cylinder finding the value volume");		// 
		_6b_cylinder cylinder = new _6b_cylinder();
		System.out.println(cylinder.getVolume(sc.nextDouble(), sc.nextDouble()));
	}
}
