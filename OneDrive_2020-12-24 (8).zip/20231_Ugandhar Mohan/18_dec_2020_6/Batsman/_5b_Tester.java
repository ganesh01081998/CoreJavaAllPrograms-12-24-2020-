package _18_org.ojas.exercise_18_dec_2020;

import java.util.Scanner;

class _5b_Tester {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("enter bats man Name runs and matches");
	_5a_Batsman batsman = new _5a_Batsman(sc.next(), sc.nextInt(), sc.nextInt());	// 
	batsman.computeBattingAverage(batsman.runs, batsman.matches);
	System.out.println(batsman.toString());
	System.out.println("details of batsman  runs ,matches and name");
	batsman.getStatistics(batsman.runs, batsman.matches, batsman.name);
}
}