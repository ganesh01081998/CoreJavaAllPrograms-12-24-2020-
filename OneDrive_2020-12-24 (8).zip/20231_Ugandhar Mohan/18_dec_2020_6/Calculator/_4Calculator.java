package _18_org.ojas.exercise_18_dec_2020;

import java.util.Scanner;

public class _4Calculator {
	
		public static void main(String[] args) {
			Scanner scanner = new Scanner(System.in);
			System.out.println("enter the Number");
			int num = scanner.nextInt();
			int sum = num;
			for(int i = 1;i <= num / 2;i++){
				if(num%i == 0){
					sum = sum + i;					
				}
			}
			System.out.println(sum);
		}
		

}
