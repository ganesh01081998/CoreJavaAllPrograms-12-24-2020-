package _18_org.ojas.exercise_18_dec_2020;

import java.util.Scanner;

public class _1c_TestingBook {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the book Title ");
		_1b_MyBook book = new _1b_MyBook();		
		book.setTitle(scanner.nextLine());
		System.out.println("The title of my book is :" + book.getTitle());
	}
}
