package _18_org.ojas.exercise_18_dec_2020;

public class _1b_MyBook extends _1a_Book {
		String title;
		public void setTitle(String bookTitle) {
			title = bookTitle;
		}
		
		String getTitle() {
			return title;
		}
}
