package _18_org.ojas.exercise_18_dec_2020;

abstract public class _1a_Book {
	String title;
	 abstract void setTitle(String title);
	 String getTitle(){
		return title;		 
	 }
	 
}
