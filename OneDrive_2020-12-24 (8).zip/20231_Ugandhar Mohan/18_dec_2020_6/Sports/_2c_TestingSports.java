package _18_org.ojas.exercise_18_dec_2020;

public class _2c_TestingSports {
	public static void main(String[] args) {
		_2b_Soccer soccer = new _2b_Soccer();		
		System.out.println( soccer.getNumberOfTeamMembers());
	}
}
