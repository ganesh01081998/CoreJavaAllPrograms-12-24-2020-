package _18_org.ojas.exercise_18_dec_2020;

public class _2b_Soccer extends _2a_Sports {	
	String getName() {
		return "Soccer";
	}
	String getNumberOfTeamMembers() {
		return "In  "+ getName()	+ ",\neach team has 11 players";
	}
}
