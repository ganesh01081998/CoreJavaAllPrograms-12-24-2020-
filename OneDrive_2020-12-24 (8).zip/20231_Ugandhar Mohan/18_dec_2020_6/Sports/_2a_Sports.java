package _18_org.ojas.exercise_18_dec_2020;
import static java.lang.System.*;
public class _2a_Sports {
	String getName() {
		return "Sports";	
	}
	
	String getNumberOfTeamMembers() {
		return "Each team has n players in Sports";		
	}
}
