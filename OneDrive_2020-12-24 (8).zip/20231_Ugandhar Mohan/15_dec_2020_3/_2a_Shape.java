package _17org.ojas.exercise_15_dec_2020;

abstract public class _2a_Shape {
	abstract double getArea();
	abstract float getPerimeter();
	
}
