package _17org.ojas.exercise_15_dec_2020;

public class _3c_Trainer {
	int id;	
	String name;
	double basicSalary;
	double HRAper;
	double DAPer;
	int batchCount;
	double perkPerBatch;
	double calculateGrossSalary() {
		double grossSalary;
		return grossSalary = basicSalary + HRAper + DAPer + batchCount + perkPerBatch;
	}
	public _3c_Trainer() {
		super();
	}
	
	public _3c_Trainer(int id, String name, double basicSalary, double hRAper, double dAPer, int batchCount,
			double perkPerBatch) {
		super();
		this.id = id;
		this.name = name;
		this.basicSalary = basicSalary;
		HRAper = hRAper;
		DAPer = dAPer;
		this.batchCount = batchCount;
		this.perkPerBatch = perkPerBatch;
	}
	@Override
	public String toString() {
		return "Trainer [id=" + id + ", name=" + name + ", basicSalary=" + basicSalary + ", HRAper=" + HRAper
				+ ", DAPer=" + DAPer + ", batchCount=" + batchCount + ", perkPerBatch=" + perkPerBatch + "]";
	}
	
	
}
