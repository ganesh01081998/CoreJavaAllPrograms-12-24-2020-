package _17org.ojas.exercise_15_dec_2020;

public class _1b_ScienceStudent extends _1a_Student {
	int physicsMarks;
	int chemistryMarks;
	int mathsMarks;
	String studentName;
	String studentClass;
	
	public _1b_ScienceStudent() {
	
	}
	 public _1b_ScienceStudent(String studentName,String studentClass,int physicsMarks, int chemistryMarks, int mathsMarks) {
		super();
		this.studentName =studentName;
		this.studentClass = studentClass;
		this.physicsMarks = physicsMarks;
		this.chemistryMarks = chemistryMarks;
		this.mathsMarks = mathsMarks;
	}
	double getPercentage() {
		if(physicsMarks <= 100 && chemistryMarks <= 100 && mathsMarks <= 100) {
			int total = physicsMarks + chemistryMarks + mathsMarks;
			double percentage; 
			return  percentage = total / 3;
		}
		return 0.0;
	}
	
	@Override
	public String toString() {
		return "ScienceStudent [physicsMarks=" + physicsMarks + ", chemistryMarks=" + chemistryMarks
				+ ", mathsMarks=" + mathsMarks + ", studentName=" + studentName + ", studentClass=" + studentClass
				+ "]";
	}
	 
	 
	
}
