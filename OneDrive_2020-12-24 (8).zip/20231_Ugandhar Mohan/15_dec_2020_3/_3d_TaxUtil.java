package _17org.ojas.exercise_15_dec_2020;

import java.util.Scanner;

public class _3d_TaxUtil {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Employee id,name,basicSalary,HRAper,DAPer");
		_3a_Employee employee = new _3a_Employee(scanner.nextInt(), scanner.next(), scanner.nextDouble(), scanner.nextDouble(), scanner.nextDouble());
		System.out.println(employee);
		_3d_TaxUtil taxUtil = new _3d_TaxUtil();
		System.out.println("Employee tax : " + taxUtil.calculatetax(employee.calculateGrossSalary()));
		System.out.println("Enter the Manager id,name,basicSalary,HRAper,DAPer,projectAllowance");
		_3b_Manager manager = new _3b_Manager(scanner.nextInt(), scanner.next(), scanner.nextDouble(), scanner.nextDouble(), scanner.nextDouble(),scanner.nextDouble());
		System.out.println(manager);
		System.out.println("Manager tax : " + taxUtil.calculatetax(manager.calculateGrossSalary()));
		System.out.println("Enter the Trainer id,name,basicSalary,HRAper,DAPer,batchCount,perkPerBatch");
		_3c_Trainer trainer = new _3c_Trainer(scanner.nextInt(), scanner.next(), scanner.nextDouble(), scanner.nextDouble(), scanner.nextDouble(),scanner.nextInt(),scanner.nextDouble());
		System.out.println(trainer);
		System.out.println("Trainer tax : " + taxUtil.calculatetax(trainer.calculateGrossSalary()));
	}
	
	double calculatetax(double grossSalary) {
		double tax;
		if(grossSalary > 30000){
			 tax = grossSalary * 20 /100;				
		}
		else {
			 tax = grossSalary * 5 /100;
		}
		return tax;
	}
}
