package _17org.ojas.exercise_15_dec_2020;

import java.util.Scanner;

public class _1d_TesterClass {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Science Student name,Class,Physics,Chemisty,Maths Marks : ");
		_1b_ScienceStudent scienceStudent = new _1b_ScienceStudent(scanner.next(),scanner.next(),scanner.nextInt(), scanner.nextInt(), scanner.nextInt());		
		System.out.println(scienceStudent.getPercentage());
		System.out.println(scienceStudent);
		System.out.println("Enter the History Student name,Class,Civics,History Marks : ");
		_1c_HistoryStudent historyStudent = new _1c_HistoryStudent(scanner.next(), scanner.next() , scanner.nextInt(), scanner.nextInt()); 
		System.out.println(historyStudent.getPercentage());
		System.out.println(historyStudent);
	}
}
