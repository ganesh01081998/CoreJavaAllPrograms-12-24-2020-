package _17org.ojas.exercise_15_dec_2020;

abstract public class _1a_Student {
	String studentName;
	String studentClass;
	static protected int totalNoOfStudents;
	
	
	
	public _1a_Student() {	
	}

	public _1a_Student(String studentName, String studentClass) {
		super();
		studentName = studentName;
		studentClass = studentClass;
	}
	
	abstract double getPercentage();
	static int getTotalNoOfStudents() {
		return 0;
	}
	
	
}
