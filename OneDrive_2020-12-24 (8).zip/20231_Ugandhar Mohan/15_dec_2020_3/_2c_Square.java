package _17org.ojas.exercise_15_dec_2020;

public class _2c_Square extends _2a_Shape {
	float side;
	
	public _2c_Square() {
		super();	
	}

	public _2c_Square(float side) {
		super();
		this.side = side;
	}

	public float getSide() {
		return side;
	}

	public void setSide(float side) {
		this.side = side;
	}

	@Override
	double getArea() {	
		return side * side;
	}

	@Override
	float getPerimeter() {		
		return 4 * side;
	}
	
}
