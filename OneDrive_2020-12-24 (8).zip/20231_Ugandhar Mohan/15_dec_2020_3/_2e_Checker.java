package _17org.ojas.exercise_15_dec_2020;

import java.util.Scanner;

public class _2e_Checker {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Circle Radius to get Area And Perimeter");
		_2b_Circle circle = new _2b_Circle();
		circle.setRadius(scanner.nextFloat());
		System.out.println("Area of circle " + circle.getArea());
		System.out.println("Perimeter of Circle " + circle.getPerimeter());
		System.out.println("Enter the Square Side to get Area And Perimeter");
		_2c_Square square = new _2c_Square();
		square.setSide(scanner.nextFloat());
		System.out.println("Area of Square " + square.getArea());
		System.out.println("Perimeter of Square " + square.getPerimeter());
		System.out.println("Enter the Rectangle length and Breadth to get Area And Perimeter");
		_2d_Rectangle rectangle = new _2d_Rectangle();
		rectangle.setLength(scanner.nextFloat());
		rectangle.setBreadth(scanner.nextFloat());
		System.out.println("Area of Rectangle " + rectangle.getArea());
		System.out.println("Perimeter of Rectangle " + rectangle.getPerimeter());
	}
}
