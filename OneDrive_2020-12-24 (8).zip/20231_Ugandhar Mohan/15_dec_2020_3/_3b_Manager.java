package _17org.ojas.exercise_15_dec_2020;

public class _3b_Manager {
	int id;	
	String name;
	double basicSalary;
	double HRAper;
	double DAPer;
	double projectAllowance;
	double calculateGrossSalary() {
		double grossSalary;
		return grossSalary = basicSalary + HRAper + DAPer + projectAllowance;
	}
	public _3b_Manager() {
		super();
	}
	
	public _3b_Manager(int id, String name, double basicSalary, double hRAper, double dAPer, double projectAllowance) {
		super();
		this.id = id;
		this.name = name;
		this.basicSalary = basicSalary;
		HRAper = hRAper;
		DAPer = dAPer;
		this.projectAllowance = projectAllowance;
	}
	@Override
	public String toString() {
		return "Manager [id=" + id + ", name=" + name + ", basicSalary=" + basicSalary + ", HRAper=" + HRAper
				+ ", DAPer=" + DAPer + ", projectAllowance=" + projectAllowance + "]";
	}
	
	
	
	
	
}
