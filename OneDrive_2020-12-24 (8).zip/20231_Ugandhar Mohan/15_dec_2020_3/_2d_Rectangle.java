package _17org.ojas.exercise_15_dec_2020;

public class _2d_Rectangle extends _2a_Shape {
	float length;
	float breadth;
	
	
	public float getLength() {
		return length;
	}

	public void setLength(float length) {
		this.length = length;
	}

	public float getBreadth() {
		return breadth;
	}

	public void setBreadth(float breadth) {
		this.breadth = breadth;
	}
	
	public _2d_Rectangle() {
		super();	
	}

	
	public _2d_Rectangle(float length, float breadth) {
		super();
		this.length = length;
		this.breadth = breadth;
	}

	@Override
	double getArea() {
		return length * breadth;
	}

	@Override
	float getPerimeter() {	
		return 2 * length * breadth;
	}
	
}
