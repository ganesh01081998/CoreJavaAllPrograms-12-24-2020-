package _17org.ojas.exercise_15_dec_2020;

public class _2b_Circle extends _2a_Shape{
	float radius;
	
	public double getRadius() {
		return radius;
	}

	public void setRadius(float radius) {
		this.radius = radius;
	}

	
	public _2b_Circle() {
		super();	
	}
	
	

	public _2b_Circle(float radius) {
		super();
		this.radius = radius;
	}

	@Override
	public double getArea() {	
		return 3.14 * radius * radius;
	}

	@Override
	float getPerimeter() {		
		return (float) ( 2 * 3.14 * radius) ;
	}
}
