package _17org.ojas.exercise_15_dec_2020;

public class _1c_HistoryStudent extends _1a_Student{
	int historyMarks;
	int civicsMarks;
	String studentName;
	String studentClass;
	
	public _1c_HistoryStudent() {	
	}
	
	public _1c_HistoryStudent( String studentName, String studentClass, int historyMarks, int civicsMarks) {
		super();
		this.historyMarks = historyMarks;
		this.civicsMarks = civicsMarks;
		this.studentName = studentName;
		this.studentClass = studentClass;
	}
	
	double getPercentage() {
		if(historyMarks <= 100 && civicsMarks <= 100) {
			int total = historyMarks + civicsMarks;
			double percentage; 
			return  percentage = total / 2;
		}
		return 0.0;
	}

	@Override
	public String toString() {
		return "HistoryStudent [historyMarks=" + historyMarks + ", civicsMarks=" + civicsMarks + ", studentName="
				+ studentName + ", studentClass=" + studentClass + "]";
	}
	
	
}
