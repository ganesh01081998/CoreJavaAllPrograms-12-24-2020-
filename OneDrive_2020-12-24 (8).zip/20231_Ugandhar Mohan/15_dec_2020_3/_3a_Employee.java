package _17org.ojas.exercise_15_dec_2020;

public class _3a_Employee {
	int id;	
	String name;
	double basicSalary;
	double HRAper;
	double DAPer;
	double calculateGrossSalary() {
		double grossSalary;
		return  grossSalary = basicSalary + HRAper + DAPer;		
	}
	public _3a_Employee() {
		super();	
	}
	public _3a_Employee(int id, String name, double basicSalary, double hRAper, double dAPer) {
		super();
		this.id = id;
		this.name = name;
		this.basicSalary = basicSalary;
		HRAper = hRAper;
		DAPer = dAPer;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", basicSalary=" + basicSalary + ", HRAper=" + HRAper
				+ ", DAPer=" + DAPer + "]";
	}
	
	
}
