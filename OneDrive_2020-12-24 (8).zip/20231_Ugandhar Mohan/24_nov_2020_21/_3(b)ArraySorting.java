package _7org.ojas.exercise_24_nov_2020;

import java.util.Scanner;

public class _5ArraySorting {
	static Scanner scanner = new Scanner(System.in);
	static void sortArrayElements(int arr[],int size) {
		for(int curr_size = size;curr_size > 1;curr_size--) {
			int index = findMax(arr,curr_size);
			if(index != curr_size) {
				flip(arr,index);
				flip(arr,curr_size - 1);
			}
			
		}
	}
	
	
	public static void main(String[] args) {
		 System.out.println("Enter the size :");
		 int size = scanner.nextInt();
		 int arr[] = new int[size];
		 readarray(arr,size);
		 sortArrayElements(arr,size);
		 printArray(arr);
		 
	}
	
	
	 static void flip(int[] arr, int index) {	
		int temp, start = 0;
		temp = arr[start];
		arr[start] = arr[index];
		arr[index] = temp;
	}


	static int findMax(int arr[],int curr_size) {
		int index = 0;
		for(int i = 0;i < curr_size;i++) {
			if(arr[i] > arr[index]) {
				index = i;
			}
		}		
		return index;
	}
	
	
	
	
	
	 static void readarray(int arr[], int size) {	
		 System.out.println("Enter the Elements : ");
		for(int i = 0; i < size;i++) {
			arr[i] = scanner.nextInt();
		}
	}
	 
	 
	 static void printArray(int [] arr) {
		 for(int varaiable : arr) {
			 System.out.print(varaiable + " ");			 
		 }
		 System.out.println();
	 }
	 
}
