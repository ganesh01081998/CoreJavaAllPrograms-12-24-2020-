package _2org.ojas._24_nov_2020;

import java.util.Scanner;

public class _1StringWordsReverse {
	static String getReverse(String str) {
		StringBuffer result = new StringBuffer(str);
		return result.reverse().toString();
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);		
		String str = scanner.nextLine();
		String strarr [] = str.split(" ");
		String revStrarr[] = new String[strarr.length];
		for(int i = 0;i < strarr.length;i++) {
			revStrarr[i] = getReverse(strarr[i]);
		}		
		for(String variable : revStrarr) {
			System.out.print (variable + " ");
		}
		
	}
}
