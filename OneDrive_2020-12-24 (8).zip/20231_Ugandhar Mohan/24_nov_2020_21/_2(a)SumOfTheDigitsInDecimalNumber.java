package _7org.ojas.exercise_24_nov_2020;

import java.util.Scanner;

public class _3SumOfTheDigitsInDecimalNumber {
	static int getSumOfDigits(int number) {
		int sum = 0,remainder;		
		while (number >0) {
			remainder = number % 10;
			sum += remainder;
			number /= 10;
		}
		return sum;		
	}
	
	static void concateSumOfDigits(int number,int number2) {
		System.out.println(number + ":" + number2);
	}
	
	
	public static void main(String[] args) {			
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the input : ");
		double number = scanner.nextDouble();
		String str = "" + number;
		int indexOfPoint= str.indexOf(".");
		String decimalPart = str.substring(indexOfPoint + 1,str.length());
		String intPart = str.substring(0,indexOfPoint);
		int intNumber = Integer.parseInt(intPart);
		int aftPointNumber = Integer.parseInt(decimalPart);	
		concateSumOfDigits(getSumOfDigits(intNumber) ,getSumOfDigits(aftPointNumber));
		
	}						
}

