package _7org.ojas.exercise_24_nov_2020;

import java.util.Scanner;

public class _6GeneratorPalindrome {
	static String result = "";
	static int add = 0; 
	static String getPalindromeList(int number) {
		
		if(isPalindrome(number)) {
			return result;
		}
		else {
			 add += number;
			 result += add + ",";
			int  listElements = getReverse(add);			
			result += listElements + ",";
			getPalindromeList(listElements);			
		}
		return result.substring(0,result.length()-1);
	}
	
	
	 static int getReverse(int number) {
		 int reverse = 0,lastDigit = 0;
		 while(number > 0) {
				lastDigit = number % 10;
				reverse = (reverse * 10) + lastDigit;
				number /= 10;			
			}
		 return reverse;
	 }
	
	
	static boolean isPalindrome(int number) {
		int temp = number,reverse = 0,lastDigit = 0;
		while(number > 0) {
			lastDigit = number % 10;
			reverse = (reverse * 10) + lastDigit;
			number /= 10;			
		}
		if(temp == reverse) {
			return true;
		}
		return false;
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the number : ");
		int number = scanner.nextInt();
		System.out.println(getPalindromeList(number) + " This is palindrome Generators" );
	}
}
