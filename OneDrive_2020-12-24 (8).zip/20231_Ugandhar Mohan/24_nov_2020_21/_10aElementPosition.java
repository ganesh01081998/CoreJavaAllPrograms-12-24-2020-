package _7org.ojas.exercise_24_nov_2020;

import java.util.Scanner;

public class _10aElementPosition {
	 static Scanner scanner = new Scanner(System.in);
	 
	 
	static int getElementPosition(int arr[],int searchElement) {
		for(int i = 0;i < arr.length;i++) {
			if(searchElement == arr[i]) {
				return i;
			}
		}
		return -1;			
	}		
	

	public static void main(String[] args) {		
		System.out.println("Enter the Size : ");
		int size = scanner.nextInt();		
		int arr[] =new int[size];	
		if(size == 0) {
			System.out.println("-2");
			System.exit(0);
		}
		System.out.println("Enter the array elements : ");
		for(int i = 0;i < arr.length;i++) {
			arr[i] = scanner.nextInt();
			if(arr[i] <= 0) {
				System.out.println("-4");						
			}				
		}
		System.out.println("Enter the Search Element :");
		int searchElement = scanner.nextInt();
		if(searchElement <= 0) {
			System.out.println("-3");
			System.exit(0);
		}
		System.out.println(getElementPosition(arr, searchElement));
}
}
