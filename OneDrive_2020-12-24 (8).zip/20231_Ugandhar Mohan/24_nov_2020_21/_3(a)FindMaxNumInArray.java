package _7org.ojas.exercise_24_nov_2020;

import java.util.Scanner;

public class _4FindMaxNumInArray {	
	static int findMax(int arr[]) {
		int count = 0,max = 0;
		for(int i = 0;i < arr.length;i++) {
			if(arr[i] < 0) {
				count++;
			}
		}
		if(arr[0] == 0) {
			return 0;
		}
		if(count < 3) {
			return -1;
		}
		
		max = arr[0];
		for(int i = 1;i < arr.length;i++) {
			if(arr[i] > max) {
				max = arr[i];
			}
		}
	return max;	
	}
	
	
	public static void main(String[] args) {			
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter the Size of an array :");
		int arr[] = new int[scanner.nextInt()];		
		System.out.println("Enter the Array elements to Check Max");
		for(int i = 0;i < arr.length;i++) {
			arr[i] = scanner.nextInt();			
		}
		System.out.println(findMax(arr));
		
	}
}
