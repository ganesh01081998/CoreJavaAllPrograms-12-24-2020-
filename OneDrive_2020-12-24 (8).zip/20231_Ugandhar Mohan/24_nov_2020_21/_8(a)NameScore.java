package _7org.ojas.exercise_24_nov_2020;

import java.util.Scanner;

public class _10NameScore {
	static int getNameScore(String str) {
		int score = 0;
		for(int i = 0;i < str.length();i++) {
			int number = 1;
			for(char character = 'a';character <= 'z';character++) {
				if(str.charAt(i) == character) {
					score += number;					
				}
				number++;
			}
		}
		return score;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the String : ");
		String str = scanner.next();
		str = str.toLowerCase();
		System.out.println(getNameScore(str));
	}
}
