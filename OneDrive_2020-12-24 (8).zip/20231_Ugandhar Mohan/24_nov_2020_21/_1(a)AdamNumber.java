package _7org.ojas.exercise_24_nov_2020;

import java.util.Scanner;

public class _1AdamNumber {
	static int getReverse(int number) {
		int lastDigit = 0,reverseNumber =  0;
		while(number > 0) {
			lastDigit = number % 10;
			reverseNumber = reverseNumber * 10 + lastDigit;
			number /= 10; 
		}
		return reverseNumber;
	}
	
	
	static int doPower(int number) {
		if(number > 0) {
			number *= number;
		}
		return number;
	}
	
	
	static boolean isAdamNumber(int inputNumber) {
		int reverseInput = getReverse(inputNumber);
		inputNumber = doPower(inputNumber);
		reverseInput = doPower(reverseInput);
		reverseInput = getReverse(reverseInput);
		if(inputNumber == reverseInput) {
			return true;
		}
		else {
			return false;
		}		
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Input to Check Adam number : ");
		int inputNumber = scanner.nextInt();
		if(isAdamNumber(inputNumber)) {
			System.out.println(inputNumber + " is Adam number");
		}
		else {
			System.out.println(inputNumber + " is  not a Adam number");
		}
		
		
	}
}
