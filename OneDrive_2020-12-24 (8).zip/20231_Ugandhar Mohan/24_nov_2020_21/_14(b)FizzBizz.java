package _7org.ojas.exercise_24_nov_2020;

import java.util.Scanner;

public class _14bFizzBizz {	
	public static void main(String[] args) {		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Number : ");
		int inputNumber = scanner.nextInt();
		System.out.println(getOutputString(inputNumber));
	}

	static String getOutputString(int num) {
		if(num % 3 == 0 && num % 5 ==0) {
			return "FIZZBIZZ";
		}
		 else if(num % 3 ==0) {
			return "FIZZ";
		}
		else if(num % 5 == 0) {
			return "BIZZ";
		}
		else {
			return "The Input is Not Multiple of 3 nor 5  :" + num;
		} 
		
	}
}
