package _7org.ojas.exercise_24_nov_2020;

import java.util.Scanner;

public class _11bFindDuplicatesInArray {
	static String getDuplicateElements(int [] arr) {
		String result = "";
		int flag = 0;
		for(int outerloop = 0;outerloop < arr.length;outerloop++) {
			for(int innerLoop = outerloop + 1;innerLoop < arr.length;innerLoop++) {
				if(arr[outerloop] == arr[innerLoop]) {
					flag++;
				}				
			}
			if(flag == 1) {
				result += "" + arr[outerloop] + " ";
			}
			flag = 0;
		}
		return result;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Size : ");
		int arr[] = new int[scanner.nextInt()];
		for(int i = 0;i < arr.length;i++) {
			arr[i] = scanner.nextInt();
		}
		System.out.println(getDuplicateElements(arr));
	}
}
