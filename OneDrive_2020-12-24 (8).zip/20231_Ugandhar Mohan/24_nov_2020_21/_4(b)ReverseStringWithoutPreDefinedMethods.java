package _7org.ojas.exercise_24_nov_2020;

import java.util.Scanner;

public class _7ReverseStringWithoutPreDefinedMethods {
	static String getReversedString(String str) {
		String result ="";
		for(int i = str.length() - 1;i >= 0;i--){
			result += str.charAt(i);
		}
		return result;
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the String : ");
		String str = scanner.next();		
		System.out.println(getReversedString(str));
	}
}
