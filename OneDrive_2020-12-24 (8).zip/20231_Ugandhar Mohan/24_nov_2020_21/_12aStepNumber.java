package _7org.ojas.exercise_24_nov_2020;

import java.util.Scanner;

public class _12aStepNumber {
	 static boolean isStepNumber(int inputNumber) {
		 int lastDigit = 0,index = 0,count = 0;
		 boolean result = false,finalResult = false;
		 String str ="" + inputNumber;
		 int intarr[] = new int[str.length()];
		 while(inputNumber > 0) {
			 lastDigit = inputNumber % 10;
			  intarr[index] = lastDigit;
			 inputNumber /= 10; 
			 index++;
		 }
		 for(int loop = 0;loop < intarr.length - 1;loop++) {
			 if(Math.abs(intarr[loop] - intarr[loop + 1]) == 1) {
				 result = true;
			 }
			 if(result ) {
				count++;
			 }
			 result = false;
		 }
		 if(count == intarr.length - 1) {
			 finalResult = true;
		 }
		 return finalResult;
		 
	 }
	 	 
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Number : ");
		int inputNumber = scanner.nextInt();
		System.out.println(isStepNumber(inputNumber));				
	}
}
