package _7org.ojas.exercise_24_nov_2020;

import java.util.Scanner;

public class _9LuckyNumber {
	public static void main(String[] args) {		
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter the DOB as DD-MM-YYYY : ");
		String str = scanner.next();
		str = str.replace("-", "");			
		String monthName = str.substring(2, 5);
		int monthnum = getMonthNum(monthName);
		String str1 = str.substring(0,2) + monthnum + str.substring(5,9);			
		System.out.println("Lucky Num : " + getLuckyNum(str1));
}


static int getMonthNum(String str) {
	int result = 0;
	str = str.toLowerCase();
	String [] monthNames = {"jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec"};
	int monthDaysarr [] = {1,2,3,4,5,6,7,8,9,10,11,12};
	for(int i = 0;i < monthNames.length;i++) {
		if(str .equals(monthNames[i])) {
			return result = monthDaysarr[i]; 
		}
	}
	return result;
}


static int getLuckyNum(String str1) {
	int result = 0,loop = 0,temp;
	int number = Integer.parseInt(str1);		
	do {
		temp = getSum(number);
		number = temp;
		result = temp;
		loop = result;
	}while(loop >= 10);
	return result;
}


static int getSum(int number) {
	int lastDigit = 0,sum = 0;
	while(number > 0) {
		lastDigit = number % 10;
		number /= 10; 
		sum += lastDigit; 
	}
	return sum;
}
}
