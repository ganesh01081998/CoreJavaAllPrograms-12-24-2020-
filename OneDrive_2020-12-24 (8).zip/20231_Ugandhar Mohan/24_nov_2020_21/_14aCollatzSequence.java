package _7org.ojas.exercise_24_nov_2020;

import java.util.Scanner;

public class _14aCollatzSequence {
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("Enter the number for collatx sequence : ");
	int number = scanner.nextInt();
	if(number < 0) {
		System.out.println("Error");
		System.exit(0);
	}
	getSequence(number);
}


	static void getSequence(int number) {
		System.out.println("--collatz Sequence--");
		System.out.print(number + " ");
		while (number > 0) {
			
			if(number > 1) {
				if(number % 2 ==0) {
					number = number/2;
					System.out.print(number + " ");
				}
				else {
					number = (number * 3) + 1;
					System.out.print(number + " ");
				}
			}
			else {
				break;
			}
		}
	}

}
