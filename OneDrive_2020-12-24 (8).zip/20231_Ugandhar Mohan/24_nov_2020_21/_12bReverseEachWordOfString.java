package _7org.ojas.exercise_24_nov_2020;

import java.util.Scanner;

public class _12bReverseEachWordOfString {
	static String reverseEachWordOfString(String str) {
		StringBuffer result = new StringBuffer(str);
		return result.reverse().toString();
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the String : ");
		String str = scanner.nextLine();
		String strarr [] = str.split(" ");
		String revStrarr[] = new String[strarr.length];
		for(int i = 0;i < strarr.length;i++) {
			revStrarr[i] = reverseEachWordOfString(strarr[i]);
		}		
		for(String variable : revStrarr) {
			System.out.print (variable + " ");
		}
		
	}
}
