package _2org.ojas._24_nov_2020;

import java.util.Scanner;

public class _2MaskedMailId {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter the mailid : ");
		String str = scanner.nextLine();
		System.out.println( str.replace(str.substring(2, 5), "XXX") );
	}
}
