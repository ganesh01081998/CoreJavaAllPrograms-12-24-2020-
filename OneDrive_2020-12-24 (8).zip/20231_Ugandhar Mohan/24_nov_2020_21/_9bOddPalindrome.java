package _7org.ojas.exercise_24_nov_2020;

import java.util.Scanner;

public class _9bOddPalindrome {
	 static int  lastDigit = 0;
	 static int  reverseNumber = 0;
	 static int temp,num;
	 
	 

static String oddPalindome(int start,int end) {
	String result = "";
	System.out.println("--Odd Palindrome--");
	for(int i = start;i <= end;i++) {
		temp = i;
		num = i;
		while(num > 0) {
			lastDigit = num % 10;
			reverseNumber =reverseNumber *10 + lastDigit;
			num = num / 10;
		}
		if(reverseNumber == temp) {
			if(reverseNumber % 2 != 0) {
				result +=reverseNumber + " ";
			}
		}
		lastDigit = 0;
		reverseNumber = 0;
	}
	return  result;
}


public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("Enter the Range : ");
	int initial = scanner.nextInt(), finalRange =scanner.nextInt();
	System.out.println(oddPalindome(initial, finalRange));
}

}
