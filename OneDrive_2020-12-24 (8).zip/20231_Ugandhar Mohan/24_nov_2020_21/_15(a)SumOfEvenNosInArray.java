package _7org.ojas.exercise_24_nov_2020;

import java.util.Scanner;

public class _15aSumOfEvenNosInArray {
	static int getSumOfEvenNumbers(int[] intarr) {
		int result = 0;
		for(int loop = 0;loop < intarr.length;loop++) {
			if(intarr[loop] % 2 == 0) {
				result += intarr[loop];
			}
		}
		return result;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Size of an Array: ");
		int intarr[] = new int [scanner.nextInt()];
		
		for(int loop = 0;loop < intarr.length;loop++) {
			intarr[loop] = scanner.nextInt();
		}
		System.out.println(getSumOfEvenNumbers(intarr));
	}
}
