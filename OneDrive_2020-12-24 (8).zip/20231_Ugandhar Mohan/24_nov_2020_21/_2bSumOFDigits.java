package _7org.ojas.exercise_24_nov_2020;

import java.util.Scanner;

public class _2bSumOFDigits {
	static int getSumOfDigits(int number) {
		int sum = 0,remainder;		
		while (number >0) {
			remainder = number % 10;
			sum += remainder;
			number /= 10;
		}
		return sum;
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the input : ");
		int number = scanner.nextInt();
		System.out.println(getSumOfDigits(number));		
	}
}
