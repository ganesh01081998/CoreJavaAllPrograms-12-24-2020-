package _2org.ojas._24_nov_2020;

import java.util.Scanner;

public class _3DispVowelsInString {
	static String getVowels(String str) {
		String result = "";
			for(int i = 0;i < str.length();i++) {
				char ch = str.charAt(i);
				if(ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch =='u') {
					result += ch + " "; 
				}
			}
			return result;
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter the inputstring : ");
		String str = scanner.next();
		System.out.println("Vowels in Given input = " + getVowels(str));
	}
}
