package _7org.ojas.exercise_24_nov_2020;

import java.util.Scanner;

public class _8LcmOfTwoNumbers {
	static int findLCM(int number1,int number2) {
		if(number1 <= 0 || number2 <= 0) {
			return -1;
		}
		int lcm = 0;
		if(number1 > number2 ) {
			lcm = number1;
		}	
		else {
			lcm = number2;
			}
		while(true) {
			if(lcm % number1 == 0 && lcm % number2 == 0) {
				return lcm;				
			}
			lcm++;
		}			
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the input : ");
		int number1 = scanner.nextInt(),number2 = scanner.nextInt();
		System.out.println(findLCM(number1, number2));
	}
}
