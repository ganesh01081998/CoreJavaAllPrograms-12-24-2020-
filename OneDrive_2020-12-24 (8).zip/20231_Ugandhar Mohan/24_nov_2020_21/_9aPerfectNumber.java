package _7org.ojas.exercise_24_nov_2020;

import java.util.Scanner;

public class _9aPerfectNumber {
	static String sumOfProperDivisors(int number) {
		String result = "";
		int sum = 0;
		if(number < 0) {
			return result = "" + -2;
		}
		if(number == 0) {
			return result = "" + -3;
		}
		for(int i =1;i < number - 1;i++) {
			if(number % i == 0) {
				sum += i; 
			}
		}
		if(sum == number) {
			return result = "" + 0;
		}
		if(sum > number) {
			return result = "" + 1;
		}
		if(sum < number) {
			return result = "" + -1;
		}		
	    return result; 	
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Number : ");
		int number = scanner.nextInt();
		System.out.println(sumOfProperDivisors(number));			
	}
}
