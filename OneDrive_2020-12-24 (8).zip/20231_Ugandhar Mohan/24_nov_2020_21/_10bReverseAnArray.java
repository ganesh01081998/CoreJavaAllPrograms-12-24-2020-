package _7org.ojas.exercise_24_nov_2020;

import java.util.Scanner;

public class _10bReverseAnArray {
	static int[] reverseArray(int arr[]) {
		int newArr[] = new int[arr.length];
		int newArrayIndex = 0;
		for(int indexNumber = arr.length - 1;indexNumber > -1;indexNumber--) {
			newArr[newArrayIndex] = arr[indexNumber];
			newArrayIndex++;			
		}
		return newArr;
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Size : ");
		int size = scanner.nextInt();		
		int arr[] =new int[size];			
		System.out.println("Enter the array elements : ");
		for(int i = 0;i < arr.length;i++) {
			arr[i] = scanner.nextInt();					
		}
		for(int variable : reverseArray(arr)) {
			System.out.print(variable + " ");
		}
		
	}
}
