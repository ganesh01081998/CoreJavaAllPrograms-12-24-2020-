package _7org.ojas.exercise_24_nov_2020;

import java.util.Scanner;

public class _11QuadraticSequence {
	static int getNthTerm(int loop) {
		int result = 1,increment = 2;
		for(int loopValue = 1;loopValue <= loop - 1;loopValue++) {
			result += increment;
			increment++;
		}
		return result;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Nthterm : ");
		int input = scanner.nextInt();
		System.out.println(getNthTerm(input));
	}
}
