package _7org.ojas.exercise_24_nov_2020;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;

public class _15bSmallestAnd2ndSmallest {
	static int getSmallest(int [] intarr) {
		int result = 0;
		int min = intarr[0];
		for(int index = 0;index < intarr.length;index++) {
			if(intarr[index] < min) {
				min = intarr[index];
			}
		}		
		return min;		
	}
	
	
	static int getSecondSmallest(int [] intarr) {
		int result = 0;
		Arrays.sort(intarr);
		int secmin = intarr[1];
		return secmin;	
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the size : ");
		int intarr[] = new int[scanner.nextInt()];
		System.out.println("Enter the Elements : ");
		for(int loop = 0;loop < intarr.length;loop++) {
			intarr[loop] = scanner.nextInt();
		}
		System.out.println("First Smallest : " + getSmallest(intarr));
		System.out.println("Secound smallest : " + getSecondSmallest(intarr));
	}
}
