package _5org.ojas.exercise_nov_21_2020;

import java.util.Scanner;

public class _5Multiplicationmatrix {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the number --First array--- rows and columns : ");		
		int firstArray[][] = new int[scanner.nextInt()][scanner.nextInt()];
		System.out.println("Enter the number --secound array--- rows and columns : ");
		int secoundArray[][] = new int[scanner.nextInt()][scanner.nextInt()];
		int thirdArray[][] = new int[firstArray.length][firstArray.length];
		System.out.println("Enter the elements in first array");
		for(int i = 0;i < firstArray.length;i++) {
			for(int j = 0;j < firstArray[i].length;j++) {
				firstArray[i][j] = scanner.nextInt();
			}
		}
		System.out.println("Enter the elements in secound array");
		for(int a = 0;a < secoundArray.length;a++) {
			for(int b = 0;b < secoundArray[a].length;b++) {
				secoundArray[a][b] = scanner.nextInt();
			}
		}
		//Below nested loop is for Multiplication
		
		for(int i = 0;i < firstArray.length;i++) {
			for(int j = 0;j < firstArray[i].length;j++) {
				thirdArray[i][j] = 0;
				for(int c = 0; c < thirdArray[j].length;c++) {
				thirdArray[i][j] += firstArray[i][c]* secoundArray[c][j];
				//arr3[i][j] += arr1[i][k] * arr2[k][j];
				}
				System.out.print(thirdArray[i][j] + " ");
			}
			System.out.println();
		}
		
		
		
		System.out.println("--Multiplication--");
		for(int a = 0;a < secoundArray.length;a++) {
			for(int b = 0;b < secoundArray[a].length;b++) {
				System.out.print(thirdArray[a][b] + " ");
			}
			System.out.println();
		}
		
		
	}
}
