package _6org.ojas.exercise_nov_21_2020;

import java.util.Scanner;

public class _2maxNumber {
	static void getMax(int[] inputArray) {		 		 
		 int max = inputArray[0];
		 for(int a = 0;a < inputArray.length;a++) {
			 if(inputArray[a] > max) {
				 max = inputArray[a];
			 }
		 }
		 System.out.println("Bigger =" + max);		
	 }
	
	 
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Size of an array as 10 only : ");
		int size = scanner.nextInt();	
		
		try {
			//If the input array size is not equal to 10, return null.
			if(size != 10) {
				System.out.println("-1");
				System.exit(size);
			}
			else {
				 int intarray[] = new int[size];
					System.out.println("Enter the " + size + " elements  : ");
				for(int i = 0;i < intarray.length;i++) {
					intarray[i] = scanner.nextInt();
				}
				getMax( intarray);
			}		
		}	
		catch(Exception e) {
			System.out.println("-1");
		}
	}
}
