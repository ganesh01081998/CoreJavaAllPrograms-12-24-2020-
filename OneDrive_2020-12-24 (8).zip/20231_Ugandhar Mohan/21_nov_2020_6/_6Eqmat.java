package _6org.ojas.exercise_nov_21_2020;

import java.util.Scanner;

public class _6Eqmat {
	static void readarray(int [][] a,int[][] b) {
		System.out.println("Enter the first elements in first array");
		Scanner scanner = new Scanner(System.in);
		for(int i = 0;i < a.length;i++) {
			for(int j = 0;j < a[i].length;j++) {
				a[i][j] = scanner.nextInt();
			}
		}
		System.out.println("Enter the secound array elements in first array");
		for(int i = 0;i < b.length;i++) {
			for(int j = 0;j < b[i].length;j++) {
				b[i][j] = scanner.nextInt();
			}
		}		
	}
	
	
	static int check(int [][] a,int[][] b) {
		
		for(int i = 0;i < a.length;i++) {
			for(int j = 0;j < a[i].length;j++) {
				if(a[i][j] != b[i][j]) {
					return 0;
				}
			}
		}
		return 1;		
	}
	static void print (int [][] a,int[][] b) {
		System.out.println("First array");
		for(int i = 0;i < a.length;i++) {
			for(int j = 0;j < b[i].length;j++) {
				System.out.print(a[i][j] + " ");
			}
			System.out.println();
		}
		System.out.println("Secound Array");
		for(int i = 0;i < a.length;i++) {
			for(int j = 0;j < b[i].length;j++) {
				System.out.print(b[i][j] + " ");
			}
			System.out.println();
		}
	}
	
	

	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the number  rows and columns : ");		
		int m = scanner.nextInt() ,n = scanner.nextInt();
		int a[][] = new int[m][n];
		int b[][] = new int[m][n];
		readarray(a,b);
		System.out.println(check(a, b));
		print(a, b);
		
	}
}
