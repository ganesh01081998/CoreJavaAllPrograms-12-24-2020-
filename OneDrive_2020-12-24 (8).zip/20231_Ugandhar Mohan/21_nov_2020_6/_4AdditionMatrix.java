package _6org.ojas.exercise_nov_21_2020;

import java.util.Scanner;

public class _4AdditionMatrix {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the number --First array--- rows and columns : ");		
		int firstArray[][] = new int[scanner.nextInt()][scanner.nextInt()];
		System.out.println("Enter the number --secound array--- rows and columns : ");
		int secoundArray[][] = new int[scanner.nextInt()][scanner.nextInt()];
		int thirdArray[][] = new int[firstArray.length][firstArray.length];
		System.out.println("Enter the elements in first array");
		for(int i = 0;i < firstArray.length;i++) {
			for(int j = 0;j < firstArray[i].length;j++) {
				firstArray[i][j] = scanner.nextInt();
			}
		}
		System.out.println("Enter the elements in secound array");
		for(int a = 0;a < secoundArray.length;a++) {
			for(int b = 0;b < secoundArray[a].length;b++) {
				secoundArray[a][b] = scanner.nextInt();
			}
		}
		//Below nested loop is for Addition
		
		for(int i = 0;i < firstArray.length;i++) {
			for(int j = 0;j < firstArray[i].length;j++) {
				thirdArray[i][j] = firstArray[i][j]  + secoundArray[i][j];  
			}
		}
		System.out.println("--Addition--");
		for(int a = 0;a < secoundArray.length;a++) {
			for(int b = 0;b < secoundArray[a].length;b++) {
				System.out.print(thirdArray[a][b] + " ");
			}
			System.out.println();
		}
		
		
	}
}
