package com.ojas;

import java.util.Scanner;

public class Diff21 {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the number");
	int a=sc.nextInt();
	diff21(a);
}

private static int diff21(int a) {
	int res=0;
	 res=21-a;
	System.out.println(res);
	return res;
}
}
