package com.ojas;

import java.util.Scanner;

public class PalyndromeAndFibonacci {
	static int num3;
	
	
	static void isPalindrome(int num3,int num,int num1,int num2) {
		for(int i = 1; i <= num;i++) {
			num3 = num1 + num2;
			num1 = num2;
			num2 = num3;
			System.out.println("The Fabinocci series are:"+ num3 +" ");
		int temp = num3;
		int rem, sum = 0;
		while(num3 > 0) {
			rem = num3 % 10;
			sum = (sum * 10)+ rem;
			num3 = num3 / 10;
		}
		if( temp == sum) {
			System.out.println(sum + "Palindome");
		}
		else {
			System.out.println(sum + "Not a Palindome");
		}
	}
	}
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("enter number for iterate");
		int num = scan.nextInt();
		System.out.println("enter  a value");
		int num1 = scan.nextInt();
		System.out.println("enter  b value");
		int num2 = scan.nextInt();
		scan.close();
		isPalindrome(num3,num, num1, num2);
	}
}
