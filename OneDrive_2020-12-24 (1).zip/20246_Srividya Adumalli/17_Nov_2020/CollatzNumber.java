package com.ojas;

import java.util.Scanner;

public class CollatzNumber {
  public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("enter the number");
	int num = sc.nextInt();
	System.out.println(getCollatz(num));
}

private static int getCollatz(int num) {
	while(num!=1){
		if(num==1){
			return 1;
		}
		else if(num%2==0){
			num=num/2;
			System.out.println(num);
		}
		else if(num%2!=0){
			num=num*3+1;
			System.out.println(num);
		}
		
	}
	
	return num;
	
}
  
}
