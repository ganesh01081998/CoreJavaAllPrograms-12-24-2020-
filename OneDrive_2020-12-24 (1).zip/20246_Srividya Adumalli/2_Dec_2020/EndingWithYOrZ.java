package com.ojas;

import java.util.Scanner;

public class EndingWithYOrZ {
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the String");
		/*
		 * String[] str=new String[2]; for(int i=0;i<str.length;i++){
		 * str[i]=sc.next(); }
		 */
		String str1 = sc.next();
		String str2 = sc.next();
		System.out.println(getCountYZ(str1, str2));
		// str.charAt(0);
		// str.charAt(str.length()-1);
	}

	private static int getCountYZ(String str1, String str2)
	{

		// System.out.println(str.length);
		int count = 0;
		if (str1.charAt(str1.length() - 1) == 'z' || str1.charAt(str1.length() - 1) == 'y')
		{
			count++;
		}
		if (str2.charAt(str2.length() - 1) == 'z' || str2.charAt(str2.length() - 1) == 'y') 
		{
			count++;
		}

		return count;

	}
}
