package com.ojas;

import java.util.Scanner;

public class WeavedString  
{
	public static void main(String[] args)
	{

		Scanner sc = new Scanner(System.in);
		System.out.println("enter the String 1");
		String str1 = sc.next();
		System.out.println("enter the String 2");
		String str2 = sc.next();
		System.out.println(weave(str1, str2));
	}

	private static String weave(String str1, String str2) 
	{
		int value1 = str1.length();
		int value2 = str2.length();
		String str = "";
		if (value1 > value2)
		{

			// System.out.println(value2+value1+value2);
			return str2 + "" + str1 + "" + str2;
		} else if (value2 > value1) 
		{

			// System.out.println(value1+value2+value1);
			return str1 + "" + str2 + "" + str1;
		} else if (value1 == value2) 
		{

			for (int i = 0; i < str1.length(); i++)
			{
				for (int j = 0; j < str2.length(); j++)
				{
					if (str1.charAt(i) == str2.charAt(j))
					{

						str += str1.charAt(i) + "" + str2.charAt(i);
					}
				}

			}
		}
		return str;
	}
}
