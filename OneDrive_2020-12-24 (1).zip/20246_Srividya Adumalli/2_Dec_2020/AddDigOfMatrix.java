package com.ojas;

import java.util.Scanner;

public class AddDigOfMatrix {
	public static void main(String[] args) 
	{
		/*
		 * Scanner sc=new Scanner(System.in);
		 * System.out.println("enter the matrix"); int[][] arr=new int[3][3];
		 * for(int i=0;i<arr.length;i++){ for(int j=0;j<arr[i].length;j++){
		 * arr[i][j]=sc.nextInt(); } int a=arr[0][0]+arr[1][1]+arr[2][2];
		 * System.out.println(a);
		 */
		int[][] arr1 = new int[3][3];
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the first matrix");
		for (int i = 0; i < arr1.length; i++) 
		{
			for (int j = 0; j < arr1[i].length; j++) 
			{
				arr1[i][j] = sc.nextInt();
			}

		}
		addDiag(arr1);
	}

	private static void addDiag(int[][] arr1)
	{
		int a = arr1[0][0] + arr1[1][1] + arr1[2][2];
		System.out.println(a);
	}
}
