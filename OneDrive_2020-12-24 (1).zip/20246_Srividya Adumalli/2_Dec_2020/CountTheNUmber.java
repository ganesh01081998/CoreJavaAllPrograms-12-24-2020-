package com.ojas;

import java.util.Scanner;

public class CountTheNUmber {
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the array");
		int[] a = new int[5];
		for (int i = 0; i < a.length; i++) 
		{
			a[i] = sc.nextInt();
		}
		System.out.println("enter the count element");
		int b = sc.nextInt();
		System.out.println(getCount(a, b));
	}

	private static int getCount(int[] a, int b) 
	{
		int c = a[0];
		int count = 0;
		for (int j = 0; j < a.length; j++)
		{
			if (a[0] == a[j])
			{
				count++;
			}
		}
		return count;

	}
}
