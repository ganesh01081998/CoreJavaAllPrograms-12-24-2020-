package com.ojas;

import java.util.Scanner;

public class PallindromeFOrRecurssion  
{

	public static String getPalindromList(int num, int rev)
	{
		String str = "";
		int num1 = num;
		if (num1 == rev) {
			str += "is palindrome " + num1;
		} else 
		{
			int sum = num1 + rev;
			System.out.println(sum);
			isReverse(sum);

		}
		return str;

	}

	public static void isReverse(int num)
	{
		int rev = 0;
		int temp = 0;
		int num1 = num;
		while (num > 0) {
			temp = num % 10;
			rev = rev * 10 + temp;
			num = num / 10;
		}
		System.out.println(rev);
		System.out.println(getPalindromList(num1, rev));
	}

	public static void main(String[] args) 
	{
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter number");
		int num = scanner.nextInt();
		isReverse(num);

	}
}
