package com.ojas;

import java.util.Scanner;

public class SumOfDigitsInString {
	public static void main(String[] args) 
	{

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the String");
		// String st="adb4hh5h1";
		String st = sc.next();
		System.out.println(sum(st));
	}

	private static int sum(String st) 
	{
		String temp = "0";
		int sum = 0;
		for (int i = 0; i < st.length(); i++) 
		{
			char ch1 = st.charAt(i);
			if (Character.isDigit(ch1))
			{
				temp += ch1;

			} else 
			{
				sum += Integer.parseInt(temp);
				temp = "0";
			}
		}
		return sum + Integer.parseInt(temp);

	}
}
