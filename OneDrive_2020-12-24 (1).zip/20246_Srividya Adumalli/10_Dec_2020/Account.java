package com.ojas;

import java.util.Scanner;

public class Account {

	double balance;
	int accno;
	float interestRate;

	public Account(Customer firstName, Customer lastName, double balance, int accno, float interestRate) {

		this.balance = balance;
		this.accno = accno;
		this.interestRate = interestRate;
	}

	@Override
	public String toString() {
		return "Account [balance=" + balance + ", accno=" + accno + ", interestRate=" + interestRate + "]";
	}

	public void withdraw(double balance, float amountforWithdraw) {
		// System.out.println("in withdraw method");
		balance = this.balance - amountforWithdraw;
		System.out.println(balance);
	}
	private void deposite1(double balance, float amountToDeposite) {
		balance = balance + amountToDeposite;
		System.out.println("Your Available balance is int your Account " + balance);
	}

	void checkAccNo() {
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Customer cust = new Customer("sri", "vidya");
		Account acc = new Account(cust, cust, 3000, 12345, 2);

		System.out.println("Please Enter Your Account number");
		int acno = sc.nextInt();
		if (acc.accno == acno) {
			System.out.println("Please Proceed for your Operations");
			System.out.println();
		} else {
			System.err.println("Please check Your Account Number Once Again");
		}

		if (acc.accno == acno) {
			for (int k = 0; k < 5; k++) {
				for (int i = 1; i < 2; i++) {
					System.out.println("please enter your wishing number");
					System.out.println("enter " + i + " for deposite");
					System.out.println("enter " + (i + 1) + " for withdraw ");
					System.out.println("enter " + (i + 2) + " for exit ");

					int j = sc.nextInt();
					if (j == 1) {

						System.out.println("enter amt to deposite");
						float amountToDeposite = sc.nextFloat();
						acc.deposite1(acc.balance, amountToDeposite);
					}

					else if (j == 2) {

						int j1 = sc.nextInt();
						System.out.println("enter amt to withdraw");
						float amountToDeposite = sc.nextFloat();
						acc.withdraw(acc.balance, amountToDeposite);
					}

					else if (j == 3) {
						System.out.print("Thank You " + cust.getFirstName());
						System.out.println(cust.getLastName());
						break;
					}
				}
			}
		}
	}
}
