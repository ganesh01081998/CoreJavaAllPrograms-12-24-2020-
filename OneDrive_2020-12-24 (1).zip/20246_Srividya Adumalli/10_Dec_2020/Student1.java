package com.ojas;

import java.util.Arrays;
import java.util.Scanner;

public class Student1 {
	 String[] str={"1.Java","2.Python","3.Html","4.CRT","5.Oracle","6.SalesForce"};
	    int[] prices={1000,2000,3000,4000,5500,7000};

@Override
		public String toString() {
			return "Student1 [str=" + Arrays.toString(str) + ", prices=" + Arrays.toString(prices) + "]";
		}



public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the Student id");
	int sid=sc.nextInt();
	System.out.println("enter Student Name");
	String sname=sc.next();
	System.out.println("enter Student Add");
	String add=sc.next();
	Student1 s1=new Student1();
	
	printDetails(s1.str, s1.prices);
}



private static void printDetails(String[] str, int[] prices) {
	Scanner sc=new Scanner(System.in);
	/*for(int i=0;i<str.length;i++){
		//System.out.println(str[i]);
	}
	*/
	System.out.println();
	
	/*for(int i=0;i<prices.length;i++){
		//System.out.println(prices[i]);	
	}*/
	System.out.println("enter 1-7 for selecting u r courses");
	int[] arr=new int[7];
	int sum=0;
	for(int i=0;i<str.length;i++){
		arr[i]=sc.nextInt();
		for(int j=0;j<prices.length;j++){
			
		if(arr[i]==j+1){
			System.out.println(str[i]+" price is "+prices[i]);
			
		 sum+=prices[j];
		
			System.out.println("Total price  is :: "+sum);
	}	
		
	}
		
	}
	 System.out.println("The Sum Of Your Selected Courses is "+sum);
}
public void calDetails(String[] str,int[] arr,int[] prices){
	
}

}


