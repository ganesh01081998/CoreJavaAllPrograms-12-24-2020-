package com.ojas;

import java.util.Scanner;

public class Rectangle {
	private int x1, y1, x2, y2;
     
	public Rectangle() {
		super();
	}

	public Rectangle(int x1, int y1, int x2, int y2) {

		this.x1 = x1;
		this.y1 = y1;
		this.x2 = x2;
		this.y2 = y2;
	}
	public int getPerimeter(int height, int width) {

		int perimeter = 2 * (height + width);
		return perimeter;
	}

	public int getHeight(int height, int width, int perimeter) {
		height = (perimeter / 2) - width;
		return height;
	}

	public int getWidth(int height, int width, int perimeter) {
		width = (perimeter / 2) - height;
		return width;
	}

	public int getArea(int height, int width) {
		int area = 0;
		area = height * width;

		return area;
	}

	public void isPointInside(int x1, int y1, int height, int width,int x2,int y2) {
		if (height > x1 && width>y1 && height <x2 && width >y2) {
			System.out.println("Points are in side of rectanlge");
		}
		
		else {
			System.out.println("the points are not lies inside the rectangle");
		}
	}

	public void move(int deltax, int deltay,int height,int width) {
		x1 = deltax;
		y1 = deltay;
		x2 = height + x1;
		y2 = width + y1; 

		String res ="\n After moved (0,0) To (" + deltax + "," + deltay + ")  \n x1 is :" + x1 + "\n y1 is :" + y1
				+ "\n x2 is :" + x2 + "\n y2 is :" + y2;
		System.out.println(res);
	}

	public static void main(String[] args) {

		Rectangle rec = new Rectangle();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the values of  height,width");

		int x1 = 0;
		int y1 = 0;
		int deltax=0;int deltay=0;
		int height = sc.nextInt();
		int width = sc.nextInt();
	    int x2=height+rec.x1;
	    int y2=width+rec.y1;
	    
		int perimeter = rec.getPerimeter(height, width);
		int area = rec.getArea(height, width);
		System.out.println("the x1 and y1 cordinates are" + "(" + x1 + "," + y1 + ")");
		System.out.println("the points of x2 and y2 are"+ "(" + x2 + "," + y2 + ")");
		System.out.println("Height of the Rectangle :: " + rec.getHeight(height, width, perimeter));
		System.out.println("Width of the Rectangle :: " + rec.getWidth(height, width, perimeter));
		System.out.println("Area of the Rectangle :: " + area);
		System.out.println("Perimeter of the Rectangle :: " + perimeter);
		
		rec.isPointInside(x1, y1, height, width,x2,y2);
		rec.move(10, 2, height, width);
	}

}
