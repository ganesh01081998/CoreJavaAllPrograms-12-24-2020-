package com.ojas;

import java.util.Scanner;

public class CountEvensInArray {
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the array");
		int[] arr = new int[4];
		for (int i = 0; i < arr.length; i++)
		{
			arr[i] = sc.nextInt();

		}
		System.out.println("having the " + coutnEvens(arr) + " even elements");
	}

	private static int coutnEvens(int[] arr)
	{
		int count = 0;
		for (int i = 0; i < arr.length; i++)
		{
			if (arr[i] % 2 == 0)
			{
				count++;
				int b1 = arr[i];
				System.out.println(b1);
			}
		}
		return count;
	}

}
