package com.ojas;

import java.util.Scanner;

public class RemovingTen {
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the array");
		int[] arr = new int[5];
		for (int i = 0; i < arr.length; i++)
		{
			arr[i] = sc.nextInt();

		}
		withoutTen(arr);
		findTen(arr);
	}

	private static void findTen(int[] arr)
	{

	}

	private static void withoutTen(int[] arr)
	{
		int count = 0;
		for (int i = 0; i < arr.length; i++)
		{
			if (arr[i] == 10) {
				arr[i] = 0;
				count++;
			}
		}
		// System.out.println(count);
		for (int i = 0; i < arr.length; i++)
		{
			int temp = arr.length-1;
			if (arr[i] == 0) {
             // temp=arr[i];
				
			}
			System.out.println(arr[i]);
		}
	}

}
