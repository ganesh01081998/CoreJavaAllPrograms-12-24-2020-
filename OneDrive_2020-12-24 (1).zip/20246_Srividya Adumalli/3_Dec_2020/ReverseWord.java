package com.ojas;

import java.util.Scanner;

public class ReverseWord {
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("ente rthe String");
		String str = sc.next();
		char[] ch = str.toCharArray();

		getReverseWord(ch);
	}

	private static void getReverseWord(char[] ch)
	{
		for (int i = ch.length - 1; i >= 0; i--)
		{
			System.out.print(ch[i]);
		}
	}
}
