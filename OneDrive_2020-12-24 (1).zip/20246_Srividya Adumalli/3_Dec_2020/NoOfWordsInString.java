package com.ojas;

import java.util.Scanner;

public class NoOfWordsInString {
	public static void main(String[] args)  
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the String");
		String str = sc.nextLine();
		String[] str1 = str.split(" ");

		getCountOfWords(str1);

	}

	private static void getCountOfWords(String[] str1) 
	{
		int count = 0;

		for (int i = 0; i < str1.length; i++)
		{
			count++;
		}
		System.out.println(count);
	}
}
