package com.ojas;

import java.util.Scanner;

public class CountOfa {
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the String");
		String name = sc.next();
		System.out.println(getCountOfa(name));
	}

	private static int getCountOfa(String name) 
	{
		int count = 1;
		for (int i = 0; i < name.length(); i++)
		{
			if (name.charAt(i) == 'a') 
			{
				count++;
			}
		}
		return count;
	}
}
