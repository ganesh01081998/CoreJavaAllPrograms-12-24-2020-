package com.ojas;

import java.util.Scanner;

public class FindingTheWord {
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the Sentence");
		String str1 = sc.nextLine();

		System.out.println("enter the String to search");
		String str2 = sc.nextLine();
		checkString(str1, str2);
	}

	private static void checkString(String str1, String str2) 
	{
		if (str1.contains(str2))

		{
			System.out.println(str2 + " is present in theString");
		} else
			System.out.println(str2 + " is not present");

	}
}
