package com.ojas;

import java.util.Scanner;

public class StringIsNunberOrNot {
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the String");
		String str = sc.nextLine();
		System.out.println(checkNumberorNot(str));
	}

	private static String checkNumberorNot(String str)
	{
		int count = 0;
		// System.out.println(str.length());
		for (int i = 0; i < str.length(); i++)
		{
			char ch = str.charAt(i);
			if (Character.isDigit(ch)) 
			{
				// if (str.length() == ch)
				{
					return true + "  is a valid Integer";
				}
			} else
				return false + "  is not a valid Integer";

		}
		return str;
	}
}