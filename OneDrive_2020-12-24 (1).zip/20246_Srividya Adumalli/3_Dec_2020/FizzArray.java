package com.ojas;

import java.util.Scanner;

public class FizzArray 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the element 1");
		int a = sc.nextInt();
		System.out.println("enter the element 2");
		int b = sc.nextInt();
		fizzArray(a, b);
	}

	private static void fizzArray(int a, int b)
	{

		for (int i = a; i <= b - 1; i++)
		{
			System.out.println(i);
		}
	}
}
