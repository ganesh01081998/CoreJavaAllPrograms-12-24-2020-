package com.ojas;

import java.util.Scanner;

 

public class Manager extends Employee {
	 ManagerEnum mgr;

	public ManagerEnum getMgr() {
		return mgr;
	}

	public void setMgr(ManagerEnum mgr) {
		this.mgr = mgr;
	}

	public Manager(String ename, int emid, double sal, ManagerEnum mgr) {
		//super(ename, emid, sal);
		this.ename=ename;
		this.emid=emid;
		this.sal=sal;
		this.mgr = mgr;
	}

	public Manager(String ename, int emid, double sal) {
		this.ename=ename;
		this.emid=emid;
		this.sal=sal;
		
	}

	   void setSalary(double sal,String HR) {
		
		   if(HR.equalsIgnoreCase(HR)) {
			   
			   sal=this.sal+10000;
			   System.out.println("Your salary is incremented to 10000 now your sal is : "+sal);
		   }
	   }
		   void setSalary1(double sal,String sales) {
		    if(sales.equalsIgnoreCase(sales)) {
			   sal=this.sal+5000;
			   System.out.println("Your salary is incremented to 5000 now your sal is : "+sal);
		   } 
	   }
	   public static void main(String[] args) {
		   Scanner sc=new Scanner(System.in);
		   System.out.println("please enter your belonging to Hr or sales manager");
		   String HR=sc.next();
		  String sales="";
		   if(HR.equalsIgnoreCase(HR)){
		   Manager mgr=new Manager("raju",101,20000);
		   mgr.setSalary(mgr.sal, HR);
		   }
		   
		   System.out.println("please your belonging to enter Hr or sales manager");
		   
		      if(sales.equalsIgnoreCase(sales)){
			    sales=sc.next();
			   Manager mgr=new Manager("raju",101,10000);
		   mgr.setSalary1(mgr.sal, sales);
		   }
	}
	}