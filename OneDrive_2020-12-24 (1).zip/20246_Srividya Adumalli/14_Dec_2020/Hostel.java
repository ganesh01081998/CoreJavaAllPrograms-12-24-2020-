package com.ojas;

import java.util.Scanner;

public class Hostel extends Student {

	double hstlFee = 9000;
	Student std;

	public Hostel(double trasportFee, int sid, String sname, double fee) {
		super();
		this.hstlFee = trasportFee;
		this.std = std;
		this.sid = sid;
		this.sname = sname;
		this.fee = fee;
	}

	public Hostel(double trasportFee, Student std) {

		this.hstlFee = trasportFee;
		this.std = std;
	}

	@Override
	public String toString() {
		return "Hostel [HostelFee=" + hstlFee + ", std=" + std + "]";
	}

	public Hostel(int sid, String sname, double fee) {

		this.sid = sid;
		this.sname = sname;
		this.fee = fee;

	}

	double payFee(double fee) {
		return fee + hstlFee;

	}

	public static void hostel() {
		Student std = new Student(101, "Srividya", 5000);
		System.out.println("Exam fee is : " + std.fee);
		System.out.println(std.toString());
		Hostel std2 = new Hostel(3000, std);
		System.out.println("Hostel fee is : " + std2.hstlFee);
		System.out.println(std2.toString());
		double totamt = std.fee + std2.hstlFee;
		System.out.println("You need to pay " + totamt);
		Student stdc2 = new Hostel(1000, 101, "Srividya", 5000);

		Student stdc1 = new Daysscholer(101, "vidya", 5000);

		// System.out.println(stdc1.DisplayDetails(stdc1.sid, stdc1.sname,
		// stdc1.fee));
		// System.out.println(stdc1.payFee(stdc1.fee));

		// static void check(double totamt){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Amount u want to pay");
		double amtToPay = sc.nextDouble();
		double amt = totamt - amtToPay;
		double amt1 = amtToPay - totamt;
		if (amtToPay < totamt) {
			System.out.println("You need to pay more :: " + amt);
		} else if (amtToPay > totamt) {
			System.out.println("You paid more remaing amt :: " + amt1);
		} else if (amtToPay == totamt) {
			System.out.println("Thank You :)");
		}
	}

}
