package com.ojas;

import java.util.Scanner;

public class Daysscholer extends Student {
	double trasportFee;
	Student std;

	public Daysscholer(double trasportFee, int sid, String sname, double fee) {
		super();
		this.trasportFee = trasportFee;
		this.std = std;
		this.sid = sid;
		this.sname = sname;
		this.fee = fee;
	}

	public Daysscholer(double trasportFee, Student std) {

		this.trasportFee = trasportFee;
		this.std = std;
	}

	@Override
	public String toString() {
		return "Daysscholer [trasportFee=" + trasportFee + ", std=" + std + "]";
	}

	public Daysscholer(int sid, String sname, double fee) {

		this.sid = sid;
		this.sname = sname;
		this.fee = fee;

	}

	double payFee(double fee) {
		return fee + trasportFee;

	}

	public static void DaysscholerStudent() {

		Student std = new Student(101, "Srividya", 5000);
		System.out.println("Exam fee is : " + std.fee);
		// System.out.println(std.toString());
		// Student std2=new Daysscholer(1000,std);
		Daysscholer std2 = new Daysscholer(1000, std);
		System.out.println(std.toString());
		System.out.println("Trasport fee is : " + std2.trasportFee);
		System.out.println(std2.toString());
		double totamt = std.fee + std2.trasportFee;
		System.out.println("You need to pay " + totamt);
		Student stdc2 = new Daysscholer(1000, 101, "Srividya", 5000);

		Student stdc1 = new Daysscholer(101, "vidya", 5000);

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Amount u want to pay");
		double amtToPay = sc.nextDouble();
		double amt = totamt - amtToPay;
		double amt1 = amtToPay - totamt;
		if (amtToPay < totamt) {
			System.out.println("You need to pay more :: " + amt);
		} else if (amtToPay > totamt) {
			System.out.println("You paid more remaing amt :: " + amt1);
		} else if (amtToPay == totamt) {
			System.out.println("Thank You :)");
		}

		// System.out.println(stdc1.DisplayDetails(stdc1.sid, stdc1.sname,
		// stdc1.fee));
		// System.out.println("You need to pay the total Amount is ::
		// "+stdc1.payFee(stdc1.fee));
	}

}
