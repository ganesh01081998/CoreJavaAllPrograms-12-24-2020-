package com.ojas;

import java.util.Scanner;

public class Clerk extends Employee {
	int speed;
	int accuracy;
	
	int getSpeed() {
		return speed;
	}
	void setSpeed(int speed) {
		this.speed = speed;
	}
	int getAccuracy() {
		return accuracy;
	}
	void setAccuracy(int accuracy) {
		this.accuracy = accuracy;
	}
	
	public Clerk() {
		
	}
	public Clerk(String ename, int emid, double sal, int speed, int accuracy) {
		super(ename, emid, sal);
		this.ename=ename;
		this.emid=emid;
		this.sal=sal;
		this.speed = speed;
		this.accuracy = accuracy;
	}
	
	public void setSalary(double sal){
		if(speed>70 && accuracy>80){
			sal=sal+1000;
			System.out.println("Your accuracy and speed are out of range so your salary is incremented to 1000 :: "+sal);
		}
		else{
			System.out.println("Your basic salary is :: "+sal);
		}
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner (System.in);
		System.out.println("enter speed");
		int speed=sc.nextInt();
		System.out.println("enter Accuracy");
		int accuracy =sc.nextInt();
		Clerk clk=new Clerk("vidya",101,10000,speed,accuracy);
		clk.setSalary(clk.sal);
		}
	}
	


