package com.ojas;

import java.util.Scanner;

public class Checker {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter where you want to come from :: ");
		String[] str = { "hostel  or  ", "  Daysscholer" };
		for (int i = 0; i < str.length; i++) {
			System.out.print(str[i]);
		}
		String str1 = sc.next();

		String s1 = "Hostel";
		String s2 = "Daysscholer";

		if (str1.equalsIgnoreCase(s1)) {
			Hostel.hostel();

		} else if (str1.equalsIgnoreCase(s2)) {
			Daysscholer.DaysscholerStudent();

		}
	}
}
