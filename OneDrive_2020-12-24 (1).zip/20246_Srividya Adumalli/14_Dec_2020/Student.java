package com.ojas;

public class Student {
	int sid;
	String sname;
	double fee;

	@Override
	public String toString() {
		return "StudentInClg [sid=" + sid + ", sname=" + sname + ", fee=" + fee + "]";
	}

	public Student() {
		super();
	}

	public Student(int sid, String sname, double fee) {
		super();
		this.sid = sid;
		this.sname = sname;
		this.fee = fee;
	}

	String DisplayDetails(int sid, String sname, double fee) {
		/*
		 * this.sid=sid; this.sname=sname; this.fee=fee;
		 */
		return "" + sid + " " + sname + " " + fee;
	}

	double payFee(double fee) {
		return fee;

	}

}
