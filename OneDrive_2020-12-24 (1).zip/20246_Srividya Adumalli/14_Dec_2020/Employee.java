package com.ojas;

public class Employee {
	
	
	
	public String ename;
	public int emid;
	public double sal;
	 
	public Employee(String ename, int emid, double sal) {
		
		this.ename = ename;
		this.emid = emid;
		this.sal = sal;
	}
	
	public Employee() {
		super();
	}

	public String getEname() {
		return ename;
	}
	
	public void setEname(String ename) {
		this.ename = ename;
	}
	
	public int getEmid() {
		return emid;
	}
	
	public void setEmid(int emid) {
		this.emid = emid;
	}
	
	public double getSal() {
		return sal;
	}
	
	public void setSal(double sal) {
		this.sal = sal;
	}
	

}
