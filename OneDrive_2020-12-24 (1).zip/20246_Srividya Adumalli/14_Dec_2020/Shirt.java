package com.ojas;

import java.util.Scanner;

public class Shirt {
	float collerSize;
	float length;
	String mat;

	static ShirtMaterial strm;

	float getCollerSize() {
		return collerSize;
	}

	String getMat() {
		return mat;
	}

	void setMat(String mat) {
		this.mat = mat;
	}

	void setCollerSize(float collerSize) {
		this.collerSize = collerSize;
	}

	float getLength() {
		return length;
	}

	void setLength(float length) {
		this.length = length;
	}

	ShirtMaterial getMaterial() {
		return strm;
	}

	void setMaterial(ShirtMaterial strm) {
		this.strm = strm;
	}

	public Shirt(float collerSize, float length, ShirtMaterial strm) {

		this.collerSize = collerSize;
		this.length = length;
		this.strm = strm;
	}

	static String displayDetails(float collerSize, float length, ShirtMaterial mat) {
		return "Shirt [collerSize=" + collerSize + ", length=" + length + ", material=" + mat + "]";
	}

	public Shirt() {
		collerSize = 0;
		length = 0;
		mat = "cotton";

	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter collerSize");
		int collerSize = sc.nextInt();
		System.out.println("enter length");
		int length = sc.nextInt();
		String[] str={"1.cotten","2.linen","3.polyester"};
		for(int i=0;i<str.length;i++){
			System.out.println(str[i]);
		}
		System.out.println("enter Material what you like");

		
		//ShirtMaterial strm1 = ShirtMaterial.linen;
		//ShirtMaterial strm2 = ShirtMaterial.polyester;

		String material = sc.next();
		
		
		
		if(material.equalsIgnoreCase("cotten")){
			System.out.println(displayDetails(collerSize, length, ShirtMaterial.cotten));
		}
		else if (material.equalsIgnoreCase("linen")) {
			System.out.println(displayDetails(collerSize, length, ShirtMaterial.linen));
		}

		else if (material.equalsIgnoreCase("polyester")) {
			System.out.println(displayDetails(collerSize, length, ShirtMaterial.polyester));
		}
		else{
			System.out.println("the type of cloth is not available");
		}

	}
}


