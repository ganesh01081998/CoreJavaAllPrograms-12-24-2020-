package com.ojas;

public enum ShirtMaterial {
	cotten, linen, polyester
}
