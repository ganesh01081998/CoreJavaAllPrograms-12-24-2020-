package com.ojas;

enum ManagerEnum {
	HR, sales;
}
