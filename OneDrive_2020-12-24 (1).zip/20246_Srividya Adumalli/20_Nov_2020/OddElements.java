package com.ojas;

import java.util.Scanner;
public class OddElements {
	static int[] getOddArray(int[] arr) 
	{
		int a1 = arr.length;
		System.out.println(a1);

		if (a1 != a1)
		{
			System.out.println("null");
		} else {
			for (int i = 0; i < a1; i++) 
			{
				if (arr[i] % 2 != 0)
				{
					// System.out.println(inputArray[i]);
					int b1 = arr[i];
					System.out.println("in b Array " + b1);
				} else {
					
				}
			}
		}
		return arr;
	}
	public static void main(String[] args)
	{
		//int a[] = { 1, 2, 6, 3, 5, 4, 8, 9, 7, 10 };
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the elements");
		int[] a = new int[5];
		
		for (int i = 0; i < a.length; i++) {
		a[i] = sc.nextInt();
		}
		System.out.println();
		getOddArray(a);
	}
}
