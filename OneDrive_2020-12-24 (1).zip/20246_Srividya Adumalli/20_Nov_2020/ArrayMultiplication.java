package com.ojas;

import java.util.Scanner;

public class ArrayMultiplication {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the number");
	int[] arr=new int[5];
	for(int i=0;i<arr.length;i++){
		arr[i]=sc.nextInt();
	}
	arrayMul(arr);
	
}
static int arrayMul(int[] arr){
	int num=1;
	for(int i=0;i<arr.length;i++){
		num=num*arr[i];
		
	}
	System.out.println(num);
	return num;
}

}
