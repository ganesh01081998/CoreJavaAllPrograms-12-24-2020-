package com.ojas;

import java.util.Scanner;

public class NoOfOccurences {
  public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the String");
	String str=sc.next();
	char[] ch=str.toCharArray();
	characterCount(ch);
}
 
  

static int characterCount(char[] ch){
    int a=ch[0];
    //int count=1;
    for(int i=0;i<ch.length;i++){
    	int count=1;
    	for(int j=i+1;j<ch.length;j++){
    		if(ch[i]==ch[j]){
    			count++;
    			
    		}
    		
    	}
    	System.out.println(ch[i]+"--"+count);
    }
    
	return a;


}
}