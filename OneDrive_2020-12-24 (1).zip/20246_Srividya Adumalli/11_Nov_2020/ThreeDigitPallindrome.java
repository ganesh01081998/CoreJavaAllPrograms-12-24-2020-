package com.ojas;

import java.util.Scanner;

public class ThreeDigitPallindrome {
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the number");
		int num = sc.nextInt();
		isPlindrome(num);
	}

	private static int isPlindrome(int num) 
	{
	int originalIntegr=num;
		int rev = 0;
		int rem=0;
		while (num != 0) {

			 rem = num % 10;
			rev = rev * 10 + rem;
			num = num / 10;
			
		}
		if ( originalIntegr== rev) 
		{
			System.out.println("is palindrome");
		}
		else 
		{
			System.out.println("is not a pallindrome");
		}

		return num;

	}
}

            

