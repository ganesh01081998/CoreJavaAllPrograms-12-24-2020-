package com.ojas;

import java.util.Scanner;

public class AddFourNumbersUsingTwoVariables {
	public static void main(String[] args) {
		
	
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the first element");
	int a=sc.nextInt();
	System.out.println("enter the second element");
	int b=sc.nextInt();
	System.out.println("enter the third element");
	int c=sc.nextInt();
	System.out.println("enter the fourth element");
	int d=sc.nextInt();
	addFourElements(a,b,c,d);
	}
	
	private static void addFourElements(int a, int b, int c, int d) {
		
	int i=a+b;
	int j=c+d;
	System.out.println(i);
	System.out.println(j);
	int a1=i+j;
	System.out.println(a1);
	
	

}
	}
