package com.ojas;

import java.util.Scanner;

public class Multiple {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the number");
		int num = sc.nextInt();
		
		num = num / 100;
		num = (num + 1) * 100;
		System.out.println(num);

	}
}
