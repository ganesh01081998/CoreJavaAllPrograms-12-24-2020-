package com.ojas;

import java.util.Scanner;

public class SwapNumbers {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the first element");
	int a=sc.nextInt();
	System.out.println("ente rthe second element");
		int b=sc.nextInt();
		swapNumbers(a,b);
}

private static void swapNumbers(int a, int b) {
	a=a*b;
	b=a/b;
	a=a/b;
	System.out.println(a);
	System.out.println(b);
}
}
