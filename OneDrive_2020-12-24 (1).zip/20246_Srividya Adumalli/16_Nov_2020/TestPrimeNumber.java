package com.ojas;

import java.util.Scanner;

public class TestPrimeNumber {
	
	   static String checkPrime(int num){
		   int count=0;
		   String number="";
		   //condition
		   for(int i=2;i<=num/2;i++){
			   if(num%i==0){
				   count++;
				   break;	   
			   }
		   }
		   number+=num;
		   if(count==0)
			   return number+ " is a prime number";
		   else 
			   return number+ " is not a prime number";
	   }
		   public static void main(String[] args)
		   {
			   //giving the inputs dynamically
			   Scanner sc=new Scanner(System.in);
			   System.out.println("enter the number");
			   int num1=sc.nextInt();
			   //calling the method from main method
			   System.out.println(checkPrime(num1));
		   }
	   
	   }

				
	 






