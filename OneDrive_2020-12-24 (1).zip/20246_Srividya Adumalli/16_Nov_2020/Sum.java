package com.ojas;

import java.util.Scanner;

public class Sum {
	static int getSum(int[] arr) {
		int b = arr.length;
		int count = 0;
		System.out.println(b);
		for (int i = 0; i < b; i++) {
			count = count + arr[i];

			if (arr[i] == 0) {
				return -1;
			}

		}
		return count;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the elements");
		int[] a = new int[5];
		
		for (int i = 0; i < a.length; i++) {
		a[i] = sc.nextInt();
		}
		System.out.println(getSum(a));

	}
}
