package com.ojas;

import java.util.Scanner;

class TestEvenOrOdd {
	static String checkEvenOrOdd() 
	{
		int num;
		System.out.println("Enter the number:");

		// giving the inputs dybamically
		Scanner input = new Scanner(System.in);
		num = input.nextInt();

		if (num % 2 == 0)
			return num + "  is even number";
		else
			return num + " is an odd number";
	}

	public static void main(String args[]) 
	{
		System.out.println(checkEvenOrOdd());
	}
}
