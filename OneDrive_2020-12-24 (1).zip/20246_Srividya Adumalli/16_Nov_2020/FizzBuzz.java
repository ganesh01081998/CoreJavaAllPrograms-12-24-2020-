package com.ojas;

import java.util.Scanner;

public class FizzBuzz {
  public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the value");
	int a=sc.nextInt();
	if(a % 3==0 && a % 5==0){
		System.out.println("FIZZBUZZ");
	}
	else if(a % 3==0){
		System.out.println("FIZZ");
	}
	else if(a % 5==0){
		System.out.println("BUZZ");
	}
	else 
		System.out.println("invalid Integer");
}
}
