package com.ojas;

import java.util.Scanner;

public class NaturalNumbers {
	public static void main(String[] args) {
		int total=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number");
		int num=sc.nextInt();
		printNaturalNumbers(num);
	}
	
		private static void printNaturalNumbers(int num) {
		int total=0;
		for(int i=0;i<num;i++){
			total=total+i;
		}
		System.out.println("display natural numbers");
		System.out.println(total);
	}

}
