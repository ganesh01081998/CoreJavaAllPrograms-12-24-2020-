package com.ojas;

public class MulTab {
	public static void main(String[] args) {
	 multab();
	}
		
		private static void multab() {
		// TODO Auto-generated method stub
		
	

		int no=7;
		for(int i=0;i<=10;i++){
			int c=no*i;
			
			System.out.println(no+" * "+i+" = "+c);
			
			
		}
	}

}