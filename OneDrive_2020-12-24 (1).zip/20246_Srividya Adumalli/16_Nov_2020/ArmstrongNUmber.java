package com.ojas;

import java.util.Scanner;

public class ArmstrongNUmber {
	 public static void main(String[] args)  {  
		 Scanner sc=new Scanner(System.in);
		 System.out.println("enter the number");
		 int a=sc.nextInt();
		 isArmString(a);
		}

	 static  void isArmString(int a){
		 int i=0,num,temp;  
		   int a1=a;
		    temp=a;  
		    while(a>0)  
		    {  
		    num=a%10;  
		    a=a/10;  
		    i=i+(num*num*num);  
		    }  
		    if(temp==i){  
		    System.out.println("armstrong number");  
		    }
		    else  {
		        System.out.println("Not armstrong number");   
		     
		    }
	 }

}

		 

