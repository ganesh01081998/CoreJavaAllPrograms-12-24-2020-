package com.ojas;

import java.util.Scanner;

public class Factorial {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number");
		int a=sc.nextInt();
		calFactorial(a);
	}
		private static void calFactorial(int a) {
		int fact=1;
		
		for(int i=1;i<=a;i++){
			
		fact=fact*i;
			System.out.println(fact);
		}
	}

}
