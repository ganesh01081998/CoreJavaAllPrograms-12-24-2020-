package com.ojas.test;



class Rectangle extends Shape {
	float length;
	float breath;

	float getLength() {
		return length;
	}

	void setLength(float length) {
		this.length = length;
	}

	float getBreath() {
		return breath;
	}

	void setBreath(float breath) {
		this.breath = breath;
	}

	public Rectangle(float length, float breath) {
		super();
		this.length = length;
		this.breath = breath;
	}

	public Rectangle() {
		super();
	}

	@Override
	void getArea() {
		float area = length * breath;
		System.out.println("area of the Rectangle : " + area);

	}

	@Override
	void getPerimeter() {
		float perimeter = 2 * (length * breath);
		System.out.println("Perimeter of the Rectangle : " + perimeter);

	}

}
