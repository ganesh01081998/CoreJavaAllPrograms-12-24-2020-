package com.ojas.test;



abstract class Shape {
	abstract void getArea();

	abstract void getPerimeter();

}

class Circle extends Shape {
	float radius;

	float getRadius() {
		return radius;
	}

	void setRadius(float radius) {
		this.radius = radius;
	}

	Circle() {
		System.out.println("In default constructor");
	}

	public Circle(float radius) {
		super();
		this.radius = radius;
	}

	@Override
	void getArea() {
		double A = Math.PI * radius * radius;
		System.out.println("Area of the radius : " + A);
	}

	@Override
	void getPerimeter() {
		// Pi x (2 x radius)
		double B = Math.PI * (2 * radius);
		System.out.println("Perimeter Of the Circle : " + B);
	}

}

