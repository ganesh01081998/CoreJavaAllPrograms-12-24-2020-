package com.ojas.test;



class Square extends Shape {
	float side;
	

	float getSide() {
		return side;
	}

	void setSide(float side) {
		this.side = side;
	}

	

	public Square(float side) {
		super();
		this.side = side;
	}

	public Square() {
		super();
	}

	@Override
	void getArea() {
		float area = side * side;
		System.out.println("Area of the Square : " + area);

	}

	@Override
	void getPerimeter() {
		int length = 10;
		int perimeter = 4 * 10;
		System.out.println("Perimeter of the square : " + perimeter);
	}

}
