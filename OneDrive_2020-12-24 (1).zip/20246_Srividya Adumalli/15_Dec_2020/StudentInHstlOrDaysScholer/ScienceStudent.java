package com.ojas.student1;



class ScienceStudent extends Student1 {
	int phyMarks;
	int cheMarks;
	int mathMarks;

	public ScienceStudent(String sname, String sclass, int phyMarks, int cheMarks, int mathMarks) {
		super(sname, sclass);
		this.sname = sname;
		this.sclass = sclass;
		this.phyMarks = phyMarks;
		this.cheMarks = cheMarks;
		this.mathMarks = mathMarks;
	}

	public ScienceStudent() {
		super();
	}

	@Override
	public String toString() {
		return "ScienceStudent [phyMarks=" + phyMarks + ", cheMarks=" + cheMarks + ", mathMarks=" + mathMarks + "]";
	}

	@Override
	double getPercentage() {
		if (phyMarks <= 100 && cheMarks <= 100 && mathMarks <= 100) {
			double totalMarks = phyMarks + cheMarks + mathMarks;
			System.out.println("Total marks u got : " + totalMarks);
			double persentage = (totalMarks / 300) * 100;
			return persentage;
		} else {
			System.out.println("Marks should be with in 100");
		}
		return 0;
	}

}