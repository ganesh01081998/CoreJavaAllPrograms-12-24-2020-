package com.ojas.student1;

import java.util.Scanner;

class Student {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String[] str = { "Sceince", "History" };
		for (int i = 0; i < str.length; i++) {
			System.out.println(str[i]);
		}
		System.out.println("enter your subject");

		String i = sc.next();
		if (i.equalsIgnoreCase("Sceince")) {

			System.out.println("enter science student details details");
			ScienceStudent ss = new ScienceStudent(sc.next(), sc.next(), sc.nextInt(), sc.nextInt(), sc.nextInt());
			System.out.println(ss.toString());

			System.out.println("Total percentage you got : " + ss.getPercentage());
		}

		if (i.equalsIgnoreCase("History")) {
			System.out.println("enter the detials of history student");

			HistoryStudent hs = new HistoryStudent(sc.next(), sc.next(), sc.nextInt(), sc.nextInt());
			System.out.println(hs.toString());
			System.out.println("Total percentage you got : " + hs.getPercentage());
		}
	}
}

