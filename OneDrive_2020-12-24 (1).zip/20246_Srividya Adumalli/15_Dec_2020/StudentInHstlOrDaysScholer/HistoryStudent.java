package com.ojas.student1;



class HistoryStudent extends Student1 {
	int hisMarks;
	int civicsMarks;

	public HistoryStudent(String sname, String sclass, int hisMarks, int civicsMarks) {
		super(sname, sclass);
		this.civicsMarks = civicsMarks;
		this.hisMarks = hisMarks;
	}

	public HistoryStudent() {
		super();
	}

	@Override
	public String toString() {
		return "HistoryStudent [hisMarks=" + hisMarks + ", civicsMarks=" + civicsMarks + "]";
	}

	@Override
	double getPercentage() {
		if (hisMarks <= 100 && civicsMarks <= 100) {
			double totalMarks = hisMarks + civicsMarks;
			System.out.println("Sum of total marks" + totalMarks);
			double percentge = (totalMarks / 200) * 100;
			return percentge;
		} else {
			System.out.println("Marks Should be less than 100");
		}
		return 0;

	}

}
