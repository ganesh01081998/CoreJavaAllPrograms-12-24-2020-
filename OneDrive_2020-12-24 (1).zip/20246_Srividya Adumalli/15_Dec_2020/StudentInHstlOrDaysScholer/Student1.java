package com.ojas.student1;

abstract class Student1 {
	String sname;
	String sclass;
	protected static int totlNoOfStds;

	public Student1(String sname, String sclass) {
		super();
		this.sname = sname;
		this.sclass = sclass;
	}

	public Student1() {
		super();
	}

	abstract double getPercentage();

	static int getTotalNoOfStds() {
		return totlNoOfStds;

	}

}
