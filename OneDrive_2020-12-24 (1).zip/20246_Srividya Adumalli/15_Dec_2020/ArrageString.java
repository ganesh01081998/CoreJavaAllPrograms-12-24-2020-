package com.ojas;

import java.util.Scanner;

public class ArrageString {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the first String");
	String str1=sc.nextLine();
	System.out.println("enter the Second String");
	String str2=sc.nextLine();
	
	int i=str1.length()+str2.length();
	
	String firstLetter=str1.substring(0, 1);
	String remainingLetters= (String) str1.subSequence(1, str1.length());
	firstLetter=firstLetter.toUpperCase();
	str1=firstLetter+remainingLetters;
	
	
	String firstLetter1=str1.substring(0, 1);
	String remainingLetters1=(String) str2.subSequence(1, str2.length());
	firstLetter=firstLetter.toUpperCase();
	str2=firstLetter1+remainingLetters1;
	
	
	System.out.print(i+"\t");
	
	if(str2.length()>str1.length()){
		System.out.print("No\t");
	}
	else if(str1.length()>str2.length()){
		System.out.print("Yes\t");
	}
	System.out.println(str1+" "+str2);
	
}
}
