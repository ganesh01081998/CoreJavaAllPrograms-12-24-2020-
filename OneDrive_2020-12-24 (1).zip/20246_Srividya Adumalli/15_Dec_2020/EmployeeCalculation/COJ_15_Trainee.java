package com.ojas.student;



class COJ_15_Trainee extends Coj_15_Employee {
	int batchCount;
	double perkPerBatch;

	public COJ_15_Trainee(int id, String name, double basicSalary, double hRAPer, double dRAPer, int batchCount,
			double perkPerBatch) {
		super(id, name, basicSalary, hRAPer, dRAPer);
		this.batchCount = batchCount;
		this.perkPerBatch = perkPerBatch;
	}

	public COJ_15_Trainee() {
		int id = 0;
		String name = null;
		double basicSalary = 0.0;
		double HRAPer = 0.0;
		double DRAPer = 0.0;
		int batchCount = 0;
		double perkPerBatch = 0.0;
	}

	double calculateGrossSalary3() {
		double grossSalary = basicSalary + HRAPer + DRAPer + (batchCount * perkPerBatch);
		return grossSalary;
	}

	double check(double grossSalary) {
		grossSalary = basicSalary + HRAPer + DRAPer + (batchCount * perkPerBatch);
		if (grossSalary > 30000) {

			grossSalary = (0.2) * 30000;
			return grossSalary;
		} else
			grossSalary = (0.05) * 30000;
		return grossSalary;
	}

}

