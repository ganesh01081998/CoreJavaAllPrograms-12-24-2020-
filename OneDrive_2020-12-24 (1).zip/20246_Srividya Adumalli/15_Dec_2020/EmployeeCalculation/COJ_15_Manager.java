package com.ojas.student;



class COJ_15_Manager extends Coj_15_Employee {
	double projectAllowence;

	public COJ_15_Manager(int id, String name, double basicSalary, double hRAPer, double dRAPer,
			double projectAllowence) {
		super(id, name, basicSalary, hRAPer, dRAPer);
		this.projectAllowence = projectAllowence;
	}

	public COJ_15_Manager() {
		int id = 0;
		String name = null;
		double basicSalary = 0.0;
		double HRAPer = 0.0;
		double DRAPer = 0.0;
		double projectAllowence = 0.0;
	}

	double calculateGrossSalary2() {
		double grossSalary = basicSalary + HRAPer + DRAPer + projectAllowence;
		return grossSalary;
	}

	double check(double grossSalary) {
		grossSalary = basicSalary + HRAPer + DRAPer + projectAllowence;
		if (grossSalary > 30000) {

			grossSalary = (0.2) * 30000;
			return grossSalary;
		} else {
			grossSalary = (0.05) * 30000;
			return grossSalary;

		}
	}
}
