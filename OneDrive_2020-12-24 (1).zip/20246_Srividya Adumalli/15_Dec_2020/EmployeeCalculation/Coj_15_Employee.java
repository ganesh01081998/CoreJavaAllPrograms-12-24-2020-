package com.ojas.student;

class Coj_15_Employee {
	int id;
	String name;
	double basicSalary;
	double HRAPer;
	double DRAPer;

	public Coj_15_Employee(int id, String name, double basicSalary, double hRAPer, double dRAPer) {
		super();
		this.id = id;
		this.name = name;
		this.basicSalary = basicSalary;
		HRAPer = hRAPer;
		DRAPer = dRAPer;

	}

	public Coj_15_Employee() {
		int id = 0;
		String name = null;
		double basicSalary = 0.0;
		double HRAPer = 0.0;
		double DRAPer = 0.0;
	}

	double calculateGrossSalary1() {
		double grossSalary = basicSalary + HRAPer + DRAPer;
		return grossSalary;

	}

	double check(double grossSalary) {
		// grossSalary=basicSalary+HRAPer+ DRAPer;
		grossSalary = basicSalary + HRAPer + DRAPer;
		if (grossSalary > 30000) {
			grossSalary = (0.2) * 30000;
			System.out.println(grossSalary);
			return grossSalary;

		} else {
			grossSalary = (0.05) * 30000;
			return grossSalary;
		}
		// return grossSalary;
	}
}
