package com.ojas.student;

import java.util.Scanner;



public class COJ_15_COnstructor {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the employee details as id , name,basic salary,hraPer,Darper");
		Coj_15_Employee emp = new Coj_15_Employee(sc.nextInt(), sc.next(), sc.nextDouble(), sc.nextDouble(),
				sc.nextDouble());
		System.out.println("Gross Salary Of Employee is : " + emp.calculateGrossSalary1());
		System.out.println("Tax to pay : " + emp.check(0));
		System.out.println("enter Manager details as id,name,basicsalary,hraper,darper,projectAlloence");

		COJ_15_Manager mgr = new COJ_15_Manager(sc.nextInt(), sc.next(), sc.nextDouble(), sc.nextDouble(),
				sc.nextDouble(), sc.nextDouble());
		System.out.println("Gross Salary Of manager is : " + mgr.calculateGrossSalary2());
		System.out.println("Tax to pay : " + mgr.check(0));

		System.out.println("enter Trainee details as id,name,basicsalary,hraper,draper,batchCount,PerkPerBatch");
		COJ_15_Trainee trainee = new COJ_15_Trainee(sc.nextInt(), sc.next(), sc.nextDouble(), sc.nextDouble(),
				sc.nextDouble(), sc.nextInt(), sc.nextDouble());
		System.out.println("Gross Salary Of Trainee is : " + trainee.calculateGrossSalary3());
		System.out.println("Tax to pay : " + trainee.check(0));

		System.out.println(
				"enter Trainee details as id,name,basicsalary,hraper,draper,enrollementTarget,EnrollmentReached,perkPerEnrollment");
		COJ_15_Sourcing source = new COJ_15_Sourcing(sc.nextInt(), sc.next(), sc.nextDouble(), sc.nextDouble(),
				sc.nextDouble(), sc.nextInt(), sc.nextInt(), sc.nextDouble());
		System.out.println("Gross Salary Of sources is : " + source.calculateGrossSalary4());
		System.out.println("Tax to pay : " + source.check(0));

	}

}

