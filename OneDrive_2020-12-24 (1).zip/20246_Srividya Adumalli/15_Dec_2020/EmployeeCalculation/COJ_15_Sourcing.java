package com.ojas.student;



class COJ_15_Sourcing extends Coj_15_Employee {
	int enrollmentTarget;
	int enrollmentReached;
	double perkPerEnrollment;

	public COJ_15_Sourcing(int id, String name, double basicSalary, double hRAPer, double dRAPer, int enrollmentTarget,
			int enrollmentReached, double perkPerEnrollment) {
		super(id, name, basicSalary, hRAPer, dRAPer);
		this.enrollmentTarget = enrollmentTarget;
		this.enrollmentReached = enrollmentReached;
		this.perkPerEnrollment = perkPerEnrollment;
	}

	public COJ_15_Sourcing() {
		int id = 0;
		String name = null;
		double basicSalary = 0.0;
		double HRAPer = 0.0;
		double DRAPer = 0.0;
		int enrollmentTarget = 0;
		int enrollmentReached = 0;
		double perkPerEnrollment = 0.0;
	}

	double calculateGrossSalary4() {
		double grossSalary = basicSalary + HRAPer + DRAPer
				+ ((enrollmentReached / enrollmentTarget) * 100) * perkPerEnrollment;

		return grossSalary;
	}

	double check(double grossSalary) {
		grossSalary = basicSalary + HRAPer + DRAPer
				+ ((enrollmentReached / enrollmentTarget) * 100) * perkPerEnrollment;
		if (grossSalary > 30000) {

			grossSalary = (0.2) * 30000;
			return grossSalary;
		} else
			grossSalary = (0.05) * 30000;
		return grossSalary;
	}
}
