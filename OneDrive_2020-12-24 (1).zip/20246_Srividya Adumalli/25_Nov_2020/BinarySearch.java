package com.ojas;

import java.util.Scanner;

class BinarySearch { 
    
     static int binarySearch(int arr[], int l, int r) 
    {  
    	 int x=0;
        if (r >= l) { 
            int mid = l + (r - l) / 2; 
            if (arr[mid] == x) 
                return mid;
            if (arr[mid] > x) 
                return binarySearch(arr, l, mid - 1 );  
            return binarySearch(arr, mid + 1, r); 
        } 
        return -1; 
    } 
    public static void main(String args[]) 
    {  
    	int i=0;    
    	Scanner sc=new Scanner(System.in);
    	System.out.println("enter the array");
      int[] arr=new int[5];
      for( i=0;i<arr.length-1;i++) {
    	  arr[i]=sc.nextInt();
    	  int x=arr[i];
      }
      
      
      System.out.println("enter the search number");
      int a=sc.nextInt();
      System.out.println(binarySearch(arr, 0, arr.length-1));
    } 
}
    
    	
