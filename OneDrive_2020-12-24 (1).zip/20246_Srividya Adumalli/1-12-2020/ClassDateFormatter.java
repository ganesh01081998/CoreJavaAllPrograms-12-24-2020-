package com.ojas;

import java.util.Scanner;

public class ClassDateFormatter {
	
	    public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);
	        System.out.println("Enter your String");
	        String str1 = sc.nextLine();
	        getDateFormatter(str1);
	    }
	    private static void getDateFormatter(String date) {
	        String s1 = date.replace(" ,", ",");
	        String s2 = s1.replace(", ", ",");
	        String s3 = s2.replace(' ', ',');
	        String[] s4 = s3.split(",");
	        String[] str = { "jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec" };
	        String[] str2 = { "January", "February", "March", "April", "May", "June", "July", "August", "September",
	                "October", "November", "December" };
	        String day = s4[0];
	        String month = s4[1];
	        String year = s4[2];
	        String s = "";
	        for (int i = 0; i < str.length; i++) {
	            if (month.equalsIgnoreCase(str[i]) || month.equalsIgnoreCase(str2[i])) {
	                s += i + 1;
	            }
	        }
	        if (s.equals("") || Integer.parseInt(day) < 1 || Integer.parseInt(day) > 31) {
	            System.out.println("null");
	        } else {
	            //System.out.println(s);
	            String modfyDate = year + "-" + s + "-" + day;
	            System.out.println(modfyDate);
	        }
	    }
}

	
  

    