package com.ojas;

import java.util.Scanner;

public class PrintConsonents {
	public static void main(String[] args) {
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the String");
		String str=sc.next();
		printvowels(str);
		
	}
	}
	private static String printvowels(String str) {
		//char[] ch={'a','e','o','i','u'};
		char[] ch={'b','c','d','f','g','h','j','k','l','m','n','p','q','r','s','t','v','w','x','y','z'};
			for(int i=0;i<str.length();i++){
				for(int j=0;j<ch.length;j++){
					if(str.charAt(i)==ch[j]){
						System.out.println(ch[j]);
					}
				}
			}
		
	
	return str;
}}

		