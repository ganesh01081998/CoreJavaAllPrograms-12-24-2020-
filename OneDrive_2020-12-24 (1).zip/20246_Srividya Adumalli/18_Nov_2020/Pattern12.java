package com.ojas;

public class Pattern12 {
public static void main(String[] args) {
	int start=-1;
	for(int rows=1;rows<5;rows++){
		start=start+2;
		for(int k=1;k<5-rows;k++){
			System.out.print(" ");
		}
		for(int cols=1;cols<=start;cols++){
			System.out.print("*");
		}
		System.out.println();
	}
}
}
