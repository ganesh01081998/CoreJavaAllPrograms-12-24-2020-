package com.ojas;

import java.util.Scanner;

public class Pattern4 {
public static void main(String[] args) {
     
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the rows and cols");
	int num1=sc.nextInt();
	int num2=sc.nextInt();
	printNo(num1,num2);
}
	private static void printNo(int num1,int num2) {
String result="";
	for(int row=1;row<=num1;row++){
		for(int col=1;col<=num2;col++){
			//System.out.println(result+=col+" ");
			System.out.println(result=result+col+" ");
		}
	}
}
}
