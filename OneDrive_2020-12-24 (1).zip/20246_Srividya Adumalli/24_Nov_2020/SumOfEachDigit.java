package com.ojas;

import java.util.Scanner;

public class SumOfEachDigit {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the number");
	int a=sc.nextInt();
	System.out.println(sum(a));
}

private static int sum(int a) {
	int sum=0;
	while(a!=0){
	sum=sum+a%10;
	 a/=10;
	
}
	return sum;
}
}
