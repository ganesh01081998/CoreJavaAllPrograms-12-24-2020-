package com.ojas.adddate;

import java.util.Scanner;

public class AvailableDays {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the month");
	String s1=sc.next();
	availableDays(s1);
}

 static void availableDays(String s1) {
	String[] s2={"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
	int[] a={30,28,30,31,30,31,30,31,30,31,30,31};
for(int i=0;i<s2.length;i++){
	if(s1.equalsIgnoreCase(s2[i])){
		System.out.println(a[i]);
	}
}
	
	
	
	
	}
 
}
	


