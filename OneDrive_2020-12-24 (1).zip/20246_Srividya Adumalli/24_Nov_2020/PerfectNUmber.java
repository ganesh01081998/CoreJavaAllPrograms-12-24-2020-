package com.ojas;

import java.util.Scanner;

public class PerfectNUmber {

	
	public static void main(String[] args) {
		int  number=0;
		int sum = 0 ;
		Scanner sc = new Scanner(System.in);		
		System.out.println("Enter any Number");
		number = sc.nextInt();
		sumOfProperDivisors(number, sum);
	}
	
		private static void sumOfProperDivisors(int number,int sum) {
		for(int i = 1 ; i < number ; i++) {
			if(number % i == 0)  {
				sum = sum + i;
			}
		}
		if (sum == number) {
			System.out.println(number+"is a perfect number");
		}
		else if(sum>number) {
			System.out.println(number+"number is a abundant");
		}
		else if(sum<number){
			System.out.println(number+"number is deficient");
		}
	}
}

