package com.ojas;

import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;
class ReverseArray{
static void reverse(int arr[], int n) 
{ 
    int[] b = new int[n]; 
    int j = n; 
    for (int i = 0; i < n; i++) { 
        b[j - 1] = arr[i]; 
        j = j - 1; 
    } 

    /*printing the reversed array*/
    System.out.println("Reversed array is"); 
    for (int k = 0; k < n; k++) { 
        System.out.println(b[k]); 
    } 
} 

public static void main(String[] args) 
{ 
   // int [] arr = {10, 20, 30, 40, 50}; 
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the array");
     int arr[]=new int[3];
     int n=arr.length;
     for(int i=0;i<arr.length;i++){
    	 arr[i]=sc.nextInt();
     }
     
    reverse(arr, n); 
} 
} 


















