package com.ojas;

import java.util.Scanner;

public class ConsonentsString {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the String");
		String str2 = sc.next();
		String str1 = "bcdfghjklmnpqrstvwxyz";
		char ch2[]=str1.toCharArray();
		

		checkConsonents(ch2, str2);
	}

	private static void checkConsonents(char[] ch, String str1) 
	{
		for (int i = 0; i < str1.length(); i++)
		{
			for (int j = 0; j < ch.length; j++) 
			{
				if (str1.charAt(i) == ch[j]) 
				{
					System.out.println(str1.charAt(i));

				}

			}
		}
	}
}
