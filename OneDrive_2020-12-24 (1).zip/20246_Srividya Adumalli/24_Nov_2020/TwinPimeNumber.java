package com.ojas;

public class TwinPimeNumber {
public static void main(String[] args) {
	printPrimeNUmbers();
}
	private static void printPrimeNUmbers() {
		int num=0;
		int count =0;
		String primeNumbers="";
		for(int i=0;i<=20;i++){
			for(int j=i;j<=i+1;j++){
			if(i%num==0){
				count=count+1;
			}
			if(count==2){
				primeNumbers = primeNumbers + i + "";
			}
			}
		
	}
		System.out.println(primeNumbers);
		   
	}
}
	
		  
		 


