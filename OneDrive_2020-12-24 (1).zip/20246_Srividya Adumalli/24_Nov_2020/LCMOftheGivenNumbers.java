package com.ojas;

import java.util.Scanner;

public class LCMOftheGivenNumbers {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the number 1");
	int a=sc.nextInt();
	System.out.println("enter the number2");
	int b=sc.nextInt();
	System.out.println(lcmOfNumbers(a,b));
}

private static int lcmOfNumbers(int a, int b) {
	int max=0;
	int lcm=0;
	int step=0;
	 if(a > b){
         max = step = a;
      }
      else{
         max = step = b;
      }
	
	while(a!=0){
		if(max % a ==0 && max % b == 0){
			lcm=max;
			break;
		}
		max=max+step;
	}
	return max;
	
}

}














/**while(a!= 0) {
         if(max % a == 0 && max % b == 0) {
            lcm = max;
            break;
         }
         max += step;*/