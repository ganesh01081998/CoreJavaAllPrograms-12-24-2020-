package com.ojas;

import java.util.Scanner;

public class NameScore {
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the String");
		String name = sc.next();
		getNameScore(name);

	}

	private static void getNameScore(String name) 
	{
		int nameScore = 0;
		String smallLetter = "abcdefghijklmnopqrstuvwxyz";
		String upperLetter = smallLetter.toUpperCase();
		for (int i = 0; i < name.length(); i++) 
		{
			for (int j = 0; j < name.length(); j++)
			{
				if (name.charAt(i) == smallLetter.charAt(j) || name.charAt(i) == upperLetter.charAt(j))
				{
					nameScore += j + 1;

				}
			}
		}
		System.out.println(nameScore);

	}

}