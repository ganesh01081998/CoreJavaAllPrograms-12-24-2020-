package com.ojas;

import java.util.Scanner;

public class QuadraticNumber {
   public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the number");
	int a=sc.nextInt();
	getQuadraticno(a);
   }
	private static void getQuadraticno(int a) {
	// TODO Auto-generated method st
	int sum=1;
	for(int i=0;i<a;i++){
		sum=sum+i;
		
	}
	System.out.println(sum);
}
}
