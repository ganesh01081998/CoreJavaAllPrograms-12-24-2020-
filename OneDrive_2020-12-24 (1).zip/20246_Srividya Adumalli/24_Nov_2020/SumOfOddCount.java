package com.ojas;

import java.util.Scanner;

public class SumOfOddCount
{
	static int oddCount(int[] inputArray)
	{
		
		int a1 = inputArray.length;
		System.out.println(a1);
		System.out.println();
		int sum=0;

		for (int i = 0; i < a1; i++)
		{
			if (inputArray[i] % 2 == 1)
			{
				//System.out.println(inputArray[i] + " is an odd number");
				sum=sum+inputArray[i];
			}
			}
		return sum;
		
		
	}

	public static void main(String[] args) 
	{
		int a[] = { 1, 5, 2, 4, 5, 8, 9, 5, 6 };
		int b = oddCount(a);
		
		System.out.println(b);

	}

}
