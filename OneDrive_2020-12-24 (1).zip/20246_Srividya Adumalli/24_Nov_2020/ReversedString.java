package com.ojas;

import java.util.Scanner;

public class ReversedString {
	public static void main(String[] args) {
		
	getReverse();
	}
	
	static String getReverse(){
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the string");
		String s1=sc.next();
		StringBuffer sb=new StringBuffer(s1);
		sb.reverse();
		System.out.println(sb);
		return s1;
		
	}
	}
	


