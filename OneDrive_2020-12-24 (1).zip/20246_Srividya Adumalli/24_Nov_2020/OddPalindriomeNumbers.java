package com.ojas;

import java.util.Scanner;

public class OddPalindriomeNumbers {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("entr the first range");
		int num1 = sc.nextInt();
		System.out.println("enter the second range");
		int num2 = sc.nextInt();
		for (int i = num1; i <= num2; i++) {
			if (i % 2 != 0) {
				checkPalindrome(i);
			}
		}
	}

	static void checkPalindrome(int num) {
		int revnum = getReverse(num);
		if (num == revnum) {
			System.out.println(num);
		}

	}

	static int getReverse(int num) {
		int rev = 0;
		while (num != 0) {
			int rem = num % 10;
			rev = rev * 10 + rem;
			num = num / 10;

		}
  
		return rev;
	}
}
