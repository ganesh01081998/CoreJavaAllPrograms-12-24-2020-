package com.ojas;

import java.util.Scanner;

public class VowelsString2 {
	public static void main(String[] args) {
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the String");
		String str=sc.next();
		printvowels(str);
		
	}
	}
	private static String printvowels(String str) {
		char[] ch={'a','e','o','i','u'};
			for(int i=0;i<str.length();i++){
				for(int j=0;j<ch.length;j++){
					if(str.charAt(i)==ch[j]){
						System.out.println(ch[j]);
					}
				}
			}
		
	
	return str;
}}

		