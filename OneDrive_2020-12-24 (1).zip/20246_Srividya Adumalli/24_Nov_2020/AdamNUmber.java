package com.ojas;

import java.util.Scanner;

public class AdamNUmber {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number");
		int a=sc.nextInt();
		getReverse(a);
		isAdamNumber(a, a);
	}
  static int getReverse(int a){
	  int rev=0;
	
	  while (a > 0) 
      { 
          rev = rev * 10 
        		  + a % 10; 
          a /= 10; 
      }
      
      System.out.println(rev);
      return rev; 
  }
  static int isAdamNumber(int a,int rev){
	  int b = a*a;
	  System.out.println(b);
	  if(b==rev)
		  System.out.println("isAdam number");
	  else
		  System.out.println("not a Adam number");
	  
	return a;
	  
  }
} 



