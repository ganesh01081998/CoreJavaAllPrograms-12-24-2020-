package com.ojas;

import java.util.Scanner;

public class MinNumber {
    public static void main(String[] args) {
		
		
    Scanner sc = new Scanner(System.in);
	System.out.println("enter the elements");
	int[] a = new int[5];
	
	for (int i = 0; i < a.length; i++) {
	a[i] = sc.nextInt();
	}
	smallest(a);
	
    }
	static int smallest(int[] a){
		//int[] a={23,15,45,18,11,5,10,25};
		int min=0;
		for(int i=0;i<a.length;i++){
			if(a[i]<min)
		      {
				min=a[i];
				}
			
		}
		System.out.println(min);
		return min;
	}
}

