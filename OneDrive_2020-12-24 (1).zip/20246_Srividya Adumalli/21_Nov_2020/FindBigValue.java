package com.ojas;

import java.util.Arrays;
import java.util.Scanner;

public class FindBigValue {
    public static void main(String[] args) {
		
		
    Scanner sc = new Scanner(System.in);
	System.out.println("enter the elements");
	int[] a = new int[5];
	
	for (int i = 0; i < a.length; i++) {
	a[i] = sc.nextInt();
	
	}

	largest(a);
	
    }
	static int largest(int[] a){
		//int[] a={23,15,45,18,11,5,10,25};
		int max=0;
		
		for(int j=0;j<a.length;j++){
			if(max<a[j])
		      {
				max=a[j];
				}
		}
		System.out.println(max);
		return max;
	}
}

