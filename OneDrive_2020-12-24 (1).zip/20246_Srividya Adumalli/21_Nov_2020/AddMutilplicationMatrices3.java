package com.ojas;

import java.util.Arrays;
import java.util.Scanner;

public class AddMutilplicationMatrices3 {
	static int[][] insertArr1() {
		int arr1[][] = new int[3][3];
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the first matrix");
		for (int i = 0; i < arr1.length; i++) {
			for (int j = 0; j < arr1[i].length; j++) {
				arr1[i][j] = sc.nextInt();
			}
		}
		return arr1;
	}

	static int[][] insertArr2() {

		int arr2[][] = new int[3][3];

		Scanner sc = new Scanner(System.in);
		System.out.println("enter the second matrix");
		for (int i = 0; i < arr2.length; i++) {
			for (int j = 0; j < arr2[i].length; j++) {
				arr2[i][j] = sc.nextInt();
			}
		}
		return arr2;
	}
	public static void main(String[] args) {
		int arr1[][] = insertArr1();
		int arr2[][] = insertArr2();
		int arr3[][] = new int[3][3];
		for (int i = 0; i < arr1.length; i++) { 
			for (int j = 0; j < arr2.length; j++) {
                   for(int k=0;k<arr3.length;k++){
                	   arr3[i][j]+=arr1[j][k]*arr2[k][j];
                	   
                   }
				System.out.print(arr3[i][j] +" ");
			}
			System.out.println();
		}

	}
}
