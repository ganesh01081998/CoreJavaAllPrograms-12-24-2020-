package com.ojas;

import java.util.Scanner;

public class EqMat {
	static int[][] insertArr1() {
		int arr1[][] = new int[3][3];
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the first matrix");
		for (int i = 0; i < arr1.length; i++) {
			for (int j = 0; j < arr1[i].length; j++) {
				arr1[i][j] = sc.nextInt();

			}
		}
		return arr1;
	}

	static int[][] insertArr2() {

		int arr2[][] = new int[3][3];

		Scanner sc = new Scanner(System.in);
		System.out.println("enter the second matrix");
		for (int i = 0; i < arr2.length; i++) {
			for (int j = 0; j < arr2[i].length; j++) {
				arr2[i][j] = sc.nextInt();

			}

		}
		return arr2;
	}

	static boolean check(int[][] arr1, int[][] arr2) {
		for (int i = 0; i < arr1.length; i++) {
			for (int j = 0; j < arr2.length; j++) {

				if (arr1[i][j] != arr2[i][j]) {

					return false;

				} else {

				}
			}

		}
		return true;
	}

	public static void main(String[] args) {
		int arr1[][] = insertArr1();
		int arr2[][] = insertArr2();

		if (check(arr1, arr2)) {
			System.out.println("both matrices are equal");
		} else {
			System.out.println("both matrices are not equal");

		}
	}

}
