package com.ojas;

import java.util.Scanner;

public class OddNumbersCountInArray {
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the array size");
		int size = sc.nextInt();
		System.out.println("enter the array elements");
		int[] elements = new int[size];
		for (int i = 0; i < elements.length; i++)
		{
			elements[i] = sc.nextInt();

		}
		System.out.println(getEvenArray(elements));

	}

	private static int getEvenArray(int[] elements) 
	{
		int sum = 0;
		if (elements.length == 0) {
			return -3;

		}
		for (int i = 0; i < elements.length; i++) 
		{
			if (elements[i] < 0)
			{
				return -1;
			} else if (elements[i] == 0)
			{
				return -2;
			} else if (elements[i] % 2 != 0)
			{
				sum = sum + elements[i];
			}
		}
		return sum;
	}

}
