package com.ojas;

abstract class Book {
	String title;

	abstract String getTitle();

	abstract void setTitle(String title);

}
