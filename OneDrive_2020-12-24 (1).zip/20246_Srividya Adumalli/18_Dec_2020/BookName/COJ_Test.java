package com.ojas;

import java.util.Scanner;

public class COJ_Test {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		MyBook book = new MyBook();
		System.out.println("Enter your wishing Book");
		book.setTitle(sc.nextLine());
		System.out.println("The Book Title is : " + book.getTitle());
	}
}