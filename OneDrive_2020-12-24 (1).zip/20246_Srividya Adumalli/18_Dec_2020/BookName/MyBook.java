package com.ojas;

class MyBook extends Book {

	void setTitle(String title) {
		this.title = title;
	}

	String getTitle() {

		return title;
	}
}