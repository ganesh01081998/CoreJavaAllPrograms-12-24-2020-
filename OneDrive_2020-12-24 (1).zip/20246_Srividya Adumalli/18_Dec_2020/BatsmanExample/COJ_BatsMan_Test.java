package com.ojas.batsman;

import java.util.Scanner;


public class COJ_BatsMan_Test {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter bats man Name runs and matches");
		COJ_45_Batsman batsman = new COJ_45_Batsman(sc.next(), sc.nextInt(), sc.nextInt());
		// System.out.println("enter the runs and mathes");
		batsman.computeBattingAverage(batsman.runs, batsman.matches);
		System.out.println(batsman.toString());
		System.out.println("details of batsman  runs ,matches and name");
		batsman.getStatistics(batsman.runs, batsman.matches, batsman.name);
	}

}

