package com.ojas.batsman;

class COJ_45_Batsman {
	String name;
	int runs;
	int matches;
	float batting_avg;

	public COJ_45_Batsman() {
		name = null;
		runs = 0;
		matches = 0;
		batting_avg = 0;

	}

	@Override
	public String toString() {
		return "name :" + name;
	}

	public COJ_45_Batsman(String name, int runs, int matches) {

		this.name = name;
		this.runs = runs;
		this.matches = matches;
	}

	void computeBattingAverage(int runs, int matches) {
		if (runs < 0 && matches < 0) {
			System.err.println("should not be a negative number");
		} else if (runs > 0 && matches > 0) {
			batting_avg = runs / matches;
			System.out.println("Avg of u r runs is : " + batting_avg);
		}
	}

	void getStatistics(int runs, int matches, String name) {
		System.out.println(name);
		System.out.println(runs);
		System.out.println(matches);

	}

}