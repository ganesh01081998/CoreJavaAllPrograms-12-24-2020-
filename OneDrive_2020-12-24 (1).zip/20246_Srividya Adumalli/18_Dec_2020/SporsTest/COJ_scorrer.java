package com.test;

import java.util.Scanner;



class COJ_scorrer extends COJ_Sports {
	@Override
	String getName(String str) {
		return super.s1 = s1;
	}

	@Override
	String getNumberOfTeamMembers() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter sports name");
		String str = sc.nextLine();
		// System.out.println(getName(str)+",");
		return "in " + str + " each team has 11 players";
	}
}