package com.test;



public class COJ_Sports_Test {
	public static void main(String[] args) {

		COJ_scorrer scorrer = new COJ_scorrer();
		System.out.print(scorrer.getNumberOfTeamMembers());
	}
}
