package com.test;

class COJ_Sports {
	String s1;

	String getName(String str) {
		return str;

	}

	String getNumberOfTeamMembers() {
		return "In Sports";

	}
}