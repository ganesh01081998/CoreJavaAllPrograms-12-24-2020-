package com.ojas.shape;



class COJ_46_Cylender extends COJ_46_Circle {
	double height;

	public COJ_46_Cylender() {
		super();
	}

	public COJ_46_Cylender(double a, double height) {

		this.height = height;
	}

	double getVolume(double a, double b) {
		b = Math.PI * (a * a) * b;
		return b;
	}

}