package com.ojas.shape;

import java.util.Scanner;



public class COJ_AreaOFCircleAndCylinder {
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("enter radius of circle");
		int a = sc.nextInt();
		COJ_46_Circle area = new COJ_46_Circle();
		System.out.println(area.getArea(a));
		System.out.println("enter  area and height for finding the value volume");
		// int b=sc.nextInt();
		COJ_46_Cylender cylinder = new COJ_46_Cylender();
		System.out.println(cylinder.getVolume(sc.nextDouble(), sc.nextDouble()));
	}
}

