package com.ojas.shape;

class COJ_46_Circle {
	double radius;

	public COJ_46_Circle(double radius) {
		this.radius = radius;
	}

	public COJ_46_Circle() {
		radius = 0.0;
	}

	double getArea(double a) {
		a = Math.PI * (a * a);
		return a;
	}
}