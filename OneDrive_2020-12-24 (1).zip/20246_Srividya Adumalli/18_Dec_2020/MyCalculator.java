package com.ojas;

import java.util.Scanner;

public class MyCalculator {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the numbe");
	int num=sc.nextInt();
	int sum=num;
	for(int i=1;i<=num/2;i++){
		if(num%i==0){
			sum=sum+i;
			System.out.println(i);		
		}
	}
	System.out.println(sum);
}
}
