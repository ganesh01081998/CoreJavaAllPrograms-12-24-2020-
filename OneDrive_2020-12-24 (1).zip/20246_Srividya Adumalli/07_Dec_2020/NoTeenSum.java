package com.ojas;

import java.util.Scanner;

public class NoTeenSum {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the a value");
	int a=sc.nextInt();
	
	System.out.println("enter the b value");
	int b=sc.nextInt();
	
	System.out.println("enter the c value");
	int c=sc.nextInt();

	System.out.println(noTeenSum(a,b,c));
}

private static int noTeenSum(int a, int b, int c) {
	
	if(a==15)
		return a;
	else if(b==15)
	  return b;
	else if(c==15)
		return c;
	if(a==16)
		return a;
	else if(b==16)
		return 16;
	else if(c==16)
		return 16;
	int arr[]={13,14,17,18};
	for(int i=0;i<arr.length;i++){
		if(a==arr[i]){
			return b+c;
		}
		else if(b==arr[i]){
			return a+c;
		}
		else if(c==arr[i]){
			return a+b;
		}
		 
			
			
		}
	return a+b+c;
}
}

/*private static int  fixTeen(int n) {
	
	if(n==15 && n==16){
		return n;
	}
	else {
		return 0;
	}
	
}

}*/
