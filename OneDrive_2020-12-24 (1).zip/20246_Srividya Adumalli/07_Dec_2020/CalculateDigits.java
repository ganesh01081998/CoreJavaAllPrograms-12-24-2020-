package com.ojas;

import java.util.Scanner;

public class CalculateDigits {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the String");
		String str = sc.next();
		System.out.println(getSum(str));
	}

	private static int getSum(String str) {
          String temp="0";
           int sum=0;
           for(int i=0;i<str.length();i++){
        	   char ch=str.charAt(i);
        	   if(Character.isDigit(ch)){
        		   temp+=ch;
        	   }
        	   else {
        		   sum+=Integer.parseInt(temp);
        		   temp="0";
        	   }
        	   
           }
           return sum + Integer.parseInt(temp);
	}
}
