package com.ojas;

import java.util.Scanner;

public class LuckySum {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the a value");
	int a=sc.nextInt();
	System.out.println("enter the b value");
	int b=sc.nextInt();
	System.out.println("enter c value");
	int c=sc.nextInt();
	
	System.out.println("The  number is :: "+luckySum(a,b,c));
}

private static int   luckySum(int a, int b, int c) {
	if(a==13){
		return 0;
	}
	else if(b==13){
		return a;
	}
	else if(c==13){
		int i=a+b;
		return i;
	}
	else {
		int j=a+b+c;
		return j;
	}
	
	
}
}
