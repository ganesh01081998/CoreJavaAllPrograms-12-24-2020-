package com.ojas;

import java.util.Scanner;

public class Near100 {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the  number");
	int a=sc.nextInt();
	nearHundred(a);
}
	private static boolean nearHundred(int a) {
	
		if(a>10 && a<200){
	
		System.out.println("true");
	}
	else {
		System.out.println("false");
	}
		return true;
}
}
