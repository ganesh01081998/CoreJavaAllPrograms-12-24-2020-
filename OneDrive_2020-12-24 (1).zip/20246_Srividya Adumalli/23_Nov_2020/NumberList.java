package com.ojas;

import java.util.Arrays;

public class NumberList {
public static void main(String[] args) {
	String str="1,2,3,4,5-8,6-10,8-15,16-25,20-30,22-2";
	String str1= str.replace('-', ',');
	System.out.println(str1);
	String[] str2=str1.split(",");
	int [] arr = new int [str2.length];
	 for(int i=0; i<str2.length; i++) {
        arr[i]= Integer.parseInt(str2[i]);
      }
	
	Arrays.sort(arr);
	
	int s=arr[0];
	int max=0;
	for(int j=0;j<=arr.length-1;j++){
		if(max<arr[j]){
			max=arr[j];
	}
		
	}
	for(int k=0;k<=max;k++){
		System.out.println(k);
	}
//	System.out.println(arr[0]);
//	System.out.println(str2.length-1);
	
	}
	

}
