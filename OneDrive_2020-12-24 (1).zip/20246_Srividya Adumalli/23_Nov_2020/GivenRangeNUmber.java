package com.ojas;

import java.util.Scanner;

public class GivenRangeNUmber {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the first range");
	int a=sc.nextInt();
	System.out.println("enter the second range");
	int b=sc.nextInt();
      System.out.println(rangeInNumbers(a,b));
}
	private static boolean rangeInNumbers(int a, int b) {
		if(a>=30 && b<=40)

	{
		return true;
	}
		else {
			return false;
	}
}
}
