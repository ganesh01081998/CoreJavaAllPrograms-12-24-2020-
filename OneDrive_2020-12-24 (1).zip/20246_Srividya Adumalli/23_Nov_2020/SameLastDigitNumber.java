package com.ojas;

import java.util.Scanner;

public class SameLastDigitNumber {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the last digit");
	int a=sc.nextInt();
	System.out.println("enter the first number");
	int i=sc.nextInt();
	System.out.println("enter the second number");
	int j=sc.nextInt();
   if(a == i && a==j){
	   
   }
   System.out.println(isSameLastDigit(i,j));
}
	   static boolean  isSameLastDigit(int i,int j) {
			
			int num1 = i % 10;
			int num2 = j % 10;
			if(num1 == num2) {
				return true;
			}
			return false;
   }
}

