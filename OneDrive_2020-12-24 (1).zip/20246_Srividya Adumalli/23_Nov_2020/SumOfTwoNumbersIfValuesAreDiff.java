package com.ojas;

import java.util.Scanner;

public class SumOfTwoNumbersIfValuesAreDiff {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the number 1");
	int a=sc.nextInt();
	System.out.println("enter the number 2");
	int b=sc.nextInt();
	System.out.println(sum(a,b));
}
	private static boolean sum(int a, int b) {
	int c=a+b;
	int d=c+c;
	if(a!=b){
		System.out.println(c);
		return false;
	}
	
	else 
		System.out.println(d);
		return true;
}
}
