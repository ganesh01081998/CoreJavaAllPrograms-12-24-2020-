package com.ojas;

import java.util.Scanner;

public class SumOfDecimalPointNUmbers {
   public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the decimal number");
	double f=sc.nextDouble();
	String str=Double.toString(f);
	concatSumOfDigits(str, f);
}

private static void concatSumOfDigits(String str,double f) {
	int i1=str.indexOf('.');
	int leftsum=0;
	int rightsum=0;
	for(int i=0;i<str.length();i++){
		if(i<i1)
		leftsum+=Character.getNumericValue(str.charAt(i));
		else if(i>i1)
			rightsum+=Character.getNumericValue(str.charAt(i));
		
		
	}
	String str1=Integer.toString(leftsum)+":"+Integer.toString(rightsum);
	System.out.println(str1);
	
	
	}


  
}
