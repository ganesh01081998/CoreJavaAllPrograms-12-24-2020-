package com.ojas;

import java.util.Scanner;

public class LeavesMainClass {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter how many leaves you want");
		LeaveSystem ls = new LeaveSystem();

		ls.checkLeavesInQuota(sc.nextInt());
	}
}
