package com.ojas;

public class LeaveSystem {
	// creating a variable for Storing the related msg about leaves
	String str = "";
	int leavesInQuota = 20;
	// creating a variable for Storing the related msg about leaves

	void checkLeavesInQuota(int leavesInQuota) {
		// int leavesInQuota=20;
		if (leavesInQuota >= 20) {
			// System.out.println("in if");
			try {
				throw new LeaveQuotedExceedException("");
			} catch (LeaveQuotedExceedException e) {
				System.out.println("U r leaves are exceeded");
			}
		}

		else {

			System.out.println("u can take leave");
		}

	}

	public LeaveSystem() {
		super();
		this.leavesInQuota = leavesInQuota;
	}
}
