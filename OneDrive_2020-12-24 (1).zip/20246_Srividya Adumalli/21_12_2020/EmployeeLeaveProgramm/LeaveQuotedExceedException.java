package com.ojas;

public class LeaveQuotedExceedException extends Exception {
	
	String str="";

	public LeaveQuotedExceedException(String str) {
		super();
		this.str = str;
	}
	
}
