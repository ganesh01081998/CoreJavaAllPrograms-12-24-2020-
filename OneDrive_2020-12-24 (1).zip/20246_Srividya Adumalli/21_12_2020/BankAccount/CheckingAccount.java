package com.ojas.bank;

public class CheckingAccount {
	int accno;
	// double balance;
	public double balance;

	// double amtToDeposite;
	public CheckingAccount(int accno, double balance) {
		super();
		this.balance = balance;
		this.accno = accno;
	}

	public CheckingAccount() {
		super();
	}

	public boolean chechAccno(int accnumber) {
		if (accnumber == accno) {
			System.out.println("proceed");

		} else
			System.out.println("check u r accno");
		return false;
	}

	void deposite(double amtToDeposite, double balance) {

		System.out.println("Your current balance is" + balance);
		balance = balance + amtToDeposite;
		System.out.println("After depositing money into Your Account now Your Balance is" + balance);

	}

	double withdraw(double amtToWithdraw) {
		double bal = balance;
		System.out.println(bal);
		// System.out.println("Enter Amount to withdraw");
		bal = bal - amtToWithdraw;
		System.out.print("After withdraw the amt , the balance is " + bal);
		/*
		 * try{ if(balance>this.balance){
		 * System.out.println("Insufficient funds"); throw new
		 * InsufficiantFundsException();
		 * 
		 * } } catch(InsufficiantFundsException e){ System.out.println(e); }
		 */
		try {
			if (balance < amtToWithdraw) {
				System.out.println("Insufficient funds");
				throw new InsufficiantFundsException();

			}
		} catch (InsufficiantFundsException e) {
			System.out.println(e);
		}
		return balance;
	}
}
