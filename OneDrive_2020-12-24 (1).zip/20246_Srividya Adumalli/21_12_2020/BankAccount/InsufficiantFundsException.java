package com.ojas.bank;

public class InsufficiantFundsException extends Exception {
	private double amount;

	double getAmount() {
		return amount;

	}
}
