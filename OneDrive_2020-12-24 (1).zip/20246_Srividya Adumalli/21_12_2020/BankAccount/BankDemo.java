package com.ojas.bank;

import java.util.Scanner;

public class BankDemo {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		CheckingAccount cb = new CheckingAccount(123456,2000);
		
		
		System.out.println("enter the Account Number");
		
		//System.out.println("Check Your Account Number");
		
		int accnumber=sc.nextInt();
		
		 cb.chechAccno(accnumber);
		 for(int j=0;j<5;j++){
		 if(accnumber==cb.accno){
		System.out.println("Please enter 1 for deposite and 2 for withdraw");
				String[] str = { "1.Deposite", "2.withdraw" };
		
		
			for (int i = 0; i < str.length; i++) {
				System.out.println(str[i]);
				
			}
		}
		  //System.out.println("enter the amount to deposite");
		String num1 = sc.next();
		if(num1.equals("1")){
			System.out.println("Please enter Amount to deposite");
			double amtToDeposite = sc.nextDouble();
			cb.deposite(amtToDeposite, cb.balance);
		}
	

	
		 if(num1.equals("2")){
			
			System.out.println("Please enter Amount to withdraw");
			double amtTowithdraw = sc.nextDouble();
			cb.withdraw(amtTowithdraw);
	}
	}
	}
}
	