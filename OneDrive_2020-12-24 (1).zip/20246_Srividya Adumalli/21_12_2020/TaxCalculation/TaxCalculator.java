package com.ojas.tax;

public class TaxCalculator {
	
		static double calculateTax(Employee emp){
			if(NotEligibleForTaxException.sal<=10000){
				System.out.println("You are not eligible to pay tax");
				
			}
			else if(NotEligibleForTaxException.sal<=10000 && NotEligibleForTaxException.sal<=30000)	
			{
				return (NotEligibleForTaxException.sal*4/100);
				
			}
			else if(NotEligibleForTaxException.sal<=30000 && NotEligibleForTaxException.sal<=50000)	
			{
				return (NotEligibleForTaxException.sal*5/100);
				
			}
			else if(NotEligibleForTaxException.sal<=50000 && NotEligibleForTaxException.sal<=100000)	
			{
				return (NotEligibleForTaxException.sal*6/100);
				
			}
			else 
			
				return (NotEligibleForTaxException.sal*8/100);
			return 0;
				
			
			
		}
}
