package com.ojas.tax;

public class NotEligibleForTaxException extends Exception {
	static float sal;

            public NotEligibleForTaxException(float sal) {
                 	super();
                	this.sal = sal;
            }

  
}
