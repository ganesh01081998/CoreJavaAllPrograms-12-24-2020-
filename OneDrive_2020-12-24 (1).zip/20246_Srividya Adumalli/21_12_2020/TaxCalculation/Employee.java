package com.ojas.tax;

public class Employee {
	String name;
	String nationality;
	String salary;
	String getName() {
		return name;
	}
	void setName(String name) {
		this.name = name;
	}
	String getNationality() {
		return nationality;
	}
	void setNationality(String nationality) {
		this.nationality = nationality;
	}
	String getSalary() {
		return salary;
	}
	void setSalary(String salary) {
		this.salary = salary;
	}
	public Employee(String name, String nationality, String salary) {
		super();
		this.name = name;
		this.nationality = nationality;
		this.salary = salary;
	}

}
