package com.ojas.tax;

public class NameNotValidException extends Exception {
	static String empName = "vidya";

	public NameNotValidException(String empName) {
		super();
		this.empName = empName;
	}
	

}
