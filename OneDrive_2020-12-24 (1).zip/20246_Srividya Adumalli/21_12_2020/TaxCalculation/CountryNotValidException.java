package com.ojas.tax;

public class CountryNotValidException extends Exception {
	static String str = "india";

	public CountryNotValidException(String str) {
		super();
		this.str = str;
	}

}
