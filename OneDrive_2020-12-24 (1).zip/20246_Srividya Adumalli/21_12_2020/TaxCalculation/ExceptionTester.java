package com.ojas.tax;

import java.util.Scanner;

public class ExceptionTester {
	public static void main(String[] args) {
		TaxSimulator ts = new TaxSimulator();
		TaxCalculator tc = new TaxCalculator();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Country");
		
		ts.checkCountry(sc.next());
		System.out.println("Enter Name");
		ts.checkName(sc.next());
		System.out.println("enter salary");
		ts.checkSal(sc.nextInt());
		
		
		
		//tc.calculateTax(null);
	}
}
