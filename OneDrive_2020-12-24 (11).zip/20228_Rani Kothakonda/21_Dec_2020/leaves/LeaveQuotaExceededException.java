package dec_21_2020;

public class LeaveQuotaExceededException extends Exception {
	public LeaveQuotaExceededException(String s) {
		super(s);
	}
}
