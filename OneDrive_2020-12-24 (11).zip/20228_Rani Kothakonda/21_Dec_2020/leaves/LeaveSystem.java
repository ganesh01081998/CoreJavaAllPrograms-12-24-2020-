package dec_21_2020;

import java.util.Scanner;

public class LeaveSystem {
	int leaves;

	public LeaveSystem(int leaves) {
		this.leaves = leaves;
	}

	public void getleaves() throws LeaveQuotaExceededException {
		
		if (leaves < 20) {
			System.out.println("leaves are sanctioned");
		} 
		
		else {
			throw new LeaveQuotaExceededException("your leaves are exceed");
		}
	}

	public static void main(String[] args) throws LeaveQuotaExceededException {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the leaves you want..");
		int leaves = sc.nextInt();
		LeaveSystem l = new LeaveSystem(leaves);
		l.getleaves();
	}
}
