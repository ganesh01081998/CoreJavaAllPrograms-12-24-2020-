package dec_21_2020;

public class InsufficientFundsException extends RuntimeException{
	public InsufficientFundsException(String s) {
		super(s);
	}
}
