package dec_21_2020;

public class CheckingAccount {
	int accNo;
	double balance = 0;

	public CheckingAccount(int accountNo) {
		this.accNo = accountNo;
	}

	public boolean checkAccount(int accountNo) {
		boolean b = false;
		if (accountNo == accNo) {
			b = true;
		}
		return b;
	}

	public void deposit(int amount) {
		balance = amount;
	}

	double withdraw(int amount) {

		if (balance < amount) {
			throw new InsufficientFundsException("Insufficient balance");
		} 
		else {
			balance = balance - amount;
		}
		return balance;
	}
}