package dec_21_2020;

import java.util.Scanner;

public class BankDemo {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter account number");
		int accountNo = sc.nextInt();
		CheckingAccount c = new CheckingAccount(accountNo);

		System.out.println("enter account numbers to proceed");
		int accNo = sc.nextInt();
		if (c.checkAccount(accNo)) {
			System.out.println("enter deposit amount");
			int depos = sc.nextInt();
			c.deposit(depos);
			System.out.println("Enter withdraw amount");
			int with = sc.nextInt();
			System.out.println("your remaining balance is " +c.withdraw(with));

		} else {
			System.out.println("invalid account number");
		}

	}
}
