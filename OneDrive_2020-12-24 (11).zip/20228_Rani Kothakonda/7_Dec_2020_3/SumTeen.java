package programswithmtds;

import java.util.Scanner;

public class SumTeen {
	public static int fixTeen(int num) {
		if ((num >= 13 && num < 15) || (num > 16 && num <= 19)) {
			return 0;
		} else {
			return num;
		}
	}

	static int noTeenSum(int num1, int num2, int num3) {
		int sum = 0;
		int numbers[] = { num1, num2, num3 };
		for (int num = 0; num < numbers.length; num++) {
			sum += fixTeen(numbers[num]);
		}
		return sum;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter numbers");
		int num1 = sc.nextInt();
		int num2 = sc.nextInt();
		int num3 = sc.nextInt();
		System.out.println(noTeenSum(num1, num2, num3));
	}
}