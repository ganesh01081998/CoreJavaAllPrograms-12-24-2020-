package programswithmtds;

import java.util.Scanner;

public class SumIfNo13 {
	static int check(int first, int second, int three) {
		int sum = 0;
		if (first == 13) {
		}
		else {
			sum += first;
			if (second == 13) {
			} 
			else {
				sum += second;
				if (three == 13) {
				} 
				else {
					sum += three;
				}
			}
		}
		return sum;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter any three values ");
		int first = sc.nextInt();
		int second = sc.nextInt();
		int three = sc.nextInt();
		System.out.println(check(first, second, three));
	}

}
