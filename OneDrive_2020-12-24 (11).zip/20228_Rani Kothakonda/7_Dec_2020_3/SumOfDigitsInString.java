package programswithmtds;

import java.util.Scanner;

public class SumOfDigitsInString {
	static int sumDigits(String str) {
		String res = "";
		int sum = 0;
		for (int i = 0; i < str.length(); i++) {
			char ch = str.charAt(i);
			if (Character.isDigit(ch)) {
				res += ch;
		
			}
		}
		int num = Integer.parseInt(res);
		return sum;
		
	}
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("enter string");
	String str = sc.nextLine();
	System.out.println( "sum "  +sumDigits(str));
}
}
