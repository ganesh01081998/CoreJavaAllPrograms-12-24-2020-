package Dec_15_2020;

public class Square extends Shape {
	float side;

	public Square(float side) {
		this.side = side;
	}

	public float getSide() {
		return side;
	}

	public void setSide(float side) {
		this.side = side;
	}

	@Override
	void getArea() {
		System.out.println("Area of Square is" + side * side);
	}

	@Override
	void getPerimeter() {
		System.out.println("Perimeter of Square is" + 4 * side);
	}

}
