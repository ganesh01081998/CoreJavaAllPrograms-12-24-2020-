package Dec_15_2020;

abstract class Shape {
	abstract void getArea();

	abstract void getPerimeter();
}

public class Circle extends Shape {
	final float pi = 3.14f;
	float radius;

	public Circle(float radius) {
		this.radius = radius;
	}

	public float getRadius() {
		return radius;
	}

	public void setRadius(float radius) {
		this.radius = radius;
	}

	@Override
	void getArea() {
		System.out.println("Area of circle is" +(pi * radius * radius));
		
	}

	@Override
	void getPerimeter() {
		System.out.println("Perimeter of circle is " +(2 * pi * radius));
	}

}


