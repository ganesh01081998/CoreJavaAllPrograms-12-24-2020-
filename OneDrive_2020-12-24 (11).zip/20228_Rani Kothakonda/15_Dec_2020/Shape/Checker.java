package Dec_15_2020;

import java.util.Scanner;

public class Checker {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter radius");
		Shape s = new Circle(sc.nextFloat());
		s.getArea();
		s.getPerimeter();
		System.out.println("enter side");
		Shape s1 = new Square(sc.nextFloat());
		s1.getArea();
		s1.getPerimeter();
		System.out.println("enter length And breadth");
		Shape s2 = new Rectangle(sc.nextFloat(), sc.nextFloat());
		s2.getArea();
		s2.getPerimeter();
	}

}
