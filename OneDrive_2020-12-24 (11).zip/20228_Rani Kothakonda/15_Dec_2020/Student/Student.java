package Dec_15_2020;

abstract public class Student {
	String studentName;
	String studentClass;
	protected static int totalNoOfStudents;

	Student() {
		this.studentName = studentName;
		this.studentClass = studentClass;
	}

	public Student(String studentName, String studentClass) {
		this.studentName = studentName;
		this.studentClass = studentClass;
	}

	abstract int getPercentage();

	static void getTotalNoStudents() {

	}

	@Override
	public String toString() {
		return "Student [studentName=" + studentName + ", studentClass=" + studentClass + "]";
	}
}
