package Dec_15_2020;

public class HistoryStudent extends Student{
	int historyMarks;
	int civicsMarks;
	public HistoryStudent(String name, String stdClas, int historyMarks, int civicsMarks) {
		super(name, stdClas);
		this.historyMarks = historyMarks;
		this.civicsMarks = civicsMarks;
	}
	@Override
	int getPercentage() {
		int perce = 0;
		if(historyMarks <= 100 && civicsMarks <= 100) {
			int totalMarks = historyMarks + civicsMarks;
			System.out.println("total marks " + totalMarks);
			return perce = (totalMarks) / 2;
		}
		else {
			System.out.println("give subject marks below 100!");
		}
		return perce;
	}
	@Override
	public String toString() {
		return "HistoryStudent [historyMarks=" + historyMarks + ", civicsMarks=" + civicsMarks + ", StudentName=" + studentName
				+ ", stdClas=" + studentClass + "]";
	}


}
