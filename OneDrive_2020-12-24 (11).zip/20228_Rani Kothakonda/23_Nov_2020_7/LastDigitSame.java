package programswithmtds;

import java.util.Scanner;

public class LastDigitSame {
	static boolean isLastDigitSame(int number1, int number2) {
		if (number1 % 10 == number2 % 10) {
			return true;
		}
		return false;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter two input values : ");
		int number1 = sc.nextInt();
		int number2 = sc.nextInt();
		System.out.println(isLastDigitSame(number1, number2));
	}
}
