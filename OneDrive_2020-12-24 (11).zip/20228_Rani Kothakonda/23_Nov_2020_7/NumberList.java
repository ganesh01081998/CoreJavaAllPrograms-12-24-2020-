package programswithmtds;

public class NumberList {

}
