package ojas.org.com;

import java.util.Scanner;

public class SwappingWithOutTemp {
	static String swap(int firstNum, int secNum) {
		String result = "";
		firstNum = firstNum + secNum;
		secNum = firstNum - secNum;
		firstNum = firstNum - secNum;
	    return result += "After swapping:" + firstNum + " , " + secNum;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter two numbers");
		int firstNum = sc.nextInt();
		int secNum = sc.nextInt();
		System.out.println("before swapping:" + firstNum + " , " + secNum);
		System.out.println(swap(firstNum,secNum));
	}
}
