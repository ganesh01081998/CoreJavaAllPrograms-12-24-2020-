package ojas.org.com;

public class PalindromeUsingMtds {
	static boolean palindrome(int num) {
		boolean b = false;
		int rev = 0, temp, num1 = num;
		while (num > 0) {
			temp = num % 10;
			rev = rev * 10 + temp;
			num = num / 10;
		}
		if (num1 == rev) {
			b = true;
		}
		return b;
	}

	public static void main(String[] args) {
		int num = Integer.parseInt(args[0]);
		System.out.println(palindrome(num));
	}
}