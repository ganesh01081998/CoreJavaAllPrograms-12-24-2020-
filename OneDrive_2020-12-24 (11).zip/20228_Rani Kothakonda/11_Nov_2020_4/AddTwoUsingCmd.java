package programswithmtds;

public class AddTwoUsingCmd {
 static String add(int sum, int num) {
	 String res = "";
	 sum = sum + num;
	 sum += num;
	 sum += num;
	 sum += num;
	return res += sum; 
 }
 public static void main(String[] args) {
	int sum = Integer.parseInt(args[0]);
	int num = Integer.parseInt(args[1]);
	System.out.println(add(sum,num));
}
}
