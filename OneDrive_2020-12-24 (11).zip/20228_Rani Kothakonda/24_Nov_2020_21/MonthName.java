package programswithmtds;

import java.util.Scanner;

public class MonthName {
	static String isMonths(String[] months, String mon, int days[]) {
		String result = "";
		for (int i = 0; i < months.length; i++) {
			if (mon.equals(months[i])) {
				result += days[i];
			}
		}
		return result;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String months[] = { "jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec" };
		int days[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
		String mon = sc.next().toLowerCase();
		System.out.println(isMonths(months, mon, days));
	}
}
