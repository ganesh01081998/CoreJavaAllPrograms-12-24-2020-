package programswithmtds;

import java.util.Scanner;

public class AdamNumber {
	static boolean isAdamNumber(int num) {
		boolean b = false;
		 int square = num * num;
		 System.out.println(square);
		 int square1 = reverseNumber(num);
		 System.out.println(square1);
		int square2 = square1 * square1;
		System.out.println(square2);
		if( square == reverseNumber(square2)) {
			b = true;
		}
		return b;
		
		
	}
	static int reverseNumber(int num) {
		  int rev = 0; 
	        while (num > 0) 
	        {
	        	int temp = num % 10;
	            rev = rev * 10 + temp;
	            num = num / 10; 
	        } 
	        return rev; 
	    } 
	
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("enter number");
	int num = sc.nextInt();
	reverseNumber(num);
	System.out.println(isAdamNumber(num));
}
}
