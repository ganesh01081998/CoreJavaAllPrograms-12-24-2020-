package com.ojas.programs;

import java.util.Scanner;

public class ReverseOfElementsArray {
	static int[] reverseArray(int array[]) {
		int ar[] = new int[array.length];
		int j = 0;
		for (int i = array.length - 1; i >= 0; i--) {
			ar[j] = array[i];
			j++;
		}

		return ar;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter elments");
		int size = sc.nextInt();
		System.out.println("enter elements");
		int arr[] = new int[size];
		for (int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		int res[] = reverseArray(arr);
		for (int i = 0; i < res.length; i++) {
			System.out.println(res[i]);
		}
	}
}
