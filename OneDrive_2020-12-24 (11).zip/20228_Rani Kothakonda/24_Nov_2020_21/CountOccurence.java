package programswithmtds;

import java.util.Scanner;

public class CountOccurence {
	static void isCountOccurance(String str) {
		String temp = "";
		int count = 0;
		for (int i = 0; i < str.length(); i++) {
			char c1 = str.charAt(i);
			for (int j = 0; j < str.length(); j++) {
				char c2 = str.charAt(j);
				if (c1 == c2 && temp.indexOf(c1) == -1) {
					count = count + 1;
				}
			}
			if (temp.indexOf(c1) == -1) {
				temp = temp + c1;
				System.out.println(" The character occurance  " + c1 + " has Occured " + count + " Times  ");
			}
			count = 0;
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter any String");
		String str = sc.next();
		isCountOccurance(str);
	}
}
