package programswithmtds;

import java.util.Scanner;

public class MaximumValueOfArray {
	public static int findMax(int array[]) {
	    if(array.length == 0) {
	        return 0;
	    }
	    int big = array[0];
	    int count = 0;
	    for (int i = 0; i < array.length; i++) {
	        if(isNegative(array[i]))  {
	            count++;
	        }
	    }
	    if(count == 3) {        
	    for (int i = 1; i < array.length; i++)
	        if(array[i] > big) {
	            big = array[i];
	        }
	    }
	    else {
	        return -1;
	    }
	    return big;    
	}

public static boolean isNegative(int num) {
    boolean b = false;
    if(num < 0) {
        b = true;
    }
    return b;
}
public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    System.out.println("enter size");
    int size = scanner.nextInt();    
    int array[] = new int[size];
    System.out.println("enter elements");
    for (int i = 0; i < array.length; i++) {
        array[i] = scanner.nextInt();
    }
    System.out.println("bigest num " + findMax(array));
}
}
