package com.ojas.programs;

import java.util.Scanner;

public class LuckyNumber {
	static int convertMMMtoMM(String str) {
		int result = 0;

		String[] monthNames = { "jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec" };
		int monthDaysarr[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 };
		for (int i = 0; i < monthNames.length; i++) {
			if (str.equals(monthNames[i])) {
				result = monthDaysarr[i];
			}
		}

		return result;
	}

	static int getLuckyNumber(String str) {
		int sum = 0;
		String str2 = "";
		String str1[] = str.split("-");
		int date = Integer.parseInt(str1[0]);
		int month = convertMMMtoMM(str1[1]);
		int year = Integer.parseInt(str1[2]);
		sum = getSumOfDigits(date) + getSumOfDigits(month) + getSumOfDigits(year);
		getSumOfDigits(sum);
		return sum;

	}

	public static int getSumOfDigits(int num) {
		int sum = 0;
		while (num > 0) {
			int num1 = num % 10;
			sum = sum + num1;
			num = num / 10;
		}
		return sum;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter string");
		String str = sc.next();
		System.out.println("lucky number is " + getLuckyNumber(str));
	}
}
