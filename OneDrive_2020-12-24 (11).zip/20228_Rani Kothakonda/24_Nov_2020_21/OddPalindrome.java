package ojas.org.com;

public class OddPalindrome {
 static boolean odd(int num) {
	boolean b = false;
	  if(num % 2 != 0) {
		b = true;
	   }
	  return b;
   }
    static boolean palindrome(int num) {
	    boolean f = false;
	       int rev = 0, temp = 0, tempnum =num;
	       while(num > 0) {
		     temp = num % 10;
		     rev = rev * 10 + temp;
		     num = num / 10;
	        }
	    if(tempnum == rev) {
		  f = true;
	        }
	     return f;
   }
    static void range() {
	 for(int i = 100; i <= 400;i++) {
		 if(odd(i) && palindrome(i)){
			 System.out.println(i);
		   }
	   }
   }
     public static void main(String[] args) {
	  System.out.println("odd plindromes are");
	    range();
   }
 }
