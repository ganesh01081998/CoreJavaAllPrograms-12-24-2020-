package programswithmtds;

import java.util.Scanner;

public class MaskMail {
	static String result ="";
	   
    static void doThis(String email) {
        for (int i = 2; i < email.length(); i++) {
            if(email.charAt(i) == '@') {
                doAgain(i,email);
                break;
            }
            else {
                result += "x";
            }
        }
    }
    static void doAgain(int i, String email) {
        for (int j = i; j < email.length(); j ++) {
            result+= email.charAt(j);
        }
    }
   
    public static void main(String[] args) {
        String email;
        System.out.println("Enter you Email id");
        Scanner sc = new Scanner(System.in);
        email = sc.next();
        result += "" + email.charAt(0) + email.charAt(1);
        doThis(email);
        System.out.println(result);
    }
}




