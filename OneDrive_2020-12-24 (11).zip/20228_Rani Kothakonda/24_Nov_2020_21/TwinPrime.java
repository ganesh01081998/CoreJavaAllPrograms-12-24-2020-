package programswithmtds;

import java.util.Scanner;

public class TwinPrime {
	static String result = "";

	static void isTwinPrime(int num1, int num2) {
		while (num1 <= num2) {
			if ((isPrime(num1)) && (isPrime(num1 + 2))) {
				result = result + (num1) + "," + (num1 + 2) + " is TwinPrime \n";
			}
			num1++;
		}
	}

	static boolean isPrime(int num) {
		int count = 0;
		for (int i = 1; i <= num; i++) {
			if (num % i == 0) {
				count++;
			}
		}
		if (count == 2) {
			return true;
		} else {
			return false;
		}
	}

	public static void main(String[] args) {
		System.out.println("Enter the range for twin prime");
		Scanner sc = new Scanner(System.in);
		isTwinPrime(sc.nextInt(), sc.nextInt());
		System.out.println(result);
	}

}
