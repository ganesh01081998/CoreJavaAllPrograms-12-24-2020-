package programswithmtds;

import java.util.Scanner;

public class NameScore {
	static int getNameScore(String name) {
		int sum = 0;
		int result = 0;
		for (int i = 0; i < name.length(); i++) {
			char c = name.charAt(i);
			int num = 1;
			for (char ch = 0; ch <= 256; ch++) {
				if (c == ch) {
					sum = sum + num;

				}
				num++;
			}
			result = sum;
		}
		return result;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter name");
		String name = sc.nextLine();
		System.out.println(getNameScore(name));
	}
}
