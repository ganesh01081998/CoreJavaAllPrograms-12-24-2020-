package ojas.org.com;

import java.util.Scanner;

public class LcmOfNumber {
	static int check(int num1, int num2) {
		int lcm = -1;
		if (num1 < 0 || num2 < 0) {
			return lcm;
		} else {
			lcm = (num1 > num2) ? num1 : num2;
			while (true) {
				if (lcm % num1 == 0 && lcm % num2 == 0) {
					break;
				}
				lcm++;
			}
		}
		return lcm;
	}

	public static void main(String[] args) {
		System.out.println("enter two numbers");
		Scanner scanner = new Scanner(System.in);
		System.out.println(check(scanner.nextInt(), scanner.nextInt()));
	}
}