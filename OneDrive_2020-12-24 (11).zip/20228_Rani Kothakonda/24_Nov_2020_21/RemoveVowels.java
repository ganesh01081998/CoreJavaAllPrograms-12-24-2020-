package programswithmtds;

import java.util.Scanner;

public class RemoveVowels {
	static String getRemoveVowels(String name) {
		String str = "";
		for (int i = 0; i < name.length(); i++) {
			char ch = name.charAt(i);
			if (ch != 'a' && ch != 'e' && ch != 'i' && ch != 'o' && ch != 'u') {
				str += ch;
			}

		}
		return str;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter any name?");
		String name = sc.nextLine();
		System.out.println(getRemoveVowels(name));
	}
}

