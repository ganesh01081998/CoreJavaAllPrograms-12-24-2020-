package com.ojas.programs;

import java.util.Scanner;

public class CollatzSequence {
	static void isCollatz(int num) {
		while (num > 1) {
			if (num % 2 == 0) {
				num = num / 2;
			} else {
				num = (num * 3) + 1;
			}
			System.out.println(num);
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter number");
		int num = sc.nextInt();
		isCollatz(num);
	}

}
