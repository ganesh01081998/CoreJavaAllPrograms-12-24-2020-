package programswithmtds;

import java.util.Scanner;

public class SumOfDigitsOfDecimalNumber {
	public static String concateSumOfDigits(double num) {
	    String str = "";
	    String left = "";
	    String right = "";
	    char ch = 0;
	    int i = 0;
	    String s = Double.toString(num);
	    String arr[] = s.split("[.]");
	    left = arr[0];
	    right = arr[1];
	    int num1 = Integer.parseInt(left);
	    int num2 = Integer.parseInt(right);
	    int sum = getSumOfDigit(num1);
	    int sum1 = getSumOfDigit(num2);
	    str += sum +":" +sum1;
	    return str;
	}
	static int getSumOfDigit(int num) {
		int rem, quo, sum = 0;
		while (num > 0) {
			rem = num % 10;
			sum = sum + rem;
			num = num / 10;
		}
		return sum;
	}
	public static void main(String[] args) {
	 Scanner sc = new Scanner(System.in);
 System.out.println("enter number");
     double num = sc.nextDouble();
    System.out.println(concateSumOfDigits(num));
 }
}
