package Dec_18_2020;

import java.util.Scanner;

public class COJ_42_Testing {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("enter the sports");
	COJ_42_Soccer s = new COJ_42_Soccer();
	s.getName(sc.next());
	System.out.println(s.getNumberOfTeamMembers());
}

}

