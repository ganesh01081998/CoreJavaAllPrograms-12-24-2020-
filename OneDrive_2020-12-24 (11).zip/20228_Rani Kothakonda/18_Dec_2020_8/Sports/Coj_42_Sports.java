package Dec_18_2020;

public class Coj_42_Sports {
	String s;
String getName(String s) {
	return s;
	
}
String getNumberOfTeamMembers() {
	return "Each team has n players in ";
	
}
}
