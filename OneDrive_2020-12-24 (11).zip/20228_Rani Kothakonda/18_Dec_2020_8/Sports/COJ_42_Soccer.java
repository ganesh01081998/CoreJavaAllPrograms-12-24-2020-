package Dec_18_2020;

public class COJ_42_Soccer extends Coj_42_Sports  {
	String getName(String s) {
		
		return super.s = s;
		
	}
	String getNumberOfTeamMembers() {
		return "In " + super.getName(super.s) +", each team has 11 players";
		
	}
}