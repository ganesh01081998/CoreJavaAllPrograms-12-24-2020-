package Dec_18_2020;

import java.util.Scanner;

public class ArrangeString {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter you word1 and word2");
		String word1 = sc.next();
		String word2 = sc.next();
		getArrangeString(word1, word2);

	}

	static void getArrangeString(String word1, String word2) {
		String res = "";
		int word1length = word1.length();
		int word2length = word2.length();
		int ch1 = word1.charAt(0);
		int ch2 = word2.charAt(0);
		if (ch1 < ch2) {
			res += word1length + word2length;
			res += "   No";
			char caps = Character.toUpperCase(word1.charAt(0));
			word1 = caps + word1.substring(1);
			char caps1 = Character.toUpperCase(word2.charAt(0));
			word2 = caps1 + word2.substring(1);
			res += "  " + word1 + " " + word2;
		} 
		else {
			res += word1length + word2length;
			res += "  Yes";
			char caps = Character.toUpperCase(word1.charAt(0));
			word1 = caps + word1.substring(1);
			char caps1 = Character.toUpperCase(word2.charAt(0));
			word2 = caps1 + word2.substring(1);
			res += "  " + word2 + " " + word1;
		}
		System.out.println(res);
	}

}