package Dec_18_2020;

public class COJ_46_Cylender extends COJ_46_Circle {

	double height;

	double volume;

	public COJ_46_Cylender() {

	}

	public COJ_46_Cylender(double radius, double height) {
		super(radius);
		this.height = height;
	}

	public double getVolume() {
		if (height < 0) {
			volume = -1;
		} else {
			volume = pie * (radius * radius * height);
		}

		return volume;
	}

}
