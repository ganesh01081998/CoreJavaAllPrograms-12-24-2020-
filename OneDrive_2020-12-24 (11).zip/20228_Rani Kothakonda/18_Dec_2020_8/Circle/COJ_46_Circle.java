package Dec_18_2020;

public class COJ_46_Circle {
	float pie = 3.14f;
	double radius;
	double area;

	COJ_46_Circle() {

	}

	public COJ_46_Circle(double radius) {
		this.radius = radius;
	}

	double getArea() {

		if (radius < 0) {
			area = -1;
		} else {
			area = pie * (radius * radius);
		}
		return area;
	}
}
