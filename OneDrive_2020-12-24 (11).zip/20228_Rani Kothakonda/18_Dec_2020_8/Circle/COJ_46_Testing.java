package Dec_18_2020;

import java.util.Scanner;

public class COJ_46_Testing {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Radius And Height");
		COJ_46_Cylender cylender = new COJ_46_Cylender(sc.nextDouble(), sc.nextDouble());
		System.out.println("Area Of Circle : " + cylender.getArea());
		System.out.println("Volume Of Cylender : " + cylender.getVolume());
	}
}
