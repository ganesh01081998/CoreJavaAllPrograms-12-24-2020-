package Dec_18_2020;

import java.util.Scanner;

interface AdvancedArithmetic {
	public abstract int divisorSum(int number);
}

class Calculator implements AdvancedArithmetic {
	public int divisorSum(int number) {
		int sum = 1;
		for (int i = 2; i <= (number / 2); i++) {
			if (number % i == 0) {
				sum += i;
			}
		}
		if (number != 1) {
			return sum + number;
		} else {
			return sum;
		}
	}
}

public class TestSolution {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter number");
		int number = sc.nextInt();
		AdvancedArithmetic a = new Calculator();
		int sum = a.divisorSum(number);
		System.out.println("sum of divisiors is" + sum);
	}

}
