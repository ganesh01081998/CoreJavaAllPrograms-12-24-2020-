package Dec_18_2020;

import java.util.Scanner;

abstract class COJ_41_Book {
	String title;

	abstract void setTitle(String s);

	String getTitle() {
		return title;
	}
}

class COJ_41_MyBook extends COJ_41_Book {

	@Override
	void setTitle(String title) {
		// System.out.println("The title is my book is: " +title);
		super.title = title;
	}

}

public class COJ_41_Testing {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the title");
		COJ_41_MyBook m = new COJ_41_MyBook();
		m.setTitle(sc.nextLine());
		System.out.println("The title is my book is: " + m.getTitle());

	}
}
