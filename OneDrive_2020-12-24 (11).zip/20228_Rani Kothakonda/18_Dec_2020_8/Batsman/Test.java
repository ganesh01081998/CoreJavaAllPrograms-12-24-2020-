package Dec_18_2020;

import java.util.Scanner;

public class Test {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		COJ_45_Batsman bat = new COJ_45_Batsman();
		System.out.println("Enter Statistics Of The Batsman like\n name\n run\n matches");
		String name = scan.next();
		int runs = scan.nextInt();
		int matches = scan.nextInt();
		if ((runs <= 0 && matches <= 0) || (runs > 0 && matches <= 0)) {
			System.out.println("ERROR");
		} else {
			bat = new COJ_45_Batsman(name, runs, matches);
			System.out.println(bat.getStatistics() + "\n\n name = " + name + "\n batting Average = "
					+ bat.computeBattingAverage());
		}
	}
}
