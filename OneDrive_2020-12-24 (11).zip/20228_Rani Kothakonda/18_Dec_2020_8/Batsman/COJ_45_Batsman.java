package Dec_18_2020;

public class COJ_45_Batsman {
	String name;
	int runs;
	int matches;
	float batting_avg;
	public COJ_45_Batsman() {
		
	}
	public COJ_45_Batsman(String name, int runs, int matches) {
		this.name = name;
		this.runs = runs;
		this.matches = matches;
	}
	public double computeBattingAverage() {
		return this.batting_avg = (float )(runs / matches);
	}
	public String getStatistics() {
		return " Batsman_5 Statistics \n name=" + name + "\n run=" + runs + "\n matches=" + matches ;
	}
}
