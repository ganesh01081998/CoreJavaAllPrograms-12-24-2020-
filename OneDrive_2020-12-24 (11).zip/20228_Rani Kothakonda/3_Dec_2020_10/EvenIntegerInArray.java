package exercise_3_11_2020;

import java.util.Scanner;

public class EvenIntegerInArray {
	static int getEven(int array[]) {
		int evenArray[] = new int[array.length];
		int count = 0;
		for (int i = 0; i < array.length; i++) {
			if (array[i] % 2 == 0) {
				count++;
			}
		}

		return count;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter size");
		int size = sc.nextInt();
		System.out.println("enter elements");
		int array1[] = new int[size];
		for (int i = 0; i < array1.length; i++) {
			array1[i] = sc.nextInt();
		}
		System.out.println(getEven(array1));
	}
}
