package o3_12_2020;

import java.util.Random;

public class Dice {
	int faceValue;
	void roll() {
		Random r = new Random();
		faceValue = r.nextInt(6) + 1;
	}
}
