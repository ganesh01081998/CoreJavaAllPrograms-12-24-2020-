package exercise_3_11_2020;

import java.util.Scanner;

public class ReverseOfWord {
	static String reverseWord(String str) {
		String res = "";
		for(int i = str.length()-1; i >= 0;i--) {
			char ch =str.charAt(i);
			res += ch;
				}
		return res;
		
	}
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("enter the word");
	String str = sc.next();
	System.out.println(reverseWord(str));
}
}
