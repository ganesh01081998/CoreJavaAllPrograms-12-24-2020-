package exercise_3_11_2020;

import java.util.Scanner;

public class SequenceNumber {
	static int[] printSequence(int n, int start, int end) {
		int array[] = new int[n];
		int k = 0;
		for (int i = start; i < end; i++) {
			array[k] = i;
			k++;
		}
		return array;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter start");
		int start = sc.nextInt();
		System.out.println("enter end");
		int end = sc.nextInt();
		int n = end - start;
		int[] res = printSequence(n, start, end);
		for (int i = 0; i < res.length; i++) {
			System.out.println(res[i]);
		}
	}
}
