package exercise_3_11_2020;

public class OccurenceOfCharacter {
	static int getCount(String str) {
		int count = 0;
		for (int i = 0; i < str.length(); i++) {
			char ch = str.charAt(i);
			if (ch == 'a') {
				count++;
			}
		}
		return count;
		 }

	public static void main(String[] args) {
		String str = "paramahamsa";
		System.out.println(getCount(str));
	}
}
