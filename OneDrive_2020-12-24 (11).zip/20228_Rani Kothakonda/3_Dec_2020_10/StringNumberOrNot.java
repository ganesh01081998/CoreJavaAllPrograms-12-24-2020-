package exercise_3_11_2020;

import java.util.Scanner;

public class StringNumberOrNot {
	static boolean isNumber(String number) {
		boolean b = false ;
		int count = 0;
		String result = "";
		for (int index = 0; index < number.length(); index++) {
			char ch = number.charAt(index);
			if (Character.isDigit(ch)) {
				count++;
				}
		}
			if(count == number.length()){
			b = true;
			}
		
		return b;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter string");
		String str = sc.next();
		System.out.println(isNumber(str));
	}
}
