package exercise_3_11_2020;

import java.util.Scanner;

public class RemoveTen {
	static int[] withoutTen(int[] array) {
		int j = 0;
		int arr[] = new int[array.length];
		for (int i = 0; i < array.length; i++) {
			if(array[i] != 10) {
				arr[j] = array[i];
				j++;
			}
			else {
				arr[j] = 0;
			}
		}
		return arr;	
	}


	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter size");
		int size = sc.nextInt();
		System.out.println("enter elements");
		int array[] = new int[size];
		for (int i = 0; i < array.length; i++) {
			array[i] = sc.nextInt();
		}
		int[] result = withoutTen(array);
		for (int i = 0; i < result.length; i++) {
			System.out.println(result[i]);
		}
	}
}
