package o3_12_2020;

import java.util.Scanner;

class Student {
	String sname;
	int snum;
	int marks[] ;
	Student(String sname,int snum,int marks[]) {
		this.sname = sname;
		this.snum = snum;
		this.marks = marks;		
	}
	public int average(int marks[]) {
		int sum = 0;
		int average = 0;
		for(int i = 0 ;i < marks.length; i++) {
			sum = sum + marks[i];
		}
		System.out.println("sum = "+ sum);
		average = sum / 5;
		
		return average;	
	}
	String stdGrade(int marks[]) {
		int avg = average(marks);
		System.out.println("average ="+avg);
		String res = "";
		if(avg > 90) {
			res += "A grade";
		}
		else if(avg < 90 && avg > 60) {
			res += "B grade";
		}
		else if(avg < 60 && avg > 40) {
			res += "C grade";
		}
		else {
			res += "Student failed in xam";
		}
		return res;
	}
}
public class StudentMarks {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("enter name");
	String sname = sc.next();
	System.out.println("enter num");
	int snum = sc.nextInt();
	System.out.println("enter number of sub marks");
	int size = sc.nextInt();
	System.out.println("enter subjects");
	int[] marks = new int[size];
	for(int i = 0; i < size ; i++) {
		marks[i] = sc.nextInt();
	}
	Student st = new Student(sname,snum,marks);
	System.out.println(st.average(marks));
	System.out.println(st.stdGrade(marks));
}
}
