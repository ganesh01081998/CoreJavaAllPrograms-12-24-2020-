package dec_12_10;

import java.util.Scanner;

public class Account {
	private Customer C;
	private int acNo;
	private double balance;
	private float rateOfIntrest;

	public Account(Customer c, int acNo, double balance, float rateOfIntrest) {
		C = c;
		this.acNo = acNo;
		this.balance = balance;
		this.rateOfIntrest = rateOfIntrest;
	}

	@Override
	public String toString() {
		return "Account [C=" + C + ", acNo=" + acNo + ", balance=" + balance + ", rateOfIntrest=" + rateOfIntrest + "]";
	}

	public void withdraw(double balance, float amountforWithdraw) {
		System.out.println("in withdraw method");
		balance = this.balance - amountforWithdraw;
		System.out.println(balance);
	}

	public static void main(String[] args) {
		Customer c = new Customer("Rani", "Jaanu");
		Account ac = new Account(c, 20220, 4000, 2);
		Scanner sc = new Scanner(System.in);
		System.out.println("enter u r account number");
		int acno = sc.nextInt();
		if (ac.acNo == acno) {
			System.out.println("Proceed");
		} else {
			System.out.println("check u r account number once again");
		}
		System.out.println(c);
		System.out.println(ac);
		System.out.println(ac.balance);
		System.out.println("enter the amount to deposit");
		float amountToDeposit = sc.nextFloat();
		ac.deposit1(ac.balance, amountToDeposit);
		System.out.println("enter the amount to withDraw");
		float amountforWithdraw = sc.nextFloat();
		ac.withdraw(ac.balance, amountforWithdraw);
	}

	private void deposit1(double balance2, float amountToDeposit) {
		System.out.println("your balance is");
		balance = this.balance + amountToDeposit;
		System.out.println(balance);

	}
}
