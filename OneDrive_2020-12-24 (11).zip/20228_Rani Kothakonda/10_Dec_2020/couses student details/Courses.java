package dec_12_10;
import java.util.Arrays;
public class Courses {
String course[] = {"1.java","2.phyton","3.dotNet","4.UI","5.DataScience","6.exit"};
int prices[] = {4000,3000,3500,5000,6000};
public String toString() {
    return "Courses [course=" + Arrays.toString(course);
}
}
