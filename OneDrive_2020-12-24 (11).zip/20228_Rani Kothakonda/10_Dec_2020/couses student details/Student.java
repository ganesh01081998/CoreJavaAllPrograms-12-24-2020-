package dec_12_10;

import java.util.Scanner;

public class Student {
	private String sName;
	static Address a;

	public Student(String sName, Address a) {
		this.sName = sName;
		this.a = a;
	}

	@Override
	public String toString() {
		return "Student [sName=" + sName + ", a=" + a + "]";
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("please Enter your Details" + "\n");
		System.out.print("sName = ");
		String sName = sc.next();
		System.out.print("Enter H-no = ");
		int hNo = sc.nextInt();
		System.out.print("Enter street name = ");
		String streetName = sc.next();
		System.out.print("Enter cityname = ");
		String cityName = sc.next();
		Address add = new Address(hNo, streetName, cityName);
		System.err.println("Available Courses are :");
		Courses c = new Courses();
		for (int i = 0; i < c.course.length; i++) {
			System.out.println(c.course[i]);

		}
		System.out.println("Please enter number which course you want ");
		int coursenum[] = new int[c.course.length];
		for (int i = 0; i < coursenum.length; i++) {
			coursenum[i] = sc.nextInt();
			if (coursenum[i] == 6) {
				break;
			}
		}
		String res = "";
		int amount = 0;
		
		for (int index = 0; index < coursenum.length; index++) {

			for (int check = 0; check < c.prices.length; check++) {

				if (coursenum[index] == check) {
					amount += c.prices[check - 1];
					res += c.course[check - 1] + ",";
				}
			}
		}
			
			Student s = new Student(sName, add);
			System.out.println(s);
			System.out.println("your selected courses are");
			System.out.println(res);
			System.out.println("Amount is :" + amount);
		
	}
}