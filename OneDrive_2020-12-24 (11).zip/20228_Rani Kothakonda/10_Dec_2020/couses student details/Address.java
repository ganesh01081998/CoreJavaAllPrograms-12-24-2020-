package dec_12_10;

public class Address {
private int hNo;
private String streetName;
private String cityName;
public Address(int hNo, String streetName, String cityName) {
	this.hNo = hNo;
	this.streetName = streetName;
	this.cityName = cityName;
}
@Override
public String toString() {
	return "Address [hNo=" + hNo + ", streetName=" + streetName + ", cityName=" + cityName + "]";
}

}
