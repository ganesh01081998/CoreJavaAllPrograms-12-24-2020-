package dec_12_10;

public class Rectangle {
	private int x1;
	private int y1;
	private int x2;
	private int y2;

	Rectangle() {

	}

	public Rectangle(int x1, int y1, int x2, int y2) {
		this.x1 = x1;
		this.y1 = y1;
		this.x2 = x2;
		this.y2 = y2;
		int height = getHeight(x1, y1);
		System.out.println("height = " + height);
		int width = getWidth(x2, y2);
		System.out.println("width = " + width);
		int area = getArea(height, width);
		System.out.println("Area = " + area);
		int perimeter = getPerimeter(height, width);
		System.out.println("perimeter =" + perimeter);

	}

	public int getHeight(int x1, int y1) {
		int res = 0;
		res = (x1 / 2) - y1;
		return res;
	}

	public int getWidth(int x2, int y2) {
		int res = 0;
		res = (x2 / 2) - y2;
		return res;
	}

	public int getArea(int height, int width) {
		int res = 0;
		res = height * width;
		return res;
	}

	public int getPerimeter(int height, int width) {
		int res = 0;
		res = 2 * (height + width);
		return res;
	}

	public static void main(String[] args) {
		Rectangle r = new Rectangle(10, 2, 10, 2);
	}
}
