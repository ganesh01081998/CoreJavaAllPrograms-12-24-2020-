package programswithmtds;

import java.util.Scanner;

public class Pattern7 {
	public static String pattern(int start, int end) {
		String str = "";
		int k = 5;
		for (int i = start; i <= end; i++) {
			for (int j = start; j <= i; j++) {
				str += k + " ";
			}
			k--;
			str += "\n";
		}
		return str;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter two numbers");
		System.out.println(pattern(sc.nextInt(), sc.nextInt()));
	}
}