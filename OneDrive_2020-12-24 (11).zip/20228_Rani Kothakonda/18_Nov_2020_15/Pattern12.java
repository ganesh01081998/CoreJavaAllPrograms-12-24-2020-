package programswithmtds;

import java.util.Scanner;

public class Pattern12 {
	static String pattern(int size) {
		String res = "";
		for (int i = 1; i <= size; i++) {
			for (int j = 1; j <= size; j++) {
				if ((j == 1 || j == size) || (i == 1 || i == size)) {
					res += "*";
				} else {
					res += " ";
				}
			}
			res += "\n";
		}
		return res;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter size");
		System.out.println(pattern(sc.nextInt()));
	}
}