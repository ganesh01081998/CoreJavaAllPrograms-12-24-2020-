package programswithmtds;

import java.util.Scanner;

public class Pattern13 {
    public static String pattern(int start,int end) {
        String str = "";
        int star = 1;
        int space = 4;
        for(int i = start ; i <= end ; i++) {
            
            for(int k = start ; k <= space ; k++) {
                str +=  " ";
            }
            for(int j = start ; j <= star ; j++) {
            str +=  "*";
            }
            space--;
            star = star+2;
        str += "\n";
            
            }
        return str ;
    }

public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("enter two numbers");
	System.out.println(pattern(sc.nextInt(),sc.nextInt()));
}
}