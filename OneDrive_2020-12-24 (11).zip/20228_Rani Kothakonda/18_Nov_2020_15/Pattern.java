package programswithmtds;

import java.util.Scanner;

public class Pattern {
	public static String pattern(int start, int end) {
		String str = "";
		for (int i = start; i <= end; i++) {
			for (int j = start; j <= end; j++) {
				str += j + " ";
			}
			str += "\n";
		}
		return str;

	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter two numbers");
		System.out.println(pattern(sc.nextInt(), sc.nextInt()));
	}
}
