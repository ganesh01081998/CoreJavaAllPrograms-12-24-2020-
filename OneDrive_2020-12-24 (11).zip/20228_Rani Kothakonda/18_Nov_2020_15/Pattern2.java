package programswithmtds;

import java.util.Scanner;

public class Pattern2 {
	public static String pattern(int start, int end) {
		 String str = "";
		 for( int i = end;i >= start;i--) {
			 for(int j = end;j >= start;j--) {
				 str += i +" ";
			 }
			 str += "\n";
		 }
		return str;
		 
	 }
	 public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter two numbers");
		System.out.println(pattern(sc.nextInt(),sc.nextInt()));
	}
	}

