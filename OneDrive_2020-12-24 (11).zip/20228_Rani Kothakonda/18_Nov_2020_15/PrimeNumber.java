package programswithmtds;

import java.util.Scanner;

public class PrimeNumber {
	static void primeRange(int num1, int num2) {
		for (int i = num1; i <= num2; i++) {
			isPrime(i);
		}
	}

	static boolean isPrime(int num) {
		boolean b = false;
		int count = 0;
		for (int i = 2; i <= num; i++) {
			if (num % i == 0) {
				count++;
			}
		}
		if (count == 1) {
			System.out.println(num + " is a Prime Number");
		}
		return b;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Start Value : ");
		int startValue = sc.nextInt();
		System.out.println("Enter End Value : ");
		int endValue = sc.nextInt();
		primeRange(startValue, endValue);

	}

}
