package programswithmtds;

import java.util.Scanner;

public class MultiplicationOnMatrices {
	public static void getMultiplication(int array[][], int array1[][], int rows, int columns) {
		int multiArray[][] = new int[rows][columns];
		for (int i = 0; i < rows; i++) {
			System.out.println("");
			for (int j = 0; j < columns; j++) {
				for (int k = 0; k < rows; k++) {
					multiArray[i][j] += array[i][k] * array1[k][j];
				}
			}
		}
		System.out.println("multiplication of two matrices");
		for (int i = 0; i < rows; i++) {
			System.out.println("");
			for (int j = 0; j < columns; j++) {
				System.out.print(multiArray[i][j] + " ");
			}
		}

	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter no of rows in 1st array");
		int rows = sc.nextInt();
		System.out.println("enter no of columns in 1st array");
		int columns = sc.nextInt();
		System.out.println("enter first array elements");
		int array[][] = new int[rows][columns];
		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array.length; j++) {
				array[i][j] = sc.nextInt();
			}
		}
		System.out.println("enter no of rows in 2nd array");
		int rows1 = sc.nextInt();
		System.out.println("enter no of columns in 2nd array");
		int columns1 = sc.nextInt();
		System.out.println("enter second array elements");
		int array1[][] = new int[rows1][columns1];
		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array.length; j++) {
				array1[i][j] = sc.nextInt();
			}
		}

		getMultiplication(array, array1, rows, columns);
	}
}
