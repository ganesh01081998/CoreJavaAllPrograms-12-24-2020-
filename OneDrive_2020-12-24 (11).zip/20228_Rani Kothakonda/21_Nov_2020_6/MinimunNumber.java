package programswithmtds;

import java.util.Scanner;

public class MinimunNumber {
	static int getMin(int[] array) {
		int min;
		if(array.length != 10) {
			min = -1;
		}
		else {
			min = array[0];
			for (int i = 0; i < array.length; i++) {
				if(array[i] < min) {
					min = array[i];
				}
			}
		}
		return min;
	}
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("enter size");
	int size = sc.nextInt();
	System.out.println("enter elements");
	int array[] = new int[size];
	for(int i = 0;i < array.length;i++) {
		array[i] = sc.nextInt();
	}
	System.out.println( "Minimum number is" +getMin(array));
}
}
