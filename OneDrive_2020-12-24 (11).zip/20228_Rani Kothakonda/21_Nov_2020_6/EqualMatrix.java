package programswithmtds;

import java.util.Scanner;

public class EqualMatrix {
	public static boolean getEquals(int array[][], int array1[][], int rows, int columns) {
		boolean b = false;
		for (int i = 0; i < rows; i++) {
			System.out.println("");
			for (int j = 0; j < columns; j++) {
				if (array[i][j] == array1[i][j]) {
					b = true;
				}
			}
		}
		return b;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter no of rows in  array");
		int rows = sc.nextInt();
		System.out.println("enter no of columns in  array");
		int columns = sc.nextInt();
		System.out.println("enter first array elements");
		int array[][] = new int[rows][columns];
		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array.length; j++) {
				array[i][j] = sc.nextInt();
			}
		}
		System.out.println("enter seond array elements");
		int array1[][] = new int[rows][columns];
		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array.length; j++) {
				array1[i][j] = sc.nextInt();
			}
		}
		System.out.println(getEquals(array, array1, rows, columns));
	}
}
