package programswithmtds;

import java.util.Scanner;

public class MaximumNumber {
	static int getMax(int[] arr) {
		int max;
		if(arr.length != 10) {
			max = -1;
		}
		else {
			max = arr[0];
			for (int i = 0; i < arr.length; i++) {
				if(arr[i] > max) {
					max = arr[i];
				}
			}
		}
		return max;
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Array Size");
		int size = sc.nextInt();
		int[] arr = new int[size];
		System.out.println("Enter Array Elements");
		for (int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		System.out.println("Max number is " + getMax(arr));
	}
}
