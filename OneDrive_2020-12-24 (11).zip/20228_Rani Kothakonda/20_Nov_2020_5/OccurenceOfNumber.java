package programswithmtds;

import java.util.Scanner;

public class OccurenceOfNumber {
	static int getOccurence(int array[], int num) {
		int count = 0;
		for (int i = 0; i < array.length; i++) {
			if (array[i] < 0) {
				int k = (array[i]) * -1;
				array[i] = k;
			}
			if (array[i] == num) {
				count++;
			}
		}
		return count;

	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter size");
		int size = sc.nextInt();
		System.out.println("enter elements");
		int array[] = new int[size];
		for (int i = 0; i < array.length; i++) {
			array[i] = sc.nextInt();
		}
		System.out.println("enter number");
		int num = sc.nextInt();
        System.out.println(getOccurence(array, num));
	}
}
