package programswithmtds;

import java.util.Scanner;

public class ArraySum {
	static String getSum(int sum[]) {
		int add = 0;
		String result = "";
		if (sum.length == 0) {
			result = result + "null";
		}
		for (int i = 0; i < sum.length; i++) {
			add = add + sum[i];
			result = "sum = " + add + " ";
		}
		return result;
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the array range");
		int range = scanner.nextInt();
		int sum[] = new int[range];
		for (int i = 0; i < sum.length; i++) {
			System.out.println("enter the array values");
			sum[i] = scanner.nextInt();
		}
		System.out.println(getSum(sum));
}
}
