package programswithmtds;

import java.util.Scanner;

public class FillMultiples {
	static String getMultiplesArray(int arr[]) {
		String res = "";
		for (int i = 0; i < arr.length; i++) {
			int k = arr[i];
			res += multi(k);
		}
		return res;
	}

	static String multi(int num) {
		String str = "";
		for (int i = 1; i <= 10; i++) {
			str += num + "*" + i + "=" + num * i + "\n";
		}
		return str;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter size");
		int size = sc.nextInt();
		System.out.println("enter the numbers");
		int array[] = new int[size];
		for (int i = 0; i < array.length; i++) {
			array[i] = sc.nextInt();
		}
		System.out.println(getMultiplesArray(array));
	}
}
