package programswithmtds;

import java.util.Scanner;

public class OddCounter {
	static int getOdd(int arr[]) {
		int count = 0;
		for (int i = 0; i < arr.length; i++) {
			if (isOdd(i)) {
				count++;
			}
		}
		return count;

	}

	static boolean isOdd(int num) {
		boolean b = false;
		if (num % 2 != 0) {
			b = true;
		}
		return b;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter size");
		int size = sc.nextInt();
		System.out.println("enter elements");
		int array[] = new int[size];
		for (int i = 0; i < array.length; i++) {
			array[i] = sc.nextInt();
		}
		System.out.println("odd values are " + getOdd(array));
	}
}
