package programswithmtds;

import java.util.Scanner;

public class SelectionSort1 {

	static void selSort(int size, int arr[]) {
		int k, min, temp;
		for (int i = 0; i <= size - 2; i++) {
			min = arr[i];
			k = i;
			for (int j = i + 1; j <= size - 1; j++) {
				if (arr[j] < min) {
					min = arr[j];
					k = j;
				}
			}
			temp = arr[i];
			arr[i] = arr[k];
			arr[k] = temp;
		}
	}

	static void isDisp(int arr[], int size) {
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}
	}

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter the array size");
		int size = scn.nextInt();
		System.out.println("enter the array elements:");
		int arr[] = new int[size];
		for (int i = 0; i < arr.length; i++) {
			arr[i] = scn.nextInt();
		}
		selSort(size, arr);
		isDisp(arr, size);

	}

}
