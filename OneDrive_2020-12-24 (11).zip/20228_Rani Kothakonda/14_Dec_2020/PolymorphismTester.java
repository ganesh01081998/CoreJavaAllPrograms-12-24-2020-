package Dec_14_2020;

import java.util.Scanner;

enum ShirtMaterial {
	Cotton, Linen, Polyester;
}

class Shirt {
	float collarSize;
	float length;
	public float getCollarSize() {
		return collarSize;
	}

	public void setCollarSize(float collarSize) {
		this.collarSize = collarSize;
	}

	public float getLength() {
		return length;
	}

	public void setLength(float length) {
		this.length = length;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(String material) {
		this.material = material;
	}

	public ShirtMaterial getS() {
		return s;
	}

	public void setS(ShirtMaterial s) {
		this.s = s;
	}

	String material;
	ShirtMaterial s;

	Shirt() {
		this.collarSize = 45;
		this.length = 0;
		this.material = "cotton";
		
	}

	public Shirt(float collarSize, float length, String material, ShirtMaterial s) {
		super();
		this.collarSize = collarSize;
		this.length = length;
		this.material = material;
		this.s = s;
	}

	@Override
	public String toString() {
		return "Shirt [collarSize=" + collarSize + ", length=" + length + ", material=" + material + ", s=" + s + "]";
	}
}
	public class PolymorphismTester {
		public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Shirt s = new Shirt();
		Shirt s1 = new Shirt(16.5f,42,"cotton",ShirtMaterial.Linen);
        System.out.println(s);
        System.out.println(s1);
	}
}
