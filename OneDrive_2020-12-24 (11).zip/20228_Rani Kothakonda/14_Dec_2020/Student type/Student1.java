package Dec_14_2020;

public class Student1 {
	int studentId;
	String name;
	double examFee;

	Student1() {

	}

	public Student1(int studentId, String name, double examFee) {
		this.studentId = studentId;
		this.name = name;
		this.examFee = examFee;
	}

	@Override
	public String toString() {
		return "Student1 [studentId=" + studentId + ", name=" + name + ", examFee=" + examFee + "]";
	}

	double payFee() {
		return examFee;

	}
}
