package Dec_14_2020;

public class Hosteller extends Student1 {
	double hostelFee;

	
	public Hosteller(double hostelFee, int studentId, String name, double examFee) {
		super(studentId, name, examFee);
		this.hostelFee = hostelFee;
	}
	
	@Override
	public String toString() {
		return "Hosteller [hostelFee=" + hostelFee + ", studentId=" + studentId + ", name=" + name + ", examFee="
				+ examFee + "]";
	}

	double payFee(int amount) {
		double fee = 0;
		double totalFee = examFee + hostelFee;
		System.out.println("Total amount is " +totalFee);
		if(totalFee == amount ) {
			System.out.println("thank you for paying");
		}
		else if(totalFee >= amount) {
			System.out.println("clear remaining amount");
			return fee = totalFee - amount;
		}
		else {
			System.out.println("receive remaining amount");
			return fee = totalFee - amount;
		}
		return totalFee;
	}
}
