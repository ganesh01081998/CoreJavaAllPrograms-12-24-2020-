package Dec_14_2020;

import java.util.Scanner;

public class Tester extends Student1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter studentId,name,examfee");
		Student1 s = new Student1(sc.nextInt(), sc.next(), sc.nextDouble());
		System.out.println(s);
		String res = "";
		res += "1.DayScholar\n";
		res += "2.Hosteller\n";
		System.out.println(res);
		System.out.println("enter student type");
		String str = sc.next();
		switch (str) {
		case "DayScholar":
			System.out.println("enter transportfee,student id,name,examfee");
			Dayscholar d = new Dayscholar(sc.nextDouble(), sc.nextInt(), sc.next(), sc.nextDouble());
			System.out.println(d);
			System.out.println("enter how much do you want to pay?");
			System.out.println(d.payFee(sc.nextInt()));
			break;
		case "Hosteller":
			System.out.println("enter hostelfee,student id , name,examfee");
			Hosteller h = new Hosteller(sc.nextDouble(), sc.nextInt(), sc.next(), sc.nextDouble());
			System.out.println(h);
			System.out.println("enter how much do you want to pay?");
			System.out.println(h.payFee(sc.nextInt()));
			break;
		default:
			System.out.println("enter vaild student type");

		}
	}
}
