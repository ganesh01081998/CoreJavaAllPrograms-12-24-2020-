package Dec_14_2020;

public class Dayscholar extends Student1 {
	double trasportFee;

	public Dayscholar(double trasportFee, int studentId, String name, double examFee) {
		super(studentId, name, examFee);
		this.trasportFee = trasportFee;
	}

	@Override
	public String toString() {
		return "Dayscholar [trasportFee=" + trasportFee + ", studentId=" + studentId + ", name=" + name + ", examFee="
				+ examFee + "]";
	}

	double payFee(int amount) {
		double fee = 0;
		double totalFee = examFee + trasportFee;
		System.out.println("Total amount is " + totalFee);
		if (totalFee == amount) {
			System.out.println("thank you for paying");
		} else if (totalFee >= amount) {
			System.out.println("clear remaining amount");
			return fee = totalFee - amount;
		} else {
			System.out.println("receive remaining amount");
			return fee = totalFee - amount;
		}
		return totalFee;
	}
}
