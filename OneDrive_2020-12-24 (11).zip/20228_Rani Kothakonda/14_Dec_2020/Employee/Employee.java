package Dec_14_2020;

public class Employee {
	String name;
	int Employeeid;
	double salary;

	Employee() {

	}

	public Employee(String name, int employeeid, double salary) {
		super();
		this.name = name;
		Employeeid = employeeid;
		this.salary = salary;
	}

	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		return "Employee [name=" + name + ", Employeeid=" + Employeeid + ", salary=" + salary + "]";
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getEmployeeid() {
		return Employeeid;
	}

	public void setEmployeeid(int employeeid) {
		Employeeid = employeeid;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

}
