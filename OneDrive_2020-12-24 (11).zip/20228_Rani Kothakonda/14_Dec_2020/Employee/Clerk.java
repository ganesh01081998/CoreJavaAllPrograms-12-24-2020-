package Dec_14_2020;

public class Clerk extends Employee {

	int speed;
	int accuracy;

	public Clerk(String empName, int empId, double salary, int speed, int accuracy) {
		super(empName, empId, salary);
		this.speed = speed;
		this.accuracy = accuracy;
	}

	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
	}

	public int getAccuracy() {
		return accuracy;
	}

	public void setAccuracy(int accuracy) {
		this.accuracy = accuracy;
	}

	double setSalary() {
		salary = salary;
		if (speed > 70 && accuracy > 80) {
			salary += 1000;
		}
		return salary;
	}

	@Override
	public String toString() {
		return "Clerk [speed=" + speed + ", accuracy=" + accuracy + ", name=" + name + ", Employeeid=" + Employeeid
				+ ", salary=" + salary + "]";
	}

}
