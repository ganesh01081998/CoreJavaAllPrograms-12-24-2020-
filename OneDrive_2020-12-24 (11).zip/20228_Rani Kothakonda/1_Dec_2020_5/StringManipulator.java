package programswithmtds;

import java.util.Scanner;

public class StringManipulator {
	static String removeVowels(String name) {
		if(name.equals("")){
			return "null";
		}
		String str = "";
		for (int i = 0; i < name.length(); i++) {
			char ch = name.charAt(i);
			if (ch != 'a' && ch != 'e' && ch != 'i' && ch != 'o' && ch != 'u' && ch != ' ') {
				str += ch;
			}
		}
		return str;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter any name?");
		String name = sc.nextLine();
		System.out.println(removeVowels(name.toLowerCase()));
	}
}
