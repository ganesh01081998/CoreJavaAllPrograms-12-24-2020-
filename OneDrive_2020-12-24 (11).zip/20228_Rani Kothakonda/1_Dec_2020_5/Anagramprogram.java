package com.ojas.sample1;

import java.util.Arrays;
import java.util.Scanner;

public class Anagramprogram {
	static String checkAnagram(String word1, String word2) {
		String res = "";
		if (word1.length() == word2.length()) {
			char c1[] = word1.toCharArray();
			char c2[] = word2.toCharArray();
			Sorting(c1);
			Sorting(c2);
			Boolean status = Arrays.equals(c1, c2);
			if (true) {
				res += "anagram";
			}
		}
		else {
				res += "not anagram";
			}
		
		return res;

	}

	public static void Sorting(char[] c1) {
		for (char ch = 'a'; ch < 'z'; ch++) {
			for (int i = 0; i < c1.length; i++) {
				int ch1 = c1.length;
				if (ch == ch1) {
					System.out.println(ch);
				}
			}
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter two words");
		String word1 = sc.next();
		String word2 = sc.next();
		System.out.println(checkAnagram(word1.toLowerCase(), word2.toLowerCase()));
		
	}
}
