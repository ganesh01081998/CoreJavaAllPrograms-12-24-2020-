package programswithmtds;

import java.util.Scanner;

public class DateFormater {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter date");
		System.out.println(format(sc.nextLine()));
	}

	static String format(String str) {

		String result = "";
		if (str.length() > 17 || str.equals("")) {
			return "null";
		}
		str = str.replaceAll(",", "-");
		str = str.replaceAll(" ", "-");
		String date[] = str.split("-");
		String month = date[1];
		String month1 = getMonthDays(month);
		for (int i = 2; i >= 0; i--) {
			if (i == 1) {
				result += "-" + month1 + "-";
			} else {
				result += date[i];
			}
		}
		return result;
	}

	static String getMonthDays(String str) {
		String result = "";
		if (str.length() <= 3) {
			String[] monthNames = { "month", "jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct",
					"nov", "dec" };
			for (int i = 0; i < monthNames.length; i++) {
				if (str.equals(monthNames[i])) {
					result += i;
				}
			}
		} else {
			String[] monthNames = { "month", "january", "february", "march", "april", "may", "june", "july", "august",
					"september", "october", "november", "december" };
			for (int i = 0; i < monthNames.length; i++) {
				if (str.equals(monthNames[i])) {
					result += i;
				}
			}
		}
		return result;
	}
}
