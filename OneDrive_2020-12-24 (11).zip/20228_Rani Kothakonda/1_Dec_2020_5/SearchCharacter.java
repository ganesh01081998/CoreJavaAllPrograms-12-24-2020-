package programswithmtds;

import java.util.Scanner;

public class SearchCharacter {
	static int charCount(String name, char ch) {
		int res = -1;
		int count = 0;
		for (int i = 0; i < name.length(); i++) {
			char ch1 = name.charAt(i);
			
			if (ch1 == ch) {
				count++;
			}
		}
		if (count > 0) {
			return count;
		}
		return res;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the string");
		String name = sc.next();
		System.out.println("enter the character");
		char ch = sc.next().charAt(0);
		System.out.println(charCount(name.toLowerCase(), ch));
	}
}