package programswithmtds;

import java.util.Scanner;

public class AbsoluteDifference {
	static int isDifference(int num) {
		int temp = 21;
		if(num <= temp) {
			num = temp - num;	
		}
		else if(num > temp) {
			num = (num - temp) * 2;
		}
		else if(num < 0) {
			num = num * -1;
			num += temp;
		}
		return num;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any Number :");
		int num = sc.nextInt();
		System.out.println(isDifference(num));

	}
}

