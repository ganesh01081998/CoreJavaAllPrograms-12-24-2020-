package programswithmtds;

import java.util.Scanner;

public class ArmStrongNDigits {
	static String isArmStrong(int num) {
		int count = digitCount(num);
		int temp = 0, copy = num;
		int sum = 0;
		while (num > 0) {
			temp = num % 10;
			sum += power(temp, count);
			num = num / 10;
		}
		if (sum == copy) {
			return " is an armstrong number";
		} else {
			return " is not an armstrong number";
		}

	}

	static int digitCount(int num) {
		int count = 0;
		while (num != 0) {
			count++;
			num /= 10;
		}
		return count;
	}

	public static int power(int basenum, int powernum) {
		int res = 1;
		for (int i = 1; i <= powernum; i++) {
			res *= basenum;
		}
		return res;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter number");
		System.out.println(isArmStrong(sc.nextInt()));
	}
}
