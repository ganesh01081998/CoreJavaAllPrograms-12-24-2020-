package programswithmtds;

import java.util.Scanner;

public class Student {
	public int studentId;
	public String studentName;
	private int marks;
	private char grade;

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("enter the student  ID & Name & Marks  ");
		Student s = new Student(scn.nextInt(),scn.next(),scn.nextInt());
		System.out.println(s.dispDetails());
	}
	public Student(int studentId, String studentName, int marks) {
		this.studentId = studentId;
		this.studentName = studentName;
		this.marks = marks;
		calcGrade(marks);
	}
	public String dispDetails() {
		String result ="";
		result = "student [ name  = " + studentName + " ,"+ "Student id = " + studentId +" , " + "marks = " + marks +  " , " + " grade  =  " + grade + " ]";
		return result;
	}
	private void calcGrade(int marks) {

		if(marks > 90) {
			this.grade = 'A';
		}
		else if(marks >= 80 && marks <= 90 ) {
			this.grade = 'B';
		}
		else if(marks >= 70 && marks <= 80) {
			this.grade ='C';
		}
		else if(marks >= 60 && marks <= 70)  {
			this.grade = 'D';
		}
		else if(marks < 60) {
			this.grade ='E';
		}
	}

}

