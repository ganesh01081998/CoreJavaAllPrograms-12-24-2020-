package programswithmtds;

import java.util.Scanner;

public class WeavedString {
	static String getWeavedString(String str1, String str2) {
		String res = "";
		int value1 = str1.length();
		int value2 = str2.length();
		 if (value1 > value2) {
			res += str2 + str1 + str2;
			
		} else if (value1 < value2) {
			res += str1 + str2 + str1;
		
		} else if (value1 == value2) {
			for (int i = 0; i < str1.length(); i++) {
				for (int j = 0; j < str2.length(); j++) {
					if (str1.charAt(i) == str2.charAt(j)) {
					 res += str1.charAt(i) + "" + str2.charAt(j);
				
					}
				}

			}
		
		}
		return res;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter String1");
		String str1 = sc.next();
		System.out.println("enter String2");
		String str2 = sc.next();
		System.out.println(getWeavedString(str1, str2));
	}
}
