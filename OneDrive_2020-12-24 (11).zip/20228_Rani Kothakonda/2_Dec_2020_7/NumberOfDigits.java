package programswithmtds;

import java.util.Scanner;

public class NumberOfDigits {
	static int getCount(int arr[], int num) {
		int count = 0;
		for (int i = 0; i < arr.length; i++) {
			if(arr[i] == num) {
				count++;
			}
			}
		return count;	
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter size");
		int size = sc.nextInt();
		System.out.println("enter array elments");
		int array[] = new int[size];
		for (int i = 0; i < array.length; i++) {
			array[i] = sc.nextInt();
		}
		System.out.println("enter search number");
		int num = sc.nextInt();
		System.out.println("number of times " + num + " exists in array is " + getCount(array, num));
	}
	}


