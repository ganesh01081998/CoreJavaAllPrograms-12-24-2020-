package programswithmtds;

import java.util.Scanner;

public class SumOfDiagonalElements {
	static int getDiagonalSum(int array[][]) {
		int sum = 0;
		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array.length; j++) {
				if (array[i] == array[j]) {
					sum = sum + array[i][j];
				}
			}

		}
		return sum;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter no of rows in array");
		int rows = sc.nextInt();
		System.out.println("enter no of columns in array");
		int columns = sc.nextInt();
		if(rows != 3 && columns != 3) {
			System.out.println(-1);
			}
		else{
		System.out.println("enter array elements");
		int array[][] = new int[rows][columns];
		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array.length; j++) {
				array[i][j] = sc.nextInt();
			}
		}
		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array.length; j++) {
				System.out.print(array[i][j] + " ");
			}
			System.out.println();
		}
		System.out.println("sum ofdiagnoal elements" + getDiagonalSum(array));
	}
}
}