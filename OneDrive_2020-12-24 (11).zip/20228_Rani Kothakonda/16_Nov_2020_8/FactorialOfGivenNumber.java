package ojas.org.com;

import java.util.Scanner;

public class FactorialOfGivenNumber {
 static void factorial(int num) {
	 int fact = 1;
	 while(num >= 1) {
		 fact = fact * num;
		 num--;
	 }
	 System.out.println("factorial of given number is " + fact);
 }
 public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("enter number");
	factorial(sc.nextInt());
}
}
