package programswithmtds;

import java.util.Scanner;

public class EvenNumbersRange {
	static String evenRange(int startNum, int endNum) {
		String range = "";
		for (int i = startNum; i <= endNum; i ++) {
			if (i % 2 == 0) {
				range += i + "\n";
			}
		}
		return range;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the range");
		System.out.println(evenRange(sc.nextInt(), sc.nextInt()));
	}
}
