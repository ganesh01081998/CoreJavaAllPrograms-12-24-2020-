package ojas.org.com;

import java.util.Scanner;

public class FizzBizz {
	static String getOutPutString(int num) {
		String res = " ";
		if (num > 0) {
			if (num % 3 == 0 && num % 5 != 0) {
				res = "fizz";
			} else if (num % 5 == 0 && num % 3 != 0) {
				res = "bizz";
			} else if (num % 5 == 0 && num % 3 == 0) {
				res = "fizzbizz";
			} else {
				res += num;
			}
		} else {
			return "error";
		}
		return res;
	}

	public static void main(String[] args) {
		while (true) {
			Scanner sc = new Scanner(System.in);
			System.out.println("enter the number");
			String res = " ";
			res = getOutPutString(sc.nextInt());
			System.out.println(res);

		}
	}
}
