package ojas.org.com;

import java.util.Scanner;

public class PrimeNumber {
 static void prime(int num) {
	 int i = 2, count = 0;
	 while(i < num / 2) {
		 if(num % i == 0) {
			count++;
			break;
		 }
		 i++;
	 }
		 if(count == 0) {
			 System.out.println(num + " is a prime number"  );
	 }
		 else {
			 System.out.println("not prime number");
		 }
 }
 public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("enter number");
	prime(sc.nextInt());
}
}
