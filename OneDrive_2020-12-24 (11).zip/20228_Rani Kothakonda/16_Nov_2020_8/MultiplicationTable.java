package ojas.org.com;

import java.util.Scanner;

public class MultiplicationTable {
	static void multi(int num) {
		for (int i = 1; i <= 10; i++) {
			System.out.println(num + "*" + i + "=" + num * i);
		}
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter number");
		multi(scanner.nextInt());
	}
}
