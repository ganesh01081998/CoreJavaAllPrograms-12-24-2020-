package programswithmtds;

import java.util.Scanner;

public class ArmstrongNum {
	static String armStrong(int num) {
		String res = "";
		int temp = 0, num1 = num;
		int arm = 0;
		while (num > 0) {
			temp = num % 10;
			arm = arm + (temp * temp * temp);
			num = num / 10;
		}
		res += arm;
		if (arm == num1) {
			return res + " is armstrong number";
		} 
		else {
			return res + " is not armstrong number";
		}
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter number");
		System.out.println(armStrong(scanner.nextInt()));
	}
}
