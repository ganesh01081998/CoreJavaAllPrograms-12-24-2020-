package _14_12_2020;

public class Clerk extends Employee{
	int speed;
	int accuracy;

	public Clerk(String empName, int empId, double salary, int speed, int accuracy) {
		super(empName, empId, salary);
		this.speed = speed;
		this.accuracy = accuracy;
	}
	double setSalary() {
		salary = salary;
		if(speed > 70 && accuracy > 80 ) {
			salary += 1000;
		}
		return salary;
	}
	@Override
	public String toString() {
		return "Clerk [speed=" + speed + ", accuracy=" + accuracy + ", empName=" + empName + ", empId=" + empId
				+ ", salary=" + salary + "]";
	}
	
}
