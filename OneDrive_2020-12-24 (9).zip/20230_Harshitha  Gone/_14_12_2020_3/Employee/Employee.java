package _14_12_2020;

public class Employee {
	String empName;
	int empId;
	double  salary;
	public Employee(String empName, int empId, double salary) {
		this.empName = empName;
		this.empId = empId;
		this.salary = salary;
	}

}
