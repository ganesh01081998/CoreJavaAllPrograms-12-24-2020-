package _14_12_2020;

import java.util.Scanner;

public class MainMethodOfEmployee {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter emp name,emp id, salary");
		Manager m = new Manager(sc.next(),sc.nextInt(),sc.nextDouble(),ManagerType.HR);
		System.out.println("enter type of role");
		System.out.println("total salary is "+ m.setSalary(sc.next()));
		System.out.println(m);
		System.out.println("enter name,id,sal,speed and acccuracy ");
		Clerk c = new Clerk(sc.next(),sc.nextInt(),sc.nextDouble(),sc.nextInt(),sc.nextInt());
		System.out.println("total salary of clerk is"+c.setSalary());
		System.out.println(c);
		
	}
}
