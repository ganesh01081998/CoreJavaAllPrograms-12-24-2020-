package ojas.org.com;

import java.util.Scanner;

public class LcmOfTwoNumbersWithMtds {
static int check(int num1 , int num2) {
	int lcm=0;
	if(num1 > num2) {
		lcm = num1;
	}
	else{
		lcm = num2;
	}
	return lcm;
}  
static void lcm() {
	Scanner scanner = new Scanner(System.in);
	System.out.println("enter two numbers");
	int num1 = scanner.nextInt();
	int num2 = scanner.nextInt();
	int k = check(num1,num2);
	while(true) {
	  if(k % num1 == 0 && k % num2 == 0) {
			System.out.println("lcm of "+ num1+ " and " + num2+ " = "+k);
			break;
		}
		k++;
	}
}
public static void main(String[] args) {
	lcm();
	
	
}
}
