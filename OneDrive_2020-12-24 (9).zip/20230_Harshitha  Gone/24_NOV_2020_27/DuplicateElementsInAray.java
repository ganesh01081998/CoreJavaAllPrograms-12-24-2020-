package ojas.array.com;

import java.util.Scanner;

public class DuplicateElementsInAray {
public static String getDuplicates(int arr[]) {
	String str = "";	
	for (int i = 0; i < arr.length; i++) {
		for (int j = i+1; j < arr.length; j++) {
			if(arr[i] == arr[j]) {
				str += arr[i]+",";			
			}
		}		
	}
	String str2 = str.substring(0,arr.length-1);
	return str2;	
}
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("enter size");
	int size = scanner.nextInt();
	System.out.println("enter elements");
	int arr[] = new int[size];
	for(int i = 0; i < arr.length; i++) {
		arr[i] = scanner.nextInt();
	}
	System.out.println(getDuplicates(arr));
}
}
