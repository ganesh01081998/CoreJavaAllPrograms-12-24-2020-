package ojas.strings.com;

import java.util.Scanner;

public class SumOfEvenNumbersInArray {
public static int getSumOfEvenNumbers(int arr[]) {
	if(arr.length == 0) {
		return -3;
	}
	int sum = 0;
	for (int i = 0; i < arr.length; i++) {
		if(arr[i] <= 0) {
			return -1;
		}
		else if(arr[i] % 2 == 0) {
			sum += arr[i];
		}
	}
	return sum;
	
}
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("enter size");
	int size = scanner.nextInt();
	System.out.println("enter elements");
	int arr[] = new int[size];
	for (int i = 0; i < arr.length; i++) {
		arr[i] = scanner.nextInt();
	}
	System.out.println(getSumOfEvenNumbers(arr));
}
}
