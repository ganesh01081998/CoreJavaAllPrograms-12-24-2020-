package ojas.strings.com;

import java.util.Scanner;

public class ConcateTheSumOfDigitsInDecimal {
public static String concateSumOfDigits(double num) {
	String str = "";
	String left = "";
	String right = "";
	char ch = 0;
	int i = 0;
	String s = Double.toString(num);
	String arr[] = s.split("[.]");
	left = arr[0];
	right = arr[1];
	int num1 = Integer.parseInt(left);
	int num2 = Integer.parseInt(right);
	int sum = getSumOfDigits(num1);
	int sum1 = getSumOfDigits(num2);
	str += sum +":" +sum1;
	return str;
}
public static int getSumOfDigits(int num) {
	int tem = 0;
	int sum = 0;
	while(num > 0) {
		tem = num % 10;
		sum = sum + tem;
		num = num / 10;		
	}
	return sum;	
}
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("enter double value");
	double num = scanner.nextDouble();
	System.out.println(concateSumOfDigits(num));
}
 }
