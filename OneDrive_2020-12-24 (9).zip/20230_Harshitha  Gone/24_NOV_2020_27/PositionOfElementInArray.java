package ojas.strings.com;

import java.util.Scanner;

public class PositionOfElementInArray {
public static int getElemntPosition(int arr[] ,int searchNum) {
	if(arr.length == 0) {
		return -2;
	}
	else if(searchNum <= 0) {
		return -3;
	}
	for (int i = 0; i < arr.length; i++) {
		if(arr[i] <= 0) {
			return -1;
		}
		if(arr[i] == searchNum) {
				return i;
			}
		}
	return -1;
	}	
	public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("enter size");
	int size = scanner.nextInt();
	System.out.println("enter elements");
	int arr[] = new int[size];
	for (int i = 0; i < arr.length; i++) {
		arr[i] = scanner.nextInt();		
	}
	System.out.println("enetr search element");
	int searchEle = scanner.nextInt();
	System.out.println( getElemntPosition(arr, searchEle));
	}
	
}
