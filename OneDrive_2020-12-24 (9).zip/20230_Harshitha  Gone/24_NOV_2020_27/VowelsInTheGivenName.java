package ojas.strings.com;

import java.util.Scanner;

public class VowelsInTheGivenName {
public static String getVowels(String str) {
	String str1 = "";
	for(int i = 0;i < str.length();i++) {
		char ch = str.charAt(i);
		if(ch == 'a' ||ch == 'e' ||ch == 'i'||ch == 'o'||ch == 'u') {
			str1 += ch + ",";
		}
	}
	
	return str1.substring(0,str1.length()-1);
}
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("enter string");
	String str = scanner.nextLine();
	System.out.println("vowels in the given String is : " + getVowels(str));
}
}
