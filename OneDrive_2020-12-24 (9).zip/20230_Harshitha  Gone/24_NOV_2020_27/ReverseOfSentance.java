package ojas.strings.com;

import java.util.Scanner;

public class ReverseOfSentance {
 public static void getRevSentence(String str[]) {
	 String str1 = reverse(str[0]) + " ";
	 for(int i = 1;i < str.length; i++) {
		 str1 += reverse(str[i]);
	 }
		System.out.println(str1.trim());	 
 }	
	public static String reverse(String str) {
		String str1 = " ";
		for(int i = str.length() - 1; i >= 0; i--) {
			char ch = str.charAt(i);
			str1 += ch;
		}
		return str1;
	}	
	public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("enter sentence");
	String str = scanner.nextLine();
	String s[] = str.split(" ");
	
	getRevSentence(s);
}
}
