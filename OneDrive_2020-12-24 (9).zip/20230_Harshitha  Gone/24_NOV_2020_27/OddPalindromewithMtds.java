package ojas.org.com;

import java.util.Scanner;

public class OddPalindromewithMtds {
static boolean odd(int num) {
	boolean b = false;
	if(num % 2 != 0) {
		b = true;
	}
	return b;
}
static boolean palindrome(int num) {
	boolean f = false;
	int reverse = 0,temp = 0, tempNum = num;
	while(num > 0) {
		temp = num % 10;
		reverse = reverse * 10 + temp;
		num = num / 10;
		
	}
	if(tempNum == reverse) {
		f = true;
	}
	return f;
	}
static void range() {
  
	for(int i = 100;i <= 500 ; i++) {
		if(odd(i) && palindrome(i)) {
			System.out.println(i);
		}
	}

}
public static void main(String[] args) {
	System.out.println("odd palindromes are");
	range();
}
}






