package ojas.strings.com;

import java.util.Scanner;

public class OccureneceOfEachChar {
	public static void getCountChar(String str) {
		int count = 0;
		int j = 0;
		char[] ch = str.toCharArray();
		for(int i = 0; i < str.length(); i++) {
			
				if(ch[0] == ch[i]&&((ch[i]>=65&&ch[i]<=91)||(ch[i]>=97&&ch[i]<=123))) {
					count++;
					
				}
			
			if(count != 0){
				System.out.println("number of "+ ch[0] + "are "+count); ;
			}
			else {
				System.out.println("not same");
			}
		}
		}
		
	
	
	
	
	public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("enter a string!");
	String str = scanner.next();
	getCountChar(str);
	
	}
} 

