package ojas.org.com;

import java.util.Scanner;

public class RverseStringWithMethods {
static String reverse(String s1) {
	String s2 = "" ;
	for(int i = s1.length()-1;i >= 0; i--) {
		char ch = s1.charAt(i);
		s2 += ch;
	}
	return s2;
}
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("enter string");
	String res = reverse(scanner.next());
	System.out.println(res);
}
}
