package ojas.array.com;

import java.util.Scanner;

public class AdamNumber {
public static boolean isAdamNumber(int number) {
	boolean b = false;
	int square = number *number;
	int square1 = getReverse(number);
	int square3 = square1 * square1;
	if(square == getReverse(square3)) {
		b = true;
	}
	return b;
}
public static int getReverse(int num) {
	int rev = 0;
	int temp = 0;
	while(num > 0) {
		temp = num % 10;
		rev = rev * 10 + temp;
		num = num / 10;
	}
	return rev;
}
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("enter number");
	int num = scanner.nextInt();
	getReverse(num);
	System.out.println("number is adam number" + isAdamNumber(num));
	
}
}
