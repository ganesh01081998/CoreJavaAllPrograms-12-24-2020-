package ojas.strings.com;

import java.util.Scanner;

public class FindMaxInArray {
public static int findMax(int arr[]) {
	if(arr.length == 0) {
		return 0;
	}
	int big = arr[0];
	int count = 0;
	for (int i = 0; i < arr.length; i++) {
		if(isNegative(arr[i]))  {
			count++;
		}
	}
	if(count == 3) {		
	for (int i = 1; i < arr.length; i++)
		if(arr[i] > big) {
			big = arr[i];
		}
	}
	else {
		return -1;
	}
	return big;	
}
public static boolean isNegative(int num) {
	boolean b = false;
	if(num < 0) {
		b = true;
	}
	return b;
}
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("enter size");
	int size = scanner.nextInt();	
	int arr[] = new int[size];
	System.out.println("enter elements");
	for (int i = 0; i < arr.length; i++) {
		arr[i] = scanner.nextInt();
	}
	System.out.println("bigest num " + findMax(arr));
}
}
