package ojas.strings.com;

import java.util.Scanner;

public class SortElmentsInArray {
public static int [] sortArrayElements(int arr[]) {
	 int array[] = new int[arr.length];
	 int i = 0;
     for ( i = 0; i < arr.length; i++) {
         for (int j = i + 1; j < arr.length; j++) {
             if (arr[i] > arr[j]) {
                 int temp = arr[i];
                 arr[i] = arr[j];
                 arr[j] = temp;
             }
             
         }
         array[i] = arr[i];
     }
     for (int j = 0; j < array.length; j++) {
		System.out.println(array[j]);
	}

     return array;
 }
public static void display(int arr[]) {
	for (int i = 0; i < arr.length; i++) {
		System.out.println(arr[i]);
	}
}
 public static void main(String[] args) {
     Scanner scanner = new Scanner(System.in);
     System.out.println("enter size");
     int size = scanner.nextInt();
     System.out.println("enter elements");
     int array[] = new int[size];
     for (int i = 0; i < array.length; i++) {
         array[i] = scanner.nextInt();
     }
     sortArrayElements(array);
}
}
