package org.ojas.com;

import java.util.Scanner;

public class PerfectNumber {
public static int getSumOfProperDivisors(int num) {
	if(num < 0) {
		return 2;
	}
	else if(num == 0) 
	{
		return -3;
	}
	int sum = 0;
	for (int i = 1; i < num; i++) {
		if(num % i == 0) {
			sum = sum + i;
		}
	}
	System.out.println(sum);
	if(sum == num) {
		return 0;
	}
	else if(sum > num) {
		return 1;
	}
		return -1;
	
}
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("enter number");
	int num = scanner.nextInt();
	System.out.println(getSumOfProperDivisors(num));
}
}