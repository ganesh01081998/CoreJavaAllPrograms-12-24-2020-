package ojas.org.com;

public class TwinPrimeNumbers {
	
public static void main(String[] args) {
	int i =0;
	for( i = 2;i <= 100;i++) {
		int count = 0;
		for(int j = 1;j <= i; j++) {
			if(i % j == 0) {
				count ++ ;
			}
		}
			if (count == 2) {
				System.out.println(i);
				}
	}
				for(int k = 2;k <= i;k++) {
					for(int x = k + 1;x <= k; x++) {
						if(x - k == 2) {
							System.out.println(x +","+ k);
						}
					}
				}
			
		}
	}


