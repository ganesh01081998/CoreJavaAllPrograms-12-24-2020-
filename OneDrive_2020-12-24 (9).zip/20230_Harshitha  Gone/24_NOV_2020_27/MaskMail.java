package ojas.array.com;

import java.util.Scanner;

public class MaskMail {
	static String res = "";
public static void getMask(String email) {
	for(int i = 2 ; i < email.length(); i++) {
		char ch = email.charAt(i);
		if(ch == '@') {
			doThis(i , email);
			break;
		}
		res += 'X';
	}	
}
static void doThis(int i , String email) {
	for(int j = i; j < email.length() ; j++) {
		res += email.charAt(j);
	}
}
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("enter email id");
	String email = scanner.next();
	res += "" + email.charAt(0) + email.charAt(1);
	getMask(email);
	
	System.out.println(res);
}
}
