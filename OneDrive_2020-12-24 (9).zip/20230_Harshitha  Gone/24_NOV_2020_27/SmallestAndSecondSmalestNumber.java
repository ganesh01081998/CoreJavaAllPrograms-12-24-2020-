package org.ojas.com;

import java.util.Scanner;

public class SmallestAndSecondSmalestNumber {
public static int getSmalest(int arr[]) {
	int small = 0;
	int arr1[] = sorting(arr);
	 small = arr1[arr1.length - 1];
	 return small;
}
public static int getSecongSmalest(int arr[]) {
	int secSmal = 0;
	int arr1[] = sorting(arr);
	secSmal = arr1[arr1.length - 2];
	return secSmal;
}
public static int[] sorting(int arr[]) {
	int arr1[] = new int[arr.length];
	for (int i = 0; i < arr.length; i++) {
		for (int j = i + 1; j < arr.length; j++) {
			if(arr[i] < arr[j]) {
				int temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
			}
			arr1[i] = arr[i];
		}
		System.out.println(arr[i]);
	}
	return arr1;			
}
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("enter size");
	int size = scanner.nextInt();
	System.out.println("enter elemnts");
	int arr[] = new int[size];
	for (int i = 0; i < arr.length; i++) {
		arr[i] = scanner.nextInt();
		}
//	System.out.println(sorting(arr));
	System.out.println("smalest number" + getSmalest(arr));
	System.out.println("second smallest"+getSecongSmalest(arr));
}
}
