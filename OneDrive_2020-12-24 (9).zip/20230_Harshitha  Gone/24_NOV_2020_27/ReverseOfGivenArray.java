package ojas.strings.com;

import java.util.Scanner;

public class ReverseOfGivenArray {
	public static int [] reverseArray(int array[]) {
		int ar[] = new int[array.length];
		int j = 0;
		for(int i = array.length - 1; i >= 0; i--) {
			ar[j] = array[i];
			j++;
		}

		return ar;	
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter elments");
		int size = scanner.nextInt();
		System.out.println("enter elements");
		int arr[] = new int[size];
		for (int i = 0; i < arr.length; i++) {
			arr[i] = scanner.nextInt();
		}
		int res[] = reverseArray(arr);
		for (int i = 0; i < res.length; i++) {
			System.out.println(res[i]);
		}
	}
}
