package ojas.strings.com;

public class Immutable {
public static void main(String[] args) {
	String str = "hello" ;//we can concate two strings
	str += "harshitha";
	System.out.println(str);
	String str1 = "1,4-6-10";//but we can not modify the string itself
	String str2=str1.replace(",", "-");
	System.out.println(str2);
}
}
