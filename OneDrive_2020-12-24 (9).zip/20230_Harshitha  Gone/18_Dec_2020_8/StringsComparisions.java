package _18_12_2020;

import java.util.Scanner;

public class StringsComparisions {
   public static int sumOfLengths(String s1,String s2) {
	   int sum = 0;
	   int len1 = s1.length();
	   int len2 = s2.length();
	   return sum = len1 + len2;
   }
public static String getStrs(String s1,String s2) {
	String str = "";
	int len1 = s1.length();
	   int len2 = s2.length();
	   if(len1 > len2) {
		   str += "no";
	   }
	   else {
		   str += "yes";
	   }
	return str;	
}
public static String changeAplbt(String s1,String s2) {
	String name = change(s1);
	String name2 = change(s2);
	return name + " " + name2;
	
}	
static String change(String s1) {
	String str = "";
	String firstL = s1.substring(0,1);
	String rem = s1.substring(1,s1.length());
	firstL = firstL.toUpperCase();
	str += firstL + rem;
	return str;
}
	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("enter two strings");
	System.out.println(sumOfLengths(sc.next(),sc.next()) );
	System.out.println("enter two strings");
	System.out.println(getStrs(sc.next(),sc.next()));
	System.out.println("enter two strings");
	System.out.println(changeAplbt(sc.next(),sc.next()));
}
}
