package _18_12_2020;

public class COJ_42_Soccer extends COJ_42_Sports {
	String getName(String s1) {
		return super.s1 = s1;
	}
	String getNumberOfTeamMembers() {
		return "in " + super.getName(super.s1) + "each team has 11 players"; 
	}
}
