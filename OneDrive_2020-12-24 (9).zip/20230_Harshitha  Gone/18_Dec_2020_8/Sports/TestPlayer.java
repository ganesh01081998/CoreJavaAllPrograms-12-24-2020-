package _18_12_2020;

import java.util.Scanner;

public class TestPlayer {
public static void main(String[] args) {
	System.out.println("enter sports name");
	Scanner sc = new Scanner(System.in);
	COJ_42_Soccer s = new COJ_42_Soccer();
	s.getName(sc.next());
	System.out.println(s.getNumberOfTeamMembers());
}
}
