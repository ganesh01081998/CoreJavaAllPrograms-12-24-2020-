package _18_12_2020;

public class COJ_42_Sports {
	String s1;
	String getName(String s1) {
		return s1;
	}
	String getNumberOfTeamMembers() {
		return "each team has 11 players";
	}
}
