package _18_12_2020;

public class Cylender extends Circle{
	double height;

	double volume;

	public Cylender() {

	}

	public Cylender(double radius,double height) {
		super(radius);
		this.height = height;
	}

	public double getVolume() {
		if(height < 0) {
			volume = -1;
		}
		else {
			volume = 3.14 * (radius * radius * height);
		}
		
		return volume;
	}
}
