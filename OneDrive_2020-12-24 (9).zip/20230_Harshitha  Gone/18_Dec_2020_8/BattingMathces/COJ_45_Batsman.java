package _18_12_2020;

public class COJ_45_Batsman {
	String pName;
	int runs;
	int matches;
	float batting_avg;
	public COJ_45_Batsman() {
		super();
		this.pName = null;
		this.runs = 0;
		this.matches = 0;
		this.batting_avg = 0;
	}
	public COJ_45_Batsman(String pName, int runs, int matches, float batting_avg) {
		super();
		this.pName = pName;
		this.runs = runs;
		this.matches = matches;
		this.batting_avg = batting_avg;
	}
	public void computeBattingAverage() {
		batting_avg = runs / matches;
		System.out.println("batting average " + batting_avg);
		if(runs > 0) {
			System.err.println("error");
		}
		else if(runs < 0 && matches == 0) {
			System.err.println("error");
		}

	}
	@Override
	public String toString() {
		return "COJ_45_Batsman [pName=" + pName + ", runs=" + runs + ", matches=" + matches + ", batting_avg=" + batting_avg
				+ "]";
	}
}
