package _18_12_2020;

import java.util.Scanner;

public class COJ_45_Testing {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		COJ_45_Batsman v = new COJ_45_Batsman();
		System.out.println(v);
		System.out.println("enter name,runs,matches,");
		COJ_45_Batsman v2 = new COJ_45_Batsman(sc.next(),sc.nextInt(),sc.nextInt(),sc.nextFloat());
		v2.computeBattingAverage();

	}
}
