package _18_12_2020;

interface COJ_44_AdvancedArithmetic {
	public abstract int divisorSum(int n);
}
