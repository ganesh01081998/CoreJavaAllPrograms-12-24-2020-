package _18_12_2020;

public class COJ_44_Testing implements COJ_44_AdvancedArithmetic{

	@Override
	public int divisorSum(int n) {
		int k = 0;
		for(int i = 1; i <= n; i++) {
			if(n % i == 0) {
				k = k + i;
			}
		}
		
		return k;
	}
	

}
