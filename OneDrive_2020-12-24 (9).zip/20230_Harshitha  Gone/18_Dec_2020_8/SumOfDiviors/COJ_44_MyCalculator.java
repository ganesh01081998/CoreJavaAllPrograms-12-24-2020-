package _18_12_2020;

import java.util.Scanner;

public class COJ_44_MyCalculator {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("enter a number");
	COJ_44_Testing c = new COJ_44_Testing();
	System.out.println("sum of divisors is " + c.divisorSum(sc.nextInt()));
}
}
