package _18_12_2020;

abstract class COJ_41_MyBook {
	String title;
	abstract void setString(String s1);
	String getString() {
		return title;
	}

}


