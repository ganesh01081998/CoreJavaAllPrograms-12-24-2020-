package _18_12_2020;

import java.util.Scanner;

public class TestFirst {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("enter book title");
	COJ_41_Book c = new COJ_41_Book();
	c.setString(sc.nextLine());
	System.out.println("The title of my book is :"+ c.getString());
	
}
}
