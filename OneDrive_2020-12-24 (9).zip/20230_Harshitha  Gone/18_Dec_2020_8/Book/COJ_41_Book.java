package _18_12_2020;

public class COJ_41_Book extends COJ_41_MyBook{

	@Override
	void setString(String title) {
		super.title = title;
	}

}
