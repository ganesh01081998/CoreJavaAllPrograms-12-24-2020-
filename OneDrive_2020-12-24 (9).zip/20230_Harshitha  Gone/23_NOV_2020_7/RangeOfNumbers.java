package ojas.org.patterns;

import java.util.Scanner;

public class RangeOfNumbers {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter two Numbers : ");
		int number1 = sc.nextInt(),number2 = sc.nextInt();
		System.out.println(is3050(number1,number2));
	}
	static boolean is3050(int number1,int number2) {
		if(number1 >= 30 && number1 <=40 && number2 >= 30 && number2 <= 40 ) {
			return true;
		}
		else if (number1 >= 40 && number1 <=50 && number2 >= 40 && number2 <= 50 ) {
			return true;
		}
		return false;
	}

}
