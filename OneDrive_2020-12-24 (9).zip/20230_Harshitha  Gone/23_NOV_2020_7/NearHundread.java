package ojas.org.patterns;

import java.util.Scanner;

public class NearHundread {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Number : ");
		int num = scanner.nextInt();
		System.out.println(nearHundred(num));
	}
	static boolean nearHundred(int num) {		
		if(Math.abs(100 - num) <= 10 && Math.abs(100 - num) >= 1  ) {
			return true;
		}
		else if(Math.abs(200 - num) <= 10 && Math.abs(200 - num) >= 1  ) {
			return true;
		}
	return false;	
	}
}
