package ojas.org.patterns;

import java.util.Scanner;

public class NearTenValue {
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
		System.out.println("Enter the two Numbers : ");
		int firstNum = sc.nextInt(),secondNum = sc.nextInt();
		System.out.println(close10(firstNum,secondNum));
		
	}
	static int close10(int firstNum,int secondNum) {
		int compare = Math.abs(firstNum -10);
		int compare1 = Math.abs(secondNum -10);
		if(compare == compare1) {
			return 0;
		}
		else if(compare < compare1) {
			return firstNum;
		}
		else {
			return secondNum;
		}
	}
}
