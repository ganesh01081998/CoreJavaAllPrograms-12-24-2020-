package ojas.org.com;

public class RussianMultiplication {
public static void russian(int num1,int num2) {
	int start = num1;
	int end = num2;
	while(num1 > 0 && num2 > 0) {
		int a = num1 / 2;
		int b = num2 * 2;
	}
}
}
