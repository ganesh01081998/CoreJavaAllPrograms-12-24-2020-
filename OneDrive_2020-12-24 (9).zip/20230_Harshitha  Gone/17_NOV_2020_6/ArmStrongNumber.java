package ojas.org.com;

import java.util.Scanner;

public class ArmStrongNumber {
	static String isArmstrong(int num) {

		int count = digitCount(num);
		int tmp = 0, copy = num;
		int sum = 0;
		while (num > 0) {
			tmp = num % 10;
			sum += power(tmp, count);
			num = num / 10;
		}
		if (copy == sum) {
			return " is armstrong number";
		} else {
			return " is not armstrong number";
		}
	}

	private static int digitCount(int num) {
		int count = 0;
		while (num != 0) {
			count++;
			num /= 10;
		}
		return count;
	}

	public static int power(int basenum, int powernum) {
        int res = 1;
		for (int i = 1; i <= powernum; i++) {
			res *= basenum;
		}
		return res;
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter number");
		System.out.println(isArmstrong(scanner.nextInt()));
	}
}
