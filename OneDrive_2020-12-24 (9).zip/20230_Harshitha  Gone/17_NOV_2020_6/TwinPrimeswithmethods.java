package ojas.org.com;

import java.util.Scanner;

public class TwinPrimeswithmethods {
	static boolean prime(int n) {
		boolean f = true;
		for(int i = 2 ; i <= n / 2 ; i++) {
				if(n % i == 0) {
					f = false ;
                       break;
				}
			}
	    return f;
	}
	static void range() {
		for(int i = 2 ; i <= 100 ; i++) {
			if(prime(i) && prime(i+2)) {
				System.out.println(i+","+(i+2));
				
			}
		}
	}
	public static void main(String[] args) {
		System.out.println("twin primes are");
		range();
	}

}
