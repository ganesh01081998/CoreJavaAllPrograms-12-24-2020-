package ojas.org.com;

public class FibonacciWithPalindrom {
public static void main(String[] args) {
	int a=70;
	int b=71;
	int c=0;
	for(int i=0;i<10;i++)
	{
		c=a+b;
		a=b;
		b=c;
		System.out.println(c);
	int count=0;
		int k=c;
	int rev=0;
	while(c>0)
	{
		int t=c%10;
		rev=rev*10+t;
		c=c/10;
	}
	System.out.println(rev);
	if(rev==k)
	{
		count++;
		if(count==1)
		{
		System.out.println("plindrome:"+k);
	    }
		else
		{
			System.out.println("not palindrom");
	
		}
	}
	
	}
}
}
	


