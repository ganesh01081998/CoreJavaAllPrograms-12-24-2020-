package ojas.org.com;

import java.util.Scanner;

public class Colladz {
    static void isColladz(int num) {
    	while(num > 1) {
    		if(num % 2 == 0) {
    			num = num / 2;
    		} 
    		else {
    			num = (num * 3) + 1;
    		}
    		System.out.println(num);
    	}
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner scanner = new Scanner(System.in);
		System.out.println("enter number");
        int num = scanner.nextInt();
        isColladz(num);
	}

}
