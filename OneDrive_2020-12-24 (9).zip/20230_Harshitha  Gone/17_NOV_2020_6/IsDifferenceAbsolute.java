package ojas.org.com;

import java.util.Scanner;

public class IsDifferenceAbsolute {
	public static void main(String[] args) {
		
	
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter Number");
	System.out.println(absoluteArmstrong(sc.nextInt()));
	}
static String absoluteArmstrong(int num){
	String result = " ";
	int fixNum = 21;
	if( num <= fixNum){
		num = (fixNum - num);
		
	}
	else{
	num = (fixNum - num) * -2;
	}
	result += "The Diffarence is "+num;
	return result;
}

}
