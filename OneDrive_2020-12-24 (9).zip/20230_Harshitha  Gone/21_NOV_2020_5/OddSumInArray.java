package ojas.org.com;

import java.util.Scanner;

public class OddSumInArray {
	public static int getOddSum(int arr[]) {
		int sum = 0;
		for(int i = 0 ; i < arr.length ; i++) {
			if(getOddNums(arr[i])) {
				sum = sum + arr[i];
			}
		}
		return sum;	 
	}

	public static boolean getOddNums(int num) {
		boolean b = false;
		if(num % 2 != 0) {
			b = true;			
		}
		return b;
		}	
	/*public static String size(int size) {
		String str = "";
		if(size != 10) {
			str += "null"; 
			
		}
		return str;
	}*/
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter size");
		int size = scanner.nextInt();
//		System.out.println(size(size));
		System.out.println("enter elements");
		int arr[] = new int[size];
		for(int i = 0; i < arr.length;i++) {
			arr[i] = scanner.nextInt();
		}
		
System.out.println("sum of odd number is " + getOddSum(arr) );
	}

}
