package ojas.array.com;

import java.util.Scanner;

public class MultiplicationOfTwoMatrices {
	public static void getMul(int array1[][] , int array2[][],int rows , int clo) {
		int mulAry[][] = new int[rows][clo];
		for(int i = 0; i < rows; i++) {
			System.out.println("");
			for(int j = 0; j < clo; j++) {
//				mulAry[i][j] = 0;
				for(int k = 0; k < rows ; k++) {
				mulAry[i][j] += array1[i][k] * array2[k][j] ;
			}
			}
		}
		System.out.println("sum of two matrices");
		for(int i = 0; i < rows; i++) {
			System.out.println("");
			for(int j = 0; j < clo; j++) {
				System.out.print(mulAry[i][j] + " ");
			}
		}		
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter number of rows for 1st array");
		int rows = scanner.nextInt();
		System.out.println("enter number of columns for 1st array");
		int col = scanner.nextInt();
		System.out.println("enter 1st array elements");
		int array1 [][] = new int[rows][col];
		for(int i = 0; i < rows; i++) {
			for(int j = 0; j < col; j++)
			array1[i][j] = scanner.nextInt();
		}
		System.out.println("enter 2nd array elements");
		int array2 [][] = new int[rows][col];
		for(int i = 0; i < rows; i++) {
			for(int j = 0; j < col; j++)
			array2[i][j] = scanner.nextInt();
		}	
		getMul(array1,array2, rows, col);
	}
}
