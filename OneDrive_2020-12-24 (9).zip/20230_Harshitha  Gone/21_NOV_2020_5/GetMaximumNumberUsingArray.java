package ojas.org.com;

import java.util.Scanner;

public class GetMaximumNumberUsingArray {
public static int getMax(int arr[])  {
	int big = 0;
	for(int i = 0 ; i < arr.length;i++) {
		int k = isCheck(arr[i]);
		if(arr[k] > big) {
			big = arr[k];
		}
	}
	
	return big;
	
	}

public static int isCheck(int num) {
	int k = 0;
	if(num < 0) {
		k = num * -1;
	}
	return k;
	
}
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("eneter size"); 
	int size = scanner.nextInt();
	System.out.println("enter elemnts");
	int arr[] = new int[size];
	for(int i = 0; i < arr.length ; i++) {
		arr[i] =  scanner.nextInt();
		}
	System.out.println("biggest number is " + getMax(arr));
		
	
}
}
