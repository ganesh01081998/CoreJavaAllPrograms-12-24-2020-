package ojas.array.com;

import java.util.Scanner;

public class MinimumNumberInArray {
	public static int getMin(int arr[])  {
		int min = arr[0];
		for(int i = 0 ; i < arr.length;i++) {	
			if(arr[i] < min) {
				min = arr[i];
			}
		}
		return min;	
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("eneter size"); 
		int size = scanner.nextInt();
		if(size != 10) {
			System.out.println("null");
		}
		else {
		System.out.println("enter elemnts");
		int arr[] = new int[size];
		for(int i = 0; i < arr.length ; i++) {
			arr[i] =  scanner.nextInt();
			}
		System.out.println("smallest number is " + getMin(arr));	
	}
	}
}
