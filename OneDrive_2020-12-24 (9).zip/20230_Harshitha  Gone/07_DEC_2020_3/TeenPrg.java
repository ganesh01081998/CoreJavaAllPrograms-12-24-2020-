package o7_12_2020;

import java.util.Scanner;

public class TeenPrg { 
public static int fixTeen(int num) {
	
	if(num >= 13 && num <= 19 && num != 15 && num != 16) {
		return 0;	
	}
	return num;
	
}
public static int getSum(int num1,int num2,int num3) {
	int sum = 0;
	sum += fixTeen(num1);
	sum += fixTeen(num2);
	sum += fixTeen(num3);
	return sum;
}
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("enter num1");
	int num1 = sc.nextInt();
	System.out.println("enter num2");
	int num2 = sc.nextInt();
	System.out.println("enter num3");
	int num3 = sc.nextInt();
	System.out.println(getSum(num1,num2 ,num3));
}
}
