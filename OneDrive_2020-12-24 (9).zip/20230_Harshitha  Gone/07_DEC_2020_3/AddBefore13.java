package o7_12_2020;

import java.util.Scanner;

public class AddBefore13 {
	 static int getSum(int number1,int number2,int number3) {
		int result = 0;
		if(number1 != 13) {
			result += number1;
		} 
		else {
			return result; 
		}
		if(number2 != 13) {
			result += number2;
		} 
		else {
			return result; 
		}
		if(number3 != 13) {
			result += number3;
		} 		
		return result;			
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Three Integer Inputs to LuckySum");
		int number1 = scanner.nextInt(),number2 = scanner.nextInt(),number3 = scanner.nextInt();
		System.out.println(getSum(number1,number2,number3));
	}
}
