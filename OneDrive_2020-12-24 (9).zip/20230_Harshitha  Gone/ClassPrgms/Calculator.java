package com.ojas.sampleprg;
interface Operations {
	void sum(int a, int b);
}
//creating anonymus object for constructors
public class Calculator {
	Calculator(int a, int b) {
		System.out.println("sum = " +(a + b));
	}
public static void main(String[] args) {
	Operations operations =  Calculator::new;
	operations.sum(2, 3);
}

}
