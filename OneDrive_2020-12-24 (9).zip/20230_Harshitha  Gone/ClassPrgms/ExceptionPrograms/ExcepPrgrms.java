package com.ojas.sample;

public class ExcepPrgrms {
public static void main(String[] args) {
	System.out.println("hellooo");
	System.out.println("hiiii....");
	int a = 10,b = 0;
	try {
		System.out.println("c = " + a/b);
	}
	catch(ArithmeticException e) {
		System.out.println("dont enter" +e.getMessage());
	}
	
	System.out.println( "how are you");
}
}
