package com.ojas.sample;

import java.util.Scanner;

public class MultipleCatchBlocks {
	public static void main(String[] args) {	
	Scanner sc = new Scanner(System.in);
	System.out.println("enter any number");
	 int num1 = sc.nextInt();
	 try {
	 int res = 45/num1;
	 System.out.println("res = " + res);
	 System.out.println("inside try block");
	 int c[] = {1};
	 c[43] = 99;
	 }
	 catch(ArithmeticException e) {
		 e.printStackTrace();
	 }
	 catch(ArrayIndexOutOfBoundsException e) {
		System.out.println(e);
	 }
	 catch(Exception e) {
		 System.out.println(e);
	 }
	 finally {
		 System.out.println("finally block");
	 }
	}		
}
