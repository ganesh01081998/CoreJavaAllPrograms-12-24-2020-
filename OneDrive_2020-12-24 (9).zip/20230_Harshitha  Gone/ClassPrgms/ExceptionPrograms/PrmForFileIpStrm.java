package com.ojas.sample;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class PrmForFileIpStrm {
public static void main(String[] args) throws FileNotFoundException {
	FileInputStream fileInputStream = new FileInputStream("D:\\hai\\sanmar.java");
	int k = 0;
	try {
		while((k = fileInputStream.read()) != -1) {
			System.out.println((char)k);
		}
	}
	catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		System.out.println("file is not available ");
	}
	
	catch (IOException e) {
		System.out.println("unable to read the data");
	}
}
}
