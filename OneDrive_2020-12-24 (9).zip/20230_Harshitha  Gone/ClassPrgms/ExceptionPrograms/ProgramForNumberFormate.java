package com.ojas.sample;

import java.util.Scanner;

public class ProgramForNumberFormate {
//	  private static final String inputString = "123.33";   
//      
//	    public static void main(String[] args) {  
//	        try {  
//	                 int a = Integer.parseInt(inputString);  
//	                 System.out.println(a);
//	        }catch(NumberFormatException ex){  
//	            System.err.println("Invalid string in argumment");  
//	            //request for well-formatted string  
//	        }  
//	            }
	    public static void main(String[] args) {  
	         int a = Integer.parseInt("123");
	         System.out.println(a);//throws Exception as     //the input string is of illegal format for parsing as it is null.  
	    }  
}