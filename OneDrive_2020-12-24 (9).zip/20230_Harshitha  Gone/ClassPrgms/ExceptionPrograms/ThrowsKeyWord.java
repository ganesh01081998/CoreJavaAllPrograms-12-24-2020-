package com.ojas.sample;

class BaseDemo {
	void disp() throws Exception {
		System.out.println("welcom");
	}
}

public class ThrowsKeyWord extends BaseDemo {
	void disp() throws Exception {
		System.out.println("hiii");

	}
	public static void main(String[] args) throws Exception {
		ThrowsKeyWord keyWord = new ThrowsKeyWord();
		keyWord.disp();
	}
}



