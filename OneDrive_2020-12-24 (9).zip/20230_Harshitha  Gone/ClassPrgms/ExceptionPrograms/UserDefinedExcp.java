package _21_12_2020;

class  NoMoneyException extends Exception{
	public NoMoneyException(String mess) {
		super(mess);
	}
}

class UserDefinedExcp {


	public static void main(String[] args) {
		try {
			int bal = 10000, withdraw = 15000;
			if(bal > withdraw) {
				throw new NoMoneyException("no sufficient balance");
			}
			else {
				System.out.println("Draw & enjoy");
			}
		}
		catch (NoMoneyException e) {
			System.out.println(e);
		}
	}
}
