package com.ojas.sample;

import java.util.Scanner;

public class ExpForArithmeticExp {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("enter any number");
	 int num1 = sc.nextInt();
	 try {
	 int res = 45/num1;
	 System.out.println("res = " + res);
	 System.out.println("inside try block");
	 }
	 catch(ArithmeticException e) {
		 e.printStackTrace();
	 }
	 finally {
		 System.out.println("finally block");
	 }
			
}
}
