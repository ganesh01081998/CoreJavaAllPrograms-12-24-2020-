package com.ojas.sample;

import java.io.File;

public class DisplayFilesInDir {

	public static void main(String[] args) {
		File dir = new File("C:");
		String[] ch = dir.list();
		if (dir.isDirectory()) {
			for (int i = 0; i < ch.length; i ++) {
				System.out.println(ch[i]);
			}
		}
		else {
			System.out.println("not a directory");
		}
	}
}
