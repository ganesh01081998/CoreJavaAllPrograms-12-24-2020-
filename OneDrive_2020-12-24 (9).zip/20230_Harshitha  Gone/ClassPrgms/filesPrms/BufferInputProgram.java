package com.ojas.sample;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class BufferInputProgram {
 public static void main(String[] args) throws IOException {
	BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream("D:\\mypackage\\Test.java"));
	BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(new FileOutputStream("abc.text"));
	int k = 0;
	while((k = bufferedInputStream.read()) != -1) {
		bufferedOutputStream.write((char)k);
		System.out.print((char)k);
	}
	bufferedOutputStream.close();
	bufferedInputStream.close();
}

}
