package com.ojas.sample;

import java.io.*;

public class FileReaderProgram {

		public static void main(String[] args) throws IOException {
			FileReader f = new FileReader("D:\\mypackage\\Test.java");
			FileWriter fileWriter = new FileWriter("abc.text");
			int k = 0;
			while((k = f.read()) != -1) {
				fileWriter.write((char)k);
				System.out.print((char)k);
			}
			fileWriter.close();
			f.close();
		}
	}
