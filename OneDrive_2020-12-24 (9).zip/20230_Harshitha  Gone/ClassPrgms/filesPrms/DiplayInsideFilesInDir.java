package com.ojas.sample;

import java.io.File;

public class DiplayInsideFilesInDir {

	static void findFIles(String dirName) {
		File f = new File(dirName);
		if(f.isDirectory()) {
			String fileName[] = f.list();
			for(int i = 0; i < fileName.length; i++) {
				String path = dirName +"/" + fileName[i];
				File next = new File(path);
				if(next.isDirectory()) {
					findFIles(path);
				}
				System.out.println(path);
			}
		}
			else {
				System.out.println("not a directory");
			}
			
		}
	public static void main(String[] args) {
		findFIles("C:\\Program Files");
	}
	
}

