package com.ojas.filesiostms;

import java.io.File;
import java.io.IOException;

public class CreateFileUsingIoStrems {
		public static void main(String[] args) throws IOException {
			File f = new File("C:\\file1\\file2.text");
			boolean b = f.createNewFile();
			System.out.println("directory created "+b);
		}
}
