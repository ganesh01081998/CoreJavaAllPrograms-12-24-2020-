package com.ojas.filesiostms;

import java.io.*;

public class CreateDirectoryUsingFile {
public static void main(String[] args) {
	File f = new File("C:\\file1");
	boolean b = f.mkdir();
	System.out.println("directory created"+b);
}
}
