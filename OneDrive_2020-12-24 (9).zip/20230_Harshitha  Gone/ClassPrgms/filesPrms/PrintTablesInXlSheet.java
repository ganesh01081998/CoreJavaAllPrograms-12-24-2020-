package com.ojas.sample;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class PrintTablesInXlSheet {
public static void main(String[] args) throws IOException {
	Scanner scanner = new Scanner(System.in);
	System.out.println("enter any number");
	int num = scanner.nextInt();
	String res = "";
	for (int i = 0; i <= 10 ; i++) {
		res += num + " * " + i + " = " + (num * i);
		res += "\n";
		
	}
	System.out.println(res);
	FileWriter fileWriter = new FileWriter("tables.csv",true);
	fileWriter.write(res);
	fileWriter.flush();
}
}
