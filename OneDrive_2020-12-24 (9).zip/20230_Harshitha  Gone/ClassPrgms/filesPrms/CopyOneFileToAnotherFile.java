package com.ojas.sample;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class CopyOneFileToAnotherFile {
public static void main(String[] args) throws IOException {
	FileInputStream fileInputStream = new FileInputStream("D:\\mypackage\\Test.java");
	FileOutputStream fileOutputStream = new FileOutputStream("abc.text");
	int k = 0;
	while((k = fileInputStream.read()) != -1) {
		fileOutputStream.write((char)k);
		System.out.print((char)k);
	}
	fileOutputStream.close();
	fileInputStream.close();
}
}
