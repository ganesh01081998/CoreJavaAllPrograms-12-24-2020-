package com.ojas.sample;

 interface ExmpAbstarct1{
	 void m1();
	void sound(); 
}		

 abstract class Dog1 implements ExmpAbstarct1 {
	public void m1() {
		System.out.println("from dog class");
	}
}
class Cat1 implements  ExmpAbstarct1 {
	public void m1() {
		System.out.println("from cat class");
	}


	public void sound() {
		System.out.println("from Cat sound");
		
	}
}
public class InterfaceExp  {
	public static void main(String[] args) {
		Animal a = new Dog();
		a.m1();
		a.sound();
		Animal c = new Cat();
		c.m1();
		c.sound();
	}
}
