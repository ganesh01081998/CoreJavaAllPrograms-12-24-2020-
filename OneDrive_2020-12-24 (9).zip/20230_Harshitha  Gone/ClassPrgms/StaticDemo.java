package dice.game.com;

public class StaticDemo {

static int num1;
static void count() {
	num1++;
}
int getNum() {
	return num1;
}
public static void main(String[] args) {
	System.out.println(num1);
	System.out.println(StaticDemo.num1);
	StaticDemo demo1 = new StaticDemo();
	StaticDemo demo2 = new StaticDemo();
	StaticDemo demo3 = new StaticDemo();
	demo1.count();
	demo1.count();
	demo1.count();
	
	demo2.count();
	demo2.count();
	demo3.count();
	System.out.println("obj1= " + demo1.getNum());
	System.out.println("obj2= " + demo2.getNum());
	System.out.println("obj3= " + demo3.getNum());
	
	
}
}
