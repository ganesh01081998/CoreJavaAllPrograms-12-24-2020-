package com.ojas.sample;

public class InnerCalses {
int a = 10;
class InnerClas {
	int b = 20;
	InnerClas() {
		System.out.println("inner demo a = " + a + "\t b = " + b);
	}
}
	InnerCalses() {
		System.out.println("outer class " + a);
	}
	public static void main(String[] args) {
		InnerCalses c = new InnerCalses();
		InnerCalses.InnerClas obj = c.new InnerClas();
		
	}
}

