package dice.game.com;
import java.util.*;
public class DiceGame {
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	Dice d1 = new Dice();
	Dice d2 = new Dice();
	System.out.println("enter first player name");
	Player p1 = new Player(scanner.next());
	p1.throwDice(d1, d2);
	System.out.println("enter second player name");
	Player p2 = new Player(scanner.next());
	p2.throwDice(d1, d2);
	String res = "";
	if(p1.value > p2.value) {
		res = p1.pName + " wins the game";
	}
	else if(p2.value > p1.value) {
		res = p2.pName + " wins the game";
	}
	else {
		res = "plz try again";
	}
	System.out.println(res);
}
}
