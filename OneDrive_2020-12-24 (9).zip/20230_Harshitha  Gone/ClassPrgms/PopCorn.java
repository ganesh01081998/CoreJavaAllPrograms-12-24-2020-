package com.ojas.sampleprg;
class Food {
	void eat() {
		System.out.println("eat healthy food");
	}
}
public class PopCorn {
 Food f = new Food() {
	 void eat() {
		 super.eat();
		 System.out.println("Popcorn is junk food");
	 }
 };
 void disp() {
	 f.eat();
 }
 public static void main(String[] args) {
	PopCorn corn = new PopCorn();
	corn.disp();
	}
}
