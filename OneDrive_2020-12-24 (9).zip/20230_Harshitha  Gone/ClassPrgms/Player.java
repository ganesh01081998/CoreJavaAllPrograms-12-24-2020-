package dice.game.com;

public class Player {
String pName;
int value;
Player(String pName) {
	this.pName = pName;
}
public void throwDice(Dice d1,Dice d2) {
	d1.roll();
	d2.roll();
	value = d1.faceValue + d2.faceValue;
	System.out.println(value + "=" +d1.faceValue + "+" + d2.faceValue) ;
}
}
