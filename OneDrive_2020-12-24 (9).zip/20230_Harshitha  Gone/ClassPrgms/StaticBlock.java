package dice.game.com;

public class StaticBlock {
static int num;
static int num1;
static {
	System.out.println("ststci");
	num = 10;
	num1 = 1;
}
{
	System.out.println("non static");
}
public StaticBlock() {
	System.out.println("hiiii");
}
public static void main(String [] args) {
	System.out.println(num);
	System.out.println(num1);
	StaticBlock block = new StaticBlock();
	
}
}
