package com.ojas.sampleprg;

public class ThreeDotAry {
static void disp(int k,int ...ary) {
	 int big = 0;
	for( int x : ary) {
		if(x > big) {
			big = x;
		}
	}
	System.out.println(" " + big);
}
public static void main(String[] args) {
	disp(12,23,12);
}
}



