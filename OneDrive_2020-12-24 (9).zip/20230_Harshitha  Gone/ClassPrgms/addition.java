package com.ojas.sampleprg;
interface sum {
	void add();
}
public class addition {
public static void main(String[] args) {
	sum s = new sum() {

		@Override
		public void add() {
			System.out.println("adition");	
		}
		public void m1() {
			System.out.println("hi..");
		}
	};
	s.add();
	
}
}
