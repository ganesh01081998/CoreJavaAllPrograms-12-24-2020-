package com.ojas.sample;

abstract class Animal {
	abstract void m1();
	void sound() {
		System.out.println("from animal class");
	}
}
class Dog extends Animal {
	void m1() {
		System.out.println("from dog class");
	}
}
class Cat extends Animal {
	void m1() {
		System.out.println("from cat class");
	}
}
public class ExmpAbstarct {
	public static void main(String[] args) {
		Animal a = new Dog();
		a.m1();
		a.sound(); 
		Animal c = new Cat();
		c.m1();
		c.sound();
	}
}
