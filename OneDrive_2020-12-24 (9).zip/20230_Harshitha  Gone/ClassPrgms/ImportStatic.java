package com.ojas.sampleprg;
import static java.lang.Integer.*;
import static java.lang.System.*;
public class ImportStatic {
public static void main(String[] args) {
	int num1 = parseInt(args[0]);
	int num2 = parseInt(args[1]);
	out.println("sum = " +(num1 + num2));
}
}
