package dice.game.com;

public class MethodsOfStatc {
int num1 = 10;
static int num2 = 20;
void accept() {
	System.out.println(num1 * num2);
}
static void disp() {
	MethodsOfStatc m = new MethodsOfStatc();
	System.out.println(m.num1 * num2);
}
public static void main(String[] args) {
	MethodsOfStatc m1 = new MethodsOfStatc();
	m1.accept();
	disp();
	MethodsOfStatc.disp();
	m1.disp();
}
}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
