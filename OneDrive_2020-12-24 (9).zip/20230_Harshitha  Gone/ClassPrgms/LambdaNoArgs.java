package com.ojas.sampleprg;
interface Addition {
	void disp(int a,int b);
	default void m1() {
		System.out.println("hi...");
	}
}

public class LambdaNoArgs {
public static void main(String[] args) {
	Addition addition = ( a, b) ->{
		System.out.println("sum = "+ a+b);
		System.out.println("product = " + a*b);
	};
		addition.disp(2,3);
		addition.m1();
	
}
}
