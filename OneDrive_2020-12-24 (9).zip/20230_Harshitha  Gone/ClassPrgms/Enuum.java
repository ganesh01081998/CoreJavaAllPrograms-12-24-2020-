package dice.game.com;
enum operation {
	Add,sub,mul,div
}
public class Enuum {
public static void main(String[] args) {
	for(operation o : operation.values()) {
		System.out.println(o);
	}
}
}
