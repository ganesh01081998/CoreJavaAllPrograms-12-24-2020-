package _15_12_2020;

import java.util.Scanner;

public class MainMtdOfNoStudent {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter type of student");
		String str = "";
		str += "1.ScienceStudent\n";
		str += "2.HistoryStudent\n";
		System.out.println(str);
		System.out.println("enter your choice");
		int ch = sc.nextInt();
		switch(ch) {
		case 1:
			System.out.println("enter student name,class,physics,chem,maths");
			ScienceStudent std = new ScienceStudent(sc.next(), sc.next(), sc.nextInt(), sc.nextInt(), sc.nextInt());
			System.out.println("percentage of science student is " + std.getPercentage()+"%");
			System.out.println(std);
			break;
		case 2:
			System.out.println("enter student name,class,history,civics");
			HistoryStudent std1 = new HistoryStudent(sc.next(), sc.next(), sc.nextInt(), sc.nextInt());
			System.out.println("percentage of history student is " + std1.getPercentage()+"%");
			System.out.println(std1);
			break;
		default :
			System.out.println("invalid choice");
		}


	}
}
