package _15_12_2020;

public class ScienceStudent extends TotalNumberOfStudent{
	int phyMarks;
	int chemMarks;
	int mathMarks;
	public ScienceStudent(String name, String stdClas, int phyMarks, int chemMarks, int mathMarks) {
		super(name, stdClas);
		this.phyMarks = phyMarks;
		this.chemMarks = chemMarks;
		this.mathMarks = mathMarks;
	}
	@Override
	int getPercentage() {
		int perce = 0;
		int totalMarks = 0;
		if(phyMarks <= 100 && chemMarks <= 100 && mathMarks <= 100) {
			totalMarks = phyMarks + chemMarks + mathMarks;
			System.out.println("total marks " + totalMarks);
			perce = (totalMarks) / 3;
		}
		else {
			System.out.println("give subject marks below 100!");
		}
		return perce;

	}
	@Override
	public String toString() {
		return "ScienceStudent [phyMarks=" + phyMarks + ", chemMarks=" + chemMarks + ", mathMarks=" + mathMarks + "]";
	}

}
