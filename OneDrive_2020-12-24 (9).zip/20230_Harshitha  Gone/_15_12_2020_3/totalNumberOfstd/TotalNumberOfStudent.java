package _15_12_2020;

abstract public class TotalNumberOfStudent {
	String name;
	String stdClas;
	protected static int noStd;

	public TotalNumberOfStudent(String name, String stdClas) {
		this.name = name;
		this.stdClas = stdClas;

	}
	abstract int getPercentage();
	static void getTotalNoStudents() {

	}

}
