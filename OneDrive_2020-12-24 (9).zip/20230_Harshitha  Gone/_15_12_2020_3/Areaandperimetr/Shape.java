package _15_12_2020;

abstract public class Shape {
	
abstract void getArea();
abstract void getPerimeter();
}
