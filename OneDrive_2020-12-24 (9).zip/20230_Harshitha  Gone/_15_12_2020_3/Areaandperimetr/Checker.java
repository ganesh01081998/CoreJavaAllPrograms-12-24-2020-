package _15_12_2020;

import java.util.Scanner;

public class Checker {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("enter radius");
	Shape s = new Circle(sc.nextFloat());
	s.getArea();
	s.getPerimeter();
	System.out.println("enter length and breadth of rectangle");
	Shape s1 = new Rectangle(sc.nextInt(),sc.nextInt());
	s1.getArea();
	s1.getPerimeter();
	System.out.println("enter side of square");
	Shape s2 = new Square(sc.nextInt());
	s2.getArea();
	s2.getPerimeter();
	
}
}
