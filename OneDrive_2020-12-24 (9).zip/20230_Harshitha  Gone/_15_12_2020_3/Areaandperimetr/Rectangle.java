package _15_12_2020;

public class Rectangle extends Shape{
	int length,breadth;

	public Rectangle( int length, int breadth) {

		this.length = length;
		this.breadth = breadth;
	}

	@Override
	void getArea() {
		System.out.println("area of rectangle " + length * breadth);
		
	}

	@Override
	void getPerimeter() {
		System.out.println("area of perimeter " + 2 * (length + breadth));
		
	}
	

}
