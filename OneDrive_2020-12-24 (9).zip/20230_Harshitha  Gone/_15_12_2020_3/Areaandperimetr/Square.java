package _15_12_2020;

public class Square extends Shape {
	float side;

	public Square(float side) {
		this.side = side;
	}

	@Override
	void getArea() {
		System.out.println("area of square is " + (side * side));
		
	}

	@Override
	void getPerimeter() {
	System.out.println("perimeter of square is " + (4 * side));
		
	}
	

}
