package _15_12_2020;

public class Circle extends Shape{
     final float pi = 3.14f;
     float radius ;
     public Circle(float radius) {
     		this.radius = radius;
     	}

	@Override
	void getArea() {
		System.out.println("area of circle is " + (pi*radius*radius));	
	}
	@Override
	void getPerimeter() {
		System.out.println("perimeter of circle is " + (2 * pi * radius));
		
	}
}
