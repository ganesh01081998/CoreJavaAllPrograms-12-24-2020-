package ojas.org.com;

import java.util.Scanner;

public class FizzBizz {
     static String getOutputString(int num) {
    	 String string = "";
    	 if(num > 0) {
    		 if(num % 3 == 0 && num % 5 != 0) {
    			 string = "fizz";
    		 }
    		 else if(num % 5 == 0 && num % 3 !=0) {
    			 string = "bizz";
    		 }
    		 else  if(num % 5 == 0 && num % 3 ==0){
    			 string = "fizzbizz";
    		 }
    	   	 else {
    		     string += num;
    		 }
    	 }
    	 else{
    		return "error";
    	 }
		return string;
     }
       public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
        System.out.println("enter number");
		String res = "";
		res = getOutputString(scanner.nextInt());
		System.out.println(res);
	
	}
	}

