package ojas.org.com;

import java.util.Scanner;

public class NaturalNumsGivenRange {
      static String getNaturals(int number) {
    	  String numbers = "";
    	  for(int i = 1;i <= number; i++) {
    		  numbers+= i + " \n";
    	  }
    	  return numbers;
      }
      public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter number");
		String res = "";
		res = getNaturals(scanner.nextInt());
		System.out.println("natural numbers are \n" +res);
	}
}
