package ojas.org.com;

import java.util.Scanner;

public class DisplayEvenNumbersInRange {
 static String evenRange(int startingNum,int endingNum) {
	 String range = "";
	 for(int i = startingNum;i <= endingNum; i++) {
		 if(i % 2 == 0) {
			 range += i + "\n" ;
		 }
		 
	 }
	 
	return range;
 }
 public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("enter starting number and ending numbers");

	System.out.println(evenRange(scanner.nextInt(),scanner.nextInt()));
}
}
