package ojas.org.com;

import java.util.Scanner;

public class SumOfNaturalNumbers {
	static String sum(int starting, int ending) {
		String result = "";
		int sum = 0;
		for (int i = starting; i <= ending; i++) {
			sum= sum + i;
			}
		result += sum;
		return result;
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter starting number and ending numbers");

		System.out.println(sum(scanner.nextInt(), scanner.nextInt()));
	}
}
