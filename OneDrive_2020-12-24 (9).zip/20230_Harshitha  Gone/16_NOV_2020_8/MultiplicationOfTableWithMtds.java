package ojas.org.com;

import java.util.Scanner;

public class MultiplicationOfTableWithMtds {
static String mul(int num) {
	String res = "";
	for(int i = 1; i <= 10 ; i++) {
		res += num +"*"+ i + " = " + num * i +"\n";
	}
	return res;
}
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("enter number");
	System.out.println(mul(scanner.nextInt()));
}
}
