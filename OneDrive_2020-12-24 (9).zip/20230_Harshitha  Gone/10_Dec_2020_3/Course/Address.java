package _10_12_2020;

public class Address {
	private String hno;
	private String cityName;
	
	public Address(String hno,String cityName) {
		this.hno = hno;
		this.cityName = cityName;
	}
	
	public String toString() {
		return "Address [ hno = " + hno +  ", cityName = " + cityName + "]" ;				
	}


}
