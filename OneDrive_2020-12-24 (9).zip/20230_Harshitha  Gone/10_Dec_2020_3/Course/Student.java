package _10_12_2020;

public class Student {
	int sno;
	String sname;
	
	public Student(int sno,String sname) {
		this.sno = sno;
		this.sname = sname;
	}

	@Override
	public String toString() {
		return "Student [sno = " + sno + ", sname = " + sname + "]";
	}
}
