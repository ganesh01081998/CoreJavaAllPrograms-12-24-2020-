package _10_12_2020;

import java.util.Scanner;

public class Account {
	public Customer c1;
	public int balence = 0;
	public int account;
	public float intrest;
	public Account(Customer c1, int account, float intrest) {
		this.c1 = c1;
		this.account = account;
		this.intrest = intrest;
	}
	public boolean validAccount(int accountNum) {
		boolean b = false;
		if(accountNum == account) {
			b = true;
		}
		else {
			System.out.println("invalid account");
			System.out.println("please enter valid account number!");
		}
		return b;
	}
	public int deposite(int accountNum , int depMny) {
		int bal = 0;
		if(validAccount(accountNum)) {
			bal += depMny;
		}
		return bal;
	}
	public int withDraw(int accountNum,int WithMny) {
		int bal = balence;
		if(validAccount(accountNum)) {
			bal = bal - WithMny;
		}
		return bal;
	}

	@Override
	public String toString() {
		return "Account [C1=" + c1 + ", balence=" + balence + ", account=" + account + ", intrest=" + intrest + "]";
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter first name and second name");
		Customer c = new Customer();
		c.setFirstName(sc.next());
		c.setLastName(sc.next());
		System.out.println("enter account number and intrset");
		Account account = new Account(c, sc.nextInt(),sc.nextFloat());
		System.out.println("enter account number and deposite money");
		System.out.println("your account number has been credited = " +  account.deposite(sc.nextInt(),sc.nextInt()));
		System.out.println("enter account number and withdraw money");
		System.out.println("your account number has been debited = " +  account.withDraw(sc.nextInt(),sc.nextInt()));
		System.out.println(account);

	}


}
