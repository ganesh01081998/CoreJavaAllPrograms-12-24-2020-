package ojas.strings.com;

import java.util.Scanner;

public class DateFormate {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter string");
		String date = scanner.nextLine();
		for(int i = 0 ; i < date.length(); i++) {
			char ch =  date.charAt(i);
			if(ch == ',' || ch == ' ' || ch == '/') {
				date = date.replace(" ","-");
				date = date.replace(",","-");		
				date = date.replace("/","-");
			}
		}
		System.out.println(date);
		System.out.println(format(date));		
	}
	public static String format(String str) {
		String fullDate = "";
		String str1[] = str.split("-");
		String str2[] = new String[str.length()];
			String date = str1[0];
			int month = convertMMMtoMM(str1[1]);
			String year = str1[2];
			fullDate += year +"-"+ month + "-" +date  ;	
		return fullDate;	
	}
	
		public static int convertMMMtoMM(String str) {
			int result = 0;
			String [] monthNames = {"jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec"};
			String monthDaysarr [] = {"january","february","march","april","may","june","july","august","september","october","november","december"};
			int monthDaysarr1 [] = {1,2,3,4,5,6,7,8,9,10,11,12};
			if(str.length() == 3) {
				for(int i = 0;i < monthNames.length;i++) {
					if(str.equalsIgnoreCase(monthNames[i])) {
						result += monthDaysarr1[i];
					}	
				}
			}
			else{
				for (int j = 0; j < monthDaysarr.length; j++) {
					if(str.equalsIgnoreCase(monthDaysarr[j])) {
					result += monthDaysarr1[j]; 
				}
			}	
			}
			return result;
		}
	}

