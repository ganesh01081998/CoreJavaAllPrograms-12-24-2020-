package ojas.strings.com;

import java.util.Scanner;

public class FindTheCharecter {
public static int charCount(String name , char ch) {
	int  res = -1;
	int count = 0;
	for (int i = 0; i < name.length(); i++) {
		char ch1 = name.charAt(i);
		if(ch1 == ch) {
			count++;
		}
	}
	if(count > 0) {
		return count;
	}
	
	return res;
}
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("enter the string");
	String str = scanner.next();
	System.out.println("enter the char");
	char ch = scanner.next().charAt(0);
	System.out.println(charCount(str, ch));
}
}
