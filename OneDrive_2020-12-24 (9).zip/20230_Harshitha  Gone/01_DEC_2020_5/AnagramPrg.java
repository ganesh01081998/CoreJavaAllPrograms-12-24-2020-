package ojas.org.com;

import java.util.Arrays;

public class AnagramPrg {

	public static void s1()
	{
		String s1="iran";
		String s2="nari";
	if(s1.length()==s2.length())//comparing lengths of both strings.... 
	{
	char c1[]=s1.toCharArray();
	char c2[]=s2.toCharArray();
	sorting(c1);
	sorting(c2);
	boolean status=Arrays.equals(c1,c2);//comparing both char arrays are equal or not....
	
	if(true)
	{
		System.out.println("anagram " );
	}
	else{
		System.out.println("not anagram");
	}
	}
	}
	
public static void sorting(char[] c1)//code for sorting without using sort method....
{
for(char ch='a';ch<='z';ch++)
{
   for(int i=0;i<c1.length;i++)
   {
	int ch1 =c1.length;
	   if(ch==ch1)
	   {
		   System.out.println(ch);
		   }
	   }
   }
}
public static void main(String[] args) 
{
	//AnagramPrg v=new AnagramPrg();
    s1();
}
}