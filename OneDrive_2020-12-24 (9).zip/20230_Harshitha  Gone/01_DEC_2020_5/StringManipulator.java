package ojas.strings.com;

import java.util.Scanner;

public class StringManipulator {
public static String getVowels(String str) {
    int count = 0;
	String str1 = "";
	for(int i = 0;i < str.length();i++) {
		char ch = str.charAt(i);
		if(ch != 'a' &ch != 'e' &ch != 'i'&ch != 'o'&ch != 'u') {
			str1 += ch ;
			count ++;
		}
	}
	if(count > 0) {
		return str1;
	}
	return null;
}
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("enter string");
	String str = scanner.nextLine();
	System.out.println( getVowels(str));
}
}
