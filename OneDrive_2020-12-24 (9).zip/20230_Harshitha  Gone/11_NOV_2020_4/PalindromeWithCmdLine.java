package ojas.org.com;

public class PalindromeWithCmdLine {
public static boolean palindrome(int num) {
	boolean f = false;
	int temp = 0,rev = 0;
	int num1 = num;
	while(num > 0) {
		 temp = num % 10;
         rev = rev * 10 + temp;
         num = num / 10;
	}
	if(num1 == rev) {
		f = true;
	}
	return f;
}
public static void main(String[] args) {
	int num = Integer.parseInt(args[0]);
	System.out.println(palindrome(num));
}
}
