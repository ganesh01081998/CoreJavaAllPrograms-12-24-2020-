package ojas.org.com;

import java.util.Scanner;

public class AcceptTwoSumFourUsingCmd {
 public static String sum(int sum,int num1) {
	 String str = "";
	 sum = sum + num1;
	 sum = sum + num1;
	 sum = sum + num1;
	 sum = sum + num1;
	  str += sum;
	 return str;
 }
 public static void main(String[] args) {
	int num1 = Integer.parseInt(args[0]);
	int num2 = Integer.parseInt(args[1]);
	
	System.out.println(sum(num1,num2));
}
}
