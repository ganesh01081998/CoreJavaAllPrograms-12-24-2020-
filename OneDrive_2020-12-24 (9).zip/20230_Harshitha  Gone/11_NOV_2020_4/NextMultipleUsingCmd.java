package ojas.org.com;

public class NextMultipleUsingCmd {
	
	    static int multiple(int num) {
	        return (num / 100 + 1) * 100;
	    }

	 

	    public static void main(String[] args) {
	        int num = Integer.parseInt(args[0]);
	        System.out.println(multiple(num));
	    }
	}

