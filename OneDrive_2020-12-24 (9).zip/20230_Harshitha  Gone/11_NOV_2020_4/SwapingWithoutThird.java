package ojas.org.com;

import java.util.Scanner;

public class SwapingWithoutThird {
    public static String swap(int num1,int num2) {
    	String res = "";
    	num1 = num1 + num2;
    	num2 = num1 - num2;
    	num1 = num1 - num2;
    	return res +=  "after swaping : num1 = " + num1 + " ; " + " num2 = " + num2;
    }
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter two numbers");
		int num1 = scanner.nextInt();
		int num2 = scanner.nextInt();
		System.out.println("before swaping num1 = " + num1 + " ; num2 = " + num2 );
		System.out.println(swap(num1,num2));
	}
}
