package ojas.org.patterns;

public class Patten_9 {
	
	public static String m1() {
			String str = "";
			char ch = 'A';
		for(int i = 1; i <= 5 ; i++)  {
			for(int j = 1 ; j <= i; j++) {
				str += ch+" ";
				ch++;
			}
			str += "\n";
		}
		return str;
	
	}
	public static void main(String[] args) {
		System.out.println(m1());
	}
}

