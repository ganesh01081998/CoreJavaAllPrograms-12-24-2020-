package ojas.org.patterns;

import java.util.Scanner;

public class Pattern_11 {
	public static String p1(int start,int end) {
		String str = "";
		for(int i = start ; i <= end ; i++) {
			
			for(int j = start ; j <= i ; j++) {
				str +=  " * ";
			}
		
			str += "\n";
		}
		
		return str ;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter two numbers");
		System.out.println(p1(scanner.nextInt(),scanner.nextInt()));
	}	
}
