package ojas.org.patterns;

import java.util.Scanner;

public class Pattern_13 {
	
	public static String p1(int start,int end) {
		String str = "";
		int star = -1;
		int space = 5;
		
		for(int i = start ; i <= end ; i++) {
			space--;
			star = star+2;
			for(int k = start ; k <= space ; k++) {
				str +=  " ";
			}
			for(int j = start ; j <= star ; j++) {
			str +=  "*";
			}
			
		str += "\n";
			
			}
		return str ;
	}
public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter two numbers");
		System.out.println(p1(scanner.nextInt(),scanner.nextInt()));
	}
}
