package ojas.org.patterns;

public class Pattern_12 {
public static String m1() {
	 String str = "";
	 for(int i = 1; i <= 5 ; i++) {
		 for(int j = 1; j <= 5 ; j++) {
			 if((j == 1 || j == 5) || (i == 1 || i == 5))
			 {
				 str += "*";
			 }
			 else {
				 str += " ";
			 }
			 
		 }
		 str += "\n";
	 }
	return str;
}
public static void main(String[] args) {
	System.out.println(m1());
}
}
