package ojas.org.patterns;

import java.util.Scanner;

public class Pattern_4 {
	static String getPattern(int number) {
		String result = "";
		for(int i = 1; i <= number; i++) {
			for(int j = 1; j <= i; j++) {
				result += j + " ";
			}
			result += "\n";
		}
		return result;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any Number : ");
		int number = sc.nextInt();
		System.out.println(getPattern(number));
	}

}
