package ojas.org.patterns;

import java.util.Scanner;

public class Pattern_6 {
	public static String p1(int start,int end) {
		String str = "";
		int k = 1;
		for(int i = start ; i <= end ; i++)
		{
			
			for(int j = start ; j <= i ; j++)
			 {
				
				str +=  k + " " ;
				k++;
		}
			if(i >= 2) {
		k--;	
			}
			str += "\n";
			
		}
		
		return str ;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter two numbers");
		System.out.println(p1(scanner.nextInt(),scanner.nextInt()));
	}	
}
