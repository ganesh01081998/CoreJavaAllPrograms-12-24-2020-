package o3_12_2020;
import java.util.*;
public class Player {
String pname;
int value;
Player(String pname) {
	this.pname = pname;
	
	}
void throwDice(Dice d1,Dice d2) {
	d1.roll();
	d2.roll();
	value = d1.faceValue + d2.faceValue;
	System.out.println(value + " = " + d1.faceValue +"+"+ d2.faceValue);
}

}
