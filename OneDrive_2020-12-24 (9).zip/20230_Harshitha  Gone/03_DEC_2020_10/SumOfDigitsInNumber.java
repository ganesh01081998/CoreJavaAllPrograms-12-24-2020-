package o3_12_2020;

import java.util.Scanner;

public class SumOfDigitsInNumber {
public static int sumOfDigits(int num) {
	int sum = 0;
	while(num > 0) {
		int temp = num % 10;
		sum = sum + temp;
		num = num / 10;
	}
	return sum;
	
}
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("enter number");
	int num = scanner.nextInt();
	System.out.println(sumOfDigits(num));
	
}
}
