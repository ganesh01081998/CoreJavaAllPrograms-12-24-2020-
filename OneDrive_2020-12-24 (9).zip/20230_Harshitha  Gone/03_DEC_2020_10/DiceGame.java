package o3_12_2020;

import java.util.*;;

public class DiceGame {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	Dice d1 = new Dice();
	Dice d2 = new Dice();
	System.out.println("enter first player name");
	Player p1 = new Player(sc.next());
	p1.throwDice(d1,d2);
	System.out.println("enter second player name");
	Player p2 = new Player(sc.next());
	p2.throwDice(d1,d2);
	String res = "";
	if(p1.value > p2.value) {
		res += p1.pname + " wins game";
	}
	else if(p2.value > p1.value) {
		res += p2.pname + " wins game";
	}
	else {
		res += "try again";
	}
	System.out.println(res);
	
}
}
