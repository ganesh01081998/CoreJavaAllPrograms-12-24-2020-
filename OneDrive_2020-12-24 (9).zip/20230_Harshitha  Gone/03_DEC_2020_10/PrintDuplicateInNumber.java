package o3_12_2020;

import java.util.Scanner;

public class PrintDuplicateInNumber {
public static void getDuplicates(int num) {
	String str = "";
	int k = 0;
	while(num > 0) {
		int rem =  num % 10;
		 str += rem;
		  num = num / 10;		
	}
	for (int i = 0; i < str.length(); i++) {
		int count  = 0;
		for (int l = i + 1; l < str.length(); l++) {
			if(str.charAt(i) == str.charAt(l)) {
				count++;
			}
			}
		if(count == 1) {
			System.out.println(str.charAt(i));
		}
		
	}
}
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("enter number");
	int num = scanner.nextInt();
	getDuplicates(num);
}
}
