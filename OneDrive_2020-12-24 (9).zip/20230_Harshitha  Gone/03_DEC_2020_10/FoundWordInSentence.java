package o3_12_2020;

import java.util.Scanner;

public class FoundWordInSentence {
public static boolean isCheck(String str, String word) {
	boolean b = false;
	String arry[] = str.split(" ");
	for(int i = 0 ; i < arry.length ; i++) {
		if(arry[i].equals( word)) {
			b = true;
		}
	}
	return b;
	}
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("enter string");
	String str = scanner.nextLine();
	System.out.println("enter word!");
	String word = scanner.nextLine();
	System.out.println(isCheck(str, word));
}
}
