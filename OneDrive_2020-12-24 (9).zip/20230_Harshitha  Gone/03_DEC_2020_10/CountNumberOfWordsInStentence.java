package o3_12_2020;

import java.util.Scanner;

public class CountNumberOfWordsInStentence {
public static int getCount(String str) {
	int count = 1;
	for (int i = 0; i < str.length(); i++) {
		char ch = str.charAt(i);
		if(ch == ' ') {
			count++;
		}
	}
	return count;
}
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("enter setence");
	String str = scanner.nextLine();
	System.out.println("number of words in sentence is " + getCount(str));
}
}
