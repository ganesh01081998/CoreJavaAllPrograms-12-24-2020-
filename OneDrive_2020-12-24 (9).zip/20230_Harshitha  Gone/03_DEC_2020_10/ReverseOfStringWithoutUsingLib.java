package o3_12_2020;

import java.util.Scanner;

public class ReverseOfStringWithoutUsingLib {
public static String reverse(String str) {
	String str2 = "";
	for(int i = str.length()-1 ; i >= 0 ; i--) {
		char ch = str.charAt(i);
		str2 += ch;
	}
	return str2;
}
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("enter string");
    String str = scanner.next();
    System.out.println(reverse(str));
}
}
