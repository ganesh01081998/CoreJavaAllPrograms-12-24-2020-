package o3_12_2020;

import java.util.Scanner;

public class GivenStrngNumOrNot {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the number");
		String number = scan.next();
		System.out.println(isCheck(number));
	}
	static boolean isCheck(String number) {
		boolean b = false;
		int count = 0;
		String result = "";
		for (int index = 0; index < number.length(); index++) {
			char ch = number.charAt(index);
			if(Character.isDigit(ch)) {
				count ++;
			}
		}
		if(count == number.length()) {
			b = true;
		}
		
		return b;
	}
}
