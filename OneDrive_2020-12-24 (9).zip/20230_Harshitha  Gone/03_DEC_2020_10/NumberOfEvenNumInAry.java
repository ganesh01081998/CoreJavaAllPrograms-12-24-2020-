package o3_12_2020;

import java.util.Scanner;

public class NumberOfEvenNumInAry {
public static int getEvenCount(int arr[]) {
	int count = 0;
	for (int i = 0; i < arr.length; i++) {
		if(arr[i] % 2 == 0) {
			count++;
		}
	}
	return count;
	
}
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("enter size");
	int size = scanner.nextInt();
	System.out.println("enter elemnts");
	int array[] = new int[size];
	for (int i = 0; i < array.length; i++) {
		array[i] = scanner.nextInt();
	}
	System.out.println(getEvenCount(array));
}
}

