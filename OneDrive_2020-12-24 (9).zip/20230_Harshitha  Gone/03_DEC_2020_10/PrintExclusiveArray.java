package o3_12_2020;

import java.util.Scanner;

public class PrintExclusiveArray {
public static int [] print1(int n,int start , int end) {
	int array[] = new int[n];
	int k = 0;
	for (int i = start; i < end; i++) {
		array[k] = i;
		k++;
	}
	return array;
	
}
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("enter start");
	int start = scanner.nextInt();
	System.out.println("enter end");
	int end = scanner.nextInt();
	int n = end - start;
    int[] res = print1(n, start, end) ;
    for (int i = 0; i < res.length; i++) {
		System.out.println(res[i]);
	}
}
}
