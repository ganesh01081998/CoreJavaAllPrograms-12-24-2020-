package ojas.org.com;

import java.util.Scanner;

public class MultiplicationOfArrayElem {
public static String getMultiplies(int a[]) {
	String str = "";
	for(int i = 0 ; i < a.length;i++) {
		int k = a[i];
		str += getTable(k);
	}
	return str;
	
}
	public static String getTable(int num) {
		String str = "";
		for(int i = 1; i <= 10 ; i++){
			str += num +" * " + i + " = " +num * i+"\n";
		
		}
		return str;
		
	}	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter size"); 
		int size = scanner.nextInt();
		int a[] = new int[size];
		System.out.println("enter elements");
		for(int i = 0;i < a.length;i++) {
			a[i] = scanner.nextInt();
		}
		System.out.println(getMultiplies(a));
	}
}
