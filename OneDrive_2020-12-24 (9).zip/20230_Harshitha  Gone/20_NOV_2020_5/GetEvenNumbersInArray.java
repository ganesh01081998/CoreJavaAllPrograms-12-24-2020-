package ojas.org.com;

import java.util.Scanner;

public class GetEvenNumbersInArray {
	public static int[] getEvenArray(int [] array) {	
		int evenArray[] = new int[array.length];
		int k = 0;
		int count = 0;
		for(int i = 0;i < array.length;i++) {
			if(array[i] % 2 == 0) {
				count++;
				evenArray[k] = array[i];
				k++;
			}
		}
		dispElements(evenArray);
		return evenArray;
	}
static void dispElements(int marks[]) {
		for(int num : marks) {
			System.out.println(num);
		}
	}
	public static String size(int size) {
		String res = "";
		if(size != 10) {
			res += null;	
		}
		return res;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter size");
		int size = scanner.nextInt();
		System.out.println(size(size));
		System.out.println("enter elements");
		int array1[] = new int[size];	
		for(int i = 0;i < array1.length;i++) {
			array1[i] = scanner.nextInt();
		}
		getEvenArray(array1);
	}
}
