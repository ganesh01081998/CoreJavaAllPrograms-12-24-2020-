package ojas.org.com;

import java.util.Scanner;

public class OccurenceCounterArray {
	public static int getCount(int []inputArray, int givenNumber) {
		int count = 0;
int k = 0;
		for(int i = 0 ; i < inputArray.length;i++) {
			if(inputArray[i] < 0) {
				 k=inputArray[i]*-1;
				inputArray[i] = k;
			}
			System.out.println(inputArray[i]);
			if(inputArray[i] == givenNumber) {

				count++;

			}
		}
		return count;	
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter size");
		int size = scanner.nextInt();
		int []a = new int[size];
		System.out.println("enter elements");
		for(int i = 0; i < a.length; i++) {
			a[i] = scanner.nextInt();
		}
		System.out.println("enter number");
		int num = scanner.nextInt();
		System.out.println("number of " + num + "' is "+getCount(a,num));
	}
}
