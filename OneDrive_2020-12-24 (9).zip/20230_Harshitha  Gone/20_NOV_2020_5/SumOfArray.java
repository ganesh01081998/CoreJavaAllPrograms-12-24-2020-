package ojas.org.com;

import java.util.Scanner;

public class SumOfArray {
public static int getSum(int a[]) {
	int sum = 0;
	for(int i = 0; i < a.length;i++) {
		sum += a[i];
		}
	return sum;
}
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("enter size");
	int size = scanner.nextInt();
	int a[] = new int[size];
	for(int i = 0;i < a.length;i++) {
		a[i] = scanner.nextInt();
	}
	System.out.println("sum of array elements is "+getSum(a));
}
}
