package ojas.org.com;

import java.util.Scanner;

public class OddNumberCounterArray {
	public static int getCount(int a[]) {
		int count = 0;
		for(int i = 0; i < a.length; i++) {
			if(isOdd(i)) {
				count++;
			}
		}
		return count;
	}
	public static boolean isOdd(int a) {
		boolean b = false;
		if(a % 2 != 0) {
            b = true;
		}
		return b;
	}
	public static String acceptSize(int size) {
		String res = "";
		if(size != 10) {
			res += "nul";
			
		}
		return res;
	}
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("enter size");
	int size = scanner.nextInt();
	System.out.println(acceptSize(size));
	int []a = new int[size];
	System.out.println("enter elements");
	for(int i = 0; i < a.length; i++) {
		a[i] = scanner.nextInt();
	}
	
	System.out.println("number of odd numbers is " + getCount(a));
}
}
