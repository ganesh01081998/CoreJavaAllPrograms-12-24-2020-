package _21_12_2020;

public class LeaveQuotaExceededException extends RuntimeException{
public LeaveQuotaExceededException(String s1) {
	super(s1);
}
}
