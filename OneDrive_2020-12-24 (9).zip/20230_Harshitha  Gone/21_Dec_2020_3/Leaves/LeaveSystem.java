package _21_12_2020;

import java.util.Scanner;

public class LeaveSystem {
	 int leaves;

	public LeaveSystem(int leaves) {
		this.leaves = leaves;
	}
	public void getLeaves() {
		if(leaves < 20) {
			System.out.println("your leaves are sanctiond! enjoy you leaves");
		}
		else {
			throw new LeaveQuotaExceededException("your leaves are exceed");
		}
	}
	public static void main(String[] args) {
     Scanner sc = new Scanner(System.in);
     System.out.println("enter number of leaves you want");
     int leaves = sc.nextInt();
     LeaveSystem l = new LeaveSystem(leaves);
     l.getLeaves();
	}
}
