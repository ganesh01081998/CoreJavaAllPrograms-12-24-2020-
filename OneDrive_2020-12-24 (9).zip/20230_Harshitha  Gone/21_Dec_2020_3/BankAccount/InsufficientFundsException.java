package _21_12_2020;

public class InsufficientFundsException extends RuntimeException{
public InsufficientFundsException(String s1) {
	super(s1);
}
}
