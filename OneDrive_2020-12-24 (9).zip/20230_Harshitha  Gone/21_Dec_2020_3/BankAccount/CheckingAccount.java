package _21_12_2020;

public class CheckingAccount {
	int accNo;
	double bal = 0;
	public CheckingAccount(int accNo) {
		this.accNo = accNo;
	}
	public boolean checkAccount(int accountNo) {
		boolean f = false;
		if(accountNo == accNo) {
			f = true;
		}
		return f;
	}
	public void deposit(int amount) {	
		bal = bal + amount;
		System.out.println("your account is added " + bal + " /- ");	
	}
	public void withdraw(int amount)  {
		double balence = 2000;	
		try {
			if(balence < amount  ) {
				throw new InsufficientFundsException("low balence and withdraw sufficient balence");
			}
			else {
				balence = balence - amount;
				System.out.println("remaing balence is " + balence);
			}
		}
		catch(InsufficientFundsException c) {
			c.printStackTrace();
			System.out.println(c.getMessage());
		}
		System.out.println("available balence is " + balence);
	}

}




