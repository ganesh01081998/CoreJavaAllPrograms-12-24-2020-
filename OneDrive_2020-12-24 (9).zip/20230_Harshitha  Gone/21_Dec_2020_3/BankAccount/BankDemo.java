package _21_12_2020;

import java.util.Scanner;

public class BankDemo {
	public static void main(String[] args)  {		
		Scanner sc = new Scanner(System.in);
		System.out.println("enter account number");
		int acc = sc.nextInt();
		CheckingAccount c1 = new CheckingAccount(acc);
		System.out.println("enter account number for transactions");
		int acc1 = sc.nextInt();
		String s = "choose option\n";
		s += "1.deposite\n";
		s += "2.withdraw\n";
		System.out.println(s);
		System.out.println("enter option");
		int option = sc.nextInt();
		switch(option) {
		case 1: if(c1.checkAccount(acc1)) {
			System.out.println("amount to deposite");
			c1.deposit(sc.nextInt());   			
		}
		break;
		case 2:
			if(c1.checkAccount(acc1)) {
				System.out.println("amount to withdraw");
				c1.withdraw(sc.nextInt());
			}
			break;
		default :
			System.out.println("inavalid account number");
		}
	}
}
