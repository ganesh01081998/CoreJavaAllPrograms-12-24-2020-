package ojas.strings.com;

import java.util.Scanner;

public class WavedString {
	public static String getWeavedString(String str1 , String str2) {
		String res = "";

		int j =0 , i = 0;
		char ch1 = 0, ch2 = 0;
		int value1 = str1.length();
		int value2 = str2.length();
		if(value1 > value2) {
			res += str2 + str1 + str2;
			return res;
		}
		else if(value1 < value2) {
			res += str1 + str2 + str1;
			return res;
		}

		else if(value1 == value2) {
			for( i = 0; i < str1.length(); i++) {
				int count = 0;
				for( j = 0; j <= i; j++) {
					if(str1.charAt(i) == str2.charAt(j)) {
						count++;	
					}
				}
				if(count <= 1) {
					res += str1.charAt(i)+""+ str2.charAt(i);



				}
			}
		}
		return res;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter first string");
		String str1 = scanner.next();
		System.out.println("enter second string");
		String str2 = scanner.next();
		System.out.println(getWeavedString(str1, str2));
	}
}
