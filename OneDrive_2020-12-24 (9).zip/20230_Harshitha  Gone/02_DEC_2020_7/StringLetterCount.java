package ojas.strings.com;

import java.util.Scanner;

public class StringLetterCount {
public static int getCountYZ(String str) {
	int count = 0;
	String ar[] = str.split(" ");
	for (int i = 0; i < ar.length; i++) {
		if(!Character.isLetter(ar[i].length()-1) || ar[i].charAt(ar[i].length()-1) == 'z' || ar[i].charAt(ar[i].length()-1) == 'y'  ) {
			 {
				count++;
			}
		}
	}
	
	return count;
}
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("enter string");
	String str = scanner.nextLine();
	System.out.println(getCountYZ(str));
}
}
