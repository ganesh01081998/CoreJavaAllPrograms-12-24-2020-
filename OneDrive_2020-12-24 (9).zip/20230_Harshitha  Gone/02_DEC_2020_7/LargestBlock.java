package ojas.strings.com;

import java.util.Scanner;

public class LargestBlock {
	static int maxBlock(String str) {
		int count = 0,tmpcount=0;
		
		if (str.length() == 0) {
			return 0;
		}
			for (int i = 0; i <str.length();i++) {
				char ch = str.charAt(i);			
				 tmpcount = 0;
				for (int j = 0; j < str.length(); j++) {
					char ch1 = str.charAt(j);
				if (ch == ch1){
					tmpcount++;
					
				}
				}
				
				if(count < tmpcount) {
					 count = tmpcount;
					
				}
			}
			return tmpcount;
				
				
		}
		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			System.out.println("enter the string");
			String str = sc.next();
			System.out.println(maxBlock(str));
		}
}
