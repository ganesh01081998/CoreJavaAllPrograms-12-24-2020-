package ojas.strings.com;

import java.util.Scanner;

public class NumberOfDigits {
public static int getCount(int arr[], int num) {
	
	int count = 0;
	for (int i = 0; i < arr.length; i++) {
		if(arr[i] == num) {
			count++;
		}
		
		
	}
	return count;	
}
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("enter size");
	int size = scanner.nextInt();
	System.out.println("enter elments");
	int array[] = new int[size];
	for (int i = 0; i < array.length; i++) {
		array[i] = scanner.nextInt();
	}
	System.out.println("enter search number");
	int num = scanner.nextInt();
	System.out.println("number of " + num + "' s are " + getCount(array, num));
}
}
