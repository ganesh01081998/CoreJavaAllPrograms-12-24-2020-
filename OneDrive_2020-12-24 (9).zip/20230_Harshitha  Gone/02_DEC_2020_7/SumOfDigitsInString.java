package ojas.strings.com;

import java.util.Scanner;

public class SumOfDigitsInString {
	public static int getSum(String str) {
		String str1 = "";
		int sum = 0;
		for (int i = 0; i < str.length(); i++) {
			char ch = str.charAt(i);
			if(Character.isDigit(ch)) {
				str1 += ch;
			}
		}
		int num = Integer.parseInt(str1);
		while(num > 0) {
			int temp = num % 10;
			sum = sum + temp;
			num = num / 10;
		}
		return sum;
		
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter string");
		String str = scanner.next();
		System.out.println("sum of digits in string " +getSum(str));
	}
}
