package ojas.strings.com;

import java.util.Scanner;

public class SumOfDaignolElements {
public static int getDaignoalSum(int arr[][]) {
	int sum = 0;
	for (int i = 0; i < arr.length; i++) {
		for (int j = 0; j < arr.length; j++) {
			if(arr[i] == arr[j]) {
				sum = sum + arr[i][j];
			}
		}
	}
	return sum;	
}
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("enter number of rows");
	int rows = scanner.nextInt();
	System.out.println("enter number of coloumns");
	int colums = scanner.nextInt();
	if(rows != 3 && colums != 3) {
		System.out.println("-1");
	}
	else {
	System.out.println("enter elements");
	int array[][] = new int[rows][colums];
	for (int i = 0; i < array.length; i++) {
		for (int j = 0; j < array.length; j++) {
			array[i][j] = scanner.nextInt();
		}
	}
	for (int i = 0; i < array.length; i++) {
		for (int j = 0; j < array.length; j++) {
			System.out.print(array[i][j]+ " ");
		}
		System.out.println();
		}
	
	System.out.println("sum of diagnoal elements is " + getDaignoalSum(array));

}
}
}
