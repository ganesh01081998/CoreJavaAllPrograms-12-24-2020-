package com.ojas.BankAccount;

import java.util.Scanner;

public class Account {

	Customer cust;
	double balance;
	int accountNo;
	float rate;
	static Scanner sc = new Scanner(System.in);
	public Account(Customer cust, double balance, int accountNo, float rate) {
		this.cust = cust;
		this.balance = balance;
		this.accountNo = accountNo;
		this.rate = rate;
	}


	@Override
	public String toString() {
		return "Account [cust=" + cust + ", balance=" + balance + ", accountNo=" + accountNo + ", rate=" + rate + "]";
	}

	public  String dispMenu() {
		String menu = "1.Deposit\n2.Withdraw\n3.exit";
		return menu;
	}

	public void depositAmt(int accno,double amountdep) {
	
		System.out.println("confirm your account Number");
		if(accno == sc.nextInt()) {
			balance +=amountdep;	
			System.out.println(amountdep+" rs Credited Successfully.The available balance"+balance);
		}
		else {
			System.out.println("Invalid account number");
		}
	}

	public void withdrawAmt(int accno,double amountwd) {
		
		System.out.println("Confirm your account Number");
		if(accno == sc.nextInt()) {
			balance = balance - amountwd;
			System.out.println(amountwd+" rs Debited Successfully.The available balance"+balance);
		}
		else {
			System.out.println("Invalid account number");
		}
	}
	

	public static void main(String[] args) {
		System.out.println("Enter your FirstName & LastName");
		Customer c = new Customer(sc.next(),sc.next());
		System.out.println("Enter the Account Number");
		int accno = sc.nextInt();
		Account ac = new Account(c,10000,accno,7);
		System.out.println(ac); 
		while(true) {
			System.out.println(ac.dispMenu());
			int choice = sc.nextInt();
			switch(choice) {
			case 1:
				System.out.println("Enter the deposit amount");
				double amountdep = sc.nextDouble();
				ac.depositAmt(accno,amountdep);
                 break;
			case 2:
				System.out.println("Enter the withdraw amount");
				double  amountwd = sc.nextDouble();
				ac.withdrawAmt(accno,amountwd);
				break;
			case 3:
				System.out.println("Thank you");
				System.exit(0);
			default :
				System.out.println("Enter valid input");
				System.exit(0);
			}

		}
	}
}

