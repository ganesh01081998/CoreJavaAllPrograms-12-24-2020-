package com.ojas.Programs10122020;

import java.util.Scanner;

public class Student   {
	int sno;
	String sname;
	String sbranch;
	Addres addrs;
	Course crse;
	public Student(int sno, String sname, String sbranch, Addres addrs,Course crse) {
		this.sno = sno;
		this.sname = sname;
		this.sbranch = sbranch;
		this.addrs = addrs;
		this.crse = crse;
	}

	
	@Override
	public String toString() {
		return "Student [sno=" + sno + ", sname=" + sname + ", sbranch=" + sbranch + ", addrs=" + addrs + ", crse="
				+ crse + "]";
	}


	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the student no,name, branch");
		int sno = sc.nextInt();
		String sname = sc.next();
		String sbranch= sc.next();
		System.out.println("enter the student house no,,colony,city");
		String hno =  sc.next();
		String colName = sc.next();
		String cityName = sc.next();
		String cname="",cDuration="";
		double cost=0;
		String menu = "select any one of the course \n 1. Java \n 2. Testing \n 3. Python \n 4.Java + Testing \n 5.Java + Python \n 6.Java + Testing + Python \n 7.Exit \n";
		System.out.println(menu);
		System.out.println("Choose u course any one of the above");
		int n =sc.nextInt();	
		if(n ==1) {
             cname = "Java";
             cDuration = "4 months";
             cost = 12000;
		}
		else if(n == 2) {
			cname = "Testing";
            cDuration = "4 months";
            cost = 10000;
		}
		else if (n == 3 ) {
			cname = "Python";
            cDuration = "4 months";
            cost = 12000;
		}
		else if( n == 4 ) {
			cname = "Java + Testing";
            cDuration = "5 months";
            cost = 20000;
		}
		else if( n == 5 ) {
			cname = "Java + Python";
            cDuration = "5 months";
            cost = 25000;
		}
		else if( n == 6 ) {
			cname = "Java + Testing + Python";
            cDuration = "6 months";
            cost = 30000;
		}
		else if( n == 7 ) {
			System.exit(0);
		}
		else {
			System.out.println("plz choose the valid option");
		}
		
		Addres a = new Addres(hno, colName, cityName);
		Course c = new Course(cname,cDuration,cost);
		Student s = new Student(sno, sname, sbranch, a, c);
		System.out.println(s);

		//System.out.println(a.toString());
	}


}
