package com.ojas.Programs10122020;

public class Addres {
	private String hno;
	private String colName;
	private String cityName;
	public Addres(String hno, String colName, String cityName) {
		this.hno = hno;
		this.colName = colName;
		this.cityName = cityName;
	}
	@Override
	public String toString() {
		return "Addres [hno=" + hno + ", colName=" + colName + ", cityName=" + cityName + "]";
	}
	
}
