package seven.dec;

import java.util.Scanner;

public class ThirteenSum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Scanner scr = new Scanner(System.in);
     System.out.println("Enter 3 numbers");
     luckySum(scr.nextInt(),scr.nextInt(),scr.nextInt());
	}
	static void luckySum(int num1,int num2,int num3) {
		int sum = 0;
	if(num1 == 13) {
		sum = sum;
	}
	else if(num2 == 13) {
		sum = sum + num1;
	}
	else if(num3 == 13) {
		sum = sum + num1 + num2;
	}
	else {
		sum = sum + num1 + num2 + num3;
	}
	System.out.println(sum);
	}
}
