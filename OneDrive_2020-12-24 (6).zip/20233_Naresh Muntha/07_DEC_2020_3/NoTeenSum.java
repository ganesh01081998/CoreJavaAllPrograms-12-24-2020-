package seven.dec;

import java.util.Scanner;

public class NoTeenSum {

	public static void main(String[] args) {
		// TODO Auto-generated method stu
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter any three values ");
		int first = scan.nextInt();
		int second = scan.nextInt();
		int three = scan.nextInt();
		System.out.println(check(first, second, three));
	}
	static int check(int num1, int num2, int num3) {
		int sum = 0;
		sum += fixTeen(num1);
		sum += fixTeen(num2);
		sum += fixTeen(num3); 
		return sum;
	}
	static int fixTeen(int num) {
		if((num >= 13 && num<= 14)||(num >= 17 && num<= 19)) {
			return 0;
		}
		else {
			return num;
		}
	}
}
