package org.neww;

import java.util.Scanner;

public class RecursiveInsertionSort {
public static void main(String[] args) {
		
		Scanner scr = new Scanner(System.in);
		System.out.println("enter the size");
		int size = scr.nextInt();
			int []arr = new int[size];
			System.out.println("enter the array elements");
			for(int i = 0 ; i < arr.length; i++){
				 arr[i] = scr.nextInt();
			}
	       
	       insertionSortRecursive(arr, arr.length); 
	       for(int x : arr){
	    	   System.out.println(x);
	       }
	}
	static int insertionSortRecursive(int arr[], int n) {
	       
        if (n <= 1) 
            return n; 
        insertionSortRecursive( arr, n-1 ); 
       
        int last = arr[n-1]; 
        int j = n-2; 
       
        while (j >= 0 && arr[j] > last) 
        { 
            arr[j+1] = arr[j]; 
            j--; 
        } 
        return arr[j+1] = last;
    } 

	
}
