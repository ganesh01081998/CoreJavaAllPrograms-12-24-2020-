package dec.third;

import java.util.Scanner;

public class CharCiuntA {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string");
		String str = sc.nextLine();
		System.out.println("Enter any character for count");
		String ch = sc.nextLine();
		System.out.println(countOccurances(str,ch));
	}
	static String countOccurances(String str,String ch){
		String result = "";
			char ch1 = ch.charAt(0);
		int count = 0;
		for(int i = 0; i < str.length(); i++ ){  
          if(ch1 == str.charAt(i)){
		   count ++;
		   }	
		}
		result +=ch+" = "+count; 

		return result;
	}

}
