package dec.third;

import java.util.Scanner;

public class IsNumOrNot {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the String");
		String num = scan.next();
		isNumbOrNot(num);
	}
static void isNumOrNot(String num) {
		int count = 0;
		for (int i = 0; i < num.length(); i++) {
			char ch = num.charAt(i);
			boolean b = Character.isDigit(ch);
			if(b) {
				count ++;
			}
		}
		if(count == num.length()) {
			System.out.println("The Given String is integer");
		}
		else {
			System.out.println("It is String not a integer");
		}
	}
	
	
}
