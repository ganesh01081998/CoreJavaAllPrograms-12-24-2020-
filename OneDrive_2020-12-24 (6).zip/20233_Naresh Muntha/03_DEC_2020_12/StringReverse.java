package org.assaignment;

import java.util.Scanner;

public class StringReverse {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);		
		String name = sc.nextLine();
		String nameSpit [] = name.split(" ");
		String revStr[] = new String[nameSpit.length];
		for(int i = 0;i < nameSpit.length;i++) {
			revStr[i] = getReverse(nameSpit[i]);
		}		
		for(String res : revStr) {
			System.out.print (res + " ");
		}
		
	}
	static String getReverse(String str) {
//		 str ="java is a programming language";
//		 String result ="";
//		//StringBuffer result = new StringBuffer(str);
//		return result.reverse().toString();
		
		String res = "";
		for(int i =str.length()-1;i >=0;i--) {
			res +=str.charAt(i);
		}
		return res; 
	}
    }
