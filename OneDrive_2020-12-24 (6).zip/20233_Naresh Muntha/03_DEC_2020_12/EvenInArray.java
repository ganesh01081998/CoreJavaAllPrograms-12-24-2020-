package dec.third;

import java.util.Scanner;

public class EvenInArray {
		static String result = "";
		public static void main(String[] args) {
			createArray();
		}
		static void createArray(){	
			System.out.println("Enter Array size");
			Scanner sc = new Scanner(System.in);
			int size = sc.nextInt();
			int []inputArray = new int[size];
			for(int i = 0; i < size;i++){
				inputArray[i] = sc.nextInt(); 
			}	
			
				System.out.println(evens(inputArray));
		}
		static String evens(int odd[]) {
			int count = 0;
			System.out.println("evens are");
			for(int i = 0;i < odd.length; i++){
				if( odd [i] % 2 == 0){
					count++;
				}
			}
			return  result += count;
		}
	}


