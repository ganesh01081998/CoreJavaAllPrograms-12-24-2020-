package dec.third;

import java.util.Scanner;

public class StudentMarks {
	int sno;
	String sname;
	int marks1,marks2,marks3,marks4,marks5;
	
	
	StudentMarks(int sno, String sname,int marks1, int marks2, int marks3,int marks4,int marks5) {
		this.sno = sno;
		this.sname = sname;
		this.marks1 = marks1;
		this.marks2 = marks2;
		this.marks3 = marks3;
		this.marks4 = marks4;
		this.marks5 = marks5;
		
		int total = marks1 + marks2 + marks3 + marks4 + marks5;
		System.out.println(total);
		int avg = (total / 5);
		//System.out.println(avg);
		
		 if(avg >= 75) {
             System.out.println( "you got distinction");
         }
         else if(avg >= 65) {
             System.out.println("you got first calss");
         }
         else if(avg >= 50) {
             System.out.println( "you got second class");;
         }
         else if(avg >= 40) {
        	 System.out.println("You got third class");
         }
         else if(avg >= 35) {
        	 System.out.println("you just passed! enjoy");
         }
         
         else {
             System.out.println("failed! Try again ");
         }
	}
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("enter the student details sno , name , marks in 5 subjects");
		StudentMarks st = new StudentMarks(scn.nextInt(),scn.next(),scn.nextInt(),scn.nextInt(),scn.nextInt(),scn.nextInt(),scn.nextInt());
		}
	 
	String dispDetails() {
		return sno + " " + sname  + " " + marks1 + " " + marks2 + " " + marks3 + " " + marks4 + " " +marks5;
	}

	

}
