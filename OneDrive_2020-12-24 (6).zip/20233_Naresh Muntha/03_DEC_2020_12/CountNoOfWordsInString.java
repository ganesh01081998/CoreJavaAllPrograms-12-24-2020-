package dec.third;

import java.util.Scanner;

public class CountNoOfWordsInString {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Scanner scr =  new Scanner(System.in);
	countWords(scr.nextLine());
	}
	static void countWords(String sentence){
		String[] senArry = sentence.split(" ");
		System.out.println("Words in the given sentence is "+senArry.length);
	}
}
