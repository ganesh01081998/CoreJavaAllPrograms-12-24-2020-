package dec.third;

import java.util.Random;

public class Dice {

	int faceValue;
	public void roll() {
		Random r = new Random();
		faceValue = r.nextInt(6) + 1;
	}

}
