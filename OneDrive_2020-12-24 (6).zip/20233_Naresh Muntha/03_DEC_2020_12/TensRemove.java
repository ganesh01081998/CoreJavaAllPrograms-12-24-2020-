package dec.third;

import java.util.Arrays;
import java.util.Scanner;

public class TensRemove {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Array Size");
		int [] arr = new int[sc.nextInt()];
		System.out.println("Enter Array Elements");
		for (int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		removeTens(arr);
	}
	static void removeTens(int[] arr) {
		int num = 0;
		//int arr2 [] = new int [arr.length];
		for (int i = 0; i < arr.length; i++) {
			if(arr[i] % 10 == 0){
			arr[i] = 0;	
			}
		}
		Arrays.sort(arr);
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}	
	}
	
	
}
