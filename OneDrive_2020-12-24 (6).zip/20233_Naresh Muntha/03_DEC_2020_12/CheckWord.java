package dec.third;

import java.util.Scanner;

public class CheckWord {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the sentence");
		String str = sc.nextLine().toLowerCase();
		System.out.println("Enter Word To Find...");
		String str1 = sc.next().toLowerCase();
		getFindWord(str,str1);
	}
	static void getFindWord(String str,String str1) {
		String[] sentence = str.split(" ");
		for (int i = 0; i < sentence.length; i++) {
			if(str1.equals(sentence[i])) {
				System.out.println(str1 + " is Found"); 
			}
		}
	}

	
}
