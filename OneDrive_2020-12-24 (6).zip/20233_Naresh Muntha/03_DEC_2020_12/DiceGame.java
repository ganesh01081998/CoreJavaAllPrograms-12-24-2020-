package dec.third;

import java.util.Scanner;

public class DiceGame {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scn = new Scanner(System.in);
		Dice d1 = new Dice();
		Dice d2 = new Dice();
		
		System.out.println("Enter First player name");
		Player p1 = new Player(scn.next());
		System.out.println("Enter second player name");
		Player p2 = new Player(scn.next());
		p1.throwDice(d1, d2);
		p2.throwDice(d1, d2);
		
		String res ="";
		if(p1.playerValue > p2.playerValue) {
			res = p1.pname + " wons the game";
		}
		else if(p1.playerValue < p2.playerValue) {
			res = p2.pname + " wons the game";
		}
		else if(p1.playerValue ==  p2.playerValue) {
			res = "Game Tie";
		}
		else {
			res = "Pls Try Again Later";
		}
		System.out.println(res);
	}
	}

