package dec.third;

import java.util.Scanner;

public class SumOfDigits {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Number");
        System.out.println(sumOfDigits(sc.nextInt()));
	  }
   static int sumOfDigits(int num){
	   int sum = 0,rem;
	   while(num > 0){
			  rem = num % 10;
			  sum = sum +  rem;
			  num = num / 10;
		   }
     System.out.println(sum); 
    return 0;
   }
}
