package dec.third;

public class Player {

	String pname;
	int playerValue;
	
	public Player(String pname) {
		this.pname = pname;
		
	}
	public void throwDice(Dice d1, Dice d2) {
		d1.roll();
		d2.roll();
		playerValue = d1.faceValue + d2.faceValue;
		System.out.println(playerValue + " = " + d1.faceValue + " + " + d2.faceValue);
	}
}
