package org.neww;

import java.util.Scanner;

public class StringRevWithOutPreDefined {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the String : ");
		String name = scanner.next();		
		System.out.println(getReverseString(name));
	}
	static String getReverseString(String name) {
		String result ="";
		for(int i = name.length() - 1;i >= 0;i--){
			result += name.charAt(i);
		}
		return result;
	}
}
