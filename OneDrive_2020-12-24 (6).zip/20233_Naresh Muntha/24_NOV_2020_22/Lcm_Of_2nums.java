package org.ojas;

import java.util.Scanner;

public class Lcm_Of_2nums {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter 2 nubers");
		Scanner scn = new Scanner(System.in);
		System.out.println(gcd(scn.nextInt(),scn.nextInt()));
	}
	static int gcd(int n1,int n2){
		int result = 0;
		if(n1 > 0 && n2 > 0){
		   int lcm;
		    lcm =(n1 > n2) ? n1 : n2;
				while(true){
					if(lcm % n1 == 0 && lcm % n2 == 0){
						result = lcm;
						break;
					}
					lcm++;
				}
		}
		else{
			result = -1;
		}
		return result;
	}

}
