package org.assaignment;

import java.util.Scanner;

public class FindConsonents {

	
		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter name");
			String name = sc.next();
			System.out.println(findConsonents(name));
		}

		static String findConsonents(String name) {
			String result = name.toUpperCase();
			String consonents = "";
			System.out.println("consonents in the given name");
			for (int i = 0; i < result.length(); i++) {
				char ch = result.charAt(i);
				if(ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U' ) {
					 continue;
				}
				else {
					consonents += ch + " " ;
				}
			}
			return consonents;
		}
	
}
