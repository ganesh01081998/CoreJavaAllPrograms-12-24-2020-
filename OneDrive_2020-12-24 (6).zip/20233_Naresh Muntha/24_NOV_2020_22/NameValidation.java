package org.assaignment;

import java.util.Scanner;

public class NameValidation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scr = new Scanner(System.in);
		System.out.println(checkValid(scr.nextLine()));
	}
	static String checkValid(String name){
		String result = "";
		char[] nameArray = name.toCharArray();
		for(int i1 = 0 ;i1 < nameArray.length;i1++){
			for(char i = 'a'; i <= 'z' ; i++){
			if(i == name.charAt(i1)){
				continue;
		   }
			else{
				result += "Given Name is Not valid ";
			i1 =nameArray.length+1;
			}
		  }
		}
		return result;
	}

}
