package org.assaignment;

import java.util.Scanner;

public class CollarzSeq {

	static String result ="";
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter any number");
		int number = scan.nextInt();
		if(number < 0) {
			result = "Error";
		}
		else {
			isCollarzSequence(number);
		}
		System.out.println(result);
	}

	static String isCollarzSequence(int number) {
		while (number != 1) { 
			result = result + number + " "; 
			if ((number & 1) == 1) {
				number = (3 * number) + 1; 
			}
			else {
				number = number / 2;
			}
		} 
		result = result + number ; 
		return result;
	} 
}
