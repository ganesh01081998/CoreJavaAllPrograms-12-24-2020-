package org.assaignment;

import java.util.Scanner;

public class SortArrayElements {

	public static void main(String[] args) 
    {
        Scanner scn = new Scanner(System.in);
        System.out.print("Enter array Size: ");
        int count = scn.nextInt();
        int num[] = new int[count];
        System.out.println("Enter "+count+"array elements:");
        for (int i = 0; i < count; i++) 
        {
            num[i] = scn.nextInt();
        }
        scn.close();
        int result [] = sortArray(num);
       for(int x : result){
    	   System.out.println(x);
       }
    }
	static int[] sortArray(int []array){
		int count, temp;
        for (int i = 0; i < array.length; i++) 
        {
            for (int j = i + 1; j < array.length; j++) { 
                if (array[i] > array[j]) 
                {
                    temp = array[i];
                    array[i] = array[j];
                    array[j] = temp;
                }
            }
        }
		return array;
       
    }

}
