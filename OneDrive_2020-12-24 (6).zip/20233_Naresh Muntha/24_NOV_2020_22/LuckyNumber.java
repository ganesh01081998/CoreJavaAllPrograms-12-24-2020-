package org.assaignment;

import java.util.Scanner;

public class LuckyNumber {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter DOB in the form of DD-MON-YEAR");
		String str = sc.nextLine();
		getLuckyNumber(str);
        }
		static void getLuckyNumber(String str){
		String month = str.substring(3,6);
		String monthnum = getMonthDays(month);
		String finalDd = str.replaceAll(str.substring(3,6), monthnum);
		String finalDd1 = finalDd.replaceAll("-", "0");
		int num = Integer.parseInt(finalDd1);
		System.out.println("your lucky number is "+getNum(num));
		}
	        static int getNum(int num){
	        	int rem,sum = 0;
	        	while(num > 0){
	        rem = num % 10;
	        sum = sum + rem;
	        num = num / 10;
	        }
	        	if(sum >= 10){
	        		sum =getNum(sum);
	        }
	        	return sum;
		}
	static String getMonthDays(String str) {
		String result = "";
		String [] monthNames = {"month","jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec"};
		
		for(int i = 0;i < monthNames.length;i++) {
			if(str .equals(monthNames[i])) {
			 result += i; 
			}
		}
		return result;
	}
}


