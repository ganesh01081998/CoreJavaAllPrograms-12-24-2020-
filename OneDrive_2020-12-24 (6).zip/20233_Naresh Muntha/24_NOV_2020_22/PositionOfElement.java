package org.neww;

import java.util.Scanner;

public class PositionOfElement {
	static int getElementPosition(int arr[],int searchElement) {
		for(int i = 0;i < arr.length;i++) {
			if(searchElement == arr[i]) {
				return i;
			}
		}
		return -1;			
	}		
	

	public static void main(String[] args) {
		storeElement();
	}
	static int storeElement(){
		int result = 0; 
		Scanner scr = new Scanner(System.in);
		System.out.println("Enter the Size : ");
		int size = scr.nextInt();		
		int arr[] =new int[size];	
		if(size == 0) {
			result = -2;
		}
		System.out.println("Enter the array elements : ");
		for(int i = 0;i < arr.length;i++) {
			arr[i] = scr.nextInt();
			if(arr[i] <= 0) {
				result =-4;						
			}				
		}
		System.out.println("Enter the Search Element :");
		int searchElement = scr.nextInt();
		if(searchElement <= 0) {
			result  = -3;
		}
		else{
		System.out.println(getElementPosition(arr, searchElement));
		}
		return result;
}
}
