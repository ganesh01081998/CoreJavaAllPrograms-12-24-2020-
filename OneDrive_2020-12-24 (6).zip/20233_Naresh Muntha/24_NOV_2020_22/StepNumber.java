package org.neww;

import java.util.Scanner;

public class StepNumber {
	static boolean answer = true;
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter any number");
		int number = scan.nextInt();
		isdiffaarence1(number);
		System.out.println(answer);
	}
	static void isdiffaarence1(int number) {
		int temp, count = 0, rev = 0;

		temp = number;
		while (temp > 0) {
			rev = temp % 10;
			count++;
			temp = temp / 10;
		}
		int [] array = new int[count];
		temp = number;
		while(temp > 0) {
			array[count-1] = temp % 10;
			temp = temp / 10;
			count --;
		}
		stepNumber(array, rev);
	}
	static void stepNumber(int[] array, int rev) {
		if(array[0] > array[array.length-1]) {
			rev = array[0] -1;
			for (int i = 1; i < array.length; i++) {
				if(rev != array[i]) {
					answer = false;
				}
				rev = array[i] - 1;
			}
		}
		else {
			rev = array[0] +1;
			for (int i = 1; i < array.length; i++) {
				if(rev != array[i]) {
					answer = false;
				}
				rev = array[i] + 1;
			}
		}
	}
}
