package org.assaignment;

public class CountOccurance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(countOccurances("narasah"));
	}
	static String countOccurances(String str){
		String result = "";
		int count = 0;
		for(int i = 0; i < str.length(); i++ ){
			char ch = str.charAt(i);  
		for(int j = 0; j < str.length(); j++){
			if(ch == str.charAt(j)){
			count++;
			}
		}
		result += ch+" = "+count+" ";
		count = 0;
		}
		return result;
	}
}
