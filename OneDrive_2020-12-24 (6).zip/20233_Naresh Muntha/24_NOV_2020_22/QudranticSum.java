package org.neww;

import java.util.Scanner;

public class QudranticSum {
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("enter any number");
		int num = scn.nextInt();
	System.out.println(getNthTerm(num));
		}
	static int getNthTerm( int num) {
		int sum = 1;
		for(int i =2 ;i <=num;i++) {
			sum +=i;
		}
		return sum;
	}

	

}
