package org.neww;

import java.util.Scanner;

public class PerfectNumber {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter an integer:");
		int num = sc.nextInt();
		System.out.println(sumOfProperDivisors(num));
	}
	static int sumOfProperDivisors(int num) {
		int result = 0;

		int sum = 0;
		if(num < 0){
			result = -2;
		}
		else if(num == 0){
			result = -3;
		}
		else if(num > 0){
			for (int i = 1; i < num; i++) {
				if (num % i == 0) {
					sum = sum + i;	
				}
			    }
		}
		
		if(sum == num)
		{
			result = 0;
		}
		else if(sum < num){
			result = -1;
		}
		else {
			result = 1;
		}
		 
		return result;
	}
	
}
