package org.assaignment;

import java.util.Scanner;

public class ThreeNegativeValuesArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scr = new Scanner(System.in);
		System.out.println("Enter Array size");
		int size = scr.nextInt();
		int []arra1 = new int[size];
		System.out.println("Enter "+size+" Array elements");
		for(int i = 0; i < size; i++){
			arra1[i] = scr.nextInt();
		}	
		System.out.println(findMax(arra1));
		}
	static int findMax(int []arra1){
		int count = 0,result = 0;
		for(int i = 0; i < arra1.length; i++){
			if(arra1[i] < 0){
				count++;
			}
		}	
		if(count == 3){
			result = 3;
		}
		return result;
	}
}
