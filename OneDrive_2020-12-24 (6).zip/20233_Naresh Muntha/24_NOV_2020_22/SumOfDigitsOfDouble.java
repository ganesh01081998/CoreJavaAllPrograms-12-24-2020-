package org.neww;

import java.util.Scanner;

public class SumOfDigitsOfDouble {
	public static void main(String[] args) {			
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the value :");
		double number = scanner.nextDouble();
		String str = "" + number;
		int indexPoint= str.indexOf(".");
		String decimalPart = str.substring(indexPoint + 1,str.length());
		String intPart = str.substring(0,indexPoint);
		int intNumber = Integer.parseInt(intPart);
		int aftPointNumber = Integer.parseInt(decimalPart);	
		concateSumOfDigits(getSumOfDigits(intNumber) ,getSumOfDigits(aftPointNumber));
		
	}						
	static int getSumOfDigits(int number) {
		int sum = 0,rem;		
		while (number >0) {
			rem = number % 10;
			sum += rem;
			number /= 10;
		}
		return sum;		
	}
	
	static void concateSumOfDigits(int number,int number2) {
		System.out.println(number + ":" + number2);
	}
	
	
	

}
