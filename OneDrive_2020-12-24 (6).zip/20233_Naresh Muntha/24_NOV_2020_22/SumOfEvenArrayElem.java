package org.neww;

import java.util.Scanner;

public class SumOfEvenArrayElem {
public static int arr(int arr[],int nega,int zero){
	int sum = 0;
	if(nega == 1){
		return -1;
	}
	else if(zero == 1){
		return -2;
	}
	else if(arr.length == 0){
		return 0;
	}
	else{
	
	for(int  i =0; i<arr.length;i++){
		if(arr[i]%2 == 0){
			sum +=arr[i];
		}
	}
	}
	return sum;
}
	public static void main(String[] args) {
		int nega = 0,zero = 0;;
	Scanner sc = new Scanner(System.in);
	System.out.println("enter array size");
	int size = sc.nextInt();
	int arra[] = new int[size];
	System.out.println("enter array elements");
	for(int i =0; i<size;i++ ){
		arra[i]= sc.nextInt();
		if(arra[i] < 0 ){
			nega++;
		}
		if(arra[i] == 0 ){
			zero++;
		}
	}
	
	int a = arr(arra,nega,zero);
	System.out.println(a);

	}
	

}
