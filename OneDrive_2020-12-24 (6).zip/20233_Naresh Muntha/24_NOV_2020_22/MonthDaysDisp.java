package org.assaignment;

import java.util.Scanner;

public class MonthDaysDisp {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter the Monthname as Three charrecter : ");
		String str = scanner.next();
		 str = str.toLowerCase();		
		System.out.println(str + " month has " + getMonthDays(str) + " days");		
	}
	static String getMonthDays(String str) {
		String result = "";
		String [] monthNames = {"jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec"};
		int monthDaysarr [] = {31,28,31,30,31,30,31,31,30,31,30,31};
		for(int i = 0;i < monthNames.length;i++) {
			if(str .equals(monthNames[i])) {
			 result += monthDaysarr[i]; 
			}
		}
		return result;
	}
	
	
	
}
