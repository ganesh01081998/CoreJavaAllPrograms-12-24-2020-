package org.neww;

import java.util.Scanner;

public class OddPalindrome {
	static int  lastDigit = 0;
	 static int  reverseNumber = 0;
	 static int temp,num;
	 public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter the Range : ");
			int start = sc.nextInt(), end =sc.nextInt();
			System.out.println(getOddPalindromeRange(start, end));
		}
static String getOddPalindromeRange(int start1,int end1) {
	     String result = "";
	     
	for(int i = start1; i <= end1; i++) {
		temp = i;
		num = i;
		while(num > 0) {
			lastDigit = num % 10;
			reverseNumber =reverseNumber *10 + lastDigit;
			num = num / 10;
		}
		if(reverseNumber == temp) {
			if(reverseNumber % 2 != 0) {
				result +=reverseNumber + " ";
			}
		}
		lastDigit = 0;
		reverseNumber = 0;
	}
	return  "Odd Palindrome numbers are "+result;
}



}
