package org.assaignment;

import java.util.Scanner;

public class AdamNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scr = new Scanner(System.in);
		System.out.println("Enter number");
		System.out.println(adamNum(scr.nextInt()));
	   }
		static String adamNum(int num){
		String res = "";
		int temp = num;
		int num1 = reverseOfnum(num);
		num = num * num;
		 num1 = num1 * num1;
		int revNum = reverseOfnum(num);
		 if(revNum == num1){
			 res += +temp+" is the adam number";
		 }
		 else{
			 res += +temp+" is the adam number";
		 }
		 return res;
	}
	static int reverseOfnum(int num){
		  int rev = 0;
		while(num > 0){
		int	rem = num % 10;
		rev = rev * 10 + rem;
	    num = num / 10;
		}
		return rev;
	}
}
