package org.neww;

import java.util.Scanner;

public class NameScore {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the word ");
		String str = sc.next();
		str = str.toLowerCase();
		System.out.println(getNameScore(str));
	}
	static int getNameScore(String str) {
		int sum = 0;
		for(int i = 0;i < str.length();i++) {
			int count = 1;
			for(char character = 'a';character <= 'z';character++) {
				if(str.charAt(i) == character) {
					sum += count;					
				}
				count++;
			}
		}
		return sum;
	}
	
}
