package org.assaignment;

import java.util.Scanner;

public class VowelsInString {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter name");
		String name = sc.next();
		System.out.println(findVowels(name));
	}

	static String findVowels(String name) {
		String result = name.toUpperCase();
		String vowels = "";
		System.out.println("Vowels in the given name");
		for (int i = 0; i < result.length(); i++) {
			char ch = result.charAt(i);
			if(ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U' ) {
				vowels += ch + " " ;
			}
		}
		return vowels;
	}

	
}
