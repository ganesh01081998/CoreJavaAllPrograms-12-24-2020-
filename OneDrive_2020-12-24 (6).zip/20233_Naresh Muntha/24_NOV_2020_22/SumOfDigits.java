package org.assaignment;

public class SumOfDigits {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(getSumOfDigits(23));
	}
	static int getSumOfDigits(int num){
		int sum = 0;
		while(num > 0){
			int	rem = num % 10;
			sum = sum + rem;
			num = num / 10;
		}
		return sum;
	}
}

