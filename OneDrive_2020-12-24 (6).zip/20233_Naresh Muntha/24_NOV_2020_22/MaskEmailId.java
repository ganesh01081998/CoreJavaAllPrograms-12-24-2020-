package org.assaignment;

import java.util.Scanner;
public class MaskEmailId {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scr = new Scanner(System.in);
	System.out.println("Enter Mail id :");
		String mail = scr.nextLine();
		System.out.println(createMask(mail));
        
	}
	static String createMask(String mail){
		String result ="";
		int num = mail.indexOf('@');
		result +=  mail.replace(mail.substring(num-3, num), "XXX") ;

		return result;
	}
	
	
	
	

}
