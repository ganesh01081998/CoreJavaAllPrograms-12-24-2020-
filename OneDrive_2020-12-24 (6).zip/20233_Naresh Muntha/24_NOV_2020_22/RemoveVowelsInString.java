package org.neww;

import java.util.Scanner;

public class RemoveVowelsInString {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter name");
		String name = sc.next();
		System.out.println(removeVowels(name));
	}

	static String removeVowels(String name) {
		String str = name.toUpperCase();
		String finalResult = "";
		
		for (int i = 0; i < str.length(); i++) {
			char ch = str.charAt(i);
			if(ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U' ) {
		
			}
			else{
				finalResult += ch;
			}
		}
		return "after removing vowels "+finalResult;
	}
}
