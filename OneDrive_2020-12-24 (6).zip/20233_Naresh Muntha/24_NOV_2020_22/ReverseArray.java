package org.neww;

public class ReverseArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
