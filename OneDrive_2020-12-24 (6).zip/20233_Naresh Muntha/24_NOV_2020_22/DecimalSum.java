package org.neww;

import java.util.Scanner;

public class DecimalSum {
	static String result = "";
	 public static void main(String[] args) {
	        System.out.println("Enter any number");
	        Scanner scan = new Scanner(System.in);
	        String number = scan.next();
	        for (int i = 0; i < number.length(); i++) {
	            if(number.charAt(i) == '.') {
	                getsum(i, number);
	                break;
	            }
	        }
	    }
    static void getsum(int i, String number) {
        int sum = 0,sum1 = 0;
        for (int j = 0; j < number.length(); j++) {
            if(j < i) {
                char ch = number.charAt(j);
                sum += Character.getNumericValue(ch);
            }
            if(j > i){
                char ch = number.charAt(j);
                sum1 += Character.getNumericValue(ch);
            }
        }
        result += sum + " : " +sum1;
        System.out.println(result);
    }
   
   
}
