package org.neww;

public class BinarySearch {

}
