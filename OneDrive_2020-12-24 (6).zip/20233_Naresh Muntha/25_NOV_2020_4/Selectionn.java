package org.assaignment;

import java.util.Scanner;

public class Selectionn {

	public static void swap(int[] arr, int i, int j)
    {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
    public static void selectionSort(int[] arr, int i, int arrayLength)
    {
        int min = i;
        for (int j = i + 1; j < arrayLength; j++)
        {
            if (arr[j] < arr[min]) {
                min = j;    
            }
        }
        swap(arr, min, i);
        System.out.println("after "+i+" st pass");
        for (int x : arr){
            System.out.print(x+" ");
        }
        System.out.println(" ");
        if (i + 1 < arrayLength) {
            selectionSort(arr, i + 1, arrayLength);
        }
    }
 
    public static void main(String[] args)
    {
    	Scanner scr = new Scanner(System.in);
    	System.out.println("enter array size");
        int[] arr = new int [scr.nextInt()];
        System.out.println("enter "+arr.length+" array elements");
        for(int i = 0;i < arr.length;  i++ ){
        	arr[i] = scr.nextInt();
        }
        System.out.println("The Array elements are ");
        for (int x : arr){
            System.out.print(x+" ");
            }
        selectionSort(arr, 0, arr.length);
        System.out.println("After all passes the Soarted Array");
        for (int x : arr){
        System.out.print(x+" ");
        }
    }
}
