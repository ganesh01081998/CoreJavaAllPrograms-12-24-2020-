package org.assaignment;

public class CollarzSeq {

	public static void main(String[] args) {


	}
	static String getCollarzSequence(int num) {
		int sum = 1;
		String result = " ";
		for(int i = 1;i <= sum;i++) {
			
		
		if(num == 1) {
			result = "1";
			break;
		}
		else {
            if(num % 2 == 0){
            	sum = num/2;
            }
            else {
            	sum = (sum * 3)+1;
            }
		}
		}
		return result;
	}

}
