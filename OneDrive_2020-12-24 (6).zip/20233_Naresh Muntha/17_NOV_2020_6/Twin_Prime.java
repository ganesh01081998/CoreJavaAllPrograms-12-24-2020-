package org.ojas;

import java.util.Scanner;

public class Twin_Prime {
	static int addNum=2;

	public static void main(String[] args) {
		System.out.println("enter start limit & end limit");
		Scanner scr = new Scanner(System.in);
		int start = scr.nextInt();
		int limit   = scr.nextInt();
		
		for (int i = start; i < limit ; i++) {

            if (isPrime(i) && isPrime(i + addNum)) {
                System.out.println("("+i + "," +(i+addNum)+")");
              
            }
        }
    }

    public static boolean isPrime(long n) {

        if (n < 2) 
        	{
        	return false;
        	}

        for (int j = 2; j <= n / 2; j++) {

            if (n % j == 0){
            	return false;
            }
            

        }
        return true;
       	
     }
  
}
