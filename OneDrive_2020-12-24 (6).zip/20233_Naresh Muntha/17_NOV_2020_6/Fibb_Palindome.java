package org.ojas;

import java.util.Scanner;

public class Fibb_Palindome {
	static Scanner scr = new Scanner(System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Enter the Fibbonacci Limit");
		fibbnocci(scr.nextInt());
	
	}
	static void fibbnocci(int n){
		System.out.println("Enter the a value");
		int a = scr.nextInt(),c;
		System.out.println("Enter the b value");
		int b =scr.nextInt();
		for(int i = 0;i <= n; i++){
			c = a + b;
			printPalindrome(c);
			a = b;
			b = c;	
		}
	}
	static void printPalindrome(int num){
		
		int rem,temp,sum = 0;
		temp = num;
		while(num > 0){
			rem = num % 10;
			sum = sum *10 + rem;
			num = num / 10;
		}
		if(temp == sum){
			System.out.println(sum);
		}
				
	}
}
