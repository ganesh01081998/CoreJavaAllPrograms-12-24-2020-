package org.assaignment;

import java.util.Scanner;
  
public class NDigitArmstrong {
	static int count;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Scanner scr= new Scanner(System.in);
	System.out.println("enter the Number");
	armstrong(scr.nextInt());
	
	}
	static void findLength(int num){
		int temp = num;
		String str= "" + num;
		count = str.length();
		System.out.println(count);
			}
		
	static void armstrong(int num){
		findLength(num);
		int rem, sum1 = 1 ,sum = 0, temp = num;
		while(num > 0 ){
		rem = num % 10;
		for(int i = 1; i <= count; i++){
			sum1 *= rem;
		}		
		sum = sum + sum1;
		sum1 = 1;
		num = num / 10;
		}
		if(temp == sum){
			System.out.println("Armstrong Number");
		}
		else{
			System.out.println("Not Armstrong");
		}
	}   
}
