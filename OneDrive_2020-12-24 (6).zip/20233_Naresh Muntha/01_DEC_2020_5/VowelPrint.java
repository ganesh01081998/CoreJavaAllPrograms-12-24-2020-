package dec.first.fiveprogrms;

import java.util.Scanner;

public class VowelPrint {

	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("enter string");
		System.out.println(filterConsonents(sc.nextLine()));
	}
	static String filterConsonents(String str){
		String result = ""; 
		if(str.equals("")){
			return "null";
		}
		for(int i = 0; i < str.length();i++){
			char ch = str.charAt(i);
			if(ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' ) {
		     result +=ch; 
			}
		}
		return result;
	}

}
