package dec.first.fiveprogrms;

import java.util.Arrays;
import java.util.Scanner;

public class AnagramString1 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scr = new Scanner(System.in);
		System.out.println("enter 2 Strings");
		
		System.out.println(checkAnagram(scr.nextLine(),scr.nextLine()));
		
	}
	static String checkAnagram(String str1,String str2){
		String result = "";
		if(str1.equals("") || str2.equals("")){
			return "null";
		}
		char first[] = str1.toCharArray();
		char second[] = str2.toCharArray();
		Arrays.sort(first);
		Arrays.sort(second);
		if (Arrays.equals(first,second)) {
			result = str1+" and "+str2+" are Anagrams";
		}
		else{
			result = "not anagrams";
		}
		return result;
	}

}
