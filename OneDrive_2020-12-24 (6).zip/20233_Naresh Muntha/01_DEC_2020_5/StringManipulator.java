package dec.first.fiveprogrms;

import java.util.Scanner;

public class StringManipulator {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter name");
		String name = sc.nextLine();

		System.out.println(removeVowels(name));
	}

	static String removeVowels(String name) {
		String finalResult = "";
		if(name.length()==0){
			finalResult = "null";
		}
		else{
		String str = name.toUpperCase();
		for (int i = 0; i < str.length(); i++) {
			char ch = str.charAt(i);
			if(ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U' ) {
	
			}
			else{
				finalResult += str.charAt(i);
			}
		}
		}
		return "after removing vowels "+finalResult;
	}
}
