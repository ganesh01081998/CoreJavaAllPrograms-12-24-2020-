package com.ojas.StudentFee;

public class Student {
	int sid;
	String sname;
	double examFee;
	
	public Student() {

	}
	Student(int sid, String sname, double examFee) {
		this.sid = sid;
		this.sname = sname;
		this.examFee = examFee;
	}
	
	@Override
	public String toString() {
		return "Student [sid=" + sid + ", sname=" + sname + ", examFee=" + examFee + "]";
	}
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public double getExamFee() {
		return examFee;
	}
	public void setExamFee(double examFee) {
		this.examFee = examFee;
	}
	static void displayDetails() {

	}
	void payFee() {

	
	}
	 
	
}

