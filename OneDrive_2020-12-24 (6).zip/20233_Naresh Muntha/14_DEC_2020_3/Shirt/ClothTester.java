package org.shirt;

import java.util.Scanner;

public class ClothTester {

	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		
		Shirt s = new Shirt();
		System.out.println("enter shirt  size");
		float cs = scr.nextFloat();
		System.out.println("enter shirt length");
		float cl = scr.nextFloat();
		System.out.println("1.Cotton \n 2.Lenin \n 3.Polister");
	int option = scr.nextInt();
	switch (option) {
	case 1:
		Shirt shrt = new Shirt(cs, cl, String.valueOf(ShirtMaterial.cotton));
		System.out.println(shrt);
		break;
	case 2:
		Shirt shrt1 = new Shirt(cs, cl, String.valueOf(ShirtMaterial.Linen));
		System.out.println(shrt1);
		break;
	case 3:
		Shirt shrt2 = new Shirt(cs,cl, String.valueOf(ShirtMaterial.polyster));
		System.out.println(shrt2);
		break;

	}

	}

}
