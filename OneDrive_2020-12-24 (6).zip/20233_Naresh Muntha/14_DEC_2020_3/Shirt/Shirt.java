package org.shirt;
enum ShirtMaterial{
	cotton,Linen,polyster
}
public class Shirt {
float colourSize;
float length;
String clothtype;

	public Shirt() {
	this.colourSize = 0;
	this.length = 0;
	this.clothtype = "cotton";
}
	public Shirt(float colourSize, float length, String clothtype) {
		this.colourSize = colourSize;
		this.length = length;
		this.clothtype = clothtype;
	}
	public float getColourSize() {
		return colourSize;
	}
	public void setColourSize(float colourSize) {
		this.colourSize = colourSize;
	}
	public float getLength() {
		return length;
	}
	public void setLength(float length) {
		this.length = length;
	}
	public String getClothtype() {
		return clothtype;
	}
	public void setClothtype(String clothtype) {
		this.clothtype = clothtype;
	}
	
	@Override
	public String toString() {
		return "Shirt [colourSize=" + colourSize + ", length=" + length + ", clothtype=" + clothtype + "]";
	}
	
}
