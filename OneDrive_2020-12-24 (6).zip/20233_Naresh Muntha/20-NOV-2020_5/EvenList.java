package org.assaignment;

import java.util.Scanner;

public class EvenList {

	static String result = "";
	public static void main(String[] args) {
		createArray();
	}
	static String createArray(){	
		System.out.println("Enter 10 numbers");
		int []inputArray = new int[10];
		Scanner sc = new Scanner(System.in);
		for(int i = 0; i < 10;i++){
			inputArray[i] = sc.nextInt(); 
		}	
		if(inputArray.length != 10){
			result =null;
		}
		else{
			System.out.println(isEvenNumbers(inputArray));
		}
		return result; 
	}
	static String isEvenNumbers(int even[]) {
		System.out.println("even elements are");
		for(int i = 0;i < even.length; i++){
			if( even [i] % 2 ==0){
				result += even[i]+",";
			}
		}
		return result;
	}
}
