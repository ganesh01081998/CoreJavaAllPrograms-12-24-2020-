package org.assaignment;

import java.util.Scanner;

public class FillMultiples {

	
	static String result = "";
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Array Size");
		int size = sc.nextInt();
		int [] array = new int [size];
		System.out.println("Enter array elements");
		for (int i = 0; i < array.length; i++) {
			int num = sc.nextInt();
			if(num > 0) {
				array[i] = num;
				getMultiply(array[i]);
			}
			else {
				System.out.println("NULL");
			}
		}
		System.out.println(result);
	}

	static void getMultiply(int number) {
		for (int i = 1;i < 11; i++) {
			result += number + " * " + i + " = " + (number * i) + "\n";
		}
		result += "\n";
	}
}
