package org.assaignment;

import java.util.Scanner;

public class OccuranceArray {
	static String result = "";
	public static void main(String[] args) {
		int count = 0;
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter Array Size");	
		int [] array = new int [scan.nextInt()];
		System.out.println("Enter array elements");
		for (int i = 0; i < array.length; i++) {
			array[i] = scan.nextInt();
		}
		getCountOfArray(array, count);	
		System.out.println(result);
	}
	static String getCountOfArray(int[] array, int count) {
		for (int i = 0; i < array.length; i++) {
			count = 0;
			for (int j = 0; j < array.length; j++) {
				if(array[i] == array[j]) {
					count++;
				}
			}
			result += array[i] +" --> " + count + "\n";
		}
		return result;
	}
}
