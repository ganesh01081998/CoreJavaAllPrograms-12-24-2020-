package dec.second;

import java.util.Scanner;

public class CountArrray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scr = new Scanner(System.in);
		System.out.println("enter array size");
		int size = scr.nextInt();
		int []arr = new int[size];
		if(size == 0){
			System.out.println("-1");
			System.exit(0);
		}
		System.out.println("enter array elements");
		for(int i = 0 ; i < arr.length; i++){
			arr[i] = scr.nextInt();
			if(arr[i] == 0){
				System.out.println("-1");
				System.exit(0);
			}
		}
		System.out.println("enter the number to count its occurance");
		System.out.println(getCount(arr,scr.nextInt()));
	}
	static int getCount(int array[],int num){
		int count = 0;
		for(int i = 0; i < array.length ; i++ ){
			if(array[i] == num){
				count++;
			}
		}
	 return count;
	}

}
