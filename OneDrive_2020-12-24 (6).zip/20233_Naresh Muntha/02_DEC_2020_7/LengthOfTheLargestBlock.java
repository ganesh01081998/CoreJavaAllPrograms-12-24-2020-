package dec.second;

import java.util.Arrays;
import java.util.Scanner;

public class LengthOfTheLargestBlock {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter name");
		String name = sc.nextLine();
		System.out.println((maxBlock(name)));
	}
	static int maxBlock(String str){
		int count1[] = new int[str.length()]; 
		for(int j = 0 ;j <str.length();j++){	
		char ch1 = str.charAt(j);
		int count = 0;
		for(int i = 0; i < str.length(); i++ ){  
          if(ch1 == str.charAt(i)){
		   count ++;
		   }
		}
		count1[j] = count;
		}
     Arrays.sort(count1);
     int result = count1[count1.length-1];
	return result;	
	}

}
