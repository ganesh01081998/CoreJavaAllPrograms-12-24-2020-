package org.neww;

import java.util.Scanner;

public class GeneratorPalindrome {
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("enter any number");
		int num = scn.nextInt();
		reverseNum(num);
	}
	static void reverseNum(int num) {
		int sum = 0, rem, temp = num;
		while(num > 0) {
			rem = num % 10;
			sum = sum * 10 + rem;
			num = num / 10;
		}
		System.out.println(sum);
		checkPalindrome(sum, temp);
	}
	
	static String checkPalindrome(int sum, int temp1) {
		String res = "";
		int result = 0;
		if(sum == temp1) {
			System.out.println(sum + " is a Palindrome");
		}
		else {
			result = sum + temp1;
			System.out.println(result);
			reverseNum(result);
		}
	return  res;
	}
}


	
