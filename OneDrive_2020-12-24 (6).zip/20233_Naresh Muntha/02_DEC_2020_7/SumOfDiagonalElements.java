package dec.second;

import java.util.Scanner;

public class SumOfDiagonalElements {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scr = new Scanner(System.in);
		System.out.println("enter  multidimensional array size A x B");
		int size = scr.nextInt();
		int size1 = scr.nextInt();
		if(size != 3 && size1 !=3){
			System.out.println("-1");
			System.exit(0);
		}
		int array[][] = new int[size][size1];
		System.out.println("Enter array elements");
		for(int i = 0 ; i < array.length; i++){
			for(int j = 0; j < array[i].length; j++){
				array[i][j] = scr.nextInt();
			}
	    }
		System.out.println(getDiagonalSum(array));
	}
static int getDiagonalSum(int array[][]){
	int sum = 0, add = 0;
	for(int i = 0 ; i < array.length; i++){
		for(int j = 0; j < array[i].length; j++){
			if( j == add){
				sum +=array[i][j];
			}
		}
		add++;
	}
	System.out.println("Sum of diagonal elements is :");
	return sum;
}
}
