package dec.second;

import java.util.Scanner;

public class WeavedString {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the String ");
		String input1 = scanner.next();
		if(input1 .equals("")) {
			System.out.println("-1");
			System.exit(0);
		}
		System.out.println("Enter the Secound String");
		String input2 = scanner.next();
		if(input2 .equals("")) {
			System.out.println("-1");
			System.exit(0);
		}
		System.out.println(getWeavedString(input1,input2));
	}
	static String getWeavedString(String str1,String str2) {
		String result = "";
		if(str1.length() > str2.length()) {
			result +=str2+" "+str1+" "+str2;
		}
			else if(str2.length() > str1.length()){
				result +=str1+" "+str2+" "+str1;
			}
			else{
				str2 +="a";
				for(int i = 0; i < str1.length(); i++){
					if(str1.charAt(i) != str2.charAt(i+1)){
						result +=str1.charAt(i)+""+str2.charAt(i);
					}
					
				}
			}
		return result;
	}
	
	
	
}
