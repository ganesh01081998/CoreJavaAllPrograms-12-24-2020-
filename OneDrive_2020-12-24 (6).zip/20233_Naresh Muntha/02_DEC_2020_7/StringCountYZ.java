package dec.second;

import java.util.Scanner;

public class StringCountYZ {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter name");
		String name = sc.nextLine();
		System.out.println((countYZ(name)));
	}
	static int countYZ(String str){
		//String a[] =str.split(" ");
		int count = 0;
 		 int spaceIndex = str.indexOf(" ");
 		 int lastIndex  = str.length();
 		 if(str.charAt(spaceIndex-1)=='y' ||str.charAt(spaceIndex-1)=='z' && str.charAt(lastIndex-1)=='y' ||str.charAt(lastIndex-1)=='z'){
 		count = 2;	 
 		 }
        
		return count;
	}

}
