package org.assaignment;

public class pattren3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(printPattren());
	}
	static String printPattren(){
		String result = "";
		for(int i = 5; i >= 1; i--){
			for(int j =5;j >= 1; j--){
				result += i+" ";
		}
			result +="\n";
	}
		return result;
	}

}
