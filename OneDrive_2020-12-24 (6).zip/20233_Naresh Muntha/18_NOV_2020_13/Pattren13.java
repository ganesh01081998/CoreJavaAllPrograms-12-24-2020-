package org.assaignment;

public class Pattren13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(printPattren());
	}
	static String printPattren(){
		
		String result = "";
		for(int i = 1; i <= 5; i++) {
            for(int j = 1; j <= 5; j++) {
                if(i == 1 || j == 1 || i == 5 || j == 5 ) {
                result += "*" + " " ;
                }
                else {
                    result += "  ";
                }
            }
            result += "\n";
        }
		return result;
	}

}
