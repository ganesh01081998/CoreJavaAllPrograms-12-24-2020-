package org.assaignment;

public class Pattren5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(printPattren());
	}
	static String printPattren(){
		String result = "";
		for(int i = 1; i <= 5; i++){
			for(int j =1;j <= i; j++){
				result += i+" ";
		}
			result +="\n";
	}
		return result;
	}

}
