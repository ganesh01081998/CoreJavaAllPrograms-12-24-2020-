package org.assaignment;

import java.util.Scanner;

public class PrimeInTheGivenRange {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scr = new Scanner(System.in);
		System.out.println("Enter the  Range of Number");
		printPrime(scr.nextInt(),scr.nextInt());
	  }
static void printPrime(int num, int num1){
	int count = 0;
	for(int k = num; k <= num1; k++){
	for(int i = 2; i <= k; i++){
		if(k % i == 0){
			count++;
		}
	}
	if(count == 1){
	System.out.println(k);
	}
	count = 0;
	}
}
}

