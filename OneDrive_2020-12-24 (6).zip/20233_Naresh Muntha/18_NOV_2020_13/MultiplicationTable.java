package org.assaignment;

import java.util.Scanner;

public class MultiplicationTable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println(" Enter any Number");
		System.out.println(multiplicatiion(sc.nextInt()));
	}
	static String multiplicatiion(int num){
		String result = "";
		for(int i = 1;i <= 10; i++){
			
			result += num +" * "+i+" = "+ num*i;
			result +="\n";
		}
		return result;
	}

}
