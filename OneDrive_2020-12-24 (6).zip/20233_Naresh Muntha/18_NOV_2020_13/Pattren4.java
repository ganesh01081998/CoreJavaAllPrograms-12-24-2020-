package org.assaignment;

public class Pattren4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(printPattren());
	}
	static String printPattren(){
		String result = "";
		for(int i = 1; i <= 5; i++){
			for(int j =1;j <= i; j++){
				result += j+" ";
		}
			result +="\n";
	}
		return result;
	}

}
