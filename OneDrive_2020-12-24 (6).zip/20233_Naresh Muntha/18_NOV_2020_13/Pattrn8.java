package org.assaignment;

public class Pattrn8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(printPattren());
	}
	static String printPattren(){
		String result = "";
		int k=1;
		for(int i = 1; i <= 5; i++){
			for(int j =1;j <= i; j++){
				
				result += k+" ";
				k++;
		}
			if(i>=2){
			k--;
			}
			result +="\n";
	}
		return result;
	}

}
