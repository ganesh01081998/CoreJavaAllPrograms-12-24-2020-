package org.assaignment;

public class Pattren12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(printPattren());
		}
		static String printPattren(){
			int jValue = 1,iValue =3;
			String result = "";
			for(int k = 1;k <= 4; k++){
				
			for(int i = 1; i <= iValue; i++){
				result +=" ";
			}
			
			
				for(int j =1;j <= jValue; j++){
					result += "*";
				}
				iValue--;
				jValue += 2;
		
				result +="\n";
			}
			return result;
	}

}
