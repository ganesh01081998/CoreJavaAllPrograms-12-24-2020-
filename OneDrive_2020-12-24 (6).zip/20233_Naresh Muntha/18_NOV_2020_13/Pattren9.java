package org.assaignment;

public class Pattren9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(printPattren());
	}
	static String printPattren(){
		String result = "";
		char ch= 'A';
		for(int i = 1; i <= 5; i++){
			for(int j =1;j <= i; j++){
				result += ch+" ";
				ch++;
		}
			result +="\n";
	}
		return result;
	}

}
