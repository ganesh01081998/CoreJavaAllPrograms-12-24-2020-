package org.assaignment;

import java.util.Scanner;

public class SumOparetion {

	
		// TODO Auto-generated method stub
		 static int isSumDouble(int number1,  int  number2) {
	         int sum = 0;
	         if(number1 !=number2) {
	            sum = number1 + number2;
	         }
	         else if(number1 == number2) {
	             sum = (number1 + number2) * 2;
	         }
	         return sum;
	    }

	 

	   public static void main(String[] args) {
		
	
	    Scanner scn = new Scanner(System.in);
	    System.out.println("enter the first number");
	    int number1 =  scn.nextInt();
	    System.out.println("enter second number");
	    int number2 = scn.nextInt();
	    System.out.println(isSumDouble(number1, number2));
	    }
	}
