package org.assaignment;

import java.util.Scanner;

public class NearHundread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the Number");
		System.out.println(nearHundread(sc.nextInt()));
	}
	static boolean nearHundread(int number){
		boolean result = false;
		if(number >= 90 & number <= 110 ){
			number = 100-number;
			if(number <= 10){
				result = true;
			}
		}
		else if(number > 190 & number < 210){
			number = 200-number;
			if(number < 10){
				result = true;
			}
		}
		 return result;
	}

}
