package org.neww;

import java.util.Scanner;

public class MulticationMatrix {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the array size");
		int [] array = new int [scan.nextInt()];
		System.out.println("Enter the array elements");
		for (int insert = 0; insert < array.length; insert++) {
			array[insert] = scan.nextInt();
		}
		System.out.println(is_smallNumber(array));
	}

	static String is_smallNumber(int[] array) {
		int small = array[0], secondSmall = 0;
		String result = "";
		for (int check = 1; check < array.length; check++) {
			if(small > array[check]) {
				secondSmall = small; 
                small = array[check];
			}
		}
		result += small + " is the smallest number in the array \n";
		result += secondSmall + " is the second smallest number in the array \n";
		return result;
	}
}
