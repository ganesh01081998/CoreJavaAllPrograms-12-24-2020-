package org.assaignment;

import java.util.Scanner;

public class MaxNumber {
	static String result = "";
	public static void main(String[] args) {
		createArray();
	}
	static String createArray(){	
		System.out.println("Enter 10 numbers");
		int []inputArray = new int[10];
		Scanner sc = new Scanner(System.in);
		for(int i = 0; i < 10;i++){
			inputArray[i] = sc.nextInt(); 
		}	
		if(inputArray.length != 10){
			result = "-1";
		}
		else{
			System.out.println(getMax(inputArray));
		}
		return result; 
	}
	static String getMax(int[] inputArray) {
		int big = inputArray[0];
		System.out.println("Max num is");
		for(int i = 0;i < inputArray.length; i++){
		if(inputArray[i] > big){
			big = inputArray[i];
			}
		}
		return  result += big;
	}
	}


