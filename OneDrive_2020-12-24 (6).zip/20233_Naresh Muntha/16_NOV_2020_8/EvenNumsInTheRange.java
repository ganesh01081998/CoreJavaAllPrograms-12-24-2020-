package org.assaignment;

import java.util.Scanner;

public class EvenNumsInTheRange {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the Range to Even Numbers");
		Scanner sc = new Scanner(System.in);
		System.out.println(printEven(sc.nextInt()));
	}
	static String printEven(int range){
		String result = "";
		
		for(int i = 1 ; i<= range; i++){
			if(i % 2 == 0){
				result += i +" ";
			}
		}
		return result;
	}
}
