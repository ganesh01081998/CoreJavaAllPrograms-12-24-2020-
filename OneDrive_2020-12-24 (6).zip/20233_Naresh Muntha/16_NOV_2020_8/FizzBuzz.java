package org.assaignment;

import java.util.Scanner;

public class FizzBuzz {
	static String getOutputString(int num) {
        String result = "";
        if(num > 0) {
            if(num % 3 == 0 && num % 5 != 0) {
                result = "FIZZ";
            }
            else if(num % 5 == 0 && num % 3 != 0) {
            	result = "BIZZ";
            }
            else  if(num % 5 == 0 && num % 3 ==0){
            	result = "FIZZBIZZ";
            }
               else {
                result += num;
            }
        }
        else {
           return "ERROR";
        }
       return result;
    }
      public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
       System.out.println("enter number");   
       System.out.println(getOutputString(sc.nextInt()));
   }
}
