package org.assaignment;

import java.util.Scanner;

public class CheckPrime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println(" Enter any Number");
		checkPrime(sc.nextInt());
	}
	static void checkPrime(int num){
		int count = 0;
		for(int i = 1;i <=num; i++){
			if( num % i == 0){
				count++;
			}
		}
		if(count == 2){
		System.out.println(num +" is Prime Number");	
		}
		else{
			System.out.println(num +" not a prime");
		}
	}

}
