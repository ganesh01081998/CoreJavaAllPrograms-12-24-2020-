package org.assaignment;

import java.util.Scanner;

public class SumOfNaturalNums {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println(" Enter the Start & end Number");
		System.out.println(sumOfNaturalNums(sc.nextInt(),sc.nextInt()));
	}
	static String sumOfNaturalNums(int start,int end){
		int sum = 0;
		for(int i = start;i <= end;i++){
			sum  = sum + i;
		}
		return "sum of numbers is "+sum ;
		
		
	}

}
