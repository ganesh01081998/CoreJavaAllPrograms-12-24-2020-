package org.assaignment;

import java.util.Scanner;

public class NaturalNums {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println(" Enter the Range To Print Natural Numbers");
		printNaturalNums(sc.nextInt());
	}
	static void printNaturalNums(int range){
		System.out.println("Natural Nums upto " +range);
		for(int i = 1; i <= range;i++){
			System.out.print(i +" ");
		}
	}

}
