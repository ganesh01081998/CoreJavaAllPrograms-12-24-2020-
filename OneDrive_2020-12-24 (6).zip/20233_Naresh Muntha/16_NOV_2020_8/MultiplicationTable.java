package org.assaignment;

import java.util.Scanner;

public class MultiplicationTable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println(" Enter any Number");
		multiplicatiion(sc.nextInt());
	}
	static void multiplicatiion(int num){
		for(int i = 1;i <= 10; i++){
			System.out.println(num +" * "+i+" = "+ num*i);
		}
	}

}
