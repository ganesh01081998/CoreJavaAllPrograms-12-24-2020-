package org.assaignment;

import java.util.Scanner;

public class CheckArmstrong {
	public static void main(String[] args) {
	    Scanner scanner = new Scanner(System.in);
	    System.out.println("enter number");
	    System.out.println(armStrong(scanner.nextInt()));
	}

	static String armStrong(int num) {
	    String result = "" ;
	   
	    int rem = 0,temp = num,sum = 0;
	    while(num > 0) {
	        rem = num % 10;
	        sum = sum  + (rem*rem*rem);
	        num = num / 10;
	    }
	    result += sum;
	    if(sum == temp) {
	        return result + " is armstrong number";
	    }
	    else {
	        return result + " is not armstrong number";
	    }
	}
	
}
