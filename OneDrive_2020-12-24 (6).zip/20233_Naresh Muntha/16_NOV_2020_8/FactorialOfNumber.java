package org.assaignment;

import java.util.Scanner;

public class FactorialOfNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println(" Enter the Number");
		System.out.println(isFactorial(sc.nextInt()));
	}
	static String isFactorial(int num){
		int fact = 1;
		for(int i = 1;i <= num; i++){
			fact = fact * i;
		}
		return "Factoria of "+num+" is "+fact;
	}

}
