package org.tax;

public class NameNotValidException extends Exception {
	public NameNotValidException(String str) {
		super(str);
	}
}
