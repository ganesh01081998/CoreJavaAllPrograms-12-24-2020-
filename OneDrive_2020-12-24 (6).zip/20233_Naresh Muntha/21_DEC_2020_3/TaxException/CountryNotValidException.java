package org.tax;

public class CountryNotValidException extends Exception{
	public CountryNotValidException(String str) {
		super(str);
	}
}
