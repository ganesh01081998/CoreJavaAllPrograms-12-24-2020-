package org.tax;

import java.util.Scanner;

public class TaxChecker {
	public static void main(String[] args) {
		System.out.println("Enter Employee Name");
		Scanner sc = new Scanner(System.in);
		String empName = sc.nextLine();
		System.out.println("Enter Employee Nationality");
		String empCountry = sc.nextLine();
		System.out.println("Enter Employee Annual Salary");
		Employee emp = new Employee(empName, empCountry, sc.nextDouble());
		TaxSimulator taxSim = new TaxSimulator();
		taxSim.findTaxOutput(emp);

	}
}
