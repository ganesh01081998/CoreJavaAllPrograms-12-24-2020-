package org.tax;

public class NotEligibleForTaxException extends Exception {
public NotEligibleForTaxException(String str) {
	super(str);
}
}
