package org.tax;

public class TaxSimulator {
	TaxCalculator taxcal=new TaxCalculator();
	void findTaxOutput(Employee emp){
		double output = taxcal.calculateTax(emp);
		if(output==1) {
			try {
			throw new CountryNotValidException("The employee should be an Indian");
		} catch (CountryNotValidException e) {

			System.out.println(e.getMessage());
		}
		}else if(output==2) {
			try {
			throw new NameNotValidException("The employee should be charecters");
		} catch (NameNotValidException e) {
			System.out.println(e.getMessage());
		}
		}else if(output==3) {
			
			try {
				throw new NotEligibleForTaxException("");
			}
			catch (NotEligibleForTaxException e) {
			System.out.println(e);
		}
			
		}else {
			System.out.println("The tax Amount is :"+taxcal.tax);
		}
	}
}
