package org.exception;

import java.util.Scanner;

public class LeaveMain {

	public static void main(String[] args) throws LeaveQuotaExceededException {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("enter till now your taken leaves");
		LeaveSystem ls = new LeaveSystem(20);
		ls.leaveChecker(sc.nextInt());
}
}