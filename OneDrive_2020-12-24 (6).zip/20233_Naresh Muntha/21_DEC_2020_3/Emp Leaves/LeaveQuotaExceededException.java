package org.exception;

public class LeaveQuotaExceededException extends Exception{
	LeaveQuotaExceededException(String str){

	}
	@Override
	public String toString() {
		return "Sorry ! you have Exceeded your leaves";
	}
}
