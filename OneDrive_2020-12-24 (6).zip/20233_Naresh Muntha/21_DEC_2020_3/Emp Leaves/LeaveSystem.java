package org.exception;

public class LeaveSystem {
	int noOfLeaves;
	public LeaveSystem(int noOfLeaves) {
		this.noOfLeaves = noOfLeaves;
	}
	void leaveChecker(int leaves) {
		if(leaves >= noOfLeaves) {
			try {
			throw new LeaveQuotaExceededException(" Sorry you have exceded your Leaves");
			}
			catch(LeaveQuotaExceededException ae) {
				System.out.println(ae);
			}
		}
		else {
			System.out.println("your leave Granted");
		}
	}
	
}
