package org.exception;

import java.util.Scanner;

public class BankDemo {

	public static void main(String[] args) throws InsufficientFundsExcetion {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter AccountNumber");
		long acno = sc.nextInt();
		CheckingAccount ca = new CheckingAccount(acno,10000);
		System.out.println("Choose Option \n 1.withdraw \n 2.deposit");
		int choose = sc.nextInt();
		switch(choose) {
		case 1 :
			System.out.println("Enter withdraw Amount");
			double amount = sc.nextDouble();
			System.out.println("Enter your Account Number");
			ca.withdraw(amount,sc.nextLong());
			break;
		case 2 :
			System.out.println("Enter Deposit Amount");
			ca.deposit(sc.nextDouble());
			break;
		case 3 :
			System.exit(0);
		}
		
	}

}
