package org.exception;

public class CheckingAccount extends InsufficientFundsExcetion{
	long accountNumber;

	public CheckingAccount(long acno, double amount) {
		super(amount);
		this.accountNumber = acno;
	}
	boolean checkAccount(long acno){
		if(acno == accountNumber)
			return true;
		else {
			System.out.println("uhkuh");
			return false;
		}
	}
	void deposit(double depAmount) {

		amount = amount + depAmount;
		System.out.println(depAmount+" RS credited");
		System.out.println("available balance "+getAmount());
	}
	void withdraw(double withAmount,long acno){

		if(checkAccount(acno)) {
			
				if(amount < withAmount) {
					try {
					throw new InsufficientFundsExcetion("");
			    }
			catch(InsufficientFundsExcetion ifs) {
				System.out.println(ifs);
			}
			}
			else {
				amount = amount - withAmount;
				System.out.println(withAmount+" RS Debited");
				System.out.println("available balance "+getAmount());
			}
		}
		else {
		System.out.println("Wrong account number");
		}
		
	}
	
	
}
