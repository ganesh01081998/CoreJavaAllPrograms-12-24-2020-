package org.exception;

public class InsufficientFundsExcetion extends Exception{
	double amount;
	InsufficientFundsExcetion(String str){
	
	}
	public InsufficientFundsExcetion(double amount) {
		super();
		this.amount = amount;
	}
	
	
	@Override
	public String toString() {
		return "InsufficientFunds /n your account balance is "+amount;
	}
	double getAmount() {
		return amount;
	}
}
