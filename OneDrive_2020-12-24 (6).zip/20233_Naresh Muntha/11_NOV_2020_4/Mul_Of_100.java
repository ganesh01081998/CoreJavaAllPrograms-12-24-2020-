package org.assaignment;

import java.util.Scanner;

public class Mul_Of_100 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter the number");
		Scanner scr = new Scanner(System.in);
		System.out.println(getNextMultipleOf100(scr.nextInt()));
	}
	static int getNextMultipleOf100(int num){
		if(num <= 0){
			return -1;
		}
		while(num > 0){
			if(num % 100 == 0){
				break;		
			}
			num++;
		}
		return num;


	}

}
