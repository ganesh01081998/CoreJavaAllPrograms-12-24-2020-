package org.assaignment;

public class Swap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		swapNum(12,18);
	}
	static void swapNum(int num1,int num2){
		    System.out.println("Before Swap num1 = "+num1+" num2 = " +num2);
			num1 = num1 + num2;
			num2 = num1 - num2;
			num1 = num1 - num2;
			System.out.println("after Swap num1 = "+num1+" num2 = " +num2);
	}

}
