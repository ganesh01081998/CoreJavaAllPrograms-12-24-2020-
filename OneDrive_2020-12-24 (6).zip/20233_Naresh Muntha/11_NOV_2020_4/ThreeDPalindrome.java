package org.assaignment;

public class ThreeDPalindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(isPal(Integer.parseInt(args[0])));
	}
	static boolean isPal(int num){
		boolean result = false;
		int sum=0,rem,temp;
		if(num > 99 && num < 1000){
			temp = num;
			while(num > 0){
				rem = num % 10;
				sum = sum * 10 +2;
				num = num / 10;	
			}
			if(sum == temp){
				result = true;;
			}	
		}
		else{
			System.out.println("enter the 3 digit Number");

		}
		return result;
	}


	}

