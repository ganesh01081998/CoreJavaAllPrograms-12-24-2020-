package org.assaignment;

public class Add_4_Nums {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum = Integer.parseInt(args[0])+Integer.parseInt(args[1]);
		int sum1 = Integer.parseInt(args[2])+Integer.parseInt(args[3]);
		System.out.println(sum+sum1);
		
	}

}
