package org.mycalculator;

import java.util.Scanner;

public class Testing {
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		MyCalculator mc = new MyCalculator();
		System.out.println("Enter the number");
		System.out.println(mc.divisorSum(scn.nextInt()));
	}
}

