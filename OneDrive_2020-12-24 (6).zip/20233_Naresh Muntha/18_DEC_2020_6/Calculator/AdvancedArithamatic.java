package org.mycalculator;

public abstract class AdvancedArithamatic {
	public abstract int divisorSum(int number);
}