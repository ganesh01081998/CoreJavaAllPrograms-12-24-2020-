package org.arrangeString;

import java.util.Scanner;

public class BookTest {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		MyBook b = new MyBook();
		System.out.println("Enter Any Book Name : ");
		b.setTitle(sc.nextLine());
		System.out.println("The title of my book is : " + b.getTitle());
	}
}
