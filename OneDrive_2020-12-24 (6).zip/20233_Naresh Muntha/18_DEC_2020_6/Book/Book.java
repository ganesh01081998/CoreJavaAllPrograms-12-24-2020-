package org.arrangeString;

abstract class Book {
	String title;
	abstract void setTitle(String title);
	
	public String getTitle() {
		return title;
	}

}


