package org.arrangeString;

public class MyBook extends Book{
public String  getTitle() {
		
		return super.title;
	}

@Override
void setTitle(String title) {
	super.title = title;
}
}
