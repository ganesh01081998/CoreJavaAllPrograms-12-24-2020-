package org.arrangeString;

import java.util.Scanner;

public class BatsManTesting {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		BatsMan bat = new BatsMan();
		System.out.println("Enter Statistics Of  Batsman like\n name\n run\n matches");
		String name = scan.next();
		int run = scan.nextInt();
		int matches = scan.nextInt();
		if((run <= 0 && matches <= 0) || (run > 0 && matches <=0)) {
			System.out.println("ERROR");
		}
		else {
			bat = new BatsMan(name, run, matches);
			System.out.println(bat.getStatistics() + "\n\n name = " + name +  "\n batting Average = " + bat.computeBattingAverage());
		}
	}

}

