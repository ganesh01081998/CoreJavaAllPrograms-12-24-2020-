package org.arrangeString;

public class BatsMan {
	String name;
	int run;
	int matches;
	double battingavg;
	public BatsMan() {
		
	}
	public BatsMan(String name, int run, int matches) {
		this.name = name;
		this.run = run;
		this.matches = matches;
	}
	public double computeBattingAverage() {
		return this.battingavg = (double )(run / matches);
	}
	public String getStatistics() {
		return " Batsman5 Statistics \n name=" + name + "\n run=" + run + "\n matches=" + matches ;
	}
}


