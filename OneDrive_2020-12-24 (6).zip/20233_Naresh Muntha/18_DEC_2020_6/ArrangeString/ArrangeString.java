package org.arrangeString;

import java.util.Scanner;

public class ArrangeString {
	static String string;
	static String result;
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter the Strings");
		System.out.println(setArrangeString(scn.next(), scn.next()));
	}
	static String setArrangeString(String string1,String string2) {
		int sumStringLength = string1.length() + string2.length();
		string1 = getChange(string1);
		string2 = getChange(string2);
		String result = "";
		if(Character.getNumericValue(string1.charAt(0)) > Character.getNumericValue(string2.charAt(0))) {
			result = (sumStringLength) + " No " + string2 + " " + string1;
		}
		else {
			result = (sumStringLength) + " Yes " + string1 + " " + string2;
		}
		return result;
	}
	private static String getChange(String string) {
		char [] ch = string.toCharArray();
		String result = ch[0] + "";
		result =result.toUpperCase();
		for (int i = 1; i < ch.length; i++) {
			result += ch[i] + "";
		}
		return result;
	}
}


