package org.arrangeString;

public class COJ_42_Soccer extends COJ_42_Sports{
	public String	getName(String sports) { 
		super.sports = sports;
		return sports;
		}
		public	String	getNumberOfTeamMembers() {
				return "In" + super.getName(sports)  +"\n each team has 11 players";
			}
}
