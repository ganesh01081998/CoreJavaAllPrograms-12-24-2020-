package org.arrangeString;

import java.util.Scanner;

public class SportTester {
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("enter the sports");
		COJ_42_Sports s = new  COJ_42_Soccer();
		s.getName(scn.nextLine());
		System.out.println( s.getNumberOfTeamMembers());
	}
}
