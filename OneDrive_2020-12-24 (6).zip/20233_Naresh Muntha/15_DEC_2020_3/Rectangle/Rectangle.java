package com.ojas.shapes;
public class Rectangle extends Shape {
       float length ;
       float bridth ;
       public Rectangle(float length , float bridth) {
           this.length = length ;
           this.bridth = bridth ;
       }
       
       public Rectangle() {
        // TODO Auto-generated constructor stub
       }
       
    @Override
    void getArea() {
        double Area = length * bridth ;
        System.out.println(Area);
    
    }
    @Override
    void getPerimeter() {
        double perimeter = 2 * (length + bridth);
        System.out.println(perimeter);
    }

 

}