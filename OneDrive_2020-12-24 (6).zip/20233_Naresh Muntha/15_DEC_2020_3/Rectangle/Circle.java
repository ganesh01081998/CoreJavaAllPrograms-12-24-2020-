package com.ojas.shapes;
class Circle extends Shape {
        float radius ;
        
        public Circle(float radius) {
            super();
            this.radius = radius;
        }
          
        public Circle() {
            // TODO Auto-generated constructor stub
        }
        @Override
        void getArea() {
            double Area = 2 * (22/7) * radius ;
            System.out.println(Area);            
        }

        @Override
        void getPerimeter() {
            double perimeter = (22/7) * radius * radius ;
            System.out.println(perimeter);
            
        }
         
     
}