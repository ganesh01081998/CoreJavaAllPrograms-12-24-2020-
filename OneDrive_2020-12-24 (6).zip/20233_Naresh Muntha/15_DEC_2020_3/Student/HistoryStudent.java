package secondProgram;

import java.util.Scanner;

public class HistoryStudent extends Student {

	int historyMarks;
	int civicsMarks;

	public HistoryStudent() {

	}

	public HistoryStudent(int historyMarks, int civicsMarks) {

		this.historyMarks = historyMarks;
		this.civicsMarks = civicsMarks;
	}

	@Override
	void getPercentage() {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter the History Marks");
		int historyMarks = scn.nextInt();
		System.out.println("Enter the Civics Marks");
		int civicsMarks = scn.nextInt();
		Student.getTotalNoStudents();
		int totalMarks= historyMarks + civicsMarks;
		System.out.println("The 2 subjects total marks are :"+totalMarks);
		int percentage =( totalMarks )/5;
		System.out.println("The percentage of 2 subjects are :"+percentage);
	}
}
