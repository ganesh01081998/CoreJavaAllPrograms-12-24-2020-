package secondProgram;

import java.util.Scanner;

public class ScienceStudent extends Student{

	int physicsMarks;
	int chemistryMarks;
	int mathsMarks;

	public ScienceStudent() {

	}

	public ScienceStudent(String studentName,String studentClass,int physicsMarks, int chemistryMarks, int mathsMarks) {
		super(studentName,studentClass);
		this.physicsMarks = physicsMarks;
		this.chemistryMarks = chemistryMarks;
		this.mathsMarks = mathsMarks;
	}
	@Override
	void getPercentage() {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter the Physics Marks");
		int physicsMarks = scn.nextInt();
		System.out.println("Enter the chemistry Marks");
		int chemistryMarks = scn.nextInt();
		System.out.println("Enter the Maths Marks");
		int mathsMarks = scn.nextInt();
		Student.getTotalNoStudents();
		int totalMarks= physicsMarks + chemistryMarks + mathsMarks;
		System.out.println("The 3 subjects total marks are :"+totalMarks);
		int percentage =( totalMarks )/5;
		System.out.println("The percentage of 3 subjects are :"+percentage);
	}

	@Override
	public String toString() {
		return "ScienceStudent [physicsMarks=" + physicsMarks + ", chemistryMarks=" + chemistryMarks + ", mathsMarks="
				+ mathsMarks + ", studentName=" + studentName + ", studentClass=" + studentClass + "]";
	}
	
}