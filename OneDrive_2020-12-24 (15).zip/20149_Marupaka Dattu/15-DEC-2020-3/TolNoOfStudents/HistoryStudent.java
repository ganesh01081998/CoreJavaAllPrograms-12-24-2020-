package _15_dec_1;

public class HistoryStudent extends NoOfStudents{
	int historyMarks;
	int CivicsMarks;
	
	
	public HistoryStudent(String name, String stdname, int historyMarks, int civicsMarks) {
		super(name, stdname);
		this.historyMarks = historyMarks;
		this.CivicsMarks = civicsMarks;
	}
	
	int getPercentage() {
		int pec = 0;
		if(historyMarks<=100 && CivicsMarks <=100 ) {
			int totalMarks= historyMarks+CivicsMarks;
			System.out.println("total marks"+ totalMarks);
			return pec = (totalMarks)/2;
		}
		else {
			System.out.println("give marks below 100!");
		}
		return pec;
	}

	@Override
	public String toString() {
		return "HistoryStudent [historyMarks=" + historyMarks + ", CivicsMarks=" + CivicsMarks + "]";
	}	

}
