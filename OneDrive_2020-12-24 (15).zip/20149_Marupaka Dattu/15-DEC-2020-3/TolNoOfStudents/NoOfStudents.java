package _15_dec_1;

abstract public class NoOfStudents {
	
	String name;
	String stdname;
	protected static int noofstudents;
	
	
	public NoOfStudents(String name,String stdname) {
		this.name = name;
		this.stdname = stdname;
		
	}
	
	abstract int getPercentage();

}
