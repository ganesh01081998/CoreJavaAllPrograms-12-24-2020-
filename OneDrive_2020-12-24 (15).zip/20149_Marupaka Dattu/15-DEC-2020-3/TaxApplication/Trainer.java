package _15_dec_3;

public class Trainer {
	int id;
	String name;
	double basicSalary;
	double hraper;
	double daper;
	double projectAllowance;
	int batchCount;
	double perkPerBatch;
	Trainer() {
		this.id = 0;
		this.name = null;
		this.basicSalary = 0;
		this.hraper = 0;
		this.daper = 0;
		this.projectAllowance = 0;
		this.batchCount = 0;
		this.perkPerBatch = 0;
	}

	public Trainer(int id, String name, double basicSalary, double hraper, double daper, double projectAllowance,
			int batchCount, double perkPerBatch) {
		this.id = id;
		this.name = name;
		this.basicSalary = basicSalary;
		this.hraper = hraper;
		this.daper = daper;
		this.projectAllowance = projectAllowance;
		this.batchCount = batchCount;
		this.perkPerBatch = perkPerBatch;
	}

	public double calculateGrossSalary() {
		return basicSalary + hraper + daper + projectAllowance + (batchCount * perkPerBatch);
	}

	@Override
	public String toString() {
		return "Trainer [id=" + id + ", name=" + name + ", basicSalary=" + basicSalary + ", hraper=" + hraper
				+ ", daper=" + daper + ", projectAllowance=" + projectAllowance + ", batchCount=" + batchCount
				+ ", perkPerBatch=" + perkPerBatch + "]";
	}

}
