package _15_dec_2;

public class Rectangle extends Shape {

	float length;
	float breadth;

	public Rectangle(float length, float breadth) {
		this.length = length;
		this.breadth = breadth;
	}

	@Override
	void getArea() {
		System.out.println("Area of the rectangle= " + length * breadth);

	}

	@Override
	void getPerimeter() {
		System.out.println("perimeter of rectangle" + 2 * (length + breadth));

	}

	public float getLength() {
		return length;
	}

	public void setLength(float length) {
		this.length = length;
	}

	public float getBreadth() {
		return breadth;
	}

	public void setBreadth(float breadth) {
		this.breadth = breadth;
	}

}
