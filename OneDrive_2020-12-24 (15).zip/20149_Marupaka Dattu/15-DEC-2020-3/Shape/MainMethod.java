package _15_dec_2;

import java.util.Scanner;

public class MainMethod {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter radius");
		Shape c = new Circle(sc.nextFloat());
		c.getArea();
		c.getPerimeter();

		System.out.println("enter side");
		Shape s = new Square(sc.nextFloat());
		s.getArea();
		s.getPerimeter();

		System.out.println("enter length and breadth");
		Shape r = new Rectangle(sc.nextFloat(), sc.nextFloat());
		r.getArea();
		r.getPerimeter();

	}
}
