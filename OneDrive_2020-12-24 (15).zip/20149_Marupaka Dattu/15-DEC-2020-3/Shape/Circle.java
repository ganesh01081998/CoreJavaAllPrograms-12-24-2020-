package _15_dec_2;

public class Circle extends Shape {
	final float pi = 3.14f;
	float radius;

	public Circle(float radius) {
		this.radius = radius;
	}

	public float getRadius() {
		return radius;
	}

	public void setRadius(float radius) {
		this.radius = radius;
	}

	Circle() {

	}

	@Override
	void getArea() {
		System.out.println("Area of the circle=" + pi * radius * radius);

	}

	@Override
	void getPerimeter() {
		System.out.println("perimeter of circle=" + 2 * pi * radius);

	}

}
