package _15_dec_2;

public class Square extends Shape {
	float side;

	public Square(float side) {
		this.side = side;
	}

	@Override
	void getArea() {
		System.out.println("Area of square=" + side * side);
	}

	@Override
	void getPerimeter() {
		System.out.println("perimeter of square=" + 4 * side);
	}

	public float getSide() {
		return side;
	}

	public void setSide(float side) {
		this.side = side;
	}

}
