package _15_dec_2;

abstract public class Shape {

	abstract void getArea();

	abstract void getPerimeter();

}
