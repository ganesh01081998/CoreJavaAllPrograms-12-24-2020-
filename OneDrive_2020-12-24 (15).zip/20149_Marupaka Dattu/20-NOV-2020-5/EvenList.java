import java.util.Scanner;

public class EvenList {
	static String result="";
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the array in range order");
		int size = sc.nextInt();
		if(size==10){
			int[] array = new int[size];
			for(int i=0;i<array.length;i++){
				array[i] = sc.nextInt();
				}
			int count = 0;
			for(int j=0;j<array.length;j++){
				if(array[j]%2==0){
					count++;
				}
				
			}
			if(count==0){
				System.out.println("empty array");
			}
			else{
				int[]even = new int[count];
				count=0;
				for(int k=0;k<array.length;k++){
					if(array[k]%2==0){
						even[count]=array[k];
						count++;
					}
				}
				for (int i = 0; i < even.length; i++) {
					System.out.println( "even numbers :"+ even[i]);
				}
			}
			
		}
		else{
			System.out.println("null");
		}
		
		
	}

}
