
import java.util.Scanner;

public class FillMultiple {

	static String getMultiplesArray(int num) {
		String result = "";
		if(num <= 0) {
			result += "null";
		}
		else {
			int size = 10;
			int[] arr = new int[size];
			for (int i = 0; i < arr.length; i++) {
				arr[i] = num * i;
				result += arr[i] + " ";
			}
		}
		return result;
	}

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("enter the array element");
		int num = scn.nextInt();
		System.out.println(getMultiplesArray(num));
	}

}

