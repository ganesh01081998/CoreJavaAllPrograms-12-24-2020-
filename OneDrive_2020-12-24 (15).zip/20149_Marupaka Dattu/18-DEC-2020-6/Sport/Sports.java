package _18_dec_2;

public class Sports {
String sports;
	
	public String	getName(String sports) { 
	return sports;
	}
	public 	String	getNumberOfTeamMembers() {
			return "Each team has n players in Sports";
		}
	

}
