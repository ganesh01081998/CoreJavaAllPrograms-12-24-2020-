package _18_dec_1;

import java.util.Scanner;

public class BookMainClass {
	

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		MyBook mb = new MyBook();
		System.out.println("Enter Any Book Name : ");
		mb.setTitle(sc.nextLine());
		System.out.println("The title of my book is : " + mb.getTitle());

	}

}
