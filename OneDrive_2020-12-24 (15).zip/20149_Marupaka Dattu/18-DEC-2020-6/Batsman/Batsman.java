package _18_dec_4;

public class Batsman {

	String name;
	int run;
	int matches;
	double battingavg;
	
	public Batsman() {
		
	}
	
	public Batsman(String name, int run, int matches) {
		this.name = name;
		this.run = run;
		this.matches = matches;
	}
	
	public double computeBattingAverage() {
		return this.battingavg = (double )(run / matches);
	}
	
	public String getStatistics() {
		return " Batsman Statistics \n Name = " + name + "\n Runs =" + run + "\n Matches = " + matches ;
	}


}
