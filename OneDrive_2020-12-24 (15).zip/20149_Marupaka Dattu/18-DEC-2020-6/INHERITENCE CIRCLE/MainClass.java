package _18_dec_6;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Radius And Height...");
		Cylender cy = new Cylender(sc.nextDouble(),sc.nextDouble());
		System.out.println("Area Of Circle : " + cy.getArea());
		System.out.println("Volume Of Cylender : " + cy.getVolume());
		

	}

}
