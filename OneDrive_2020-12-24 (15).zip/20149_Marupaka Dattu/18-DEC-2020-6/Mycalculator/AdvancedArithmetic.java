package _18_dec_5;

public interface AdvancedArithmetic {
	
	public abstract int divisorSum(int num);

}
