package practise;

public class polindrom {

		
			public static void main(String[] args) {
			int sum = 0;
			int number = Integer.parseInt(args[0]);
			if(number < 100) {
			System.out.println("Enter the number grater than 99");
			}
			else {
			int temp = number;
			while (number > 0) {
			int rev = number % 10;
			sum = (sum * 10) + rev;
			number = number / 10;
			}
			if (sum == temp) {
			System.out.println(" The given number is palindrome " + temp);
			}
			else {
			System.out.println(" The given number is not a palindrome " + temp);
			}
			}
			}
			}


