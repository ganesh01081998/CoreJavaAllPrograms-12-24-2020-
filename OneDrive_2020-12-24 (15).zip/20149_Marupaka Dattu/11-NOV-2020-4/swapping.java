package practise;

public class swapping {
	public static void main(String[] args) {
		int num1,num2;
		num1 = Integer.parseInt(args[0]);
		num2 = Integer.parseInt(args[1]);
		num(num1,num2);
		
	}
	
	static void num(int num3 , int num4){
		System.out.println("before swapping first value:" +num3 + "second value" +num4);
		
		num3 = num3 + num4;
		num4 = num3 - num4;
		num3 = num3 - num4;
		System.out.println("After swapping first value:" +num3 +  "second value" +num4);
	}
	
	

}
