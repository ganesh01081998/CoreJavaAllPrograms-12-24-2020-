package practise;


public class SumOfFour {
		
		public static void main(String[] args) {
			if(args.length < 4) {
				System.out.println("Enter any four numbers");
				return;
			}
			else {
				int nNum1 = Integer.parseInt(args[0]);
				int nNum2 = Integer.parseInt(args[1]);
				nNum1 += Integer.parseInt(args[2]);
				nNum2 += Integer.parseInt(args[3]);
				System.out.println("Sum = " +(nNum1 + nNum2));
			}
		}
 }
	


