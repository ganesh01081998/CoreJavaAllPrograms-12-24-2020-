package practise;

public class NextMultipleOf100 {
	static int nextMultipleNum(int num) {
		int res = 0;
		
		return res;
	}
	public static void main(String[] args) {
		int sum = 0 ;
		int number = Integer.parseInt(args[0]);

		if(number > 0) {
		int rev = number / 100;
		sum = (rev + 1) * 100;
		}
		System.out.println("The Next Multiple of 100 is: " + sum);
		}

}
