
import java.util.Scanner;

public class OddSum {
	
	
	static Scanner sc = new Scanner(System.in);
	
	static int getOddCount(int size) {
		int sum = 0;
		if(size == 10) {
			int[] arr = new int[size];
			System.out.println("Enter Array Elements....");
			for (int i = 0; i < arr.length; i++) {
				try {
				arr[i] = sc.nextInt();
				}
				catch(Exception e) {
					System.out.println("InputMismatch");
					
				}
			}
			for (int i = 0; i < arr.length; i++) {
				if(arr[i] % 2 != 0) {
					sum += arr[i];
				}
			}
			
		}
		else {
			return -1;
		}
		
		return sum;
	}

	public static void main(String[] args) {

		System.out.println("Enter Array Size : ");
		int size =  sc.nextInt();
		System.out.println(getOddCount(size));
	}

}