

	import java.util.Scanner;

	public class MinNumber {
		
		static int getMin(int[] arr) {
			int min;
			if(arr.length != 10) {
				min = -1;
			}
			else {
				min = arr[0];
				for (int i = 0; i < arr.length; i++) {
					if(arr[i] < min) {
						min = arr[i];
					}
				}
			}
			return min;
		}
		
		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter Array Size...");
			int size = sc.nextInt();
			int[] arr = new int[size];
			System.out.println("Enter Array Elements...");
			for (int i = 0; i < arr.length; i++) {
				arr[i] = sc.nextInt();
			}
			System.out.println("Min Element is : " + getMin(arr));
		}

	}


