package practise;

import java.util.Scanner;

public class evenNumbers {
	
		static String result="";
		public static void main(String[] args) {
			System.out.println("Enter the number in range order");
			Scanner sc = new Scanner(System.in);
			is_EvenNumbers(sc.nextInt(),sc.nextInt());
			System.out.println(result);
		}
		
		static void is_EvenNumbers(int starting,int ending){
			if(starting > 0){
				for(int count = starting;count<=ending;count++){
					
					if( starting%2==0){
						result =result + starting +" " ;
			             }  
					starting++;
				
			       }
		     }
		}
}
		


