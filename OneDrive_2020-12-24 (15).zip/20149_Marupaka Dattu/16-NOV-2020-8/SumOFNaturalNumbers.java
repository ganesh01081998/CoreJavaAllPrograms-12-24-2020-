package practise17;


	import java.util.Scanner;

	public class SumOFNaturalNumbers {
		static String result = "";
		public static void main(String[] args) {
			System.out.println("Enter numbers in range order");
			Scanner scan = new Scanner(System.in);
			is_SumOfNaturalNumbers(scan.nextInt(),scan.nextInt());
			scan.close();
			System.out.println(result);
		}

		static void is_SumOfNaturalNumbers(int starting, int ending) {
			if(starting > 0) {
				int sum = 0;
				for (int count = starting; count <= ending; count++) {
					sum = sum + count ;			
				}
				result = result + sum;
				
			}
			else {
				result = "Starting number must be greater then zero";
			}
			
		}

}
