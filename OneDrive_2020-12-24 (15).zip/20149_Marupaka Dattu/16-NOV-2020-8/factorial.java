package practise;

import java.util.Scanner;

public class factorial {
	
		
		static String result="";
		public static void main(String[] args) {
			System.out.println("Enter the number ");
			Scanner sc = new Scanner(System.in);
			is_Factorial(sc.nextInt());
			
		}
		
		static void is_Factorial(int number){
			int sum = 1;
			if(number>0){
				while(number > 0){
				sum = sum*number;
				number--;
		}
			System.out.println("The factorial of given number is:" +sum);
		     }  
		}
}




