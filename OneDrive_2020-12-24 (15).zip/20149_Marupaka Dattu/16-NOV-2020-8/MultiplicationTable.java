package practise;


	import java.util.Scanner;

	public class MultiplicationTable {
		static String result = "";
		public static void main(String[] args) {
			System.out.println("Enter any numbers ");
			Scanner scan = new Scanner(System.in);
			is_MultiplicationTable(scan.nextInt());
			scan.close();
			System.out.println(result);
		}

		static void is_MultiplicationTable(int number) {
			for (int count = 0; count <= 10; count++) {
				result = result + (number + " * " + count + " = " + (number * count) + "\n"); 
			}
		}
	}



