package _10_dec;

import java.util.Scanner;

public class Courses {
	int price;
	Student student;
	String courses;

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String menus = "Courses avaliable are \n 1. JAVA\n 2. DotNet\n 3. Python\n "
				+ "4. Testing(Automation)\n 5. Java + Python\n 6. Java + Testing\n "
				+ "7. Java + DotNet + Python\n 8.Exit \n Enter the Option of chosie";
		System.out.println("Enter the Name , Branch ,House Number and City ");
		Student student = new Student(scan.next(), scan.next(), scan.next(), scan.next());
		System.out.println(menus);
		Courses cou = new Courses(scan.nextInt(), student);
		System.out.println(cou.toString());
	}
	public Courses(int option, Student student) {
		this.student = student;
		String [] menu = {"JAVA", "DotNet", "Python", "Testing(Automation)", "Java + Python", "Java + Testing", "Java + DotNet + Python"};
		int [] prices = {15000, 15000, 15000, 10000, 25000, 20000, 35000};
		if(option <= prices.length) {
			this.price = prices[option-1];
			this.courses = menu[option-1];
		}
		else if(option == 8) {
			System.exit(0);
		}
		else {
			System.out.println("Enter the correct option");
			main(null);
		}
	}
	@Override
	public String toString() {
		return "Courses [price=" + price + ", student=" + student + ", courses=" + courses + "]";
	}
}
