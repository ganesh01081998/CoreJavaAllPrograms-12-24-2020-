
import java.util.Scanner;

public class SumEvenNoInArray {
	public static void main(String[] args) {
		int count = 0, recount = 0;
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the size of array");
		int [] array = new int [scan.nextInt()];
		System.out.println("Enter the array elements");
		for (int insert = 0; insert < array.length; insert++) {
			int temp = scan.nextInt();
			if(temp < 0) {
				count++;
			}
			if(temp == 0) {
				recount++;
			}
			array[insert] = temp;
		}
		System.out.println(getSumOfEvenNumbers(array, count , recount));
	}

	static String getSumOfEvenNumbers(int[] array, int count, int recount) {
		int sum = 0;
		String result ="";
		if(recount > 0) {
			result ="-1";
		}
		else if (count > 0) {
			result = "-2";
		}
		else if (recount > 0) {
			result = "-3";
		} 
		else {
			for (int check = 0; check < array.length; check++) {
				if(array[check] % 2 == 0) {
					sum += array[check];
				}
			}
			result ="" + sum;
		}
		return result;
	}
}
