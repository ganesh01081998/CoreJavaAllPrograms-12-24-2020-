
import java.util.Scanner;

public class MarkEmali {
	static String result ="";
	public static void main(String[] args) {
		String Email;
		System.out.println("Enter you Email id");
		Scanner sc = new Scanner(System.in);
		Email =sc.next();
		result += ""+Email.charAt(0)+Email.charAt(1);
		doThis(Email);
		System.out.println(result);
	}
	static void doThis(String Email) {
		for (int i = 2; i < Email.length(); i++) {
			if(Email.charAt(i) == '@') {
				doAgain(i,Email);
				break;
			}
			else {
				result+="x";
			}
		}
	}
	static void doAgain(int i, String Email) {
		for (int j = i; j < Email.length(); j ++) {
			result+= Email.charAt(j);
		}
	}
}

