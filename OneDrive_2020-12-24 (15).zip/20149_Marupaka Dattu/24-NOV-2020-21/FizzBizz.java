
import java.util.Scanner;

public class FizzBizz {
	static String result = "";
	public static void main(String[] args) {
		System.out.println("Enter any numbers");
		Scanner scan = new Scanner(System.in);
		is_FizzBizz(scan.nextInt());
		scan.close();
		System.out.println(result);
	}

	static String is_FizzBizz(int num) {
		if(num > 0) {
			if(num% 3 == 0 && num % 5 != 0) {
				result = "FIZZ";
			}
			else if(num% 3 != 0 && num % 5 == 0) {
				result = "BIZZ";
			}
			else if(num% 3 == 0 && num % 5 == 0) {
				result = "FIZZBIZZ";
			}
		}
		else {
			if(num < 0) {
				result = " Enter the number greater then ZERO";
			}
		}
		return result;
	}
}