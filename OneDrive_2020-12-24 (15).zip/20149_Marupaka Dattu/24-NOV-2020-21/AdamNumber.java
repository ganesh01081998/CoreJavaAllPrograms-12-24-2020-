

	import java.util.Scanner;

	public class AdamNumber {
		public static void main(String[] args) {
			int sum1=0, sum=0, number, number1,temp;
			System.out.println("ENTER A VALUE: ");
			Scanner sc = new Scanner(System.in);
			number = sc.nextInt();
			temp = number1 = number;
			number *= number;
			sum = getReverse(number);
			sum1 = getReverse(number1);
			sum1 *= sum1;
			if(sum == sum1)
				System.out.println(temp+" is a adam number");
			else
				System.out.println(temp+" is not a adam number");
		}

		 static int getReverse(int num) { 
			int rev , sum = 0;
			while(num > 0)
			{
				rev = num % 10;
				sum = (sum * 10)+rev;
				num = num / 10;
			}
			return sum;

}
	}
