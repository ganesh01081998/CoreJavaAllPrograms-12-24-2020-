

	import java.util.Scanner;

	public class LuckyNumber {
		public static void main(String[] args) {
	        int luckyNumber = 0;
	        String monthName = "";
	        Scanner sc = new Scanner(System.in);
	        System.out.println("Enter Your Date Of Birth : ");
	        String dateOfBirth = sc.next().toLowerCase();
	        dateOfBirth = dateOfBirth.replaceAll("-", "");
	        dateOfBirth = dateOfBirth.replaceAll("/", "");
	        String[] month = {"jan","feb","mar","apr","may","jun","july","aug","sep","oct","nov","dec"};
	        monthName += dateOfBirth.charAt(2) + dateOfBirth.charAt(3) + dateOfBirth.charAt(4);
	        System.out.println(monthName);
	        for (int i = 0; i < month.length; i++) {
	            if(monthName.equals(month[i])) {
	            	luckyNumber += i+1;
	            }
	        }
	        for (int i = 0; i < dateOfBirth.length(); i++) {
	            char ch  = dateOfBirth.charAt(i);
	            if(i < 2 || i > 4) {
	            	luckyNumber += Character.getNumericValue(ch);
	            }
	        }
	        while(luckyNumber > 10) {
	            int rev = luckyNumber % 10;
	            luckyNumber = luckyNumber / 10;
	            luckyNumber = luckyNumber + rev;
	        }
	        System.out.println(luckyNumber);        
	    }

}
