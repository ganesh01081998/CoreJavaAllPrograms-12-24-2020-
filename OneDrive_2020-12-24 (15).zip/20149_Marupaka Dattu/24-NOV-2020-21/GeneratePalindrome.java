

	import java.util.Scanner;

	public class GeneratePalindrome {
		static int fixNumber;
		static String result ="";
		public static void main(String[] args) {
			Scanner scan = new Scanner(System.in);
			System.out.println("Enter any number");
			fixNumber = scan.nextInt();
			
			is_palindrome(fixNumber);
			System.out.println(result);
		}
		static String is_palindrome(int number) {
			result += " " + number ;
			int rev, temp, sum=0;
			temp = number;
			while (number > 0) {
				rev = number % 10;
				sum = (sum*10) + rev;
				number = number/10;
			}
			if (sum == temp) {
				result +=  " This is the generation of the palindrome";
			}
			else {
				result += " " + sum ;
				number = sum + temp;
				is_palindrome(number);
			}
			return result;
		}

}
