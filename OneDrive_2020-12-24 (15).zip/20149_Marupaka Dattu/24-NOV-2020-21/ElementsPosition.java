

	import java.util.Scanner;
	public class ElementsPosition {
		public static void main(String[] args) {
			int count = 0, search;
			Scanner scan = new Scanner(System.in);
			System.out.println("Enter the size of the array");
			int [] array = new int[scan.nextInt()];
			System.out.println("Enter the elements in the array");
			for (int insert = 0; insert < array.length; insert++) {
				int temp = scan.nextInt();
				if(temp <= 0) {
					count++;
				}
				array[insert] = temp;
			}
			System.out.println("Enter the search number");
			search = scan.nextInt();
			System.out.println(getElepositions(search,array,count));
		}

		static String getElepositions(int search, int[] array, int count) {
			String result = "";
			if(array.length ==0) {
				result = "-2";
			}
			else if(count > 0) {
				result ="-4";
				
			}
			else if( search <= 0) {
				result = "-3";
			}
			else  {
				for (int check = 0; check < array.length; check++) {
					if(search == array[check]) {
						result = " the position of the elements is: "+ (check+1);
					}
				}
			}
			return result;
		}

}
