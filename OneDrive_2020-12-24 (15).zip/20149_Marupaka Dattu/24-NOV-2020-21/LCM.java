

	import java.util.Scanner;

	public class LCM {
		static int  lcm = 0;
		public static void main(String args[]){
		      int firstNumber, secondNumber;
		      Scanner sc = new Scanner(System.in);
		      System.out.println("Enter first number :");
		      firstNumber = sc.nextInt();
		      System.out.println("Enter second number :");
		      secondNumber = sc.nextInt();
		      is_Lcm(firstNumber, secondNumber);
		      
		      System.out.println("LCM of given numbers is : "+lcm);
		   }

		static void is_Lcm(int firstNumber, int secondNumber) {
			int  max, step;
			if(firstNumber > secondNumber){
		         max = step = firstNumber;
		      }
		      else{
		         max = step = secondNumber;
		      }

		      while(firstNumber!= 0) {
		         if(max % firstNumber == 0 && max % secondNumber == 0) {
		            lcm = max;
		            break;
		         }
		         max += step;
		      }
		}

}
