
import java.util.Scanner;

public class NameScore {
	static String result = "";
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the name ");
		String name = sc.next();
		ScoreOfTheName(name);	
		System.out.println(result);
	}
	static String ScoreOfTheName(String name) {
		int sum = 0;
		boolean b1;
		for (int insert = 0; insert < name.length(); insert++) {
			char c = name.charAt(insert);
		    b1 = Character.isUpperCase(c);
		    if(b1 == true) {
		    	sum += c - 64;
		    }
		    else if(b1 == false){
		    	sum += c - 96;
		    }
		    else {
		    	System.out.println("Dont Enter the spaces");
		    }
		}
		result += sum;
		return result;
	}
}