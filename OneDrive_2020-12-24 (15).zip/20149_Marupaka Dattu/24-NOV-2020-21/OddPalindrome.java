
import java.util.Scanner;

public class OddPalindrome {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the numbers for range");
		int starting = scan.nextInt();
		int ending = scan.nextInt();
		System.out.println("The Odd Palindrome in the given range is " + is_OddPalindrome(starting , ending));
	}

	static String is_OddPalindrome(int start, int end) {
		int temp , num;
		String result = "";
		for (int index = start; index <= end ; index++) {
			temp = num = index;
			int rev = temp % 10;
			if(rev % 2 !=0) {
				int  sum = 0;
				while(temp > 0) {
					rev = temp % 10;
					sum =sum *10 + rev;
					temp = temp / 10;
				}
				if(sum == num) {
					result += " \n" + sum;
				}
			}
		}
		return result;
	}
}
