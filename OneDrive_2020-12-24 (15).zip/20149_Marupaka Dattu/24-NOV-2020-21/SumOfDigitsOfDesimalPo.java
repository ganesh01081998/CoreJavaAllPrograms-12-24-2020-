
import java.util.Scanner;

public class SumOfDigitsOfDesimalPo{
	static String result ="";
	public static void main(String[] args) {
		System.out.println("Enter any number");
		Scanner sc = new Scanner(System.in);
		String num = sc.next();
		for (int i = 0; i < num.length(); i++) {
			if(num.charAt(i) == '.') {
				getsum(i, num);
				break;
			}
		}
	}
	static void getsum(int i, String num) {
		int sum = 0,sum1=0;
		for (int j = 0; j < num.length(); j++) {
			if(j < i) {
				char ch = num.charAt(j);
				sum += Character.getNumericValue(ch);
			}
			if(j>i){
				char ch = num.charAt(j);
				sum1 += Character.getNumericValue(ch);
			}
		}
		result += sum + ":" +sum1;
		System.out.println(result);
	}
}
