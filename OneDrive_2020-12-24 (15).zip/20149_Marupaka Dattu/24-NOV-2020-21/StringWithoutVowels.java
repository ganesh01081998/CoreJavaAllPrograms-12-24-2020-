
import java.util.Scanner;

public class StringWithoutVowels {
	public static void main(String[] args) {
		String name;
		System.out.println("Enter you name ");
		Scanner scan = new Scanner(System.in);
		name =scan.nextLine();
		System.out.println(is_DisplayVowels(name.toLowerCase()));
	}

	static String is_DisplayVowels(String name) {
		 String result="";
		for (int i = 0; i < name.length(); i++) {
			char ch = name.charAt(i);
            if(ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' ) {
               
            }
            else {
            	 result += ch + " " ;
            }
		}
		return result.toUpperCase();	
	}
}