import java.util.Scanner;

public class StringVowels {
	public static void main(String[] args) {
	 String name;
	System.out.println("Enter the name");
	Scanner sc = new Scanner(System.in);
	name = sc.next();
	displayvowels(name.toLowerCase());
	System.out.println(name.toUpperCase());
	}

	 static String displayvowels(String name) {
		String result = "";
		for(int i = 0;i<name.length();i++){
			char ch = name.charAt(i);
			if(ch=='a' || ch=='e' || ch=='i' || ch=='o' || ch=='u'){
				result+=ch+" ";
			}
		}
		return result;
	}
	
}
