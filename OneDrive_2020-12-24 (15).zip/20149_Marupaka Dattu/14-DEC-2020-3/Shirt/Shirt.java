package _14_dec_2;

import java.util.Scanner;
enum Material {
	COTTON,LENIN,Polyester;
}
class Shirt1 {
	private float collerSize;
	private float collerLength;
	private String material;
	Material m;
	Shirt1() {
		this.collerSize = 0;
		this.collerLength = 0;
		this.material = "cotton";
	}

	public Shirt1(float collerSize, float collerLength, String material, Material m) {
		this.collerSize = collerSize;
		this.collerLength = collerLength;
		this.material = material;
		this.m = m;
	}
	public float getCollerSize() {
		return collerSize;
	}
	public Material getM() {
		return m;
	}

	public void setM(Material m) {
		this.m = m;
	}

	public void setCollerSize(float collerSize) {
		this.collerSize = collerSize;
	}
	public float getCollerLength() {
		return collerLength;
	}
	public void setCollerLength(float collerLength) {
		this.collerLength = collerLength;
	}
	public String getMaterial() {
		return material;
	}
	public void setMaterial(String material) {
		this.material = material;
	}
	@Override
	public String toString() {
		return "Shirt1 [collerSize=" + collerSize + ", collerLength=" + collerLength + ", material=" + material + ", m="
				+ m + "]";
	}
}
	public class Shirt {
    public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("enter size,length,material");
	Shirt1 s1 = new Shirt1(sc.nextFloat(),sc.nextFloat(),sc.next(), Material.Polyester);
	Shirt1 s3 = new Shirt1();
	System.out.println(s3);
	System.out.println(s1);
}
}
