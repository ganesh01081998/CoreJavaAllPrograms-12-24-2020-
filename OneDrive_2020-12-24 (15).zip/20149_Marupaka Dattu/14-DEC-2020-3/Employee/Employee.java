package _14_dec;

public class Employee {
	String empName;
	int empId;
	double  salary;
	public Employee(String empName, int empId, double salary) {
		this.empName = empName;
		this.empId = empId;
		this.salary = salary;
	}

}
