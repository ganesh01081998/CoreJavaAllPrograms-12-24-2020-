package _14_dec;

enum ManagerType {
	HR,SALES;
}
public class Manager extends Employee{
	ManagerType m;

	public Manager(String empName, int empId, double salary, ManagerType m) {
		super(empName, empId, salary);
		this.m = m;
	}
	public double setSalary(String empType) {
		salary = salary;
		if(empType.equalsIgnoreCase("HR")) {
			salary = salary + 10000;
		}
		else if(empType.equalsIgnoreCase("SALES")) {
			salary =  salary + 5000;
		}
		else {
			System.out.println("enter valid role name");
		}
		return salary;
	}
	@Override
	public String toString() {
		return "Manager [m=" + m + ", empName=" + empName + ", empId=" + empId + ", salary=" + salary + "]";
	}

}

