package _14_dec_3;

public class Hosteller extends Student {
	double hostelFee ;
	public Hosteller(int stdId, String sName, double examFee, double hostelFee) {
		super(stdId, sName, examFee);
		this.hostelFee = hostelFee;
	}
	double payFee(int amount) {
		double fee = 0;
		double totalFee = examFee + hostelFee;
		System.out.println("total fee is " + totalFee);
		if(totalFee == amount) {
			System.out.println("thak you... your amount successfully paid");
		}
		else if(totalFee >= amount) {
			System.out.println("please clear the remainng amount");
			return fee = totalFee - amount;
		}
		else {
			System.out.println("recive remaing amount");
			return fee = totalFee - amount;	
		}
		return totalFee ;
	}
	public String toString() {
		return "Hosteller [hostelFee=" + hostelFee + ", stdId=" + stdId + ", sName=" + sName + ", examFee=" + examFee + "]";
	}
}