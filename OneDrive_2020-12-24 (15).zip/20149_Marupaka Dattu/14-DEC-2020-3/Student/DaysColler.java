package _14_dec_3;

public class DaysColler extends Student{
	double transPortFee;

	public DaysColler(int stdId, String sName, double examFee,double transPortFee) {
		super(stdId, sName, examFee);
		this.transPortFee = transPortFee;
	}
	double payFee(int amount) {
		double fee = 0;
		double totalFee = examFee + transPortFee;
		System.out.println("total fee is " + totalFee);
		if(totalFee == amount) {
			System.out.println("thak you... your amount successfully paid");
		}
		else if(totalFee >= amount) {
			System.out.println("please clear the remainng amount");
			return fee = totalFee - amount;
		}
		else {
			System.out.println("recive remaing amount");
			return fee = totalFee - amount;	
		}
		return totalFee ;
	}
	@Override
	public String toString() {
		return "DaysColler [transPortFee=" + transPortFee + ", stdId=" + stdId + ", sName=" + sName + ", examFee=" + examFee
				+ "]";
	}

}

