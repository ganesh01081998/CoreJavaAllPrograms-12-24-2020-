package _14_dec_3;

import java.util.Scanner;

public class MainMethdOfStd {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String res = "";
		res += "1.DaysColler\n";
		res += "2.Hosteller\n";
		System.out.println(res);
		System.out.println("enter type of student");
		String str = sc.next();
		switch(str) {
		case "DaysColler":
			System.out.println("enter days coler id,name,exam fee,trasportaion fee");
			DaysColler d = new DaysColler(sc.nextInt(), sc.next(), sc.nextDouble(),sc.nextDouble());
			System.out.println("enter how much you want to pay");
			System.out.println(d.payFee(sc.nextInt()));
			System.out.println(d);
			break;
		case "Hosteller" :
			System.out.println("enter hosteller id,name,exam fee,Hostel fee");
			Hosteller h = new Hosteller(sc.nextInt(), sc.next(), sc.nextDouble(),sc.nextDouble());
			System.out.println("enter how much you want to pay");
			System.out.println(h.payFee(sc.nextInt()));
			System.out.println(h);
			break;
       default : 
    	   System.out.println("enter valid type of student");
		}
	}
}
