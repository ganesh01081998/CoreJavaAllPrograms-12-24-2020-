package _14_dec_3;

public class Student {
	int stdId;
	String sName;
	double examFee;
	public Student(int stdId, String sName, double examFee) {
		super();
		this.stdId = stdId;
		this.sName = sName;
		this.examFee = examFee;
	}
	double payFee() {
		return examFee;
	}
	@Override
	public String toString() {
		return "Student [stdId=" + stdId + ", sName=" + sName + ", examFee=" + examFee + "]";
	}

}