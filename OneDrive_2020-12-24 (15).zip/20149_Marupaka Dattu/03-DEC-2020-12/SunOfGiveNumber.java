package _03_dec;

import java.util.Scanner;

public class SunOfGiveNumber {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter any number");
		int number = scan.nextInt();
		is_SumOfDigits(number);
		
	}

	static void is_SumOfDigits(int number) {
		int sum = 0,rev;
		while(number > 0) {
			rev = number % 10;
			sum += rev;
			number = number/10;
		}
		System.out.println(sum);
	}
}
