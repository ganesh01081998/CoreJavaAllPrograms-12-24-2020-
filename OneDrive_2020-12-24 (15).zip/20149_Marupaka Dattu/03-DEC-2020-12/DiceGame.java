package _03_dec;

import java.util.Random;
import java.util.Scanner;

public class DiceGame {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		Dice d1 = new Dice();
		Dice d2 = new Dice();
		System.out.println("Enter first player name");
		Player p1 = new Player(scan.next());
		System.out.println("Enter Second Player name");
		Player p2 = new Player(scan.next());
		p1.throwDice(d1, d2);
		p2.throwDice(d1, d2);
		String result = "";
		if (p1.playerValue > p2.playerValue) {
			result = p1.playerName + " Wins the game";
		}
		else if (p2.playerValue > p1.playerValue) {
			result = p2.playerName + " Wins the game";
		}
		else{
			result = "The Game is TIE Try Again";
		}
		System.out.println(result);
	}
}
class Dice{
	int faceValue;
	public void roll() {
		Random r = new Random();
		faceValue = r.nextInt(6) + 1;
	}
}
class Player{
	String playerName;
	int playerValue;
	public Player(String playerName) {
		this.playerName = playerName;
	}
	public void throwDice(Dice d1, Dice d2) {
		d1.roll();
		d2.roll();
		playerValue = d1.faceValue + d2.faceValue;
		System.out.println(playerName + "=" + d1.faceValue + " + " +d2.faceValue);
	}
}

