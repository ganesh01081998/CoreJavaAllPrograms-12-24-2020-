package _03_dec;

import java.util.Scanner;

public class FindWord {
	
	static void getFindWord(String str,String str1) {
		String[] str3 = str.split(" ");
		for (int i = 0; i < str3.length; i++) {
			if(str1.equals(str3[i])) {
				System.out.println(str1 + " is Found..."); 
			}
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any Sentence...");
		String str = sc.nextLine().toLowerCase();
		System.out.println("Enter Word To Find...");
		String str1 = sc.next().toLowerCase();
		getFindWord(str,str1);
	}
}
