package _03_dec;

import java.util.Scanner;

public class CreateArray {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the starting and Ending numbers");
		int starting = scan.nextInt();
		int ending = scan.nextInt();
		System.out.println(is_CreateArray(starting, ending));
	}

	static String is_CreateArray(int start, int end) {
		String result = "";
		if(start > end) {
			int temp = start;
			start = end;
			end = temp;
		}
		int [] array = new int[end - start];
		for (int index = 0; index < array.length; index++) {
			array[index] = start ++;
			result += array[index] +" ";
		}
		return result;
	}
}
