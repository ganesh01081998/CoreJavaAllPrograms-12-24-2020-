package _07_dec;


	import java.util.Scanner;

	public class SumIfThereIsNo13 {
		public static void main(String[] args) {
			Scanner scan = new Scanner(System.in);
			System.out.println("Enter any three values ");
			int first = scan.nextInt();
			int second = scan.nextInt();
			int three = scan.nextInt();
			System.out.println(check(first, second, three));
		}
		static int check(int first, int second, int three) {
			int sum = 0;
			if (first == 13) {
			}
			else {
				sum += first;
				if(second == 13) {
				}
				else {
					sum += second;
					if(three == 13) {
					}
					else {
						sum += three;
					}
					}
				}
			
			return sum;
		}
	}


