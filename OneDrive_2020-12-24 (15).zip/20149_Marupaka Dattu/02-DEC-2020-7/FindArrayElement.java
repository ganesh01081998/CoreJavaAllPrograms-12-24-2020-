package _02_12_20;

import java.util.Scanner;

public class FindArrayElement {
	
	static int getCount(int[] arr,int find) {
		int count = 0;
		if(arr.length == 0) {
			return -1;
		}
		for (int i = 0; i < arr.length; i++) {
			if(arr[i] == find) {
				count++;
			}
		}
		return count;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Array Size");
		int size = sc.nextInt();
		int[] arr = new int[size];
		System.out.println("Enter Array Elements");
		for (int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		System.out.println("Enter Search Element In given Array");
		int find = sc.nextInt();
		System.out.println(find + " : " + getCount(arr,find));
	}

}
