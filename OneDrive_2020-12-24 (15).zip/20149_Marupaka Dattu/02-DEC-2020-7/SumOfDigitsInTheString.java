package _02_12_20;

import java.util.Scanner;

public class SumOfDigitsInTheString {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the numbers");
		String name = sc.nextLine();
		System.out.println(sumOfDigits(name));
	}
	static int sumOfDigits(String str){
		int sum = 0;
	 for(int i= 0;i < str.length();i++){
		 char ch = str.charAt(i);
		 for(int j = 1; j < 10; j++){
			 int check = Character.getNumericValue(ch);
			 if(check == j){
				 sum = sum + check;  
			 }
		 }
		 
	 }
		return sum;
	}
}
