package _02_12_20;

import java.util.Scanner;

public class DiagonalSum {

	static int getDiagonalSum(int[][] arr) {
		int count = 0;
		for (int i = 0; i < arr.length; i++) {
			for (int j = i; j < arr.length; j++) {
				if(i == j) {
					count += arr[i][j];
				}
			}

		}
		return count;	
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Array Size");
		int size = sc.nextInt();
		if(size!=3) {
			System.out.println("ERROR");
		}
		else{
			int[][] arr = new int[size][size];
			System.out.println("Enter Array Elements");
			for (int i = 0; i < arr.length; i++) {
				for (int j = 0; j < arr.length; j++) {
					arr[i][j] = sc.nextInt();
				}
			}

			System.out.println(getDiagonalSum(arr));
		}
	}
}