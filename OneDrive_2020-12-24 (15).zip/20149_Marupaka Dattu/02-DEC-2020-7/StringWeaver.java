package _02_12_20;

import java.util.Scanner;

public class StringWeaver {
	public static void main(String[] args) {
		System.out.println("Enter two Strings one after another");
		Scanner scan = new Scanner(System.in);
		String one = scan.next();
		String two = scan.next();
		System.out.println(is_StringWeaver(one , two));
	}
	static String is_StringWeaver(String one, String two) {
		
		String result = "";
		if((one == null) && (two == null)) {
			result = "-1";
		}
		else if (one.length() > two.length()) {
			result = two + " " + one + " " + two;
		}
		else if (one.length() < two.length()) {
			result = one + " " + two + " " + one;
		}
		else if(one.length() == two.length()) {
			for (int index = 0; index < one.length(); index++) {
				int sum = 0;
				for (int check = 0; check <= index; check++) {
					if(one.charAt(index) == two.charAt(check)) {
						sum ++;
					}
				}
				if(sum <= 1) {
					result += one.charAt(index) + "" + two.charAt(index) +" ";
				}
			}
		}
		return result;
	}
}

