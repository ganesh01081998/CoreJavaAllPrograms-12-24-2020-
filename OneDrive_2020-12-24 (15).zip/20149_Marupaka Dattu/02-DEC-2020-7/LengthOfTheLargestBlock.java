package _02_12_20;

import java.util.Scanner;

public class LengthOfTheLargestBlock {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter name");
		String name = sc.nextLine();
		System.out.println((maxBlock(name)));
	}
	static int maxBlock(String str){
		String result = "";
		int count1 = 0;
		
		for(int j = 0 ;j <str.length();j++){	
		char ch1 = str.charAt(j);
		int count = 0;
		for(int i = 0; i < str.length(); i++ ){  
          if(ch1 == str.charAt(i)){
		   count ++;
		   }	
		}

		if(count1<count)
		count1=count; 
		}
	
	return count1;	
	}

}