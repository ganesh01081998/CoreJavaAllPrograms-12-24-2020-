package practise17;


	import java.util.Scanner;

	public class Differ21 {
		static String result ="";
		public static void main(String[] args) {
			Scanner scan = new Scanner(System.in);
			System.out.println("Enter any number");
			is_Differ21(scan.nextInt());
			System.out.println(result);
		}

		private static String is_Differ21(int number) {
			if(number < 21) {
				result = result + (21- number);
			}
			else {
				result = result + (number - 21)*2;
			}
			return result;
		}
	}



