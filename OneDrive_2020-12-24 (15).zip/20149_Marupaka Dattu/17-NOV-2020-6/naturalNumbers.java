package practise;

import java.util.Scanner;

public class naturalNumbers {
	static String result="";
	public static void main(String[] args) {
		System.out.println("Enter the number in range order");
		Scanner sc = new Scanner(System.in);
		is_NaturalNumbers(sc.nextInt(),sc.nextInt());
		System.out.println(result);
	}
	
	static void is_NaturalNumbers(int starting,int ending){
		if(starting > 0){
			for(int count = starting;count<=ending;count++){
				result = result + count +",";
			}
		}
			else {
				result = "Starting number must be greater than zero";
			}
		}
	}
	

