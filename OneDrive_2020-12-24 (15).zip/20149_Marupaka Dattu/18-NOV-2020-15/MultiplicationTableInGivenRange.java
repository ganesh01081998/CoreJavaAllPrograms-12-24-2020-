package practise18;


	

	import java.util.Scanner;

	public class MultiplicationTableInGivenRange {
		static String result = "";
		public static void main(String[] args) {
			Scanner scan = new Scanner(System.in);
			System.out.println("Enter the numbers to give range");
			is_printTable(scan.nextInt(), scan.nextInt());
			System.out.println(result);
		}

		static void is_printTable(int starting, int ending) {
			for (int num = starting; num <= ending; num++) {
				for (int mult = 1; mult <= 10; mult++) {
					do_Multiplication(num, mult);
				}
				result += "\n";
			}
			
		}

		static void do_Multiplication(int num, int mult) {
			result += "num " + num +" * " + mult +" = "+ (num * mult) + "\n";
		}
	}


