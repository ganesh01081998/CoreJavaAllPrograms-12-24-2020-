package practise18;

import java.util.Scanner;

public class Patten13 {
	static String result ="";
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter number of rows and coloum");
		int num1 = scan.nextInt();
		int num2 = scan.nextInt();
		is_Patten(num1, num2);
		System.out.println(result);
	}

	static void is_Patten(int num1, int num2) {
		int start = -1;
		for (int row= 1; row <= num1; row++)
        {
			start += 2;
			for (int space = 1 ; space <= num1-row ;space++)
            {
                result += " ";
            }
            for (int col = 1; col <= start; col++)
            {
                result += "*";
            }
            result += "\n";
		}
	}	    
}