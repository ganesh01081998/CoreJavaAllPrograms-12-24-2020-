package _04_dec;

import java.util.Scanner;

public class GetStudentData {
    public int stdid;
    public String stdName;
    private int marks;
    private char grade;

    public void displayDetails() {
        System.out.println("[Name=" + stdName + " StudentId=" + stdid + 
                 " Marks =" + marks + " grade=" + grade + "]");
    }
    private void calculateGrade(int marks) {
        if (marks > 90) {
            grade = 'A';
        } else if (marks > 80) {
            grade = 'B';
        } else if (marks > 70) {
            grade = 'C';
        } else if (marks > 60) {
            grade = 'D';
        } else {
            grade = 'E';
        }
    }
    GetStudentData(int stdid, String stdName, int marks) {
        this.stdid = stdid;
        this.stdName = stdName;
        this.marks = marks;
    }
    public static void main(String[] args) {
    	Scanner sc = new Scanner(System.in);
    	System.out.println("Enter the Student id,name,marks");
        GetStudentData std1 = new GetStudentData(sc.nextInt(), sc.next(), sc.nextInt());
        std1.calculateGrade(std1.marks);
        std1.displayDetails();
       
    }
}