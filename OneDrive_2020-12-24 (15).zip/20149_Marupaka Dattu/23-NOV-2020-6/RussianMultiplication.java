
public class RussianMultiplication {
	public static void main(String[] args) {
		russionmulti(11,7);
	}
		
	
	static void russionmulti(int half,int mul){
		int sum = 0;
		while(half>=1){
		if(half%2 !=0){
		sum = sum+mul;
		half = half/2;
		mul = mul*2;

		}
		else{
		half = half/2;
		mul = mul*2;
		}


		}
		System.out.println(sum);

		}

		 

		
		
		

		 

}
