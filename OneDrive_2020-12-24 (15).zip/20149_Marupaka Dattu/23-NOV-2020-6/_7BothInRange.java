
import java.util.Scanner;



public class _7BothInRange {
	static boolean is3050(int num1,int num2) {
		if(num1 >= 30 && num1 <=40 && num2 >= 30 && num2 <= 40 ) {
			return true;
		}
		else if (num1 >= 40 && num1 <=50 && num2 >= 40 && num2 <= 50 ) {
			return true;
		}
		return false;
	}
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter two inputs : ");
		int num1 = scanner.nextInt(),num2 = scanner.nextInt();
		System.out.println(is3050(num1,num2));
	}
}