
import java.util.Scanner;

public class NearHundred {

	static boolean nearHundred(int number){
		boolean b = false;
		if(number >= 90 & number <= 110 ){
			number = 100 - number;
			if(number <= 10){
				b = true;
			}
		}
		else if(number >= 190 & number <= 210){
			number = 200 - number;
			if(number <= 10){
				b = true;
			}
		}
		return b;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any Number...");
		int number = sc.nextInt();
		System.out.println(nearHundred(number));
	}
}
