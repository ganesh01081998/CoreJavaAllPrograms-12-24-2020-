
import java.util.Scanner;

public class SumDouble {
	
	static int isSumDouble(int firstNum,int secNum) {
		int sum = 0;
		if(firstNum != secNum) {
			sum = firstNum + secNum;
		}
		else if(firstNum == secNum) {
			sum = (firstNum * 2) + (secNum * 2);
		}
		return sum;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any Two Numbers : ");
		int firstNum = sc.nextInt();
		int secNum = sc.nextInt();
		System.out.println(isSumDouble(firstNum,secNum));

	}

}
