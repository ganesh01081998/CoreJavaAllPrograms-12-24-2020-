
import java.util.Scanner;

public class SameLastDigit {
	
	static boolean  isSameLastDigit(int firstNum,int secNum) {
		boolean b = false;
		int num1 = firstNum % 10;
		int num2 = secNum % 10;
		if(num1 == num2) {
			b = true;
		}
		return b;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any Two Numbers : ");
		int firstNum = sc.nextInt();
		int secNum = sc.nextInt();
		System.out.println(isSameLastDigit(firstNum,secNum));

	}

}
