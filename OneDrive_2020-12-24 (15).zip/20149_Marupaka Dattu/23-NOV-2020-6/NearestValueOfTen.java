
import java.util.Scanner;

public class NearestValueOfTen {
	
	static int isNearestValue(int firstNum,int secNum) {
		int diff = 0;
		int nearest = 10 - firstNum;
		int near = 10 - secNum; 
		nearest = Math.abs(nearest);
		near = Math.abs(near);
		if(nearest < near) {
			diff = firstNum;
		}
		else if(nearest > near) {
			diff = secNum;
		}
		else if(nearest == near)  {
			diff = 0;
		}
		return diff;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any Two Numbers...");
		int firstNum = sc.nextInt();
		int secNum = sc.nextInt();
		System.out.println(isNearestValue(firstNum,secNum)); 

	}

}
