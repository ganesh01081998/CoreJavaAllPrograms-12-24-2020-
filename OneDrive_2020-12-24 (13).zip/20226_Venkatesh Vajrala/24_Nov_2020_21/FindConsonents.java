package com.ojas.strings;

import java.util.Scanner;

public class FindConsonents {
	
	static String findConsonets(String name) {
		String result = name.toLowerCase();
		String consonents = "";
		for (int i = 0; i < result.length(); i++) {
			char ch = result.charAt(i);
			if(ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' ) {
				
			}
			else {
				consonents += ch + " " ;
			}
		}
		return consonents;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any String...");
		String name = sc.next();
		System.out.println(findConsonets(name));
	}

}
