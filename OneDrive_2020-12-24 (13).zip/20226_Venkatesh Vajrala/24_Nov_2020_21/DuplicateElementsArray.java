package com.ojas.programs;

import java.util.Scanner;

public class DuplicateElementsArray {
	
	public static void main(String[] args) {      
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Array Size");
		int [] arr = new int [sc.nextInt()];
		System.out.println("Enter The Array Elements");
		for (int index = 0; index < arr.length; index++) {
			arr[index] = sc.nextInt();
		}
        isDublicateElements(arr);
    }

	static void isDublicateElements(int[] arr) {
		System.out.println("Duplicate Elements in given array: ");   
        for(int i = 0; i < arr.length; i++) {  
            for(int j = i + 1; j < arr.length; j++) {  
                if(arr[i] == arr[j])  
                    System.out.println(arr[j]);  
            }  
        }  
		
	}  

}
