package com.ojas.strings;

import java.util.Scanner;

public class FindVowels {
	
	static String findVowels(String name) {
		String result = name.toLowerCase();
		String vowels = "";
		for (int i = 0; i < result.length(); i++) {
			char ch = result.charAt(i);
			if(ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' ) {
				vowels += ch + " " ;
			}
		}
		return vowels;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any String...");
		String name = sc.next();
		System.out.println(findVowels(name));
	}
}
