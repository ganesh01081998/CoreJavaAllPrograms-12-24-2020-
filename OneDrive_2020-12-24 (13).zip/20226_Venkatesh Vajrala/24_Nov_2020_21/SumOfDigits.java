package com.ojas.programs;

import java.util.Scanner;

public class SumOfDigits {
	
static int getSumOfDigit(int num) {
		
		int rem,quo,sum = 0;
		while(num > 0) {
			rem = num % 10;
			sum = sum + rem;
			num = num / 10;	
		}
		return sum;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any Number : ");
		int num = sc.nextInt();
		System.out.println("Sum Of Digits : " + getSumOfDigit(num));
	}

}
