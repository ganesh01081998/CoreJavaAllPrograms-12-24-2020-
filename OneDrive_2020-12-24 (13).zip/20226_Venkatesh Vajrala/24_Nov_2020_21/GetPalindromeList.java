package com.ojas.programs;

import java.util.Scanner;

public class GetPalindromeList {
	
	static String result = "";

	static String getPalindromeList(int num) {
		int total = 0;
		int temp = num;
		int rem,sum = 0;
		while(num > 0) {
			rem = num % 10;
			sum = (sum * 10) + rem;
			num = num / 10;
		}
		System.out.println(sum);
		if(sum == temp) {
			System.out.println(sum + " Palindrome");
		}
		else {
			result += sum;
			total = sum + temp;
			getPalindromeList(total);
		}
		return result;
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any Number...");
		int num = sc.nextInt();
		getPalindromeList(num);
	}
}
