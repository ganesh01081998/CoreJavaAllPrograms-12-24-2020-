package com.ojas.programs;

import java.util.Scanner;

public class ReverseArray {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Array Size");
		int [] arr = new int [sc.nextInt()];
		System.out.println("Enter The Array Elements");
		for (int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		isReverseArray(arr);
	}

	static void isReverseArray(int[] arr) {
		for (int  i = arr.length-1;i >= 0; i--) {
			System.out.print(arr[i] + " ");
		}
		
	}

}
