package com.ojas.programs;

import java.util.Scanner;

public class RemoveVowels {
	
	static String isRemoveVowels(String str) {
		String result = "";
		for (int i = 0; i < str.length(); i++) {
			char ch = str.charAt(i);
			if(ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' ) {
				
			}
			else {
				result += str.charAt(i);
			}
		}
		return result;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any String...");
		String str  = sc.nextLine();
		System.out.println(isRemoveVowels(str));
	}
}
