package com.ojas.programs;

import java.util.Scanner;

public class LuckyNumber {
	
	static int isLuckyNumber(String str,String[] month,int[] days) {
		int mon = 0;
		String str1 = "";
		for (int i = 2; i < 5; i++) {
			str1 += str.charAt(i);
		}
		System.out.println(str1);
		for (int i = 0; i < month.length; i++) {
			if(str1.equals(month[i])) {
				mon += days[i];
			}
		}
		for (int i = 0; i < str.length(); i++) {
			char ch  = str.charAt(i);
			if(i < 2 || i > 4) {
				mon += Character.getNumericValue(ch);
			}
		}
		if(mon > 10) {
			int rev = mon % 10;
			mon = mon / 10;
			mon = mon + rev;
		}
		return mon;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Your Date Of Birth : ");
		String str = sc.next().toLowerCase();
		str = str.replaceAll("-", "");
		str = str.replaceAll("/", "");
		String[] month = {"jan","feb","mar","apr","may","jun","july","aug","sep","oct","nov","dec"};
		int[] days = {1,2,3,4,5,6,7,8,9,10,11,12};
		System.out.println(isLuckyNumber(str, month, days));
	}

}
