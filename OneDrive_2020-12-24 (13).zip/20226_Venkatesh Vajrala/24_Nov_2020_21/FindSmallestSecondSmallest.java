package com.ojas.programs;

import java.util.Scanner;

public class FindSmallestSecondSmallest {
	
	static int getSmallest(int[] arr) {
		int temp = arr[0];
		int small = 0;
		for (int i = 0; i < arr.length; i++) {
			if(arr[0] > arr[i]) {
				small = arr[i];
			}
		}
		return small;
	}
	
	static int getSecondSmall(int[] arr) {
		int temp = arr[0];
		int secondSmall = 0;
		for (int i = 1; i < arr.length; i++) {
			if(temp > arr[i]) {
				secondSmall = temp;
				temp = arr[i];
			}
		}
		return secondSmall;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Array Size..");
		int size = sc.nextInt();
		int[] arr = new int[size];
		System.out.println("Enter Array Elements...");
		for (int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		System.out.println("Smallest Element : " + getSmallest(arr));
		System.out.println("SecondSmallest Elements : " + getSecondSmall(arr));
	}
}
