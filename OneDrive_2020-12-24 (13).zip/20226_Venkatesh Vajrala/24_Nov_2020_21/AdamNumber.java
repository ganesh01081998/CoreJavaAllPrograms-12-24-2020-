package com.ojas.programs;

import java.util.Scanner;

public class AdamNumber {
	
	static boolean isReverse(int num) {
		
		boolean b = false;
		int rem,sum = 0;
		int number = num * num;
		while(num > 0) {
			rem = num % 10;
			sum = (sum * 10) + rem;
			num = num / 10;
		}
		System.out.println(sum);
		int rem1,sum1 = 0;
		int number2 = sum * sum;
		while(number2 > 0) {
			rem1 = number2 % 10;
			sum1 = (sum1 * 10) + rem1;
			number2 = number2 / 10;
		}
		if(number == sum1) {
			b = true;
		}
		return b;
	}
		

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any Number..");
		int num = sc.nextInt();
		System.out.println(isReverse(num));
	}

}
