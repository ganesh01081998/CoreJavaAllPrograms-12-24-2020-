package com.ojas.programs;

import java.util.Scanner;

public class OddPalindrome {
	
	static boolean palindrome(int num) {
		boolean b = false;
		int temp = num,rem,sum = 0;
		while(num > 0) {
			rem = num % 10;
			sum = (sum * 10) + rem;
			num = num / 10;
		}
		if(temp == sum && sum % 2 == 1) { 
			System.out.println(sum+" Palindrome");
		}
		return b;
	}

	static boolean range(int startValue,int endValue) {
		String res = ""; 
		for(int i = startValue;i <= endValue; i++) {
			if(palindrome(i)) {
				res = res + i;
			}
		}
		return false;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter First Number : ");
		int num1 = sc.nextInt();
		System.out.println("Enter Second Number : ");
		int num2 = sc.nextInt();
		range(num1,num2);
	}
}
