package com.ojas.programs;

import java.util.Scanner;

public class SortArrayElements {
	
	static void sortArray(int[] arr) {
		for (int i = 0; i < arr.length; i++) {
			for (int j = i+1; j < arr.length; j++) {
				if(arr[i] > arr[j]) {
					int temp = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
				}
			}
		}
	}
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the size of array");
		int arr[] = new int[scan.nextInt()];
		System.out.println("Enter the array elements");
		for (int insert = 0; insert < arr.length; insert++) {
			arr[insert] = scan.nextInt();
		}
		sortArray(arr);
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
	}
}
