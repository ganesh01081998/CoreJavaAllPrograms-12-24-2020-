package com.ojas.programs;

import java.util.Scanner;

public class LCM {

	static int result;
	
	static int lcmOfNumbers(int num1, int num2) {
		int lcm = 0;
		if(num1 < 0 || num2 < 0) {
			lcm = -1;
		}
		else {
			for(int i =1;i <= num1 && i <= num2;i++) {
				if(num1 % i == 0 && num2 % i == 0) {
					result = i;
				}
			}
			lcm = (num1 * num2) / result;
		}
		return lcm;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Two Numbers : ");
		int firstNum = sc.nextInt();
		int secNum = sc.nextInt();
		System.out.println(lcmOfNumbers(firstNum,secNum));
	}
}
