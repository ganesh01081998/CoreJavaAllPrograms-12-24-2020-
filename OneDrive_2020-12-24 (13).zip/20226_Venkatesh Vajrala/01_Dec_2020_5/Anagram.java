package com.ojas.programs;

import java.util.Arrays;
import java.util.Scanner;

public class Anagram {

	static String anagram(String str1,String str2) {
		String res = "";
		if(str1.length() == 0 || str2.length() == 0) {
			res = null;
		}
		else if(str1.length() == str2.length()) {
			char[] c1 = str1.toLowerCase().toCharArray();
			char[] c2 = str2.toLowerCase().toCharArray();
			Arrays.sort(c1);
			Arrays.sort(c2);

			boolean result = Arrays.equals(c1, c2);

			if(result) {
				res = "Anagram";
			}
			else	{
				res = "Not Anagram";
			}
		}
		return res;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the String1 : ");
		String s1 = sc.nextLine();
		System.out.println("Enter the String2 :  ");
		String s2 = sc.nextLine();
		System.out.println(anagram(s1,s2));
	}
}
