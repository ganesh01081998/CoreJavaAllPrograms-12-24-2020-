package com.ojas.simple;

import java.util.Scanner;

public class NumbersList {

	static String naturalNumbers(String name) {
		String res = "";
		name = name.replaceAll(",","-");
		String nums[] = name.split("-");
		int values[] = new int[nums.length];
		for (int i = 0; i < values.length; i++) {
			values[i] = Integer.parseInt(nums[i]);
		}
		for (int i = findSmall(values); i <= findBig(values); i++) {
			res += i;
			if(i < findBig(values)) {
				res += ",";
			}
		}
		return res;
	}
	
	static int findBig(int[] nums) {
		int big = nums[0];
		for (int i = 1; i < nums.length; i++) {
			if(nums[i] > big) {
				big = nums[i];
			}
		}
		return big;
	}
	
	static int findSmall(int[] nums) {
		int small = nums[0];
		for (int i = 1; i < nums.length; i++) {
			if(nums[i] < small) {
				small = nums[i];
			}
		}
		return small;
	}

	public static void main(String[] args) {

		String str1 = "1,4-6-10,30";
		System.out.println(naturalNumbers(str1));

	}
}
