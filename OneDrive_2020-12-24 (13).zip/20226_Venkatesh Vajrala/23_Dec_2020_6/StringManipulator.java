package com.ojas.dec23;

import java.util.Scanner;

public class StringManipulator {
	
	static String removeVowels(String name) {
		String result = name;
		String vowels = "";
		if(result.length() == 0) {
			vowels = null;
		}
		else {
			for (int i = 0; i < result.length(); i++) {
				char ch = result.charAt(i);
				if(ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' || 
						ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U' ) {
					
				}
				else {
					vowels += ch ;
				}
			}
		}		
		return vowels;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any String...");
		String name = sc.nextLine();
		System.out.println(removeVowels(name));
	}

}
