package com.ojas.dec23;

import java.util.Scanner;

public class MirrorImage {
	
	static void isMirror(String word) {
		int count = 0;
		String mirror ="";
		int size = word.length() - 1;
		while(count < word.length()) {
			if(word.charAt(count) == word.charAt(size)) {
				mirror +=word.charAt(count);
			}
			else {
				break;
			}
			count++;
			size--;
		}
		System.out.println(mirror);
		
	}

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string in form of mirror");
		String word = sc.next().toLowerCase();
		isMirror(word);

	}

}
