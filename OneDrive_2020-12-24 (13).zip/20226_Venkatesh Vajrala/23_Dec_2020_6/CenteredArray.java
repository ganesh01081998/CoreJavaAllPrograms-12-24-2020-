package com.ojas.dec23;

import java.util.Scanner;

public class CenteredArray {
	
	static Scanner sc = new Scanner(System.in);
	
	static void centeredAverage(int size) {
		 int center = 0;
		int[] arr = new int[size];
		System.out.println("Enter Array Elements...");
		for (int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		
		for (int i = 0; i <= arr.length / 2; i++) {

			center = arr[i];
		}
		System.out.println(center);
		
	}
	
	public static void main(String[] args) {
		
		System.out.println("Enter Array Size");
		int size = sc.nextInt();
		if(size >= 3) {
			centeredAverage(size);
			
		}
		else {
			System.out.println("Give Atleast Array Size 3...");
		}	

	}

}
