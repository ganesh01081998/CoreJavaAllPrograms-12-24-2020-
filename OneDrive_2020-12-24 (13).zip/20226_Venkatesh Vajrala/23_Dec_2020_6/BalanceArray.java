package com.ojas.dec23;

import java.util.Scanner;

public class BalanceArray {
	
static Scanner sc = new Scanner(System.in);
	
	static boolean canBalance(int size) {
		boolean b = false;
		 int first = 0;
		 int second = 0;
		 
		int[] arr = new int[size];
		System.out.println("Enter Array Elements...");
		for (int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		
		int len = size / 2;
		for (int i = 0; i < arr.length; i++) {
			if(i <= len) {
				first = first + arr[i];
			}
			else if(i >= len) {
				second = second + arr[i];
			}
		}
		
		if(first == second) {
			b = true;
		}
		return b;
		
	}
	
	public static void main(String[] args) {
		
		System.out.println("Enter Array Size");
		int size = sc.nextInt();
		if(size != 0) {
			System.out.println(canBalance(size));
			
		}
		else {
			System.out.println("Give Minimum Array Size ...");
		}	

	}


}
