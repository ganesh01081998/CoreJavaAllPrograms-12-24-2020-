package com.ojas.dec07;

import java.util.Scanner;

public class SumNoTeen {
	
	static int check(int first, int second, int three) {
		int sum = 0;
		sum += fixTeen(first);
		sum += fixTeen(second);
		sum += fixTeen(three); 
		return sum;
	}
	
	static int fixTeen(int num) {
		if((num >= 13 && num <= 14) || (num >= 17 && num <= 19)) {
			return 0;
		}
		else {
			return num;
		}
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any Three Values... ");
		int first = sc.nextInt();
		int second = sc.nextInt();
		int three = sc.nextInt();
		System.out.println(check(first, second, three));
	}
}
