package com.ojas.dec07;

import java.util.Scanner;

public class LuckySum {
	
	static void getLuckySum(int firstNum,int secNum,int thirdNum) {
		int sum = 0;
		if(firstNum != 13 && secNum != 13 && thirdNum != 13 ) {
			sum = firstNum + secNum + thirdNum;
		}
		else if(firstNum == 13) {
			sum = sum;
		}
		else if(secNum == 13) {
			sum = firstNum;
		}
		else if(thirdNum == 13) {
			sum = firstNum + secNum;
		}
		System.out.println(sum);
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any Three Numbers...");
		int firstNum = sc.nextInt();
		int secNum = sc.nextInt();
		int thirdNum = sc.nextInt();
		getLuckySum(firstNum, secNum, thirdNum);

	}

}
