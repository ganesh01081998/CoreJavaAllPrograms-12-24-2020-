package com.ojas.patterns;

import java.util.Scanner;

public class Pattern2 {
	
	static String getPattern(int number) {
		String result = "";
		for(int i = number; i >= 1; i--) {
			for(int j = number; j >= 1; j--) {
				result += j + " ";
			}
			result += "\n";
		}
		return result;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any Number : ");
		int number = sc.nextInt();
		System.out.println(getPattern(number));
	}
}
