package com.ojas.patterns;

import java.util.Scanner;

public class Pattern12 {
	
	static String getPattern(int number) {
		String result = "";
		
		for(int i = 1; i <= number; i++) {
			for(int j = 1; j <= number; j++) {
				if(i == 1 || j == 1 || i == number || j == number ) {
				result += "*" + " " ;
				}
				else {
					result += "   ";
				}
			}
			result += "\n";
		}
		return result;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any Number : ");
		int number = sc.nextInt();
		System.out.print(getPattern(number));
	}
	
}
