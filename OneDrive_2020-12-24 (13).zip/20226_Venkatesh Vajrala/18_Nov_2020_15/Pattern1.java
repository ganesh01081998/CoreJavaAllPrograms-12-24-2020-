package com.ojas.patterns;

import java.util.Scanner;

public class Pattern1 {
	
	static String getPattern(int rows,int cols) {
		String result = "";
		for(int i = 1; i <= rows; i++) {
			for(int j = 1; j <= cols; j++) {
				result += j + " ";
			}
			result += "\n";
		}
		return result;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Rows & Cols Number :");
		System.out.println(getPattern(sc.nextInt(),sc.nextInt()));

	}

}
