package com.ojas.sample;

import java.util.Scanner;

public class RangeOfMultiplicationTable {
	
	static boolean multiplication(int num) {
		boolean b = false;
		int i = 1;
		while(i <= 10) {
			System.out.println(num + " * " + i + " = " + (num * i));
			i++;
		}
		System.out.println();
		return true;
	}
	
	static void rangeTable(int num1,int num2) {	
		for(int i = num1; i <= num2; i++) {
			if(multiplication(i)) {
				
			}
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Two Numbers : ");
		int firstNum = sc.nextInt();
		int secNum = sc.nextInt();
		rangeTable(firstNum,secNum);
	}
}
