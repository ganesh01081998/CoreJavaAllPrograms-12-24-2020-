package com.ojas.dec21;

import java.util.Scanner;

public class Test_Leaves {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("How Many Leaves You Needed....");
		LeaveSystem ls = new LeaveSystem(sc.nextInt());
		ls.exceedLeave();

	}

}
