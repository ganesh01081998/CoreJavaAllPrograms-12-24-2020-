package com.ojas.dec21;

public class LeaveSystem {
	
	int  leave;
	int totalLeaves = 20;
	
	public LeaveSystem(int leave) {
		this.leave = leave;
	}
	
	public void exceedLeave() {
		try {
			if(leave > totalLeaves) {
				throw new LeaveQuotaExceededException("You Exceed Leaves...");
			}
			else {
				System.out.println("Sanction The Leave...");
			}
		}
		catch(LeaveQuotaExceededException e) {
			System.out.println(e);
		}
	}

}
