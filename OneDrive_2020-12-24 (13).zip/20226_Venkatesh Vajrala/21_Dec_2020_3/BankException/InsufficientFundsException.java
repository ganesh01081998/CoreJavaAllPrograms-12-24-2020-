package com.ojas.AccountException;

public class InsufficientFundsException extends Exception{
	
	private double amount;
	
	public InsufficientFundsException(String amount) {
		System.out.println("Your Account has Less Amount : " + getAmount());
	}
	
	public  double getAmount() {
		
		return amount;
		
	}

}
