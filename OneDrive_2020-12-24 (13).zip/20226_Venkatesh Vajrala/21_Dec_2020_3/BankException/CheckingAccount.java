package com.ojas.AccountException;

public class CheckingAccount {

	private int accountNo;
	private double balance;

	public CheckingAccount(int accountNo, double balance) {
		this.accountNo = accountNo;
		this.balance = balance;
	}

	public boolean checkAccount(int accountNo) {
		boolean b = false;
		if(this.accountNo == accountNo) {
			b = true;
		}
		return b;

	}

	public void deposit(int accountNo,int amount) {

		if(this.accountNo == accountNo) {
			balance = balance + amount;
			System.out.println("Deposit Amount : " + amount);
		}
		else {
			System.out.println("Invalid Account Number....");
		}
	}

	public double withdraw(int accountNo,int amount) {

		try {
			if(this.accountNo == accountNo) {
				if(amount > balance) {
					throw new InsufficientFundsException("InsufficientFundsException");
				}
				else {
					balance = balance - amount;
				}
			}
			else {
				System.out.println("Invalid Account Number....");
			}
		}
		catch(InsufficientFundsException e) {
			System.out.println(e);
		}

		return amount;
	}

}
