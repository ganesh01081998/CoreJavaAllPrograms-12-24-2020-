package com.ojas.AccountException;

import java.util.Scanner;

public class BankDemo {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Your Account Number & Balance....");
		CheckingAccount  ca = new CheckingAccount(sc.nextInt(),sc.nextDouble());
		System.out.println("Re-Enter Your Account Number....");
		if(ca.checkAccount(sc.nextInt()) == false) {
			System.out.println("Give Correct Account Number....");
		}
		else {
			String menu = "Select Any Option...\n 1.Deposit \n 2.WithDraw \n 3.Exit";
			System.out.println(menu);
		}
		int choice = sc.nextInt();
		switch(choice) {
		case 1 : 
			System.out.println("Enter AccountNumber & Deposit Amount....");
			ca.deposit(sc.nextInt(),sc.nextInt());
			break;
		case 2 : 
			System.out.println("Enter AccountNumber &  Withdraw Account....");
			System.out.println("The Withdraw Amount : " + ca.withdraw(sc.nextInt(),sc.nextInt()));
			break;
		case 3 : 
			System.exit(0);
		}


	}

}
