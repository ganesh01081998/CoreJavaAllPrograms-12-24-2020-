package com.ojas.dec14;

import java.util.Scanner;

public class InheritenceTester {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Select Any Option...\n 1.DayScholar\n 2.Hosteller");
		switch (sc.nextInt()) {
		case 1:
			System.out.println("Enter StudentID And StudentName And ExamFee And TranspotationFee");
			DayScholar ds = new DayScholar(sc.nextInt(),sc.next(),sc.nextDouble(),sc.nextDouble());
			ds.payFee();
			ds.dispDetails();
			break;
		case 2:
			System.out.println("Enter StudentID And StudentName And ExamFee And HostleFee");
			Hosteller hs = new Hosteller(sc.nextInt(),sc.next(),sc.nextDouble(),sc.nextDouble());
			hs.payFee();
			hs.dispDetails();
			break;
		default:
			break;
		}
			

	}

}
