package com.ojas.dec14;

public class Student {
	
	int studentId;
	String name;
	double examFee;
	
	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getExamFee() {
		return examFee;
	}

	public void setExamFee(double examFee) {
		this.examFee = examFee;
	}

	public Student() {
		
	}
	
	public Student(int studentId,String name,double examFee) {
		this();
		this.studentId = studentId;
		this.name = name;
		this.examFee = examFee;
	}

	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", name=" + name + ", examFee=" + examFee + "]";
	}
	
	public void payFee() {
		
		this.examFee = examFee;
		
	}
	
	public String dispDetails() {
		return toString();
	}

}
