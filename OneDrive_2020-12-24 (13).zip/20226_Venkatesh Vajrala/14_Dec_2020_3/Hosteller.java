package com.ojas.dec14;

public class Hosteller extends Student {
	
double hostile;
	
	public Hosteller() {
		
	}

	public Hosteller(int studentId,String name,double examFee,double hostile) {
		super(studentId,name,examFee);
		this.hostile = hostile;
	}
	
	public void payFee() {
		double totalFee = 15000;
		  
		 if((examFee + hostile) == totalFee) {
			 System.out.println("Amount Paid Successfully...");
		 }
		 else if((examFee + hostile) < totalFee) {
			 System.out.println("Due Amount : " + (totalFee - (examFee + hostile)) );
		 }
		 else if((examFee + hostile) > totalFee) {
			 System.out.println("Return Amount : " + ((examFee + hostile) - totalFee) );
		 }
		

	}
	
	public String dispDetails() {
		return toString();
	}

	@Override
	public String toString() {
		return "Hosteller [hostile=" + hostile + "]";
	}

}
