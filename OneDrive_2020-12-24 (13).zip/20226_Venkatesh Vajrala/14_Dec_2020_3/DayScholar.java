package com.ojas.dec14;

public class DayScholar extends Student {
	
double transportFee;
	
	
	public DayScholar() {
		
	}

	public DayScholar(int studentId,String name,double examFee,double transportFee) {
		super(studentId,name,examFee);
		this.transportFee = transportFee;
	}
	
	public void payFee() {
		double totalFee = 10000;
		  
		 if((examFee + transportFee) == totalFee) {
			 System.out.println("Amount Paid Successfully...");
		 }
		 else if((examFee + transportFee) < totalFee) {
			 System.out.println("Due Amount : " + (totalFee - (examFee + transportFee)) );
		 }
		 else if((examFee + transportFee) > totalFee) {
			 System.out.println("Return Amount : " + ((examFee + transportFee) - totalFee) );
		 }
		

	}
	
	public String dispDetails() {
		return toString();
	}

	@Override
	public String toString() {
		return "DayScholar [transportFee=" + transportFee + "]";
	}
	
	

}
