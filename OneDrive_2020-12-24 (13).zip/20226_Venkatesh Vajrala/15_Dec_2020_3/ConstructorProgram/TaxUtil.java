package com.ojas.dec15;

public class TaxUtil {
	
	double tax;
	
	public double calculateTax(double grossSalary) {
		if(grossSalary > 30000) {
			tax = (grossSalary  * 20) /100;
		}
		else {
			tax = (grossSalary  * 5) /100;
		}
		return tax;
		
	}

}
