package com.ojas.dec15;

public class Sourcing {
	
	int empId;
	String name;
	double basicSalary;
	double HRAPer ;
	double DAPer;
	int enrollmentTarget;
	int enrollmentReached;
	double perkPerEnrollment;
	double grossSalary;
	
	public double calculateGrossSalary() {
		grossSalary = basicSalary + HRAPer + DAPer +((enrollmentReached / enrollmentTarget) * 100) * perkPerEnrollment;
		return grossSalary;
	}

	public Sourcing(int empId, String name, double basicSalary, double hRAPer, double dAPer, int enrollmentTarget,
			int enrollmentReached, double perkPerEnrollment) {
		super();
		this.empId = empId;
		this.name = name;
		this.basicSalary = basicSalary;
		HRAPer = hRAPer;
		DAPer = dAPer;
		this.enrollmentTarget = enrollmentTarget;
		this.enrollmentReached = enrollmentReached;
		this.perkPerEnrollment = perkPerEnrollment;
	}

	@Override
	public String toString() {
		return "Sourcing [empId=" + empId + ", name=" + name + ", basicSalary=" + basicSalary + ", HRAPer=" + HRAPer
				+ ", DAPer=" + DAPer + ", enrollmentTarget=" + enrollmentTarget + ", enrollmentReached="
				+ enrollmentReached + ", perkPerEnrollment=" + perkPerEnrollment + ", grossSalary=" + grossSalary + "]";
	}
	
	

}
