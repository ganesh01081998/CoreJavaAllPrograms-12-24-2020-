package com.ojas.dec15;

public class Trainer {
	
	int empId;
	String name;
	double basicSalary;
	double HRAPer ;
	double DAPer;
	double batchCount;
	double perkPerBatch;
	double grossSalary;
	
	public double calculateGrossSalary() {
		grossSalary = basicSalary + HRAPer + DAPer + (batchCount * perkPerBatch);
		return grossSalary;
	}

	public Trainer(int empId, String name, double basicSalary, double hRAPer, double dAPer, double batchCount,
			double perkPerBatch) {
		super();
		this.empId = empId;
		this.name = name;
		this.basicSalary = basicSalary;
		HRAPer = hRAPer;
		DAPer = dAPer;
		this.batchCount = batchCount;
		this.perkPerBatch = perkPerBatch;
	}

	@Override
	public String toString() {
		return "Trainer [empId=" + empId + ", name=" + name + ", basicSalary=" + basicSalary + ", HRAPer=" + HRAPer
				+ ", DAPer=" + DAPer + ", batchCount=" + batchCount + ", perkPerBatch=" + perkPerBatch
				+ ", grossSalary=" + grossSalary + "]";
	}
	
	

}
