package com.ojas.dec15;

public class Manager {
	
	int empId;
	String name;
	double basicSalary;
	double HRAPer ;
	double DAPer;
	double projectAllowance;
	double grossSalary;
	
	public double calculateGrossSalary() {
		grossSalary = basicSalary + HRAPer + DAPer + projectAllowance;
		return grossSalary;
	}

	public Manager(int empId, String name, double basicSalary, double hRAPer, double dAPer, double projectAllowance) {
		super();
		this.empId = empId;
		this.name = name;
		this.basicSalary = basicSalary;
		HRAPer = hRAPer;
		DAPer = dAPer;
		this.projectAllowance = projectAllowance;
	}

	@Override
	public String toString() {
		return "Manager [empId=" + empId + ", name=" + name + ", basicSalary=" + basicSalary + ", HRAPer=" + HRAPer
				+ ", DAPer=" + DAPer + ", projectAllowance=" + projectAllowance + ", grossSalary=" + grossSalary + "]";
	}

		
	
}
