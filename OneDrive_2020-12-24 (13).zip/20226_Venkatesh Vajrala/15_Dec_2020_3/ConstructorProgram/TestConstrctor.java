package com.ojas.dec15;

import java.util.Scanner;

public class TestConstrctor {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		TaxUtil tu = new TaxUtil();
		System.out.println("Enter Employee ID,Name,BasicSalary,HRAPer,DAPer.....");
		Employee e = new Employee(sc.nextInt(),sc.next(),sc.nextDouble(),sc.nextDouble(),sc.nextDouble());
		System.out.println("Employee Tax : " + tu.calculateTax(e.calculateGrossSalary()));
		System.out.println();
		System.out.println("Enter Manager ID,Name,BasicSalary,HRAPer,DAPer,ProjectAllowance.....");
		Manager m = new Manager(sc.nextInt(),sc.next(),sc.nextDouble(),sc.nextDouble(),sc.nextDouble(),sc.nextDouble());
		System.out.println("Manager Tax : " + tu.calculateTax(m.calculateGrossSalary()));
		System.out.println();
		System.out.println("Enter Trainer ID,Name,BasicSalary,HRAPer,DAPer,BatchCount,PerkPerBatch.....");
		Trainer t = new Trainer(sc.nextInt(),sc.next(),sc.nextDouble(),sc.nextDouble(),sc.nextDouble(),sc.nextDouble(),sc.nextDouble());
		System.out.println("Trainer Tax : " + tu.calculateTax(t.calculateGrossSalary()));
		System.out.println();
		System.out.println("Enter Sourcing ID,Name,BasicSalary,HRAPer,DAPer,EnrollmentTarget,EnrollmentReached,PerkPerEnrollment.....");
		Sourcing s = new Sourcing(sc.nextInt(),sc.next(),sc.nextDouble(),sc.nextDouble(),sc.nextDouble(),sc.nextInt(),sc.nextInt(),sc.nextDouble());
		System.out.println("Sourcing Tax : " + tu.calculateTax(s.calculateGrossSalary()));
		
	}

}
