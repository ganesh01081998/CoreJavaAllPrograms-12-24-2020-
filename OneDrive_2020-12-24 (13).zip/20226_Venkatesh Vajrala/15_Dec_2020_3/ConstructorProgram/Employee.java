package com.ojas.dec15;

public class Employee {
	
	int empId;
	String name;
	double basicSalary;
	double HRAPer ;
	double DAPer;
	double grossSalary;
	
	public double calculateGrossSalary() {
		grossSalary = basicSalary + HRAPer + DAPer;
		return grossSalary;
	}

	public Employee(int empId, String name, double basicSalary, double hRAPer, double dAPer) {
		super();
		this.empId = empId;
		this.name = name;
		this.basicSalary = basicSalary;
		HRAPer = hRAPer;
		DAPer = dAPer;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", name=" + name + ", basicSalary=" + basicSalary + ", HRAPer=" + HRAPer
				+ ", DAPer=" + DAPer + ", grossSalary=" + grossSalary + "]";
	}
	
	

}
