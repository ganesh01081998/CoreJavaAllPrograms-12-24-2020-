package com.ojas.dec15;

public class ScienceStudent extends Student {

	int physicsMarks;
	int chemistryMarks;
	int mathsMarks;
	int percentage;

	public ScienceStudent(String studentName,String studentClass,int physicsMarks, int chemistryMarks, int mathsMarks) {
		super(studentName,studentClass);
		this.physicsMarks = physicsMarks;
		this.chemistryMarks = chemistryMarks;
		this.mathsMarks = mathsMarks;
	}

	@Override
	int getPercentage() {
		if(physicsMarks <= 100 && chemistryMarks <= 100 && mathsMarks <= 100) {
			int total = physicsMarks + chemistryMarks + mathsMarks;
			 percentage = total / 3;
			
		}
		else {
			System.out.println("Give Proper Marks...");
		}
		return percentage;
	}

	@Override
	public String toString() {
		return "ScienceStudent [StudentName = " + studentName + ", StudentClass = "
				+ studentClass + " PhysicsMarks = " + physicsMarks + ", ChemistryMarks = " + chemistryMarks + ", MathsMarks = "
				+ mathsMarks + ", Percentage = " + getPercentage() + "]";
	}

	public String display() {
		return toString();
	}
	
	
}
