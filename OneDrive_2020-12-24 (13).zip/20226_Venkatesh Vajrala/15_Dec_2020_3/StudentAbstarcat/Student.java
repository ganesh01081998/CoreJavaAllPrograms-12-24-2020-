package com.ojas.dec15;

abstract class Student {
	
	String studentName;
	String studentClass;
	protected static int totalNoOfStudents;
	
	abstract int getPercentage() ;
		
	static void getTotalNoStudents() {
		
	}
	
	public Student() {
		
	}

	public Student(String studentName, String studentClass) {
		super();
		this.studentName = studentName;
		this.studentClass = studentClass;
	}

	@Override
	public String toString() {
		return "Student [studentName=" + studentName + ", studentClass=" + studentClass + "]";
	}

	

}
