package com.ojas.dec15;

import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Select Catageroy Of Student...\n 1. ScienceStudent\n 2. HistoryStudent");
		
		switch (sc.nextInt()) {
		case 1:
			System.out.println("Enter Science Student Name,Class,Marks....");
			ScienceStudent ss = new ScienceStudent(sc.next(),sc.next(),sc.nextInt(),sc.nextInt(),sc.nextInt());

			System.out.println(ss.display());
			break;
		case 2:
			System.out.println("Enter History Student Name,Class,Marks....");
			HistoryStudent hs = new HistoryStudent(sc.next(),sc.next(),sc.nextInt(),sc.nextInt());

			System.out.println(hs.display());
			break;

		default:
			break;
		} 

	}

}
