package com.ojas.dec15;

public class HistoryStudent extends Student {

	int historyMarks;
	int civicsMarks;
	int percentage;

	public HistoryStudent(String studentName,String studentClass,int historyMarks, int civicsMarks) {
		super(studentName,studentClass);
		this.historyMarks = historyMarks;
		this.civicsMarks = civicsMarks;
	}

	@Override
	int getPercentage() {
		if(historyMarks <= 100 && civicsMarks <= 100) {
			int total = historyMarks + civicsMarks;
			percentage = total / 2;
			
		}
		else {
			System.out.println("Give Proper Marks...");
		}
		return percentage;
	}

	@Override
	public String toString() {
		return "HistoryStudent [StudentName = " + studentName + ", StudentClass = " + studentClass + " HistoryMarks = " + historyMarks + ", CivicsMarks = " + civicsMarks + ", Percentage = "
				+ getPercentage() +  "]";
	}

	public String display() {
		return toString();
	}


}
