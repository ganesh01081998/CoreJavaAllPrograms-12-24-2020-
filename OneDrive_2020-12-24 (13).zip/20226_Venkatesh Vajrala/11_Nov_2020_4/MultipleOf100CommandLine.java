package com.ojas.sample;

public class MultipleOf100CommandLine {

	static void isMultiple(int num) {

		int quo,result;
		if(num > 1) {
			quo = num / 100;
			result = (quo + 1) * 100;
			System.out.println("Multiple Of " + num + " Hundred is : " + result);
		}
	}

	public static void main(String[] args) {
		int num = Integer.parseInt(args[0]);
		isMultiple(num);
	}
}
