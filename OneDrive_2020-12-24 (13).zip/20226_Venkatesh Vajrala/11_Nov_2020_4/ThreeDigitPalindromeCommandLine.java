package com.ojas.sample;

public class ThreeDigitPalindromeCommandLine {

	static boolean isPalindrome(int num) {
		
		boolean b = false;
		int temp = num;
		int rem, sum = 0;
		while(num > 0) {
			rem = num % 10;
			sum = (sum * 10) + rem;
			num = num / 10;
		}
		if( temp == sum) {
			b = true;
		}
		return b;
	}

	public static void main(String[] args) {
		int num = Integer.parseInt(args[0]);
		System.out.println(isPalindrome(num));

	}

}
