package com.ojas.sorting;

import java.util.Scanner;

public class InsertionSort {
	
	static void insertionsort(int[] arr) {
		int i,j,sort;
		for (i = 0; i < arr.length; i++) {
			sort = arr[i];
			for (j = i - 1; j >= 0 && arr[j] > sort ; j--) {
				arr[j + 1] = arr[j];
			}
			arr[j + 1] = sort;
		}
	}
	
	static void display(int[] arr) {
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Array Size");
		int size = sc.nextInt();
		int[] arr = new int[size];
		System.out.println("Enter Array Elements..");
		for (int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		insertionsort(arr);
		display(arr);
	}

}
