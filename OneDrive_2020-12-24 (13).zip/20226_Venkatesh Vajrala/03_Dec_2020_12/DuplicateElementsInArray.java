package com.ojas.arrays;

import java.util.Scanner;

public class DuplicateElementsInArray {
	
	static void duplicateElements(int[] arr) {
		
		for (int i = 0; i < arr.length; i++) {
			int count = 0;
			for (int j = i + 1; j < arr.length; j++) {
				if(arr[i] == arr[j]) {
					count++;
					break;
				}
			}
			if(count == 0) {
				System.out.println(arr[i]);
			}
		}	
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Array Size..");
		int size = sc.nextInt();
		int[] arr = new int[size];
		System.out.println("Enter Array Elements...");
		for (int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		duplicateElements(arr);
	}

}
