package com.ojas.dec03;

import java.util.Scanner;

public class TenReplacesWithZero {
	
	 static void isRemoveTens(int[] arr) {
		int num = 0;
		int arr2 [] = new int [arr.length];
		for (int i = 0; i < arr.length; i++) {
			if(arr[i] % 10 == 0) {
				arr[i] = 0;
			}
			else {
				arr2[num] = arr[i];
				num++;
			}
		}
		for (int i = 0; i < arr2.length; i++) {
			System.out.println(arr2[i]);
		}	
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("EnterArray Size...");
		int [] arr = new int[sc.nextInt()];
		System.out.println("Enter Array Elements...");
		for (int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		isRemoveTens(arr);
	}

}
