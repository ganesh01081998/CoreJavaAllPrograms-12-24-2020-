package com.ojas.dec03;

import java.util.Scanner;

public class StringNumberOrNot {
	
	static void isNumberOrNot(String num) {
		
		int count = 0;
		for (int i = 0; i < num.length(); i++) {
			char ch = num.charAt(i);
			boolean b = Character.isDigit(ch);
			if(b) {
				count ++;
			}
		}
		if(count == num.length()) {
			System.out.println("The Given String is integer...");
		}
		else {
			System.out.println("It is String...");
		}
	}
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the number");
		String num = scan.next();
		isNumberOrNot(num);
	}

}
