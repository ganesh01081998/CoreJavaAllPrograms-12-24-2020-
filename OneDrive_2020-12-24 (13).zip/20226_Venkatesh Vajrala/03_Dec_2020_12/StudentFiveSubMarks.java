package com.ojas.dec03;

import java.util.Scanner;

public class StudentFiveSubMarks {
	
	int sno;
	String sname;
	int marks1,marks2,marks3,marks4,marks5;
	
	StudentFiveSubMarks(int sno,String sname,int marks1,int marks2,int marks3,int marks4,int marks5) {
		
		int total,avg;
		String result = "";
		this.sno = sno;
		this.sname = sname;
		this.marks1 = marks1;
		this.marks2 = marks2;
		this.marks3 = marks3;
		this.marks4 = marks4;
		this.marks5 = marks5;
		
		total = marks1 + marks2 + marks3 + marks4 +marks5;
		System.out.println(total);
		avg = (total / 5);
		if(avg >= 75) {
			result = "Distention";
		}
		else if(avg >= 65 ) {
			result = "First Class";
		}
		else if(avg >= 50) {
			result = "Second Class";
		}
		else if(avg >= 40) {
			result = "Third Class";
		}
		else if(avg >= 35) {
			result = "Just Pass..";
		}
		else {
			result = "Fail Try Again...";
		}
		System.out.println(result);
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Student Details...");
		StudentFiveSubMarks stu = new StudentFiveSubMarks(sc.nextInt(),sc.next(),sc.nextInt(),sc.nextInt(),sc.nextInt(),sc.nextInt(),sc.nextInt());
		
		}
		
}
