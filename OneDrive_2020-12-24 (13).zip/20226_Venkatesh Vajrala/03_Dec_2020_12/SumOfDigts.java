package com.ojas.dec03;

import java.util.Scanner;

public class SumOfDigts {
	
static void sumOfDigit(int num) {
		
		int rem,sum = 0;
		while(num > 0) {
			rem = num % 10;
			sum = sum + rem;
			num = num / 10;	
		}
		System.out.println("Sum Of Digits : " + sum);	
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any Number : ");
		int num = sc.nextInt();
		sumOfDigit(num);
	}
}
