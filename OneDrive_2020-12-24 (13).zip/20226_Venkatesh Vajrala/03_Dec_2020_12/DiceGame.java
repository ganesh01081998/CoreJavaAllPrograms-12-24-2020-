package com.ojas.dec03;

import java.util.Random;
import java.util.Scanner;

class Dice {
	
	int faceValue;
	public void roll() {
		Random r = new Random();
		faceValue = r.nextInt(6) + 1;
	}
}

class Player {
	
	String pname;
	int playerValue;
	Player(String pname) {
		this.pname = pname;
	}
	public void throwDice(Dice d1,Dice d2) {
		d1.roll();
		d2.roll();
		playerValue = d1.faceValue + d2.faceValue;
		System.out.println(playerValue + " = " + d1.faceValue + " + " + d2.faceValue);
	}
}

public class DiceGame {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Dice d1 = new Dice();
		Dice d2 = new Dice();
		System.out.println("Enter First player name.");
		Player p1 = new Player(sc.next());
		System.out.println("Enter Second player name.");
		Player p2 = new Player(sc.next());
		p1.throwDice(d1,d2);
		p2.throwDice(d1,d2);
		String res = "";
		if(p1.playerValue > p2.playerValue) {
			res = p1.pname + " Wins the game";
		}
		else if(p2.playerValue > p1.playerValue) {
			res = p2.pname + " Wins the game";
		}
		else if(p1.playerValue == p2.playerValue) {
			res = "Game Tie";
		}
		else {
			res = "Plz try again";
		}
		System.out.println(res);
	}

}
