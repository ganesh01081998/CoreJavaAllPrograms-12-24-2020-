package com.ojas.dec03;

import java.util.Scanner;

public class ReverseOfWord {
	
	static void getReverse(String str) {
		String str2 = "";
		for (int i = str.length() - 1 ; i >= 0 ; i--) {
			str2 += str.charAt(i);
		}
		System.out.println(str2);
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any String...");
		String str = sc.next();
		getReverse(str);
	}
}
