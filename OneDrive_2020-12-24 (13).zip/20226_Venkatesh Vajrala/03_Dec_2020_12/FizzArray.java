package com.ojas.dec03;

import java.util.Scanner;

public class FizzArray {
	
	static void getFizzArray(int start, int end) {
       
        if(start > end) {
            int temp = start;
            start = end;
            end = temp;
        }
        int [] arr = new int[end - start];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = start ++;
        }
        for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i]);
		}
    }

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any Two Elements...");
		int num1 = sc.nextInt();
		int num2 = sc.nextInt();
		getFizzArray(num1, num2);
	}

}
