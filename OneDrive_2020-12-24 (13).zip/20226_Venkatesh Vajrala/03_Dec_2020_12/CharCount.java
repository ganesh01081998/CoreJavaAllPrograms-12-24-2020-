package com.ojas.dec03;

import java.util.Scanner;

public class CharCount {
	
	static void getCharCount(String name,String find) {
		int count = 0;
		char ch = find.charAt(0);
		for (int i = 0; i < name.length(); i++) {
			char ch1 = name.charAt(i);
			if(ch == ch1) {
				count++;
			}	
		}
		System.out.println(ch + " : " + count);
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any Name...");
		String name = sc.next();
		System.out.println("Enter Any Character in the Name...");
		String find = sc.next();
		getCharCount(name,find);
	}
}
