package com.ojas.dec02;

import java.util.Scanner;

public class DiagonalSum {

	static int getDiagonalSum(int[][] arr) {
		int count = 0;
		if(arr.length != 3 || arr.length == 0) {
			return -1;
		}
		else {
			for (int i = 0; i < arr.length; i++) {
				for (int j = i; j < arr.length; j++) {
					if(i == j) {
						count += arr[i][j];
					}
				}
			}
		}
		return count;	
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Array Size...");
		int size = sc.nextInt();
		int[][] arr = new int[size][size];
		System.out.println("Enter Array Elements...");
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr.length; j++) {
				arr[i][j] = sc.nextInt();
			}
		}
		System.out.println(getDiagonalSum(arr));
	}
}
