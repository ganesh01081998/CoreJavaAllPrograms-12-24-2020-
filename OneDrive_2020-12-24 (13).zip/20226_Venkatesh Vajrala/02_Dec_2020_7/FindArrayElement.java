package com.ojas.dec02;

import java.util.Scanner;

public class FindArrayElement {

	static int getCount(int[] arr,int find) {
		int count = 0;

		for (int i = 0; i < arr.length; i++) {
			if(arr[i] == find) {
				count++;
			}
		}
		return count;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Array Size...");
		int size = sc.nextInt();
		int[] arr = new int[size];
		if(arr.length == 0) {
			System.out.println(-1);
		}
		else {
			System.out.println("Enter Array Elements...");
			for (int i = 0; i < arr.length; i++) {
				arr[i] = sc.nextInt();
			}
			System.out.println("Enter Search Element In given Array...");
			int find = sc.nextInt();
			System.out.println(find + " : " + getCount(arr,find));
		}
	}
}
