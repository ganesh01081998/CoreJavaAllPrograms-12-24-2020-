package com.ojas.dec02;

import java.util.Scanner;

public class FindYZ {
	
	static void countYZ(String str) { 
		int count = 0;
		String[] str1 = str.split(" ");
		str = str1[0];
		String str2 = str1[1];
		for (int i = 0; i < str1.length; i++) {
			if(!Character.isLetter(str1[i].length() - 1) ||str1[i].charAt(str1[i].length() - 1) == 'z' || str1[i].charAt(str1[i].length() - 1) == 'y') {
				count++;
			}
		}
		System.out.println(count);
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any String...");
		String str = sc.nextLine().toLowerCase();
		countYZ(str);
	}
}
