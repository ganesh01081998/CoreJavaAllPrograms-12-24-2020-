package com.ojas.dec02;

import java.util.Scanner;

public class WaveString {

	static String getWaveString(String str1,String str2) {
		String result = "";
		
		if(str1.length() > str2.length()) {
			result = str2 + str1 + str2;
		}
		else if(str1.length() < str2.length()) {
			result = str1 + str2 + str1;
		}
		else if(str1.length() == str2.length()) {
			for (int i = 0; i < str1.length(); i++) {
				int count = 0;
				for (int j = 0; j <= i; j++) {
					if(str1.charAt(i) == str2.charAt(j)) {
						count++;
					}
				}
				if(count <= 1) {
					result += str1.charAt(i) + "" +  str2.charAt(i);
				}
			}
		}
		return result;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter First String...");
		String str1 = sc.nextLine();
		System.out.println("Enter Second String");
		String str2 = sc.nextLine();
		System.out.println(getWaveString(str1, str2));
	}
}
