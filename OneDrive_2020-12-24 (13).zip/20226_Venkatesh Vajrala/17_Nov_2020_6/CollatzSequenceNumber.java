package com.ojas.sample;

import java.util.Scanner;

public class CollatzSequenceNumber {
	
	static String getCollatzSequence(int number) {
		String result = "" + number + " ";
		while(number > 1) {
			if(number % 2 == 0) {
				number = number / 2;
			}
			else {
				number = ( number * 3 ) + 1;
			}
			result += number + " ";
		}
		return result;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any Number");
		int number = sc.nextInt();
		System.out.println(getCollatzSequence(number));

	}
}
