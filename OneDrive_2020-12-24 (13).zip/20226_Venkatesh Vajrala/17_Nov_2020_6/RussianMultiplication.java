package com.ojas.sample;

import java.util.Scanner;

public class RussianMultiplication {
	
	static String getProductOfRussian(int number1,int number2) {
		String result = "" + number1 + " " + number2 + "\n";
		int sum = 0;
		if(number1 % 2 != 0) {
			sum += number2;
		}
		while(number1 > 1) {
			number1 = number1 / 2;
			number2 = number2 * 2;
			result += "" + number1 + " " + number2 + "\n";
			if(number1 % 2 != 0) {
				sum += number2;
			}
		}
		result += "Product of two numbers = " + sum;
		return result;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Two Values?");
		System.out.println(getProductOfRussian(sc.nextInt(),sc.nextInt()));

	}
}
