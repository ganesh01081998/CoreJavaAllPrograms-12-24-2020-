package com.ojas.arrays;

import java.util.Scanner;

public class EqualMatrix {

	static String printArray(int arr1[][],int arr2[][]) {
		String result = "";
		for(int i = 0 ; i < arr1.length ; i++) {
			for(int j = 0 ; j < arr1.length ; j++) {
				result += arr1[i][j] +" ";
			}
			result += "\n";
		}
		result += "\n";
		for(int i = 0 ; i < arr2.length ; i++) {
			for(int j = 0 ; j < arr2.length ; j++) {
				result += arr2[i][j] + " ";

			}
			result += "\n";
		}
		return result ;
	}
	
	static int equalOrNot(int arr1[][],int arr2[][]) {
		int result = 0;
		for(int i = 0 ; i < arr1.length ; i++) {
			for(int j = 0 ; j < arr1.length ; j++) {
				if(arr1[i][j] == arr2[i][j]) {
					result = 1;
				}
				else {
					result = 0;
				}
			}
		}	
		return result;
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Rows & Cols Size...");
		int rows = sc.nextInt();
		int cols = sc.nextInt();
		int arr1[][] = new int [rows][cols];
		int arr2[][] = new int [rows][cols];
		System.out.println("Enter First Array Elements:");
		for(int i = 0 ; i < arr1.length ; i++){
			for(int j = 0 ; j < arr1.length ; j++){
				arr1[i][j] = sc.nextInt();
			}
		}
		System.out.println("Enter Second Array Elements:");
		for(int i = 0 ; i < arr2.length ; i++){
			for(int j = 0 ; j < arr1.length ; j++){
				arr2[i][j] = sc.nextInt();
			}
		}
		System.out.println(printArray(arr1,arr2));
		System.out.println(equalOrNot(arr1,arr2));
	}
}
