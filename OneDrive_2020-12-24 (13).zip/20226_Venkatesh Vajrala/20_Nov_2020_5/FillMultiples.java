package com.ojas.arrays;

import java.util.Scanner;

public class FillMultiples {

	static String getMultiplesArray(int number) {
		String result = "";
		if(number <= 0) {
			result += "null";
		}
		else {
			int size = 10;
			int[] arr = new int[size];
			for (int i = 0; i < arr.length; i++) {
				arr[i] = number * i;
				result += arr[i] + " ";
			}
		}
		return result;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any Number..");
		int number = sc.nextInt();
		System.out.println(getMultiplesArray(number));
	}

}
