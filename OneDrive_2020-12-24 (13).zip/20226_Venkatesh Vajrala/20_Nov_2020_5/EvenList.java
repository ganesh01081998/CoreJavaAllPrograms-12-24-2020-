package com.ojas.arrays;

import java.util.Scanner;

public class EvenList {
	
	 static String isSize(int size) {
	        String result = "";
	        if(size != 10) {
	            return "null";
	        }
	        else if( size == 10) {
	            Scanner scn = new Scanner(System.in);
	            System.out.println("Enter  Array elements...");
	            int even[] = new int[size];
	            for(int i = 0;i < even.length;i++) {
	                even[i] = scn.nextInt();
	             }
	            int arr[] = new int[even.length];
	            int count = 0;
	            for(int i = 0;i < arr.length;i++) {
	                if(even[i] % 2 == 0) {
	                    count++;
	                    arr[i] = even[i];
	                    result += arr[i] + "\n";
	                }
	            }
	            if(count == 0) {
	                result = "empty array";
	            }
	        }
	          return result.toString();
	    }
	 
	public static void main(String[] args) {
	        Scanner scn = new Scanner(System.in);
	        System.out.println("Enter Array Size..");
	        int size = scn.nextInt();
	        System.out.println(isSize(size));
	    }

}
