package com.ojas.dec18;

import java.util.Scanner;

public class ArrangeString {
	
	static String str;
	static String result;
	
	static String setArrangeString(String str1,String str2) {
		int length = str1.length() + str2.length();
		str1 = getChange(str1);
		str2 = getChange(str2);
		String result = "";
		if(Character.getNumericValue(str1.charAt(0)) > Character.getNumericValue(str2.charAt(0))) {
			result = (length) + " No " + str2 + " " + str1;
		}
		else {
			result = (length) + " Yes " + str1 + " " + str2;
		}
		return result;
	}
	
	public static String getChange(String string) {
		char [] ch = string.toCharArray();
		String result = ch[0] + "";
		result =result.toUpperCase();
		for (int i = 1; i < ch.length; i++) {
			result += ch[i] + "";
		}
		return result;
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any Strings...");
		System.out.println(setArrangeString(sc.next(), sc.next()));
		
	}

}
