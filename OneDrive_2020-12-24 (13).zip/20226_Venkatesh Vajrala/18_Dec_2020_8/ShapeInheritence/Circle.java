package com.ojas.dec18;

public class Circle {

	double radius;
	double area;

	public Circle() {

	}

	public Circle(double radius) {
		super();
		this.radius = radius;
	}

	public double getArea() {

		if(radius < 0) {
			area = -1;
		}
		else {
			area = 3.14 * (radius *  radius);
		}
		return area;
	}
	

}
