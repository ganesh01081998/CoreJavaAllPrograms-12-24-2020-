package com.ojas.dec18;

public class Soccer extends Sports{
	
	public String	getName(String sports) { 
		super.sports = sports;
		return sports;
		}
		public	String	getNumberOfTeamMembers() {
				return "In" + super.getName(sports)  + "\n Each team has 11 players";
			}

}
