package com.ojas.dec18;

import java.util.Scanner;

public class Test_Sports {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter The Sports");
		Sports s = new  Soccer();
		s.getName(sc.nextLine());
		System.out.println( s.getNumberOfTeamMembers());

	}


}
