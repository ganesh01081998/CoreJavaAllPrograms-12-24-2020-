package com.ojas.dec18;

public interface AdvancedArithmetic {
	
	public abstract int divisorSum(int num);

}
