package com.ojas.dec18;

abstract  public class Book {
	
	String title;
	
	abstract void setTitle(String title);
	
	public String getTitle() {
		return title;
	}

}
