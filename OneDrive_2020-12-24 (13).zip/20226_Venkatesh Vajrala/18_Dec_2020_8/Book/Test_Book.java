package com.ojas.dec18;

import java.util.Scanner;

public class Test_Book {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		MyBook mb = new MyBook();
		System.out.println("Enter Any Book Name : ");
		mb.setTitle(sc.nextLine());
		System.out.println("The title of my book is : " + mb.getTitle());

	}

}
