package com.ojas.dec18;

public class MyBook extends Book{
	

	@Override
	void setTitle(String title) {
		super.title = title;
		
	}
	
	public String  getTitle() {
		
		return super.title;
	}


}
