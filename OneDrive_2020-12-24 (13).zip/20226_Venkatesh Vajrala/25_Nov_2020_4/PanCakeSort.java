package com.ojas.sortings;

import java.util.Scanner;

public class PanCakeSort {
	
	static void flip(int[] arr, int index)
	{		
		int temp, start = 0;
			temp = arr[start];
			arr[start] = arr[index];			
			arr[index] = temp;			
	}

	static int pancakeSort(int[] arr, int length)
	{		
		for (int currsize = length; currsize > 1; currsize--)
		{			
			int index = findMax(arr, currsize);
			if (index != currsize - 1)
			{		
				flip(arr, index);				
				flip(arr, currsize - 1);																								
			}
		}
		return 0;
	}	

	static int findMax(int[] arr, int currSize)
	{
		int index = 0, i;
		for (i = 0; i < currSize; i++) {
			if (arr[i] > arr[index]){
				index = i;
			}
		}
		return index;
	}
		
	static void printArray(int arr[], int arrSize)
	{
		for (int i = 0; i < arrSize; i++)
			System.out.print(arr[i] +" ");
	}
	
	public static void main (String[] args)
	{		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size : ");
		int size = sc.nextInt();
		int arr[] = new int[size];
		System.out.println("Enter the Elements :");
		for(int i = 0;i < arr.length;i++) {
			arr[i] = sc.nextInt();
		}		
		pancakeSort(arr, size);		
		System.out.println("After Sorting Array Elements...");
		printArray(arr, size);
	}
}
