package com.ojas.sortings;

import java.util.Scanner;

public class MergeSort {
	
	static void merge(int[] arr, int low, int mid, int high) {
		int left = mid - low + 1;
		int right = high - mid;
		int[] leftArr = new int[left];
		int[] rightArr = new int[right];
		for (int insert = 0; insert < left; insert++) {
			leftArr[insert] = arr[low + insert];
		}
		for (int check = 0; check < right; check++) {
			rightArr[check] = arr[mid + 1 + check];
		}
		int i = 0, j = 0;
		int k = low;
		while (i < left && j < right) {
			if (leftArr[i] <= rightArr[j]) {
				arr[k] = leftArr[i];
				i++;
			}
			else {
				arr[k] = rightArr[j];
				j++;
			}
			k++;
		}
		while (i < left) {
			arr[k] = leftArr[i];
			i++;
			k++;
		}
		while (j < right) {
			arr[k] = rightArr[j];
			j++;
			k++;
		}
	}
	
	static void sort(int[] arr, int low, int high) {
		if (low < high) {
			int mid = (low + high) / 2;
			sort(arr, low, mid);
			sort(arr, mid + 1, high);
			merge(arr, low, mid, high);
		}
	}
	
	static void printArray(int[] arr) {
		for (int i = 0; i < arr.length; ++i) {
			System.out.print(arr[i] + " ");
		}
		System.out.println();
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Array Size");
		int size = sc.nextInt();
		int[] arr = new int[size];
		System.out.println("Enter Array Elements...");
		for (int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		System.out.println("Before Sort Array Elements...");
		printArray(arr);
		sort(arr, 0, arr.length - 1);
		System.out.println("After Sort  Array Elements...");
		printArray(arr);
	}
}
