package com.ojas.sample;

import java.util.Scanner;

public class MultiplicationTable {
	
	static void multiplication(int num) {
		int i = 1;
		while(i <= 10) {
			System.out.println(num + " * " + i + " = " + (num * i));
			i++;
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any Number : ");
		int num = sc.nextInt();
		multiplication(num);
	}

}
