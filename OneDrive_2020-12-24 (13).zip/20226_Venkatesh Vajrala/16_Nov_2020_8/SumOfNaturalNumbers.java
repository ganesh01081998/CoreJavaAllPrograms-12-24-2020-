package com.ojas.sample;

import java.util.Scanner;

public class SumOfNaturalNumbers {
	
	static void findSumOfNaturalNumbers(int num) {
		int sum = 0;
		for(int i = 0 ; i <= num ; i++) {
			sum += i;
		}
		System.out.println("Sum Of Natural Numbers : " + sum);
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any Number :");
		int num = sc.nextInt();
		findSumOfNaturalNumbers(num);

	}

}
