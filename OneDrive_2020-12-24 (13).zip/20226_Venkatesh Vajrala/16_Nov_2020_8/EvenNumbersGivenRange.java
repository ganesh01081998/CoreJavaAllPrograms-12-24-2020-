package com.ojas.sample;

import java.util.Scanner;

public class EvenNumbersGivenRange {

	static boolean isEven(int num) {
		boolean b = false;
		if(num % 2 == 0) {
			b = true;
		}
		return b;
	}

	static String rangeEvenNum(int startValue,int endValue) {
		String result = "";
		for(int i = startValue;i <= endValue;i++) {
			if(isEven(i)) {
				result += i +",";
			}
		}
		return result.substring(0,result.length()-1);
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Start And End Values : ");
		System.out.println(rangeEvenNum(sc.nextInt(),sc.nextInt()));

	}

}
