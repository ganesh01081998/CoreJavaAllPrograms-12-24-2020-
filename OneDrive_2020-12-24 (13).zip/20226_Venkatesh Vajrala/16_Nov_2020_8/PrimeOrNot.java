package com.ojas.sample;

import java.util.Scanner;

public class PrimeOrNot {

	static boolean isPrime(int num) {
		boolean b = false;
		int count = 0;
		for(int i = 2 ; i <= num ; i++) {
			if(num % i == 0 ) {
				count++;
			}
		}
		if(count == 1) {
			System.out.println(num + " is a Prime Number...");
		}
		else {
			System.out.println(num + " is Not a Prime Number...");
		}
		return b;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any Number : ");
		int num = sc.nextInt();
		isPrime(num);

	}

}
