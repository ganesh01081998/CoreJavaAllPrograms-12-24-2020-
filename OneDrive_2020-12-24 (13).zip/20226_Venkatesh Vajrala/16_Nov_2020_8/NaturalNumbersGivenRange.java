package com.ojas.sample;

import java.util.Scanner;

public class NaturalNumbersGivenRange {
	
	static void rangeNaturalNumbers(int startValue,int endValue) {
		while(startValue <= endValue) {
			System.out.print(startValue+" ");
			startValue++;
		}
		
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter StartValue : ");
		int num1 = sc.nextInt();
		System.out.println("Enter EndValue : ");
		int num2  = sc.nextInt();
		rangeNaturalNumbers(num1,num2);
	}

}
