package com.ojas.sample;

import java.util.Scanner;

public class FizzBizz {

	static String getOutputString(int num) {
		String result = "";
		if(num > 0) {
			if(num % 3 == 0 && num % 5 != 0) {
				result += "FIZZ";
			}
			else if(num % 3 != 0 && num % 5 == 0) {
				result += "BIZZ";
			}
			else if(num % 3 == 0 && num % 5 == 0) {
				result += "FIZZBIZZ";
			}
			else if( num % 3 != 0 && num % 5 != 0) {
				result += num;
			}
		}
		else {
			if(num < 0) {
				result += "ERROR";
			}
		}
		return result;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any Number : ");
		int result = sc.nextInt();
		System.out.println(getOutputString(result));

	}

}
