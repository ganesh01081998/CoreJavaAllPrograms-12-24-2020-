package com.ojas.dec10;

import java.util.Scanner;

public class Rectangle {
	
	public Rectangle() {

	}
	
	void getWidth(int p ,int  height) {
		System.out.println("getting width");
		int getwidth = (p / 2) - height ;
		System.out.println(getwidth);
	}
	
	void getheight(int p ,int  width) {
		System.out.println("getting height");
		int getheight = (p / 2) - width ;
		System.out.println(getheight);
	}
	
	void Area(int width , int height) {
		System.out.println("area of Rectangle = ");
		int area = width * height ;
		System.out.println(area);
	}
	
	int Perimeter(int width , int height) {
		System.out.println("perimeter of rectangle = ");
		int perimeter = 2 *(width + height) ;
		System.out.println(perimeter);
		return perimeter;
	}
	
	void MovingRectangle (int move1 , int move2 , int x2 , int y2) {
		move1 = move1 + x2 ;
		move2 = move2 + y2 ;
		System.out.println("Rectangle is moved to " + move1+"  " + move2);
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner (System.in);
		Rectangle rec = new Rectangle();
		System.out.println("enter width ");
		int width = scan.nextInt();
		System.out.println("enter height");
		int height = scan.nextInt();
		int p =rec.Perimeter(width,height);
		rec.Area(width , height) ;
		rec.getWidth(p , height) ;
		rec.getheight(p, width);
		int x1 = 0;
		int y1 = 0;

		int x2 = height + x1 ; 
		int y2 = width +  y1;
		System.out.println("enter two number");
		int move1 = scan.nextInt();
		int move2 = scan.nextInt();
		rec.MovingRectangle(move1 , move2 , x2 , y2) ;

	}

}
