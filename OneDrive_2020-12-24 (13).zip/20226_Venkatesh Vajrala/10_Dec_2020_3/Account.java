package com.ojas.dec10;

import java.util.Scanner;

public class Account extends Customer {
	
	 static Scanner sc = new Scanner(System.in);
	    
	    int accountNumber;
	    double balance;
	    float intrest;
	    static Customer customer;
	    
	    public static void main(String[] args) {
	        System.out.println("Enter Your\n 1. First and Last Name \n 2. Account Number ");
	        Account acc = new Account(sc.next(), sc.next() , sc.next() , customer);
	        acc.display();
	    }
	    
	    public Account(String firstName, String lastName, String account, Customer customer) {
	        super(firstName, lastName);
	        this.customer = customer;
	        if(verifyAccount(account)) {
	            String menu = "Select an option\n"+"1. Deposit" + "\n2.WithDraw" + "\nEnter the option";
	            System.out.println(menu);
	            int option = sc.nextInt();
	            switch (option) {
	            case 1:
	                this.balance += deposit();
	                intrest(balance);
	                break;
	            
	            case 2:
	                withDraw();
	                intrest(balance);
	                break;
	            
	            default:
	                System.out.println("Choose Correct Option");
	                break;
	            }
	        }
	    }
	    
	    private void intrest(double balance) {
	        this.intrest = (float) (balance / 100);   
	    }
	    
	    public int deposit() {
	        System.out.println("Enter the amount for deposit");
	        return sc.nextInt();
	    }
	    
	    private  void withDraw() {
	        System.out.println("Enter the amount for withDrow");
	        int amount = sc.nextInt();
	        if(balance > amount ) {
	            this.balance = balance - amount;
	        }
	        else{
	            System.out.println("The WithDraw Amount Is Grater Then Balance");
	        }
	    }
	    
	    public void display() {
	        super.display();
	        System.out.println("Account [" + "accountNumber = " + accountNumber + ", balance = " + balance + ", intrest = " + intrest + "]");
	    }
	    
	    public boolean verifyAccount(String account) {
	        if(account.length() == 5) {
	            int count = 0;
	            for (int index = 0; index < account.length(); index++) {
	                char ch = account.charAt(index);
	                boolean b= Character.isDigit(ch);
	                if(b) {
	                    count++;
	                }
	            }
	            if(count == account.length()) {
	                this.accountNumber = Integer.parseInt(account);
	                return true;
	            }
	        }
	        else {
	            System.out.println("Entered values are invalid");
	        }
	        return false;
	    }

}
