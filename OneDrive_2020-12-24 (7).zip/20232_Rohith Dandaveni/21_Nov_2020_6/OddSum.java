package cls7;
import java.util.Scanner;

import javax.security.sasl.SaslClient;

public class OddSum {

	static int getOddSum(int num) {
		int result = 0;
		int sum = 0;
	 if (num != 10) {
		 result = result + -1;
	 }
	 Scanner scanner = new Scanner(System.in);
	 System.out.println("enter 10 values");
	 int arr[] = new int[num];
	  for (int i = 0; i < arr.length; i++) {
		  arr[i] = scanner.nextInt();
		  if (arr[i] % 2 != 0) {
			  sum = sum + arr[i];
		  }
	  }
	  	   result = sum;
		return result;
	
		
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the range of array");
		int num = scanner.nextInt();
		System.out.println(getOddSum(num));
	}
}
