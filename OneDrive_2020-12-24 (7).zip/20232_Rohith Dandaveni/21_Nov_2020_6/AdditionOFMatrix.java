package cls7;

import java.util.Scanner;

import javax.swing.plaf.synth.SynthSpinnerUI;

public class AdditionOFMatrix {
	
	static String add(int arr[][],int brr[][],int crr[][]) {
		String result = "";

			for(int i = 0; i < arr.length; i++) {
				for (int j = 0; j < arr[i].length; j++) {
					crr[i][j] = arr[i][j]+ brr[i][j];
					result = result + crr[i][j] + " ";
				}
				result = result + "\n";
			}
		return result;
	}
	
	static String disp(int arr[][]) {
		String result = "";
		for(int i = 0; i < arr.length; i++) {
			for(int j = 0; j < arr[i].length; j++) {
		result = result + arr[i][j] + " ";
		}
			result = result + "\n";
		}
		return result;
	}

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the 1st array values");
		int arr[][] = new int[3][3];
		for(int i  = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				arr[i][j] = scanner.nextInt();	
			}
		}
			int brr[][] = new int[3][3];
			System.out.println("enter the 2nd array values");
			for (int i1 = 0; i1 < brr.length; i1++) {
				for (int j = 0; j< brr[i1].length; j++) {
					brr[i1][j] = scanner.nextInt();
				}
			}
			int crr[][] = new int[3][3];
		System.out.println(disp(arr));
		System.out.println(disp(brr));
		System.out.println(add(arr,brr,crr));
			}
}
