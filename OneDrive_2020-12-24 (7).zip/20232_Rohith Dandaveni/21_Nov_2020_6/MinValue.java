package cls7;

import java.util.Scanner;

public class MinValue {

	static int getMin(int num) {
		int num1 = 0;
	    if (num != 10) {
	    	return -1;
	    }
	    else {
	    	Scanner scanner = new Scanner(System.in);
	    	System.out.println("enter the values of an array");
	    	int min = 0;
	    	int arr[] = new int[num];
	    	for(int i = 0; i < arr.length; i ++) {
	    		arr[i] = scanner.nextInt();
	    		if (arr[0] > arr[i]) {
		    		min = arr[i];
		    	}
	    	}
	    	num1 = min;
	    
	    	
	    }
		return num1;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the range of an array");
		int num = scanner.nextInt();
		System.out.println(getMin(num));

	}

}
