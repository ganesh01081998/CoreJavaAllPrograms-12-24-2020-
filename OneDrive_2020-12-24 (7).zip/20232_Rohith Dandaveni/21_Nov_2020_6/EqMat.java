package cls7;

import java.util.Scanner;

public class EqMat {
	static void eqMat(int mm,int nn){
//		int arr[][] = {{1,2,3},{2,4,5},{3,5,6}};
//		int brr[][] = {{1,2,3},{2,4,5},{3,5,6}};
		int arr[][] = new int[mm][nn];
		int brr[][] = new int[mm][nn];
		readarray(arr,brr,mm,nn);
}
	static void readarray(int arr[][],int brr[][],int mm,int nn) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the array values");
		for(int i = 0; i< mm;i++) {
			for (int j = 0; j < nn;j++) {
				arr[i][j] = scanner.nextInt();
			}
		}
		System.out.println("enter the 2nd array values");
		for(int i = 0; i < mm; i++) {
			for(int j = 0;j < nn; j++) {
				brr[i][j] = scanner.nextInt();
			}
		}
	    dispaly(arr,brr,mm,nn);
		System.out.println(check(arr,brr,mm,nn));
		
	}
	static void dispaly(int arr[][],int brr[][],int mm,int nn) {
		System.out.println("displaying array1");
		for(int i = 0; i< mm;i++) {
			for (int j = 0; j < nn;j++) {
				System.out.print(arr[i][j] + " ");
			}
			System.out.println( );
		}
		System.out.println("displaying array2");
		for(int i = 0; i < mm; i++) {
			for(int j = 0;j < nn; j++) {
				System.out.print(arr[i][j] + " ");
			}
			System.out.println();
		}
	}
	static int check(int arr[][],int brr[][],int mm,int nn) {
		int result = 0;
		String s1 = "";
		for (int i = 0; i < mm; i++){
			for(int j = 0; j < nn;j++) {
				if (arr[i][j] == brr[i][j]) {
					result = 1;
				}
				else {
					result = 0;
				}
			}
		}
		return result;
		
	}
	public static void main(String[] args) {
		int m = 3,n= 3;
		eqMat(m,n) ;
		
	
		
	}

}
