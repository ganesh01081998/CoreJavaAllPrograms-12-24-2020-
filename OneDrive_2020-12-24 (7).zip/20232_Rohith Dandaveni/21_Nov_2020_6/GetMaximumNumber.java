package cls7;

import java.util.Scanner;

public class GetMaximumNumber {
		static int result = 0;
	static int getMax(int num) {
		 if (num != 10) {
			 result = result + -1;
		 }
		 Scanner scanner = new Scanner(System.in);
		 System.out.println("enter 10 values");
		 int arr[] = new int[num];
		 int max = 0;
		  for (int i = 0; i < arr.length; i++) {
			  arr[i] = scanner.nextInt();
			  if (max < arr[i]) {
				  max = arr[i];
			  }
			 
		  }
		return max;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the range of array");
		int num = scanner.nextInt();
		System.out.println(getMax(num));

	}

}
