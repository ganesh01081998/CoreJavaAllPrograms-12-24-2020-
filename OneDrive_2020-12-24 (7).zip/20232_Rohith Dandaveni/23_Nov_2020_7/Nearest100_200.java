package cls8;

import java.util.Scanner;

public class Nearest100_200 {

	static int getNum(int number) {
		int result = 0;
		number = Math.abs(number);
		result = number;
		System.out.println(findNearHundred(result));
		return result;
	}
	static boolean findNearHundred(int result) {
		boolean b = false;
		if (result < 100 && 100 - result <= 10 ) {
		 b = true;
		}
		else if (result < 200 && 200 - result <= 10 ) {
			b = true;
		}
		return b;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the number");
		int num = scanner.nextInt();
	
		System.out.println(getNum(num));
		
	}

}
