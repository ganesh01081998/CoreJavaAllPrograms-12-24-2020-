package cls8;

import java.util.Scanner;

public class Range {

	static boolean range(int num1,int num2) {
		boolean b = false;
		if (num1 >= 30 && num1 <=40 && num2 >= 30 && num2 <= 40) {
			b = true;
		}
		else if (num1 >= 40 && num1 <= 50 && num2 >= 40 && num2 <= 50) {
			b = true;
		}
		return b;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter 1st value");
		int num = scanner.nextInt();
		System.out.println("enter the 2nd value");
		int num2 = scanner.nextInt();
		System.out.println(range(num,num2));

	}

}
