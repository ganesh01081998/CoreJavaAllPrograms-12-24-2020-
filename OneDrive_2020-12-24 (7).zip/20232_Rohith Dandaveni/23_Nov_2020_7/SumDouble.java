package cls8;

import java.util.Scanner;

public class SumDouble {

	static String sumDouble(int num1,int num2) {
		String result = "";
		int sum = 0;
		if (num1 == num2) {
			sum = num1 + num2;
			result = "close10" + "(" + num1 + "," + num2 + ")" + "  ->  " + (sum + sum);
		}
		else {
			sum = sum + (num1+num2);
			result = "close10" + "(" + num1 + "," + num2 + ")" + "  ->  " + sum;
		}
		return result;
		
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter 1st value");
		int num1 = scanner.nextInt();
		System.out.println("enter the 2nd value");
		int num2 = scanner.nextInt();
		System.out.println(sumDouble(num1,num2));

	}

}
