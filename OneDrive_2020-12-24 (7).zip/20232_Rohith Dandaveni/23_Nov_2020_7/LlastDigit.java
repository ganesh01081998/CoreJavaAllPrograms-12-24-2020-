package cls8;

import java.util.Scanner;

public class LlastDigit {

	static boolean lastDigit(int num1,int num2) {
	
		boolean b = false;
		num1 = num1 % 10;
		num2 = num2 % 10;
		if (num1 == num2) {
			b = true;
		}
	
		return b;
	}
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter 1st value");
		int num = scanner.nextInt();
		System.out.println("enter the 2nd value");
		int num2 = scanner.nextInt();
		System.out.println(lastDigit(num,num2));
	}

}
