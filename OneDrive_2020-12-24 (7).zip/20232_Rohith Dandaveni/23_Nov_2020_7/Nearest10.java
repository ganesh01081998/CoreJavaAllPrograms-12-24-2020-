package cls8;

import java.util.Scanner;

public class Nearest10 {

	static String near(int num,int num2) {
		String result = "";
		num = num - 10; 
		num = Math.abs(num);
		num2 = num2 - 10;
		num2 = Math.abs(num2);
		if (num == num2) {
			result = result + "0";
		}
		else if(num > num2) {
			result = result + "num2 is near";
		}
		else{
			result = result + "num is near";
		}
		return result;
		
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter 1st value");
		int num = scanner.nextInt();
		System.out.println("enter the 2nd value");
		int num2 = scanner.nextInt();
		System.out.println(near(num,num2));
	}
}
