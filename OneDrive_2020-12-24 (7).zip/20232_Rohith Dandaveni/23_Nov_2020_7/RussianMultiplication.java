package cls8;

import java.util.Scanner;

public class RussianMultiplication {
	    static String getProduct(int num1,int num2) {
	    	String result ="";
	    	int temp ;
	    	temp = num2;
	    	int sum = 0;
	    	if (num1 == 0 || num1 < 0 || num2 == 0 || num2 < 0) {
	    		result = result + "-1";
	    	}
	    	else {
	    		while (num1 >= 1) {
	    			num1 = num1 / 2;
	    			num2 = num2 * 2;
	    			if(num1 % 2 != 0) {
	    				sum = sum + num2;
	    				System.out.println(sum);
	    			}
	    		}
	    		result = result + (sum + temp);
	    	}
	    	
	    	return result;
	    }
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the 1st number");
		int num1 = scanner.nextInt();
		System.out.println("enter the 2nd number");
		int num2 = scanner.nextInt();
		System.out.println(getProduct(num1,num2));
	}
}
