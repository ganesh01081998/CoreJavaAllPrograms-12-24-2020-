package cls8;

public class NumberList {

	static String num(String s) {
		String res = "";
		
		s = s.replaceAll("-", ",");
		String name[] = s.split(",");
		int num[] = new int[name.length];
		for(int i = 0; i < num.length; i++) {
			num[i] = Integer.parseInt(name[i]);
		}
		for(int i = findSmall(num) ; i <= findBig(num) ; i++) {
			res = res + i ;
			if (i < findBig(num)) {
				res = res + ",";
			}
		}
		return res;
	}
	static int findBig(int num[]) {
		int result = 0;
		int big = num[0];
		for(int i = 1; i < num.length; i++) {
			if (big < num[i]) {
				big = num[i];
				result = big;
			}
		}
		return result;
	}
	static int findSmall(int num[]) {
		int result = 0;
		int small = num[0];
		for(int i = 0; i < num.length; i++) {
			if (small > num[i]) {
				small = num[i];
			}
		}
		result = result + small;
		return result;
	}
	public static void main(String[] args) {
		String s = "1,2,3,4,5-8,6-10,8-15,16-25,20-30,22-26";
		System.out.println(num(s));

	}

}
