package cls11_12_1_2020;

public class VowelPrinte {

	static String printer(String name) {
		String result = "";
		System.out.println(name);
		String name1 = name.replaceAll("[^a-zA-Z0-9]", "");
		System.out.println(name1);
		for (int i = 0; i < name.length();i++) {
			char ch = name.charAt(i);
			if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
				result = result + ch;
			}
		}
		return result;
	}
	public static void main(String[] args) {
		String name = "Tele?p%ho/ne";
		System.out.println(printer(name.toLowerCase()));

	}

}
