package cls11_12_1_2020;

import java.util.Scanner;

public class RemoveVowelsStringinput {

	static String remove(String name,int num) {
		String result = "";
		if (num == 0) {
			return -1 + "";
		}
		for(int i = 0; i < name.length(); i++) {
			char ch = name.charAt(i);
			if (ch != 'a' && ch != 'e' && ch != 'i' && ch != 'o' && ch != 'u') {
				result = result + ch;
			}
		}
		splt(result);
		return result;
	}
	static void splt(String result) {
		String result1 = "";
		String st = result.replaceAll("[^a-zA-Z0-9]","");
		String st1[] = st.split(" ");
		for(int i = 0; i < st1.length; i++) {
		System.out.println(st1[i]);
		}
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the string");
		String name = scanner.nextLine();
		int num = name.length();
	
		remove(name,num);

	}

}
