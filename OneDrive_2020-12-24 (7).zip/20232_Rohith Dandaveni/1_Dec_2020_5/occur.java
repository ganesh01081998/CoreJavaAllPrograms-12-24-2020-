package cls11_12_1_2020;

import java.util.Scanner;

public class occur {

	static void characterCount(String str) {
        int result = 0,count = 0,flag = 0;
        String str2 ="";
    for(int i = 0 ; i < str.length() ; i++) {
        for(int j = i+1 ; j < str.length() ; j++) {
            
            if(str.charAt(i) == str.charAt(j)) {
                count++;
            }
            
        }
        if(count == 0) {
            str2 +="" + str.charAt(i);
        }
        count = 0;
        
    }
    
    for(int i = 0 ; i < str2.length() ; i++) {
        for(int j = 0 ; j < str.length() ; j++) {
            
            if(str2.charAt(i) == str.charAt(j)) {
                flag++;
            }
            
        }
        System.out.println(str2.charAt(i) + "counts" + flag);
        flag = 0;
    } 
    
    
    }
    
 public static void main(String[] args) {
	 Scanner scr = new Scanner(System.in) ;
        
        
        System.out.println("enter a String");
        String str = scr.next();
        if(str.equals("")) {
            System.out.println("-1");
        }
        String str1 = str.replaceAll("[^a-zA-Z0-9]", "");
        characterCount(str1);
 }

}
