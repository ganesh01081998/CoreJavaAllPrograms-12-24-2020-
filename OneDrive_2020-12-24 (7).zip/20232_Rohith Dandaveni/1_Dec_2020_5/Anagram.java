package cls11_12_1_2020;

import java.util.Arrays;
import java.util.Scanner;

public class Anagram {

	static String anagram(String name1,String name2) {
		String result = "";
		if (name1.length() == 0 && name2.length() == 0) {
			return "" + -1;
		}
		else {
			if (name1.length() != 0 && name2.length() !=0) {
				char ch[] = name1.toLowerCase().toCharArray();
				char c[] = name2.toLowerCase().toCharArray();
				Arrays.sort(ch);
				Arrays.sort(c);
				boolean result1 = Arrays.equals(ch, c);
				if (result1) {
					result = "is anagram";
				}
				else {
					result = "is not angram";
				}
			}
		}
		return result;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the 1st String");
		String name1 = scanner.next();
		System.out.println("enter the 2nd String");
		String name2 = scanner.next();
		System.out.println(anagram(name1,name2));

	}

}
