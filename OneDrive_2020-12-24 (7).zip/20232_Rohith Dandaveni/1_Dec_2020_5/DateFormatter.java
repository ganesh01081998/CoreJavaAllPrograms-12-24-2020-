package cls11_12_1_2020;

import java.util.Scanner;

public class DateFormatter {

	static String dateFor(String date) {
		String result = "";
		int num1 = 0;
		String st = date.replaceAll("[ ,]", "-");
		String stt[] = st.split("-");
		String month1 = stt[1];
	    String month2 = month(month1.toLowerCase());
//		String month3 = 0 + month2;
	   int num = Integer.parseInt(month2);
	   if (num < 10) {
		   num1 = num1  + num;
		   result = "0" + num1 + "";
	   }
	   else {
		   num1 = num1 + num;
		   result = num1 + "";
	   }
		System.out.println(stt[2] + "-" + result + "-" +stt[0]);
		return "";
	}
	static String month(String month2) {
		String result = "";
		int i ;
//		String month =  (monthSearch.length ||  monthFullName.length );
//		String value = search(month2);
		 String value1 = search(month2);
		if (month2.equalsIgnoreCase(value1)){
			String value = searchForIndex(month2);
			result = value;
		}
		else {
			String monthFullName[] = {"january","febuary","march","april","may","june","july","augast","september","october","november","december"};
			for(i = 0; i < (monthFullName.length ); i++) {
				if (month2.equalsIgnoreCase(monthFullName[i])) {
					result = result + (i + 1);
					break;
				}
			}
		}
		return result;
	}
	static String search(String month2) {
		String result = "";
		int i ;
		String monthSearch[] = {"jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec"};
		for(i = 0; i < (monthSearch.length ); i++) {
			if (month2.equalsIgnoreCase(monthSearch[i])) {
//				result = result + (i + 1);
				result = result + monthSearch[i];
				break;
				
			}
	}
		return result;
	}
		static String searchForIndex(String month2) {
			String result = "";
			int i ;
			String monthSearch[] = {"jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec"};
			for(i = 0; i < monthSearch.length ; i++) {
				if (month2.equalsIgnoreCase(monthSearch[i])) {
					result = result + (i + 1);
//					result = result + monthSearch[i];
					break;
					
				}
		}
			return result;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the date");
		System.out.println("use only space and comma");
		String date = scanner.nextLine();
//		String date = "12-january-2020";
		System.out.println(dateFor(date));
		
	}
}
