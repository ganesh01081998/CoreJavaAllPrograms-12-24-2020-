package cls12_12_2_2020;

import java.util.Scanner;

public class GetCount {

	static int getCount(int arr[],int searchNumber) {
		int result = 0;
		
		if (arr.length == 0) {
			return -1;
		}
		else {
		int count = 0;
		int num = searchNumber;
		for (int i = 0; i < arr.length; i++) {
			if (num == arr[i]) {
				count++;
			}
		}
		result = count;
		return result;
	}
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the size of array");
		int size = scanner.nextInt();
		System.out.println("enter teh array values");
		int arr[] = new int[size];
		for(int i = 0; i < arr.length; i++) {
			arr[i] = scanner.nextInt();
		}
		System.out.println("enter the search number in array");
		int searchNumber = scanner.nextInt();
		System.out.println(getCount(arr,searchNumber));

	}

}
