package cls12_12_2_2020;

import java.util.Scanner;

import javax.security.sasl.SaslClient;

public class DigitsCount {

	  static String digits(String name) {
	        String result = "";
	        if (name.length() < 0) {
	            return  "0";
	        }
	        int sum = 0;
	        for (int i = 0 ; i < name.length(); i++) {
	            char ch = name.charAt(i);
	            if (Character.isDigit(ch)) {
	                //1st method
//	                result = result + ch;
	                int num = Character.getNumericValue(ch);
	                sum = sum + num;
	            }
	        }
	        //1st method
//	        int num = Integer.parseInt(result);
//	        int reminder = 0;
//	        while(num > 0) {
//	            reminder = num % 10;
//	            sum =  sum + reminder;
//	            num = num / 10;
//	        }
//	        return sum + "";
	        return sum + "";
	}
	    public static void main(String[] args) {
	    	Scanner scanner = new Scanner(System.in);
	    	System.out.println("enter the String ");
	    	String name = scanner.next();
//	        String name = "akjdfk35kjaldkfe654";
	        System.out.println(digits(name));
	    }
}
