package cls12_12_2_2020;

import java.util.Scanner;

public class SumOfDiagonalElements {

	static int sumOfDigonal(int arr[][],int row,int col) {
		if (row != 3 && col != 3) {
			return -1;
		}
		int result = 0;
		int sum = 0;
		for(int i = 0; i < row; i++) {
			for(int j = 0 ; j < col; j++) {
				if (arr[i] == arr[j]) {
					sum = sum + arr[i][j];
				}
			}
			result = sum;
		}
		return result;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the size of rows");
		int row = scanner.nextInt();
		System.out.println("entert the sizr of col");
		int col = scanner.nextInt();
		int arr[][] = new int[row][col];
		for(int i = 0; i < row ; i++) {
			for (int j = 0; j < col ; j++) {
				arr[i][j] = scanner.nextInt();
				
			}
		}
		System.out.println(sumOfDigonal(arr,row,col));

	}

}
