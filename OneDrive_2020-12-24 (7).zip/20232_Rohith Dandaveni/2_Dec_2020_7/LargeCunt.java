package cls12_12_2_2020;

import java.util.Scanner;

public class LargeCunt {

	 static int maxBlock(String str) {
	        int count , temp = 0;
	        for (int i= 0; i < str.length(); i++) {
	            char ch = str.charAt(i);
	            count = 0;
	            for (int j = 0; j < str.length(); j++) {
	                if(ch == str.charAt(j)) {
	                    count ++;
	                }
	            }
	            if(temp < count) {
	                temp = count;
	            }
	        }
	        return temp;
	    }

	 

	    public static void main(String[] args) {
//	        Scanner sc = new Scanner(System.in);
//	        System.out.println("enter the string");
//	        String str = sc.next();
	        String name = "abbCCCddBBBxx";
	        System.out.println(maxBlock(name));
	    }

}
