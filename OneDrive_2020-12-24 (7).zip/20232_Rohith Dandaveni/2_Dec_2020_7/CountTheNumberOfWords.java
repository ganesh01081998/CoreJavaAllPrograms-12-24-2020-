package cls12_12_2_2020;

public class CountTheNumberOfWords {

	static String countNoOfWords(String name) {
		String result = "";
		int count = 0;
		String st[] = name.split(" ");

		for(int i = 0; i < st.length; i++) {
			String name1 = st[i];
			char c = name1.charAt(name1.length()-1);
			if (Character.isLetter(c)) {
				if (c == 'y' || c == 'z') {
					count++;
				}
			}
		}
		result = "count of y&z(or)y/z = " +count;
			
			
		return result;
		}
	
	public static void main(String[] args) {
		String name = "fez day hey mazz";
		System.out.println(countNoOfWords(name));
	}
}
