package cls12_12_2_2020;

public class WeavedString {

	static String wave(String firstName,String secName) {
		String result = "";
		String name = "";
		int firstNum = firstName.length();

		int secNum = secName.length();
		
		if (firstNum > secNum) {
			result = secName + firstName + secName;
		}
		else if (firstNum < secNum) {
			result = firstName + secName + firstName;
		}
		else if (firstNum == secNum) {
			for(int i = 0; i < firstNum; i++) {
				for(int j = 0; j < secNum; j++) {
//					char ch1 = ;
//					char ch2 = ;
					if (firstName.charAt(i) == secName.charAt(j)) {
						name = name + firstName.charAt(i) + secName.charAt(j);
						result = name;
						break;
					}	
				}				
			}
//			System.out.println(name);
		}
		return result;
	}
	public static void main(String[] args) {
		String firstName = "hello";
		String secName = "hello";
		System.out.println(wave(firstName,secName));
	}
}
