package clsprog4;

public class PalindromeInFibonicci {

	public static void main(String[] args) {
		int a = 0,b=1,c;
		System.out.print(a + "," + b + ",");
		for (int i = 2 ; i <= 10 ; i++) {
			c = a + b;
			a = b;
			b = c;
			System.out.println(c);
			int temp = 0,rem = 0,rev = 0;
			temp = c;
			while ( c > 0) {
				rem = c % 10 ;
				rev = (rev * 10) + rem;
				c = c / 10;
			}
			if (temp == rev) {
				System.out.println("palindrome");
			}
			else {
				System.out.println("not palindrome");
			}
		}

	}

}
