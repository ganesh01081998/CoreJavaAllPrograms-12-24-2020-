package clsprog4;

public class Collarze {
		static void collarze(int num) {
			while (num > 1) {
				if (num % 2 == 0) {
					num = num / 2 ;
					System.out.println("even num" + num);
				}
				else {
					num = (num * 3) + 1;
					System.out.println("odd num" + num);
				}
			}
		}
	public static void main(String[] args) {
		int num = 10;
		System.out.println("given number" + num );
		System.out.println("collarze sequence is");
		collarze(num);
	

	}

}
