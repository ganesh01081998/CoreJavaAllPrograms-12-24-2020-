package clsprog4;

import java.util.Scanner;

public class TwinPrimeNumber {

	static boolean isPrime(int num) {
		boolean b = true;
		int count = 0;
		for (int i = 2; i <= (num / 2); i++) {
			if (num % i == 0) {
				return b = false;
			}
		}
		return b;
	}
		static void prime (int num1,int num2) {
			for (int i = num1; i <= num2; i++) {
				if (isPrime(i) && isPrime(i +2)) {
					System.out.println(i + "," + (i+2));
				}
			}
		}
		
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the range");
	    prime(scanner.nextInt(),scanner.nextInt());
	}
}
