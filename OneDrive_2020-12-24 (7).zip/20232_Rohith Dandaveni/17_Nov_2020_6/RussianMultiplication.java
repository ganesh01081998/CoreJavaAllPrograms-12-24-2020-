package clsprog4;

public class RussianMultiplication {
		static void russian(int nNum1, int nNum2) {
			int sum = 0;
			int temp;
			temp = nNum2;
			
				if (nNum1 % 2 == 0) {
					while (nNum1 > 1) {
						nNum1 = nNum1 / 2;
						nNum2 = nNum2 * 2;
						if (nNum1 % 2 != 0) {
							System.out.println(sum = sum + nNum2);
						}
					}
				}
				else {
					while (nNum1 > 1) {
						nNum1 = nNum1 / 2;
						nNum2 = nNum2 * 2;
						if (nNum1 % 2 != 0) {
							System.out.println(sum = sum + nNum2);
						}
						}
					temp = temp + sum;
					System.out.println(temp);
				}

		}
	public static void main(String[] args) {
		int nNum1 = 12;
		int nNum2 = 3;
		russian(nNum1 , nNum2);
	}



}
