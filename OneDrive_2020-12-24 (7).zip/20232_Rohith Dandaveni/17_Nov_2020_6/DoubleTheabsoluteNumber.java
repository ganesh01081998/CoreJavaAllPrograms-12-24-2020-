package clsprog4;

import java.util.Scanner;

public class DoubleTheabsoluteNumber {

	static String dobuleTheabsolute(int num) {
		String result = "";
		if (num > 21) {
			num = num -21;
			System.out.println("double the absoulte value" + (num * 2));
		}
		else {
			num = 21 - num;
			System.out.println(num);
		}
		return result;
		
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the num value");
		int num = scanner.nextInt();
		dobuleTheabsolute(num);
	}

}
