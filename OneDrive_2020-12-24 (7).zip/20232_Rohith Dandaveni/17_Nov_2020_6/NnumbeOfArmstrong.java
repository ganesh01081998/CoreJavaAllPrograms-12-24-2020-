package clsprog4;

public class NnumbeOfArmstrong {

	static void arm(int num){
		int temp, length, reminder = 0, sum = 0;
		temp = num;
		String result = "";
		result = num + "";
		length = result.length();
		while (num > 0) {
			int rev = 1;
			reminder = num % 10;
			for (int i = 1; i<= length; i++) {
				rev = rev * reminder;
			}
			sum = sum + rev;
			num = num / 10;
			rev = 1;
		}
		if (temp == sum){
			System.out.println("is armstrong");
		}
		else {
			System.out.println("is not armstrong");
		}
	}
	public static void main(String[] args) {
		int num = 8208;
		arm(num);
		
		

	}
}
