package cls9;

import java.util.Scanner;

public class GetPalindromeList {
	static String getPalindromeList(int num) {
		
	
		
            int num1 = getReverse(num);
           
           
          
            check(num,num1);
            return "";
	}
	
            static String check(int num , int num1) {
            	 String  result = "";
            	int num2 = 0,num3 = 0;
            		if(num != num1) {
            
            		num2 = num + num1;
                	
                	System.out.println(num1);
                	System.out.println(num2);
                	getPalindromeList(num2);
                	return result;
            	}
					return  "";
            	
            }
            
	static int getReverse(int num) {
		int result = 0;
		int rem = 0 , rev = 0;
		while (num > 0) {
			rem = num % 10;
			rev = (rev * 10) + rem;
			num = num / 10;
		}
		result = result + rev;
		return result;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the number");
		int num = scanner.nextInt();
		
		
		System.out.println(getPalindromeList(num));
	}

}
