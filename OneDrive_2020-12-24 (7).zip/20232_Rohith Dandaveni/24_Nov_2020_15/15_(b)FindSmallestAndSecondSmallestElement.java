package cls9;

import java.util.Arrays;

public class FindSmallestAndSecondSmallestElement {

	static int temp = 0;
	static String small(int arr[]) {
		String result = "";
		for (int i = 0; i < arr.length; i++) {
			for(int j = i +1 ; j < arr.length; j++) {
				if (arr[i] > arr[j]) {
					temp = arr[j];
					arr[i] = arr[j];
					arr[j] = temp;
				
				}
					result = arr[j] + "secomd smallest";
			}
			
		}
		return result;
		
	}
	public static void main(String[] args) {
//		int  i1 = 0;
		int arr[] = {47,84,96,35,14,15};
		int temp ;
		
//		Arrays.sort(arr);
//		for (int i = i1 ; i < arr.length; i++) {	
//		}
//		System.out.println("1st smallest " + arr[ i1 ]);
//		System.out.println("second smallest " + arr[i1+1]);
		System.out.println(small(arr));
		
	}

}
