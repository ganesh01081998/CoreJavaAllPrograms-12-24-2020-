package cls9;

public class LuckyNumber {

	static String luckyNumber(String number) {
		String result = "";
		int givenNumber = 0;
//		int[] num = new int[number.length()];
		String st[] = number.toLowerCase().split("-");
		String month = month(st[1]);
//		int num = Integer.parseInt(month);
		String sum = st[0] + month + st[2];
		int num = Integer.parseInt(sum);
		givenNumber = add(num);
		if (givenNumber > 10) {
			result = add(givenNumber) + "";
		}
		else {
			result = givenNumber + "";
		}

		return result;
	}
	static int add(int num) {
		int result = 0;
		int temp,reminder,sum = 0;
		while(num > 0) {
			temp = num;
			reminder = num % 10;
			sum = sum + reminder ;
			num = num / 10;
		}
		result = sum;
		return sum;
	}
	static String month(String monthName) {
		String result = "";
		String st1[] = {"jan","frb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec"};
		for(int i = 0; i < st1.length; i++) {
			if (st1[i].equalsIgnoreCase(monthName)) {
				result = result + (i + 1);
			}
		}
		return result;
	}
	public static void main(String[] args) {
		String number = "15-JAN-2016";
		System.out.println(luckyNumber(number));
		
	
	}

}
//if (num > 10) {
//	result = add(num);
//}
//else {
//	result = num;
//}
//int num1 = Integer.parseInt(st[0]);
//if (num1 > 10) {
//	result = add(num1);
//}
//else {
//	result = num1;
//}
//int num2 = Integer.parseInt(st[2]);
//if (num > 10) {
//	result = add(num2);
//}
//else {
//	result = num2;
//}