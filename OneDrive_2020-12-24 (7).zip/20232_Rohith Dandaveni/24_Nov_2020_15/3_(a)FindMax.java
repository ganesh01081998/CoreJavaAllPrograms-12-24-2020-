package cls9;

import java.util.Scanner;

public class FindMax {

	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the range of array");
		int size = scanner.nextInt();
		int arr[] = new int[size];
		System.out.println("enter the array values");
		for (int i = 0; i < arr.length;i++) {
			arr[i] = scanner.nextInt();
		}
		System.out.println(findMax(arr));
	}

	private static int findMax(int arr[]) {
		int num = 0;
		int count = 0;
	if(arr.length == 0) {
		return 0;
	}
	for (int i = 0; i < arr.length; i++) {
		if (arr[i] < 0) {
			count++;
		}
	}
	if (count < 3)  {
		return -1;
	}
	else {
		num = getMax(arr);
	}
	return num;
	
	}

	private static int getMax(int[] arr) {
		int max = arr[0];
		for(int i = 1; i< arr.length; i++) {
			if (max < arr[i]) {
				max = arr[i];
			}
		}
		return max;
		
		
	}

}
