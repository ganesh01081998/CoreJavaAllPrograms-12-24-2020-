package cls9;

public class GetSumOfDigits {

	static int getSumOfDigits(int num) { 
		int result = 0;
		result = result + sum(num);
		return result;
	}
	static int sum(int num) {
		int result = 0;
		int reminder = 0, rev = 0;
		while (num > 0) {
			reminder = num % 10;
			rev = rev + reminder;
			num = num / 10;
			result = rev;
		}
		return result;
	}
	public static void main(String[] args) {
		int num = 12;
		System.out.println(getSumOfDigits(num));
	}

}
