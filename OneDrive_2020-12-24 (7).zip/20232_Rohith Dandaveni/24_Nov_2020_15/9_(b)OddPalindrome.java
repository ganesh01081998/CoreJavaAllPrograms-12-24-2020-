package cls9;

import java.util.Scanner;

public class OddPalindrome {

	static void oddpalindrome(int num1,int num2) {
	for(int i = num1; i <= num2; i ++) {
			int temp,reminder = 0,rev = 0;
			temp = i;
			int num = i;
			while (num > 0) {
				reminder = num % 10;
				rev =  (rev * 10) + reminder;
				num = num / 10;
			}
			if (rev == temp && rev % 2 != 0) {
				System.out.println(rev + "  is odd palindrome");
			}
		}
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the range1");
		int num1 = scanner.nextInt();
		System.out.println("enter the range2");
		int num2 = scanner.nextInt();
		oddpalindrome(num1,num2);

	}

}
