package cls9;

public class GetReversedString { 
	static String getReversedString(String s) {
		String result = "";
		for (int i = s.length()-1; i >= 0; i--) {
			 char ch = s.charAt(i);
			 result = result + ch +" "; 
		}
		return result;
	}
	public static void main(String[] args) {
		String s = "java";
		System.out.println(getReversedString(s));

	}

}
