package cls9;

public class QuadraticSequence {
	static int quadrtic(int num) {
		int sum = 1;
		int num2 = 2;
		
		for (int i = 1; i < num; i++) {
			sum = sum + num2;
			num2++;
		}
		return sum;
	}
public static void main(String[] args) {
	int num = 10;
	System.out.println(quadrtic(num));
}
}
