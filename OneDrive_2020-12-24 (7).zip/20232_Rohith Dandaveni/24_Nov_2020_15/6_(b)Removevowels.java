package cls9;

public class Removevowels {

	static String removevowels(String name) {
		String result = " ";
		for (int i = 0; i < name.length(); i++) {
			char ch = name.charAt(i);
			if (ch != 'a' && ch != 'e' && ch != 'i' && ch != 'o' && ch != 'u') {
				result = result +ch + " "; 
			}
		}
		return result;
	}
	public static void main(String[] args) {
		String name = "java is a programming language";
		
		System.out.println(removevowels(name));
	}

}
