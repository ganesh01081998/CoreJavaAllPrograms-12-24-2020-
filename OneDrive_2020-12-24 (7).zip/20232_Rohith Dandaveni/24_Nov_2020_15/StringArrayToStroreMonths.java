package cls9;

import java.util.Scanner;

public class StringArrayToStroreMonths {

	static String dispDays(int arr[]) {
		String result = "";
		for(int i = 0; i < arr.length; i++) {
			result = result + arr[i] + "\n";
		}
		return result;
	}
	static String dispMonths(String st[]) {
		String result = "";
		for(int i = 0; i< st.length; i++) {
			result = result + st[i] + "\n";
		}
		return result;
	}
	
	static int check(String st[],String month,int arr[]) {
		int result = 0;
		int temp;
		for(int i = 0; i < st.length; i++) {
			if (month == st[i]) {
				temp = i;
				for(int j = 0; j < arr.length; j++) {
					if ( temp == j) {
						result = result +(arr[j]);
					}
				}
			}
			
		}
		return result;
	}
	
	public static void main(String[] args) {
		String st[] = {"jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec"};
		int arr[] = {31, 29, 31, 30, 31, 30, 31,31,30,31,30,31};
//		Scanner scanner = new Scanner(System.in);
//		System.out.println("enter the month");
//		String month = scanner.next();
		String month = "jan";
			System.out.println(dispMonths(st));
			System.out.println(dispDays(arr));
			System.out.println(check(st,month,arr));
	}

}
