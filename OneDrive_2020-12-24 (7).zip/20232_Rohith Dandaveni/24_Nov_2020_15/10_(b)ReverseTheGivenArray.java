package cls9;

import java.util.Arrays;

public class ReverseTheGivenArray {

	static int[] reverseTheGivenArray(int arr[],int brr[]) {
		int result = 0;
		
	for(int i = arr.length-1; i >= 0; i--) {
		brr[arr.length-i] = arr[i];
		
	}
	
	return brr;
}
	public static void main(String[] args) {
		int arr[] = {12,11,10,5,6,1};
		int brr[] = new int[arr.length];
 		reverseTheGivenArray(arr,brr);
System.out.println(Arrays.toString(brr));
	}

}
