package cls9;

public class FindLCM {

	static int findLCM(int num1,int num2) {
		int result = 0;
		int temp = (num1 < num2) ? num1 : num2;
		while (temp > 0) {
			if (temp % num1 == 0 && temp % num2 == 0) {
				result = result + temp;
				break;
			}
			else {
				result = result + -1;
			}
			temp++;
	}
		return result;
	}
		
	public static void main(String[] args) {
		int num1 = -20;
		int num2 = 10;
	System.out.println(findLCM(num1,num2));

	}

}
