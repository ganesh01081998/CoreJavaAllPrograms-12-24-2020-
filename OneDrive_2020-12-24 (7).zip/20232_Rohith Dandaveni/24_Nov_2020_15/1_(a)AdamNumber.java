package cls9;

import java.util.Scanner;

public class AdamNumber {
	static void multiplication(int num) {
		
		int temp = num;
		num = num * num;
		int revNumberOfGivenNum = getReverse(temp);
		revNumberOfGivenNum = revNumberOfGivenNum * revNumberOfGivenNum;
		int output = getReverse(revNumberOfGivenNum);
		System.out.println(isAdamNumber(output,num));
	}
	static boolean isAdamNumber(int output,int temp) {
		boolean b = false;
		if (output == temp) {
			b = true;
		}
		else {
			b = false;
		}
		return b;
		
	}
	static int getReverse(int revNumberOfGivenNum) {
		int result = 0;
		int rem = 0 , rev = 0,temp;
		while (revNumberOfGivenNum > 0) {
			rem = revNumberOfGivenNum % 10;
			rev = (rev * 10) + rem;
			revNumberOfGivenNum = revNumberOfGivenNum / 10;
		}
		result = result + rev;
		return result;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the number");
		int num = scanner.nextInt();
		multiplication(num);
		
		
		
	}

}
