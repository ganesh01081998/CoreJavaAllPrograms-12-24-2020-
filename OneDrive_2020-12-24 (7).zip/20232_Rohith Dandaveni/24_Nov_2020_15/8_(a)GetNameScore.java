package cls9;

import java.util.Scanner;

public class GetNameScore {

	public static void main(String[] args) {
		String name = "dad";
		int sum = 0;
		for( int i =0; i < name.length(); i++) {
			char ch = name.charAt(i);
			int num = 1;
			for(char j = 'a'; j < 'z'; j++) {
				
				if (ch == j) {
					sum = sum + num;
					break;
				}
				num++;
			}
		}
			
		
		System.out.println(sum);
	}
}
		
		
	
//char crr[] = new char[25];
//char ch[] = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y'};
//for(char i = 0; i < ch.length;i++) {
//	ch[i] = i;
//	System.out.println(ch[i]);
//System.out.println(ch.length);}