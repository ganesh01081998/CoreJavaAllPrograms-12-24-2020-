package cls9;

import java.util.Arrays;
import java.util.Scanner;

public class ReverSeeachWordofaString {

	static String rev(String name) {
		String result = "";
		String st[] = name.split(" ");
		String st1 = "";
//		String st1[] = new String[st.length];
		for(int i = 0; i < st.length; i++) {
			String name1 = st[i];
			for(int j = name1.length(); j > 0 ; j--) {
				st1 = reverse(st[i]);
//				result = result + st1 + " ";
			}
			result = result + st1 + " ";
		}
		
		return result;
	}
	static String reverse (String st1) {
		String result = "";
		StringBuffer sb =  new StringBuffer(st1);
		result = sb.reverse().toString();
		return result;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the name of a String");
		String name = scanner.nextLine();
		System.out.println(rev(name));

	}

}
