package cls9;

public class PerfectNumber {

	static int perfect(int num) {
		int sum = 0;
		int result = 0;
		for(int i = 1; i < num; i++) {
			if (num % i == 0) {
				sum = sum + i;
				
			}
			
		}
		result = sumOfProperDivisors(sum,num);
		return result;	
	}
	private static int sumOfProperDivisors(int sum,int num) {
		int result = 0;
		if(sum > num) {
			result = result + 1;
	}
	else if (sum < num) {
		result = result + -1;
	}
	else {
		result = result + 0;
	}
		return result;
	}



	public static void main(String[] args) {
		int num = 23;
		System.out.println(perfect(num));

	}

}
