package cls9;

public class ReverseOfString {

	static String rev(String name) {
		String result = "";
		for(int i = name.length()-1; i >= 0 ;i--) {
			char ch = name.charAt(i);
			result = result + ch;
		}
		
		return result;
	}
	public static void main(String[] args) {
		String name = "Java is programming language";
		System.out.println(rev(name));

	}

}
