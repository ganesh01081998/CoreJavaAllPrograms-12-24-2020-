package cls9;

import java.util.Scanner;

public class Collatz {
	static String  collatz(int num) {
		String result = "";
		while(num > 1) {
			if (num % 2 == 0) {
				num = num / 2;
			}
			else {
				num = ( num *3 ) + 1;
			}
			result = result + num +  " ";
		}
		return result;
}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the number");
		int num = scanner.nextInt();
		System.out.println(collatz(num));

	}

}
