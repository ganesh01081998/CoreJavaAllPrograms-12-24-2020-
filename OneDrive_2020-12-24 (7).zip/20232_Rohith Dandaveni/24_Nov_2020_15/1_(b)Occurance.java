package cls9;

public class Occurance {

	static String occur(int count) {
		String result = "";
		String name = "java";		
		String name1 = name;
		String name2 = "";
		char ch = 0,ch1 = 0;
		for(int i = 0; i < name.length(); i++) {
			for (int j = i + 1; j < name.length(); j++) {
				ch = name.charAt(i);
				ch1 = name1.charAt(j);
				if (ch ==  ch1) {			
				}
				else {
					name2 = name2 +  ch;
					break;
				}
			}
			}
		System.out.println(name2);
		for (int i = 0; i < name2.length(); i++) {
			for (int j = 0; j < name.length(); j++) {
				ch = name.charAt(i);
				ch1 = name1.charAt(j);
				if (ch ==  ch1) {		
					count++;
				}
			}
			if(count > 0) {
				result = result + ch + " " + count + "\n" ;
				
			}
			count = 0;
		}
		return result;
		
	}
	public static void main(String[] args) {
		int count = 0;
		System.out.println(occur(count));
		}
}
