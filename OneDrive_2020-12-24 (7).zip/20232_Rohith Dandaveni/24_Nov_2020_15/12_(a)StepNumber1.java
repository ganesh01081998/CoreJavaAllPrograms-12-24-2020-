package cls9;

import java.util.Arrays;

public class StepNumber1 {

	static boolean step(int num) {
		String number = num + "";
		boolean b = false;
		int arr[] = new int[number.length()];
		int count= 0,temp = 0;
		while (num > 0) {
		arr[temp] = num % 10;
		num = num / 10;
		temp++;
		}
		
		for (int i = 0; i < arr.length - 1; i++) {
			if (Math.abs(arr[i] - arr[i + 1]) == 1) {
				count++;
			}
				if (count == number.length()-1) {
					b = true;
				}
		}
		return b;
		
	}
	public static void main(String[] args) {
		int num = 1279;
 		System.out.println(step(num));
		
	}
}
