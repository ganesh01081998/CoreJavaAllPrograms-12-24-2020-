package cls6Arrays;

import java.util.Scanner;

public class GetEvenDuplica {
	static String getEvenArray(int arr[]) {
		String result = "";
		int brr[] = new int[6];
	
		for (int i = 0; i < arr.length; i++) {
			
			if (arr[i] % 2 == 0) {
				result = result + "even numbers" + arr[i];
				result = result + "\n";
				brr[i] = arr[i];
				System.out.println("brr[i]" + brr[i]);
			}
			}
		if (brr[0] == 0) {
			result = result + "empty";
		}	
	
	return result;
}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the range");
		int range = scanner.nextInt();
		//int brr[] = new int[8];
		int arr[] = new int[range];
		if (arr.length != 4) {
			System.out.println("null");
		}
		else {
			System.out.println("enter the minmum 10 numbers");
		for (int i = 0; i < arr.length; i++) {
			arr[i] = scanner.nextInt();
		}
				System.out.println(getEvenArray(arr));
	}
}
}