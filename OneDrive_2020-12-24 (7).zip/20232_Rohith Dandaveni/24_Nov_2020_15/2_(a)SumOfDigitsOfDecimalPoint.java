package cls9;

public class SumOfDigitsOfDecimalPoint {

	static String concateSumOfDigits(String st0,String st1) {
		String result = "";
		System.out.println(st0);
		int num1 = Integer.parseInt(st0);
		int num2 = Integer.parseInt(st1);
		int sum1 = sum(num1);
		int sum2 = sum(num2);
		result = result + sum1+ ":" + sum2;
		return result;
	}
	
	static int sum(int num) {
		int result = 0;
		int reminder = 0, rev = 0;
		while (num > 0) {
			reminder = num % 10;
			rev = rev + reminder;
			num = num / 10;
			result = rev;
		}
		return result;
	}
	public static void main(String[] args) {
		String name = "120.520";
		String st[] = name.split("[.]");
		String st0 = st[0];
		String st1 = st[1];
		System.out.println(concateSumOfDigits(st0,st1));

	}
	
}
