package cls9;

public class FindDuplicateElementsInAnArray {

	static String  findDuplicate(int arr[]) {
		String result = "";
		int count = 0;
		for (int i = 0; i <arr.length; i++) {
			for (int j = i + 1; j <arr.length;j++) {
			if (arr[i] == arr[j]) {
				count++;
				
			}
			}
			if (count == 1) {
				result = result + arr[i];
			}
			count = 0;
		}
		
		return result;
	}
	public static void main(String[] args) {
		int arr[] = {10,12,3,10,12,17,12};
		System.out.println(findDuplicate(arr)); 
	}                                                                                                                                                                           
}
