package cls9;

public class GivenConsonents {

	static String vowels(String st) {
		String result = "";
		for(int i =0 ; i < st.length(); i++) {
			char ch = st.charAt(i);
			if (ch != 'a' && ch != 'e' && ch != 'i' && ch != 'o' && ch != 'u') {
				result = result + ch + " ";
			}
		}
		return result;
	}
	public static void main(String[] args) {
		String st = "chinna";
		System.out.println(vowels(st));

	}

}
