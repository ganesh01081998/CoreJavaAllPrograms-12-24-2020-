package cls9;

import java.util.Scanner;

public class GetElePosition {

	 static int getElePosition(int arr[], int value) {
		int result = 0;

		if(arrayContainZeoOrNega(arr)== -4 || arraySize(arr)==-2 || negativeOrZero(value)== -3) {
		System.out.println(arrayContainZeoOrNega(arr));
		System.out.println(arraySize(arr));
		System.out.println(negativeOrZero(value));
		}
//		arrayContainZeoOrNega(arr);
//		arraySize(arr);
//		negativeOrZero(value);
		else {
		for (int i = 0; i < arr.length; i++) {
			if (value == arr[i]) {
				result = i+1;
			}
			else {
				result = -1;
			}
		}
		}
		return result;
	}
	 static int arrayContainZeoOrNega(int arr[]) {
		 int result = 0;
		 for(int i = 0; i < arr.length; i++) {
			 if (arr[i] == 0 || arr[i] < 0) {
				 result = -4;
			 }
		 }
		 return result;
	 }
	 static int negativeOrZero(int value) {
		 int result = 0;
		 if (value == 0 || value < 0) {
			 result = -3;
		 }
		 return result;
			
	 }
	 static int arraySize(int arr[]) {
		 int result = 0;
		 if (arr.length < 0) {
			 result = -2;
		 }
		 return result;
	 }
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		System.out.println("enter the size of array");
		int size = scanner.nextInt();
		int arr[] = new int[size];
		System.out.println("enter the array values");
		for (int i = 0; i < arr.length; i++) {
			arr[i] = scanner.nextInt();
		}
	
		System.out.println("enter search values/search element");
		int value = scanner.nextInt();
		System.out.println(getElePosition(arr,value));
	}
}
