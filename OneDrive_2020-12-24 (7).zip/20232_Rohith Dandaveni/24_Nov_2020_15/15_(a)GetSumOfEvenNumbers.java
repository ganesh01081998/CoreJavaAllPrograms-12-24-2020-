package cls9;

public class GetSumOfEvenNumbers {

	static int getSum(int arr[]) {
		int result = 0;
		int sum = 0;
		if (arr.length == 0) {
			return -3;
		}
		for(int i = 0; i < arr.length;i++) {
			if (arr[i] < 0) { 
				return -1;
			}
			else if (arr[i] % 2 == 0) {
				sum = sum + arr[i];
				result = sum;
			}
		}
		return result;
	}
	public static void main(String[] args) {
		int arr[] = {1,2,3,4,5,-6};
		System.out.println(getSum(arr));

	}

}
