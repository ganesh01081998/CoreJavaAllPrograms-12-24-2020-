package cls_12_21_2020;

import java.util.Scanner;

public class CheckingAccount {
	Scanner sc = new Scanner(System.in);
	//Instance Variables: accountNo:integer balance: double
	int accountNo;
	double balance;
//	checkAccount(accountNo):Boolean Instance Method 2: deposit(amount):void Instance Method 3: withdraw(amount):double
	public CheckingAccount(int accountNo, double balance) {
		super();
		this.accountNo = accountNo;
		this.balance = balance;
	}
	
	public boolean checkAccount(int accountNo,int enterYourAc) {
		boolean b = false;
		if (accountNo == enterYourAc) {
			return true;
		}
		return b;
	}
	
	public void deposit(double balance,double enterYourDepositMoney) {
		System.out.println("your current balance = " + balance + "your now deposited amount is = " + enterYourDepositMoney  + "\n" + "your final balnce is = " + (balance + enterYourDepositMoney));
	}

	public double withdraw(double balance,double enterYourwithdrawMoney) {
		double result = 0;
		try {
		if (balance < enterYourwithdrawMoney) {
			System.out.println("you dont have any that much of balance in your ac please select below " + balance);
		}
		else {
			result = (balance - enterYourwithdrawMoney);
			throw new InsufficientException (result + "");
		}
	}
		catch(InsufficientException e) {
			System.out.println(e);
		}
		return result;
	}
	}

