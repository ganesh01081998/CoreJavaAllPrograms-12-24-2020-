package cls_12_21_2020;

import java.util.Scanner;

public class BankDemo {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter your money(bal)");
		int bal = scanner.nextInt();
		InsufficientFundsException ob = new InsufficientFundsException(bal);
		System.out.println("your balance = " + ob.getAmount());
		
		
		System.out.println("enter your ac number");
		int accountNo = scanner.nextInt();
		CheckingAccount ob1 = new CheckingAccount(accountNo,bal);
		System.out.println("enter your ac number for your withdraw or for deposit");
		int enterYourAc = scanner.nextInt();
		ob1.checkAccount(accountNo, enterYourAc);
		
		if (accountNo == enterYourAc) {
		System.out.println("for deposit = 1" + "\n" + "for withdraw = 0");
		int num = scanner.nextInt();
		if (num == 1) {
			System.out.println("enter enter Your Deposit Money");
			int enterYourDepositMoney = scanner.nextInt();
			ob1.deposit(bal, enterYourDepositMoney);
		}
		else {
		System.out.println("enter enter Your withdraw Money");
		int enterYourwithdrawMoney = scanner.nextInt();
		ob1.withdraw(bal, enterYourwithdrawMoney);
		}
		}
		else {
			System.out.println("you entered ac number is wrong please check your ac thank you");
		}
}
}
