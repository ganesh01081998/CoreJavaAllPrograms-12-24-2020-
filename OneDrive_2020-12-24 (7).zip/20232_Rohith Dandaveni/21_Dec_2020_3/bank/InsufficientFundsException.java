package cls_12_21_2020;

class InsufficientException extends Exception{
	public InsufficientException(String mess){
		super(mess);
	}
}
public class InsufficientFundsException {
	private double amount;
	InsufficientFundsException(double amount){
		this.amount = amount;
	}
	public double getAmount() {
		double result = 0;
		result = amount;
		return result;
	}
	
}
