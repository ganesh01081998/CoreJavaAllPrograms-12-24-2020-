package cls18_15_12_2020;

class LeaveQuotaExceededException extends Exception {
	 public LeaveQuotaExceededException(String mess) {
	        super(mess);
	    }
}
public class ExcepLeaveQuota {

	public static void main(String[] args) {
		int leavesYouHave = 0;
		int imAskingLeave = 1;
		try {
		if (leavesYouHave > imAskingLeave) {
			throw new LeaveQuotaExceededException("you leave has sanstioned happy journey" + "\n" + "you have remain leaves are = " + (leavesYouHave - imAskingLeave));
			
		}
		else {
			System.out.println("you dont have any leaves sorry");
		}
	}
		catch(Exception e) {
			System.out.println(e);
		}
	}
	
}
