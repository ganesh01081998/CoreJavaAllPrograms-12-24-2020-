package cls15_12_7_2020;

public class SumOfDigits {

	static int sum(String name) {
		int result = 0;
		int sum = 0;
		int num = 0;
		for(int i = 0; i < name.length(); i++) {
			char ch = name.charAt(i);
				if (Character.isDigit(ch)) {
					num = Character.getNumericValue(ch);
					sum = sum + num;
					result = sum;
		
			}
		}
		return result;
	}
	public static void main(String[] args) {
		String name = "aa1bc2d3";
		System.out.println(sum(name));
	}
}
