package cls15_12_7_2020;

import java.util.Scanner;

public class Sum {

	static int sum(int arr[],int sum) {
		int result = 0;
		

		for(int i = 0;i < arr.length; i++) {
			int num1 = fixTeen(arr[i]) ;
			if(num1 > 0) {
				sum = sum + num1;
				result = sum;
			}
		}
		return result;
	}
	public static int fixTeen(int n) {
		int result = 0;
		if (n == 13 || n == 14) {
			result = result + 0;
		}
		else if (n == 17 || n == 19 || n == 18) {
			result = result + 0;
		}
		else if (n == 15 || n == 16) {
			result = result + n;
		}
		else {
			result = result + n;
		}
		return result;
		
	}
	public static void main(String[] args) {
		int sum = 0;
		int arr[] = new int[3];
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the array values");
		for(int i = 0; i <arr.length; i++) {
			arr[i] = scanner.nextInt();
		}
		System.out.println(sum(arr,sum));
	}
}
