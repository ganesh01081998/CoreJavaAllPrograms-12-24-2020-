package clsprograms3;

import java.util.Scanner;

public class SumOfNaturalNumbers {
		static int sumOfNaturals(int num1 , int num2) {
			int sum = 0;
			for (int i = num1 ; i<= num2 ; i++) {
				sum = sum + i;
				System.out.println(sum);
			}
			return sum;
			
		}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the range");
		int num1 = scanner.nextInt();
		int num2 = scanner.nextInt();
		System.out.println(sumOfNaturals(num1 , num2));

	}

}
