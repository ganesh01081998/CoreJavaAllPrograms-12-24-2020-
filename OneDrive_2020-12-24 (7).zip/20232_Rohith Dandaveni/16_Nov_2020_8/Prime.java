package clsprograms3;

import java.util.Scanner;

public class Prime {
	static void prime(int num) {
		int count = 0;
		for( int i = 2 ; i < num ; i++) {
		
			if (num % i == 0) {
				count++;
			}
		}
		if ( count == 0) {
			System.out.println(num + " its prime number");
		}
		else {
			System.out.println(num + " its not a prime number");
		}
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the number");
		int num = scanner.nextInt();
		prime(num);

	}

}
