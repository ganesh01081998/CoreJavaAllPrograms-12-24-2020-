package clsprograms3;

import java.util.Scanner;

public class FizzBizz {
	static String getOutputString(int num) {
		if(num % 3 == 0 && num % 5 == 0) {
			return "fizzbizz";
		}
		else if (num % 3 == 0) {
			return "fizz";
		}
		else if (num % 5 == 0) {
			return "bizz";
		}
		else {
			return "error";
		}
		
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the number");
		int num = scanner.nextInt();
		System.out.println(getOutputString(num));
		
	}

}
