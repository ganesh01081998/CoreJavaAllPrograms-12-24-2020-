package clsprograms3;

import java.util.Scanner;

public class Armstrong { 
		static  void armstrong(int num) {
		int temp = 0 , reminder = 0, arm = 0 ;
		temp = num; 
		while(num > 0) {
			reminder = num %10;
			arm = arm + reminder * reminder * reminder ;
			num = num / 10;
		}
		if (arm == temp) {
			System.out.println(temp + " it is a armstrong number");
		}
		else {
			System.out.println(temp + " it not a armstrong number");
		}
		}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the number");
		int num = scanner.nextInt();
		armstrong(num);

	}

}
