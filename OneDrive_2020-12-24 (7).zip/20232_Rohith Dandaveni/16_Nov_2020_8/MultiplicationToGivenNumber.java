package clsprograms3;

import java.util.Scanner;

public class MultiplicationToGivenNumber {
		static void mul(int num) {
			int results = 0;
			for (int i = 0 ; i <= 10 ; i++) {
			System.out.println( num + "*" + i + "=" + (num * i));
			}
		}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the number");
		int num = scanner.nextInt();
		mul(num);

	}

}
