package clsprograms3;

import java.util.Scanner;

public class Factorial {
	static void fac(int num) {
		
		int factorial = 1;
		for (int i = 1 ; i <= num ; i++ )
			factorial = factorial * i;
			System.out.println(factorial);
		return;
		
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the number");
		int num = scanner.nextInt();
		fac(num);

	}

}
