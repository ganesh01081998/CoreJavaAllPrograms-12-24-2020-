package cls18_15_12_2020;

import java.util.Scanner;

public class Check {

	public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
		Circle ob = new Circle();
		System.out.println("enter the circle redius");
		ob.setRadius(scanner.nextFloat());
		ob.getArea();
		ob.getPerimeter();
		
		Square ob1 = new Square();
		System.out.println("enter the square side");
		ob1.setSide(scanner.nextInt());
		ob1.getArea();
		ob1.getPerimeter();
		
		Rectangle ob2 = new Rectangle();
		System.out.println("enter the rectangle length");
		ob2.setBreadth(scanner.nextInt());
		System.out.println("enter the rectangle breadth");
		ob2.setLength(scanner.nextInt());
		ob2.getArea();
		ob2.getPerimeter();
	}

}
