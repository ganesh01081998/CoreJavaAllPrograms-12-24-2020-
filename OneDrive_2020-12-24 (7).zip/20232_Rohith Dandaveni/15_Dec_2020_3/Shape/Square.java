package cls18_15_12_2020;

public class Square extends Shape {

	public int side;

	public int getSide() {
		return side;
	}

	public void setSide(int side) {
		this.side = side;
	}
	
	public Square() {
		
	}
	Square(int side) {
		this.side = side;
	}

	@Override
	void getArea() {
		System.out.println("Area = " + (side * side));
		
	}

	@Override
	void getPerimeter() {
		System.out.println("Perimeter = " + (4 * side));
		 
	}
	
	}

