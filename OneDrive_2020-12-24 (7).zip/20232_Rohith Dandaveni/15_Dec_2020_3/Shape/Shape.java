package cls18_15_12_2020;

abstract public class Shape {

	
	public Shape() {
		
	}
	abstract void getArea();
	abstract void getPerimeter();
	
	
}
