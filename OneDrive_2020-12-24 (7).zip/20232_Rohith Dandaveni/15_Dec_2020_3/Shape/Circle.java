package cls18_15_12_2020;

class Circle extends Shape {
	public float radius;
	
	
	public float getRadius() {
		return radius;
	}

	public void setRadius(float radius) {
		this.radius = radius;
	} 
	public Circle() {
		
	} 
	Circle(float radius) {
		this.radius = radius;
	}

	@Override
	void getArea() {
		System.out.println("area = " + " " +(3.14 * (radius * radius )));
		
	}

	@Override
	void getPerimeter() {
		System.out.println("perimeter = " + " " +(2 * 3.14 * radius));
		
	}
	
}
