package cls18_15_12_2020;

public class CivicsStudent extends Student{

	private int historyMarks;
	private int civicsMarks;
	private int  mathMarks;
	
	public CivicsStudent(String name,String cls,int historyMarks,int civicsMarks,  int mathMarks ) {
		this.name = name;
		this.cls = cls;
		this.historyMarks = historyMarks;
		this.mathMarks = mathMarks;
		this.civicsMarks = civicsMarks;
	}
	@Override
	void getPercentage() {
		int num = historyMarks + mathMarks + civicsMarks;
		System.out.println("student percentage" + (num / 3) );
	}
	@Override
	public String toString() {
		return "CivicsStudent [ " + "Student name" + name + " " + "class" + cls + " " + "historyMarks=" + historyMarks + ", civicsMarks=" + civicsMarks + ", mathMarks="
				+ mathMarks + "]";
	}
	
	
}
