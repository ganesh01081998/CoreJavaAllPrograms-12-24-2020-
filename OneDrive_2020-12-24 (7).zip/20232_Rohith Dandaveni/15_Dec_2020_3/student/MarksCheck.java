package cls18_15_12_2020;

import java.util.Scanner;

public class MarksCheck {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the student name,cls,phyMarks,chemMarks,mathMarks");
		ScienceStudent ob = new ScienceStudent(sc.next(),sc.next(),sc.nextInt(),sc.nextInt(),sc.nextInt()); 
		ob.getPercentage();
		System.out.println(ob);
		
		System.out.println("enter the student name,cls,hysMarks,mathMarks,civicsMarks");
		CivicsStudent ob1 = new CivicsStudent(sc.next(),sc.next(),sc.nextInt(),sc.nextInt(),sc.nextInt());
		ob1.getPercentage();
		System.out.println(ob1);
	}
}
