package cls18_15_12_2020;

public class ScienceStudent extends Student {

	private int physicsMarks;
	private int chemistryMarks;
	private int  mathMarks;
	
	public ScienceStudent(String name,String cls, int physicsMarks,int chemistryMarks,  int mathMarks ) {
		this.name = name;
		this.cls = cls;
		this.chemistryMarks = chemistryMarks;
		this.mathMarks = mathMarks;
		this.physicsMarks = physicsMarks;
	}
	
	@Override
	void getPercentage() {
		int num =  physicsMarks + chemistryMarks + mathMarks;
		System.out.println("student percentage" + (num / 3));
	}

	@Override
	public String toString() {
		return "ScienceStudent [ " + "name" + name + " " + "class" + cls + " " + "physicsMarks=" + physicsMarks + ", chemistryMarks=" + chemistryMarks + ", mathMarks="
				+ mathMarks + "]";
	}
	
}
