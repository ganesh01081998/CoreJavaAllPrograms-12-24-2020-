package cls18_15_12_2020;

import java.util.Scanner;

public class COJ_15_TaxUtil {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Employee id,name,basicSalary,HRAper,DAPer");
		COJ_15_Employee employee = new COJ_15_Employee(scanner.nextInt(), scanner.next(), scanner.nextDouble(), scanner.nextDouble(), scanner.nextDouble());
		System.out.println(employee);
		COJ_15_TaxUtil taxUtil = new COJ_15_TaxUtil();
		System.out.println("Employee tax : " + taxUtil.calculatetax(employee.calculateGrossSalary()));
		System.out.println("Enter the Manager id,name,basicSalary,HRAper,DAPer,projectAllowance");
		COJ_15_Manager manager = new COJ_15_Manager(scanner.nextInt(), scanner.next(), scanner.nextDouble(), scanner.nextDouble(), scanner.nextDouble(),scanner.nextDouble());
		System.out.println(manager);
		System.out.println("Manager tax : " + taxUtil.calculatetax(manager.calculateGrossSalary()));
		System.out.println("Enter the Trainer id,name,basicSalary,HRAper,DAPer,batchCount,perkPerBatch");
		COJ_15_Trainer trainer = new COJ_15_Trainer(scanner.nextInt(), scanner.next(), scanner.nextDouble(), scanner.nextDouble(), scanner.nextDouble(),scanner.nextInt(),scanner.nextDouble());
		System.out.println(trainer);
		System.out.println("Trainer tax : " + taxUtil.calculatetax(trainer.calculateGrossSalary()));
	}

	double calculatetax(double grossSalary) {
		double tax;
		if(grossSalary > 30000){
			 tax = grossSalary * 20 /100;				
		}
		else {
			 tax = grossSalary * 5 /100;
		}
		return tax;
	}
	}

