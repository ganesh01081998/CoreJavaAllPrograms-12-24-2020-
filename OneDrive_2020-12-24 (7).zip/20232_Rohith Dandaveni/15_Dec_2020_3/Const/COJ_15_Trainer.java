package cls18_15_12_2020;

public class COJ_15_Trainer {

	//id: int, name :String, basicSalary : double, HRAPer : double,DAPer : double, batchCount: int, perkPerBatch: double
	public int id;
	public String name;
	public double basicSalary;
	public double HRAPer;
	public double DAPer;
	public int batchCount;
	public double perkPerBatch;
	
	double calculateGrossSalary() {
		double result = 0;
		//Calculate the gross salary as : basicSalary +HRAPer +DAPer
		double grossSalary = basicSalary + HRAPer + DAPer + (batchCount * perkPerBatch);
				result = grossSalary;
				return result;
	}
	
	COJ_15_Trainer() {
		id = 0;
		name = "null";
		basicSalary = 0.0;
		HRAPer = 0.0;
		DAPer = 0.0;
		batchCount = 0;
		perkPerBatch = 0.0;
	}
	COJ_15_Trainer( int id,String name,double basicSalary,double HRAPer,double DAPer,int batchCount,double perkPerBatch) {
		this.id = id;
		this.name = name;
		this.basicSalary = basicSalary;
		this.HRAPer = HRAPer;
		this.DAPer = DAPer;
		this.batchCount = batchCount;
		this.perkPerBatch = perkPerBatch;
	}

	@Override
	public String toString() {
		return "COJ_15_Trainer [id=" + id + ", name=" + name + ", basicSalary=" + basicSalary + ", HRAPer=" + HRAPer
				+ ", DAPer=" + DAPer + ", batchCount=" + batchCount + ", perkPerBatch=" + perkPerBatch + "]";
	}
	
	
}
