package cls18_15_12_2020;

public class COJ_15_Sourcing {

//	id: int, name : String, basicSalary : double, HRAPer : double,DAPer : double, enrollmentTarget: int, 
//	enrollmentReached: int, perkPerEnrollment: double
	
	public int id;
	public String name;
	public double basicSalary;
	public double HRAPer;
	public double DAPer;
	public double enrollmentTarget;
	public int enrollmentReached;
	public double perkPerEnrollment;
	
	//Calculate the gross salary as : basicSalary +HRAPer +DAPer +((enrollmentReached/enrollmentTarget)*100)*perkPerEnrollment)
	double calculateGrossSalary() {
		double result = 0;
		double grossSalary = basicSalary + HRAPer + DAPer +(((enrollmentReached/enrollmentTarget)*100)*perkPerEnrollment);
				result = grossSalary;
				return result;
	}
	
	COJ_15_Sourcing() {
		id = 0;
		name = "null";
		basicSalary = 0.0;
		HRAPer = 0.0;
		DAPer = 0.0;
		enrollmentTarget = 0.0;
		enrollmentReached = 0;
		perkPerEnrollment = 0.0;
	}
	COJ_15_Sourcing( int id, String name, double basicSalary, double HRAPer, double DAPer, int enrollmentTarget, int enrollmentReached, double perkPerEnrollment) {
		this.id = id;
		this.name = name;
		this.basicSalary = basicSalary;
		this.HRAPer = HRAPer;
		this.DAPer = DAPer;
		this.enrollmentTarget = enrollmentTarget;
		this.enrollmentReached = enrollmentReached;
		this.perkPerEnrollment = perkPerEnrollment;
	}

	@Override
	public String toString() {
		return "COJ_15_Sourcing [id=" + id + ", name=" + name + ", basicSalary=" + basicSalary + ", HRAPer=" + HRAPer
				+ ", DAPer=" + DAPer + ", enrollmentTarget=" + enrollmentTarget + ", enrollmentReached="
				+ enrollmentReached + ", perkPerEnrollment=" + perkPerEnrollment + "]";
	}
	
}
