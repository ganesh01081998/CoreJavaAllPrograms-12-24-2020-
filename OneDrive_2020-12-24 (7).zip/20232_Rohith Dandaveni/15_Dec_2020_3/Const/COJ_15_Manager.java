package cls18_15_12_2020;

public class COJ_15_Manager {

	public int id;
	public String name;
	public double basicSalary;
	public double HRAPer;
	public double DAPer;
	public double projectAllowance;
	
	double calculateGrossSalary() {
		double result = 0;
		//Calculate the gross salary as : basicSalary +HRAPer +DAPer
		double grossSalary = basicSalary + HRAPer + DAPer + projectAllowance;
				result = grossSalary;
				return result;
	}
	
	COJ_15_Manager() {
		id = 0;
		name = "null";
		basicSalary = 0.0;
		HRAPer = 0.0;
		DAPer = 0.0;
		projectAllowance = 0.0;
	}
	COJ_15_Manager( int id,String name,double basicSalary,double HRAPer,double DAPer,double projectAllowance) {
		this.id = id;
		this.name = name;
		this.basicSalary = basicSalary;
		this.HRAPer = HRAPer;
		this.DAPer = DAPer;
		this.projectAllowance = projectAllowance;
	}

	@Override
	public String toString() {
		return "COJ_15_Manager [id=" + id + ", name=" + name + ", basicSalary=" + basicSalary + ", HRAPer=" + HRAPer
				+ ", DAPer=" + DAPer + ", projectAllowance=" + projectAllowance + "]";
	}
	
}
