package cls18_15_12_2020;

public class COJ_15_Employee {

	public int id;
	public String name;
	public double basicSalary;
	public double HRAPer;
	public double DAPer;
	
	double calculateGrossSalary() {
		double result = 0;
		//Calculate the gross salary as : basicSalary +HRAPer +DAPer
		double grossSalary = basicSalary +HRAPer +DAPer;
				result = grossSalary;
				return result;
	}
	COJ_15_Employee() {
		id = 0;
		name = "null";
		basicSalary = 0.0;
		HRAPer = 0.0;
		DAPer = 0.0;
	}
	COJ_15_Employee( int id,String name,double basicSalary,double HRAPer,double DAPer) {
		this.id = id;
		this.name = name;
		this.basicSalary = basicSalary;
		this.HRAPer = HRAPer;
		this.DAPer = DAPer;
	}
	@Override
	public String toString() {
		return "COJ_15_Employee [id=" + id + ", name=" + name + ", basicSalary=" + basicSalary + ", HRAPer=" + HRAPer
				+ ", DAPer=" + DAPer + "]";
	}
	
}
