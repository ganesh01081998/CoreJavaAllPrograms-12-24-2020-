package clsprogs2;

public class Palindrome {
	static boolean palidrome(int num) {
		boolean b = false;
		int reminder = 0 , reverse = 0 , temp;
		temp = num;
		while (temp > 0) {
			reminder = temp % 10;
			reverse = (reverse * 10) + reminder;
			temp = temp / 10;
		}
		System.out.println("reverse of given number is = " + reverse);
		if ( reverse == num ) {
		return true;
		}
		else{
	return b;
	}
		}
	public static void main(String[] args) {
		int num = Integer.parseInt(args[0]);
		System.out.println(palidrome(num));
	}
}
