package clsprogs2;

public class Mul100WithCommArg {

		static int mulOfHundred(int num) {
			num = (num / 100 + 1) * 100;
			return num;
		}
		public static void main(String args[]) {
			int num = Integer.parseInt(args[0]);
			System.out.println(mulOfHundred(num));

		}

	}
