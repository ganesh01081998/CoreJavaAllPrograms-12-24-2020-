package clsprogs2;

public class Swapping {
	
		static int swap(int num1 , int num2) {
			num1 = num1 + num2;
			num2 = num1 - num2;
			num1 = num1 - num2; 
			System.out.println("after" +num1 + "," + num2);
			return 0;
			
		}
	public static void main(String[] args) {
		int num1 = Integer.parseInt(args[0]);
		int num2 = Integer.parseInt(args[1]);
		System.out.println("before" +num1 + "," + num2);
		swap(num1,num2);

	}

}
