package clsprogs2;

public class SumOfFourDigits {
	static int sumOfNumber(int arr[]) {
		int sum = 0;
		sum = sum + (arr[0]);
		sum = sum + (arr[1]);
		sum = sum + (arr[2]);
		sum = sum + (arr[3]);
				
		return sum;
		
	}

	public static void main(String[] args) {
		int arr [] = new int[4];
		arr[0] = Integer.parseInt(args[0]);
		arr[1] = Integer.parseInt(args[1]);
		arr[2] = Integer.parseInt(args[2]);
		arr[3] = Integer.parseInt(args[3]);
		System.out.println(sumOfNumber(arr));

	}

}
