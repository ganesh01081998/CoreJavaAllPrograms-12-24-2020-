package cls16_12_10_2020;

public class StudentOfInst {

	private String sName;
	private int id;
	public String getsName() {
		return sName;
	}
	public void setsName(String sName) {
		this.sName = sName;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "StudentOfInst [sName=" + sName + ", id=" + id + "]";
	}
	
}
