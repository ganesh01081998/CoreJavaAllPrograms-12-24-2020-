package cls16_12_10_2020;

public class Customer {

	private String firstName;
	private String secName;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getSecName() {
		return secName;
	}
	public void setSecName(String secName) {
		this.secName = secName;
	}
	@Override
	public String toString() {
		return "Customer [firstName=" + firstName + ", secName=" + secName + "]";
	}
	
}
