package cls16_12_10_2020;

import java.util.Scanner;

public class Rec {
	
	private int x1;
	private int y1;
	private int x2;
	private int y2;
	private int height;
	private int width;
	public Rec(int x1,int y1,int x2,int y2) {
//	public Rec(int height,int width) {
		this.x1 = x1;
		this.y1 = y1;
		this.x2 = x2;
		this.y2 = y2;
	}
	public void getArea(int height , int width) {
		this.height = height;
		this.width = width;
		int result = (height * width);
		System.out.println("area of rectangle" + result);
	}
	public int getPerimeter(int height, int width) {
		this.height = height;
		this.width = width;
		int result = 2 * (height + width);
		return result;
	}
	public int getHeight(int result , int width) {
		int height = ( result / 2) - width;
		return height;
	}
	public int getWidth(int result, int height) {
		int width = (result / 2 ) - height;
		return width;
	}
	static boolean isPointInside(int num1,int num2,int height,int width) {
		if (num1 <= height && num2 <= width) {
			return true;
		}
 		return false;
	}
	static void move(int num1, int num2,int height,int width) {
		int move1 = num1 + height;
		int move2 = num2 + width;
		System.out.println("(" + move1+  "," +move2 + ")");
	}
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the height and width vlaues");
		int height = scanner.nextInt();
		int width = scanner.nextInt();
		
		Rec ob = new Rec(10,5,10,5);
		ob.getArea(height,width);
		int result = ob.getPerimeter(height, width);
		System.out.println("Perimeter of rectangle" + result);
		int result1 = ob.getHeight(result, width);
		System.out.println("Height of rectangle" + result1);
		System.out.println("Width of rectangle" + ob.getWidth(result, height));
		System.out.println("enter the range num1,num2 for checking the values of poins in the range or outof range");
		int num1 =  scanner.nextInt();
		int num2 = scanner.nextInt();
		System.out.println(isPointInside(num1,num2,height,width));
		System.out.println("enter the range move1,move2 for move the values of poins ");
		int move1 =  scanner.nextInt();
		int move2 = scanner.nextInt();
		move(move1,move2,height,width);
	}
}
