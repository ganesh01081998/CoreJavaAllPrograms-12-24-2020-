package cls16_12_10_2020;

import java.util.Scanner;


public class Institute {
	int sum = 0;
	private static StudentOfInst student;
	private static Address add;
	public Institute( StudentOfInst student,Address add) {
		System.out.println("Student details" + "\n" + "student name : " + student.getsName()+ "\n" + "student id : " + student.getId());
		System.out.println("student Hn0 : " + add.getHno() +  "\n" + "student Street : " + add.getStreet() + "\n" + "student Village : " + add.getVillage() + "\n" + "student Mndl : " + add.getMndl() + "\n" + "student Dist : " + add.getDist() + "\n" + "student pincode : " + add.getPincode());

	} 
	
	static Scanner scanner = new Scanner(System.in);
	String st = "welcome to the ours institute" + "\n"; {
	st = st + "Choose ur courses" + "\n";
	st = st + " 1. Java " + "its cost : 5000" + "\n";
	st = st + " 2. Python " + "its cost : 7000" + "\n";
	st = st + " 3. DotNet " + "its cost : 6500" + "\n";
	st = st + " 4. FrameWorks " + "its cost : 5500";
	System.out.println(st);
	System.err.println("select the number cources you need" + "\n" + "For 1 course press => 1 \n" + "For 2 course press => 2 \n" + "For 3 course press => 3 \n" + "For 4 course press => 4 \n");
	int num = scanner.nextInt();
	int arr[] = new int[num];
	System.out.println("Now enter the courses you want");
	for(int i = 0; i <arr.length; i++) {
		arr[i] = scanner.nextInt();
	}
	int brr[] = {5000, 7000, 6500, 5500};
	
	String crr[] = {"Java", "Python", "Dotnet", "FrameWorks"};
	System.out.println("you are selcted these courses");
	for(int i = 0; i < arr.length; i++) {
		for (int j= 0; j < brr.length; j++) {
			
			if (arr[i] == (1 + j) ) {
				System.out.println( (crr[j]));
				sum = sum + brr[j];
			}
			
		}
	}
	System.out.println( "The total cost of your selected couses " + sum);
	}
		public static void main(String[] args) {
			StudentOfInst student = new StudentOfInst();
			System.out.println("enter the student name");
			String name = scanner.next();
			student.setsName(name);
			System.out.println("enter the student id");
			int num = scanner.nextInt();
			student.setId(num);
			Address add = new Address();
			System.out.println("enter the student H.no");
			String hno = scanner.next();
			add.setHno(hno);
			System.out.println("enter the student steet");
			String dist = scanner.next();
			add.setDist(dist);
			System.out.println("enter the student village");
			String mndl = scanner.next();
			add.setMndl(mndl);
			System.out.println("enter the student mondal");
			String street = scanner.next();
			add.setStreet(street);
			System.out.println("enter the student dist");
			String village = scanner.next();
			add.setVillage(village);
			System.out.println("enter the student pincode");
			int pin = scanner.nextInt();
			add.setPincode(pin);
			Institute ob = new Institute(student,add);
	}
}
//String course1 = "Java";
//String course2 = "Python";
//String course3 = "DotNet";
//String course4 = "FrameWorks";