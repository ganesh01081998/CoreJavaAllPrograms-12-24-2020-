package cls16_12_10_2020;

import java.util.Scanner;

public class Acc {
	static Scanner scanner = new Scanner(System.in);
	private static Customer customer;
	private double balance;
	private int ac;
	private float interest;
	public Acc() {
		System.out.println("ours bank");
	}
	public Acc(Customer customer,double balance, int ac,float interest) {
		this.balance = balance;
		this.ac = ac;
		this.interest = interest;
		double bal = balance;
		this.customer = customer;
		System.out.println("Acc [" + customer.getFirstName() + " " + customer.getSecName() + "balance=" + balance + ", ac=" + ac + ", interest=" + interest + "]");
		
		while (true) { 
			System.out.println(" 1.deposit " +  "\n" +  " 2.withdraw " + "\n" + " 3.exit ");
//			Scanner scanner = new Scanner(System.in);
			int num = scanner.nextInt();
			switch(num) { 
			case 1 :
				System.out.println("enter the ac number");
				int acc = scanner.nextInt(); 
				if (ac == acc) {
				deposit(balance);
				}
				else {
					System.err.println("you entered wrong ac number");
				}		
				break;
			case 2 :
				
					System.out.println("enter the ac number");
					int acc1 = scanner.nextInt(); 
					if (ac == acc1) {
						withdraw(balance);
						}
						else {
							System.err.println("you entered wrong ac number");
						}
				break;
			case 3 : System.out.println("have a good day");
			System.exit(0);
			}
		}
		
	}
	static void deposit(double balance) {
		System.out.println("enter the amount for deposit");
//		Scanner scanner = new Scanner(System.in);
		double num = scanner.nextDouble();
		double bal = balance + num;
		System.out.println("your amount deposited your final amount = " + bal);
	}
	static void withdraw(double balance) {
		System.out.println("enter the amount for withdraw");
//		Scanner scanner = new Scanner(System.in);
		double num = scanner.nextDouble();
		double bal = balance - num;
		System.out.println("your amount withdrawed your final amount = " + bal);
	}
	public static void main(String[] args) {
		
		Customer customer = new Customer();
		System.out.println("welcome to OUR's Bank" + "\n" + "enter your firstName and secName"  );
		String name1 = scanner.next();
		String name2 = scanner.next();
		customer.setFirstName(name1);
		customer.setSecName(name2);
//		System.out.println(ob.getFirstName() + "" + ob.getSecName());
		System.out.println("enter your balnce and account number and interest");
		Acc ob1 = new Acc(customer, scanner.nextDouble(),scanner.nextInt(),scanner.nextFloat());
		
	}
}
