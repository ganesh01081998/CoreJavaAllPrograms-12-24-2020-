package cls_23_12_2020;

import java.util.Scanner;

public class Center {

	static int cent(int arr[],int size){
		int result = 0;
		int centerIndex = size / 2;
		if (size % 2 == 0) {
			for(int index = 0; index <= size; index++) {
				int calculate = arr[centerIndex] + arr[centerIndex + 1];
				result = calculate / 2;
			}
		}
		else {
			for(int index = 0; index <= size; index++) {
				int calculate = arr[centerIndex];
				result = calculate / 1;
			}
		}
		return result;
	}
	public static void main(String[] args) {
	
		Scanner scanner = new Scanner(System.in);
		System.out.println("entert the size of the array");
		int size = scanner.nextInt();
		int arr[] = new int[size];
		System.out.println("enter the array values");
		int index;
		for(index = 0; index < size; index++) {
			
		arr[index] = scanner.nextInt();
		}
		System.out.println("avarage value is = " +cent(arr,size));
		
	}
	
}
