package cls19_18_12_2020;

abstract public class COJ_42_Sports {


	abstract String getName(String name);
	abstract String getNumberOfTeamMembers(String name1);
}
