package cls19_18_12_2020;

import java.util.Scanner;

public class Check1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		COJ_42_Soccer ob = new COJ_42_Soccer();
		System.out.println("sport name");
		String sport = sc.next();
		System.out.println(ob.getName(sport));
		System.out.println("sport players ");
		String players = sc.next();
		System.out.println(ob.getNumberOfTeamMembers(players));
		
	}
}
