package cls19_18_12_2020;

public class COJ_42_Soccer extends COJ_42_Sports {

	private String name;
	private String name1;

	@Override
	String getName(String name) {
		
		return name;
	}

	@Override
	String getNumberOfTeamMembers(String name1) {
		
		return  "each team has" +   name1   + "players";
	}

	
	
}
