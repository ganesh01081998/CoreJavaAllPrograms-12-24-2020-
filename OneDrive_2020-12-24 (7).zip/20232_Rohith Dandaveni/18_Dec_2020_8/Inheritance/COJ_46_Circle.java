package circlee;

public class COJ_46_Circle {

	protected double radius;
	COJ_46_Circle(){
		this.radius = 0;
	}
	public COJ_46_Circle(double radius) {
		this.radius = radius;
	}
	double getArea(){
	double result = 0;
	if (radius < 0) {
		result = -1;
	}
	else {
		result = (2 * 3.14 * radius);
	}
	return result;
	}
}
