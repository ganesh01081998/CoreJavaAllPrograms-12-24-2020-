package circlee;

public class COJ_46_Cylender extends COJ_46_Circle {

	private double height;
	 
	COJ_46_Cylender(){
		this.height = 0;
	}
	COJ_46_Cylender(double radius, double height) {
		this.height = height;
		this.radius = radius;
	}
	public double getVolume() {
		double result = 0;
		if (height < 0) {
			result = -1;
		}
		else {
			result = 3.14 * (radius * radius * height);
		}
		return result;
	}
}
