package circlee;

import java.util.Scanner;

public class COJ_46_Testing {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the circle radius");
		double radius = scanner.nextDouble();
		COJ_46_Circle ob = new COJ_46_Circle(radius);
		System.out.println(ob.getArea());
		System.out.println("enter the cylender height");
		double cylender = scanner.nextDouble();
		COJ_46_Cylender ob1 = new COJ_46_Cylender(radius,cylender);
		System.out.println(ob1.getVolume());
	}
}
