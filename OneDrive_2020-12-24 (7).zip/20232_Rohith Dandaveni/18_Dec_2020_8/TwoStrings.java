package cls19_18_12_2020;

import java.util.Scanner;

public class TwoStrings {

	static void sumOfLength(String st,String st1) {
		int num = st.length();
		int num1 = st1.length();
		System.out.println("sum of two strings =  " + (num + num1));
	}
	static String larger(String st, String st1) {
		String result = "";
		for(int i = 0; i <st.length(); i++) {
			char ch = st.charAt(i);
				char ch1 = st1.charAt(i);
				if(ch == ch1) {
					result = "given Strings are same";
					break;
				}
				else {
					if ((int)ch > (int)ch1) {
						result = "yes";
						break;
					}
					else {
						result = "no";
						break;
					}
				}
			}
		
		return result;
	}
	static void change(String st,String st1){
		String givenSt = letterChange(st);
		String givenSt1 = letterChange(st1);
		System.out.println(givenSt + " " + givenSt1);
	}
	static String letterChange(String name) {
		String result = "";
		String firstLetter = name.substring(0,1);
		String firstLetter1 = firstLetter.toUpperCase();
		String remainLetters = name.substring(1,name.length());
		result = firstLetter1 + remainLetters;
		return result;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the 1st String");
		String st = scanner.next();
		System.out.println("enter the 2nd String");
		String st1 = scanner.next();
		sumOfLength(st,st1);
		System.out.println(larger(st,st1));
		change(st,st1);
	}
}
