package cls19_18_12_2020;

public class COJ_41_MyBook extends COJ_41_Book {

	@Override
	void setTitle(String title) {
		this.title = title;
		
	}

	@Override
	String getTitle() {
		// TODO Auto-generated method stub
		return title;
	}

	

	

	
}
