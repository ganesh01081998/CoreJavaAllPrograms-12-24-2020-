package cls19_18_12_2020;

abstract public class COJ_41_Book {

	public String title;
	abstract void setTitle(String title);
	abstract String  getTitle();
	
	COJ_41_Book() {
		
	}
}
