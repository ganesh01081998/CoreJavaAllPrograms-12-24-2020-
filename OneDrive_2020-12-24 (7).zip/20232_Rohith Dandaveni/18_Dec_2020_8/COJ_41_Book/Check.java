package cls19_18_12_2020;

import java.util.Scanner;

public class Check {

	public static void main(String[] args) {
		COJ_41_MyBook ob = new COJ_41_MyBook();
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the title");
		String title = scanner.nextLine();
		ob.setTitle(title);
		System.out.println("The title of my book is : " + ob.getTitle());
	}
}
