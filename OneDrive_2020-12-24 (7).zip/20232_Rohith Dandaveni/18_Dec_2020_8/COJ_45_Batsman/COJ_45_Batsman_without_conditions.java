package cls19_18_12_2020;

public class COJ_45_Batsman {

	private static String name;
	private static int runs;
	private static int matchs;
	private static float batting_avg;
	
	COJ_45_Batsman() {
		String name = null;
		int runs = 0;
		int matchs = 0;
		float batting_avg = 0.0f;
	}
	COJ_45_Batsman(String name,int runs,int matchs) {
		this.matchs = matchs;
		this.name = name;
		this.runs = runs;
	}
	
	static void computeBattingAverage(){
		batting_avg = runs / matchs ;
		System.out.println("batting_avg" + batting_avg);
	}
	static void getStatistics() {
		System.out.println("name" + name + "\n" + "runs" + runs + "\n" + "matchs" + matchs);
	}
}
