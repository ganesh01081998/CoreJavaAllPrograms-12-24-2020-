package cls19_18_12_2020;

public class COJ_45check {

	public static void main(String[] args) {
		COJ_45_Batsman ob  = new COJ_45_Batsman("sachin", 18000, 463);
		ob.computeBattingAverage();
		ob.getStatistics();
	}
}
