package cls19_18_12_2020;

public class COJ_44_MyCalculator implements COJ_44_AdvancedArithmetic {

	@Override
	public int divisorSum(int num) {
		int result = 0;
		for (int i = 1; i <= num; i++) {
			if (num % i == 0) {
				result = result + i;
			}
		}
		return result;
		
	}

	
	
	
}
