package cls19_18_12_2020;

public interface COJ_44_AdvancedArithmetic {

	abstract int divisorSum(int num);
}
