package cls19_18_12_2020;

import java.util.Scanner;

public class COJ_Checker {

	public static void main(String[] args) {
		COJ_44_MyCalculator ob = new COJ_44_MyCalculator();
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the number");
		int num = scanner.nextInt();
		System.out.println(ob.divisorSum(num));
	}
}
