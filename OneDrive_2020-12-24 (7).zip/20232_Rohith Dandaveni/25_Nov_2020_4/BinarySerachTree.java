package cls1025_nov_2020;

public class BinarySerachTree {

	public static void main(String args[]) { 
		BinarySerachTree bst = new BinarySerachTree(); 
		int array[] = { 10, 20, 48, 50, 60 };  
		int searchElement = 50; 
		int result = bst.binarySearch(array, 0, array.length-1, searchElement); 
		if (result == -1) 
			System.out.println("Element not present"); 
		else
			System.out.println("Element found at index " + result); 
	} 
	int binarySearch(int array[], int lower, int high, int search) { 
		if (high >= lower) { 
			int middel = (high + lower) / 2; 
			if (array[middel] == search) {
				return middel; 
			}
			else if (array[middel] > search) {
				return binarySearch(array, lower, middel-1, search); 
			}
			else if(array[middel] < search) {
				return binarySearch(array, middel+1, high, search); 
			}
		} 
		return -1; 
	} 
}
