package cls7;

import java.util.Arrays;
import java.util.Scanner;

public class Multiplication {

	static void mul(int arr[][],int brr[][],int row,int col) {
		int crr[][] = new int[row][col];
		int mulAry[][] = new int[row][col];
		for(int i = 0; i < row; i++) {
			System.out.println("");
			for(int j = 0; j < col; j++) {
//				mulAry[i][j] = 0;
				for(int k = 0; k < row ; k++) {
				mulAry[i][j] += arr[i][k] * brr[k][j] ;
			}
			}
		}
		for(int i1 = 0; i1 < row; i1++) {
			for(int j1 = 0; j1 < col; j1++) {
			System.out.print(mulAry[i1][j1] + " ");
		}
			System.out.println( );
	}
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the row size");
		int row = scanner.nextInt();
		System.out.println("enter the col size");
		int col = scanner.nextInt();
		int arr[][] = new int[row][col];
		int brr[][] = new int[row][col];
		System.out.println("enter the array values");
		for(int i = 0; i < row; i++) {
			for (int j = i; j < col; j++) {
				arr[i][j] = scanner.nextInt();
			}
		}
		System.out.println("enter the second array values");
		for(int i = 0; i <row; i++) {
			for(int j = 0; j < col; j++) {
				brr[i][j] = scanner.nextInt();
			}
		}
		mul(arr,brr,row,col);
	}
}
