package cls1025_nov_2020;

public class RecursiveSelectionSort {

	public static void main(String args[])  
	{ 
		int arrar[] = {45, 84, 12, 11, 0, 1}; 
		recurSelectionSort(arrar, arrar.length, 0); 
		for (int index = 0; index< arrar.length; index++) {
			System.out.print(arrar[index] + " "); 
		}
	} 
	static void recurSelectionSort(int array[], int num, int index) 
	{ 

		if (index == num) { 
			return; 
		}
		int k = minIndex(array, index, num-1); 
		if (k != index) {
			int temp = array[k]; 
			array[k] = array[index]; 
			array[index] = temp; 
		} 
		recurSelectionSort(array, num, index + 1); 
	} 
	static int minIndex(int array[], int in, int out) 
	{ 
		if (in == out) {
			return in;
			} 
		int value = minIndex(array, in + 1, out); 
		return (array[in] < array[value])? in : value; 
	} 
}
