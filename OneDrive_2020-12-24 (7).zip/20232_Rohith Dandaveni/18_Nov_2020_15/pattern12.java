package cls5;

public class pattern12 {

	static String pattern(int row ,int col) {
		String result = "";
		
		for(int i = 1; i <= row; i++) {
			for (int j = 1; j <= col; j++) {
				if(i == 1 || j == 1 || i == row || j == col) {
					result = result + "*" + " ";
				}
				else {
					result = result + " " + "  ";
				}
			}
			result = result +"\n";
		}
		return result;
	}
	public static void main(String[] args) {
		System.out.println(pattern(5,5));
	}
}
