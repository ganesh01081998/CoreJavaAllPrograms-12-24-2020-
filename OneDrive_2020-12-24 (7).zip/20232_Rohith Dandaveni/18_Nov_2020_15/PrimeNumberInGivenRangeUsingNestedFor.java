package cls5;

import java.util.Scanner;

public class PrimeNumberInGivenRangeUsingNestedFor {
	static String prime(int range1 , int range2) {
	String result = "";
	int count = 0;
	for (int i = range1; i <= range2; i++) {
		for (int j = 1; j <= i; j++) {
			if (i % j == 0) {
				count++;
			}
		}
		if (count == 2) {
			result = result + i + "is prime" + "\n";
		}
		else {
			result =  result + i + "is not prime" + "\n";
		}
		count = 0;
	}
	return result;
}
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter range from 2");
		System.out.println(prime(scanner.nextInt(),scanner.nextInt()));
	}
}
