package cls5;

import java.util.Scanner;

public class Pattern6 {

	static String pattern (int row) {
		String result = "";
		int num = 1;
		for (int i = 1; i <= 5; i++) {
			for (int j = 1; j <= i; j++) {
				result = result +num + " ";
				num++;
			}
			result = result + "\n";
		}
		return result;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the range1");
		int row = scanner.nextInt();
		System.out.println(pattern (row));
		
	}

}
