package cls5;

import java.util.Scanner;

public class Pattern5 {

	static String pattern (int row) {
		String result = "";
		for (int i = 1; i <= row; i++ ) {
			for (int j = 1; j <=i; j++) {
				result = result + i;
			}
				result = result + "\n";
		}
		return result;
	}
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the range");
		int row = scanner.nextInt();
		System.out.println(pattern (row));
	}
}
