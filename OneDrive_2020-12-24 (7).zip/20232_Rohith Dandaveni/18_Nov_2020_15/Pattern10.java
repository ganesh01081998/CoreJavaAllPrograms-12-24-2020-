package cls5;

import java.util.Scanner;

public class Pattern10 {

	static String pattern (int row ,int col) {
		String result = "";
		String star = "*";
		for (int i = 1; i <= row; i++) {
			for (int j = 1; j <= col; j++) {
				result = result + star + " ";
			}
			result = result + "\n";
		}
		return result;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the range1");
		int row = scanner.nextInt();
		System.out.println("enter the range2");
		int col = scanner.nextInt();
		System.out.println(pattern (row , col));

	}

}
