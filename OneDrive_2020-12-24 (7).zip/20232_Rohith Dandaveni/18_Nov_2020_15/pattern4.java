package cls5;

public class pattern4 {
		static String getPattern(int num1,int num2) {
			String result = "";
			for (int i = num1 ; i<= num2 ; i++) {
				for (int j = 1 ; j<= i ; j++) {
					System.out.print(j + " ");
				}
				System.out.println( );
			}
			return result;
			
		}
	public static void main(String[] args) {
		getPattern(1,5);

	}

}
