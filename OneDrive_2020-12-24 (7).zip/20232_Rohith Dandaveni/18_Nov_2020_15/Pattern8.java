package cls5;

import java.util.Scanner;

public class Pattern8 {
		static String pattern(int range1,int range2) {
			String result = "";
			int num = 1;
			for (int i = range1; i <= range2; i++) {
				for (int j = 1; j <= i; j++ ) {
					result = result + (num + " ");
					num++;
				}
					result = result + "\n";
			}
			return result;
		}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the 1st range");
		int range1 = scanner.nextInt();
		System.out.println("enter the 2nd range");
		int range2 = scanner.nextInt();
		System.out.println(pattern(range1,range2));
	}
}
