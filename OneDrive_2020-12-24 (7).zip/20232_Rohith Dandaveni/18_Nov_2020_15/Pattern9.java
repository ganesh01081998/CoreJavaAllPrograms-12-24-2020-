package cls5;

public class Pattern9 {

	static String pattern(char ch) {
		String result = "";
		for (int i = 1; i <= 5; i++) {
			for (int j = 1; j <= i; j++) {
				result = result + ch + " ";
				ch++;
			}
			result = result + "\n";
		}
		return result;
	}
	public static void main(String[] args) {
		char ch = 'A';
		System.out.println(pattern(ch));
	}

}
