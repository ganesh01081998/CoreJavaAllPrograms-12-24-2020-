package cls5;

import java.util.Scanner;

public class MultiplicationTableInGivenRange {

	static String mul(int range1 ,int range2) {
		String result = "";
		for (int i = range1; i <= range2; i++) {
			for (int j = 0; j <= 10; j++) {
				result = result + (i + "*" + j + "=" + (i * j) + "\n");
				
			}
				result = result + "\n";
		}
		return result;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the range");
		System.out.print(mul(scanner.nextInt(),scanner.nextInt()));
	}
}