package pattern;

public class Pattern13 {

	static String pattern() {
		String result = "";
		for (int i = 1; i <= 4; i++) {
			for (int j = 1; j <= (5 - i); j++) {
				result = result + "   ";
			}
			for (int k = 1; k <= (2 * i)-1; k++) {
				result = result + "*" + " " ;
			}
			result = result + "\n";
		}
		return result;
	}
	public static void main(String[] args) {
		System.out.println(pattern());
	}
}
