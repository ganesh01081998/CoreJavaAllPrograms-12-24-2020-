package cls5;

import java.util.Scanner;

public class Pattern2 {
		static String pattern (int num1, int num2) {
			String result = "";
			for (int i = 1 ; i <= num1 ; i++) {
				for (int j = num2 ; j >= 1 ; j--) {
				 result = result + j + " ";
				}
				 result = result + "\n"; 
			}
			return result;
			
		}
	public static void main(String[] args) {
		
		System.out.println(pattern(5,5));

	}

}
