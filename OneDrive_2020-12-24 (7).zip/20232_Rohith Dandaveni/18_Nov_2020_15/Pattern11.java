
package cls5;

public class Pattern11 {

	static String pattern(String star) {
		String result = "";
		for (int i = 1; i <= 5; i++) {
			for (int j = 1; j <= i; j++) {
				result = result + star + " ";
			}
			result = result + "\n";
		}
		return result;
		
	}
	public static void main(String[] args) {
		String star = "*";
		System.out.println(pattern(star));
	}
}
