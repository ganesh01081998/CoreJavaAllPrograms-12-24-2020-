package cls5;

public class pattern {

	static String pattern(int num1,int num2) {
		String result = " ";
		for (int i = 1; i <= 5; i++) {
			for (int j = 1; j <= 5; j++) {
				result = result + j + " ";
			}
			result = result +  "\n";
		}
		return result;
	}
	public static void main(String[] args) {
		System.out.println(pattern(5,5));

	}

}
