package cls17_14_12_2020;

public class DayScholar extends Student {

	public DayScholar() {
		
	}
	public static double transportFee = 10000;
	public DayScholar( int studentId,String studentName,double examFee,double transportFee) {
		this.studentId = studentId;
		this.studentName = studentName;
		this.examFee = examFee;
		this.transportFee = transportFee;
	}
 void dispDetils(int studentId,String studentName,double examFee) {
		System.out.println("Student [studentId=" + studentId + ", studentName=" + studentName + ", examFee=" + examFee + "you have to pay the exam fee and transportfee = 10000 + 100" + transportFee + "]");		
	}
static void payFee(double examFee) {
	double result = 0;
	if (examFee < 10100) {
		result = (10100 - examFee);
		System.out.println(result);
		System.out.println("you have to pay");
	}
	else if(examFee >= 10100){
		if (examFee > 10100) {
		result = (examFee - 10100);
		System.out.println( " you are paid your fee " + result +" take your balance " +  " thank you have a gud day ");
		}
		else {
		System.out.println(" you are paid your examFee & transpoetFee " + " \n " + " thank you have a gud day ");
	}
//	return result;
	
}
}
}
