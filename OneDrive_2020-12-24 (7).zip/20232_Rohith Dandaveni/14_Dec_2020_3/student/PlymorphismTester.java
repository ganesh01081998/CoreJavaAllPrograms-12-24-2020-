package cls17_14_12_2020;

public class PlymorphismTester  {
	
	public static void main(String[] args) {
		Shirt ob = new Shirt(16.5f,42,Clot.COTTEN);
//		ob.setCollarSize(16.5f);
//		ob.setLength(42);
//		System.out.println(ob);
		System.out.println(ob);
	}
	
}
