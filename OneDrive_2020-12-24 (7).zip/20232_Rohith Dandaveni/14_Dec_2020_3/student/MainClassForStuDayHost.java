package cls17_14_12_2020;

import java.util.Scanner;

public class MainClassForStuDayHost {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		
		Student ob = new Student();
		System.out.println("enter the student id");
		int id = scanner.nextInt();
		System.out.println("enter the student name");
		String name = scanner.next();
		ob.dispDetils(id, name);
		
		System.out.println("enter the student fee = 100");
		int stuFee = scanner.nextInt();
		ob.payFee(stuFee);
		
		
		DayScholar ob1 = new DayScholar();
		System.out.println("enter the student id");
		int id1 = scanner.nextInt();
		System.out.println("enter the student name");
		String name1 = scanner.next();
		ob1.dispDetils(id1, name1);
		System.out.println("enter the student fee and transportFee = 10000 + 100 = 10100");
		int stuFeeAndTrasns = scanner.nextInt();
		ob1.payFee(stuFeeAndTrasns);
		
		
		Hosteller ob2 = new Hosteller();
		System.out.println("enter the student id");
		int id2 = scanner.nextInt();
		System.out.println("enter the student name");
		String name2 = scanner.next();		
		ob2.dispDetils(id2, name2);
		System.out.println("enter the student fee and hostel fee = 20000 + 100 = 20100");
		int stuFeeAndHostel = scanner.nextInt();
		ob2.payFee(stuFeeAndHostel);
	}
}
