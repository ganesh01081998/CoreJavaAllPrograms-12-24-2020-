package cls17_14_12_2020;

enum Clot {
	COTTEN,LINEN,POLYSTER
}
public class Shirt {


	private float collarSize;
	private float length;
	Clot clot;

	Shirt(float collarSize,float length,Clot clot) {
		this.collarSize =  collarSize;
		this.length = length;
		this.clot = clot;
	}

	public String getOperation() {
        String res = "";
        switch(clot) {
        case COTTEN : 
            res = "COTTEN";
            break;
        case LINEN : 
            res = "LINEN";
            break;
        case POLYSTER : 
            res = "POLYSTER";
            break;
        }
        return res;        
    }
	
	public float getCollarSize() {
		return collarSize;
	}


	public void setCollarSize(float collarSize) {
		this.collarSize = collarSize;
	}


	public float getLength() {
		return length;
	}


	public void setLength(float length) {
		this.length = length;
	}


	@Override
	public String toString() {
		return "Shirt [collarSize=" + collarSize + ", length=" + length + ", clot=" + clot + "]";
	}

	
	
	
}
