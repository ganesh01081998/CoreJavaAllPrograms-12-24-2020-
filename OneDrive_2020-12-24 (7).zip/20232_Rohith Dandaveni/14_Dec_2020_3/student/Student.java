package cls17_14_12_2020;

public class Student {

	public static   int studentId;
	public static String studentName;
	public static double examFee = 100;
	
	public Student() {
//		System.out.println("its a Student details");
	}
	public Student(int studentId,String studentName) {
		this.studentId = studentId;
		this.studentName = studentName;
		this.examFee = examFee;
		
	}
	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentName=" + studentName + ", examFee=" + examFee + "]";
	}
	static void dispDetils(int studentId,String studentName) {
		
		System.out.println("Student [studentId=" + studentId + ", studentName=" + studentName + ", examFee=" + examFee + "]");
//		return "Student [studentId=" + studentId + ", studentName=" + studentName + ", examFee=" + examFee + "]";
		
	}
	static void payFee(double examFee) {
		double result = 0;
		if (examFee < 100) {
			result = (100 - examFee);
			System.out.println(result);
			System.out.println("you have to pay");
		}
		else if(examFee >= 100){
			if (examFee > 100) {
			result = (examFee - 100);
			System.out.println( "you are paid your fee" + result +"take your balance" +  "thank you have a gud day");
			}
			else {
			System.out.println("you are paid your examFee" + "\n" + "thank you have a gud day");
		}
//		return result;
		
	}
	}
	}
