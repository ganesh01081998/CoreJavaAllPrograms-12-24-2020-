package cls17_14_12_2020;

public class Hosteller extends Student{

	public static double hostile = 20000 ;
	public Hosteller() {
		
	}
	public Hosteller( int studentId,String studentName,double examFee,double hostile) {
		this.studentId = studentId;
		this.studentName = studentName;
		this.examFee = examFee;
		this.hostile = hostile;
	}
static void dispDetils(int studentId,String studentName,double examFee) {
		
		System.out.println("Student [studentId=" + studentId + ", studentName=" + studentName + ", examFee=" + examFee + " you have to pay the exam fee and hostel = 20000 + 100 " + hostile + "]");
		
	}
static void payFee(double examFee) {
	double result = 0;
	if (examFee < 20100) {
		result = (20100 - examFee);
		System.out.println(result);
		System.out.println("you have to pay");
	}
	else if(examFee >= 20100){
		if (examFee > 20100) {
		result = (examFee - 20100);
		System.out.println( "you are paid your fee" + result +"take your balance" +  "thank you have a gud day");
		}
		else {
		System.out.println("you are paid your examFee" + "\n" + "thank you have a gud day");
	}
//	return result;
}
}
}
