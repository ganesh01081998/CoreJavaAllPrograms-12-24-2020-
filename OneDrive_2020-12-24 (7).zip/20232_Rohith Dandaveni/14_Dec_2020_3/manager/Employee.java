package cls17_14_12_2020;

public class Employee {

	protected String name;
	protected int emplyeeId;
	protected double salary;
	public Employee() {
		
	}
	public Employee(String name,int employeeId,double salary) {
		this.emplyeeId = employeeId;
		this.name = name;
		this.salary = salary;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getEmplyeeId() {
		return emplyeeId;
	}

	public void setEmplyeeId(int emplyeeId) {
		this.emplyeeId = emplyeeId;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}
	
}
//switch (num) {
//case 1 : 
//	System.out.println("enter the name,id");
//	Manager ob = new Manager(sc.next(),sc.nextInt(),ManagerType.HR);
//	System.out.println(ob);
//	ob.setSalary(1000);
//	break;
//case 2 :
//	System.out.println("enter the name,id");
//	Manager ob1 = new Manager(sc.next(),sc.nextInt(),ManagerType.SALES);
//	System.out.println(ob1);
//	ob1.setSalary(1000);
//	break;
//
//}