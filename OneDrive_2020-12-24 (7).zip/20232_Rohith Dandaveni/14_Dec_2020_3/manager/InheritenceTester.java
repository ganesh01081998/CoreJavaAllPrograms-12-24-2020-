package cls17_14_12_2020;

import java.util.Scanner;

public class InheritenceTester {

	public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
//			System.out.println("enter the name,id,type(choose : hr / sales)");
			System.out.println("enter the num=1.for Hr or num=2.for SALES ");
			int num = sc.nextInt();
			switch (num) {
			case 1 : 
				System.out.println("enter the name,id");
				Manager ob = new Manager(sc.next(),sc.nextInt(),ManagerType.HR);
				System.out.println(ob);
				ob.setSalary(1000);
				break;
			case 2 :
				System.out.println("enter the name,id");
				Manager ob1 = new Manager(sc.next(),sc.nextInt(),ManagerType.SALES);
				System.out.println(ob1);
				ob1.setSalary(1000);
				break;
			
			}
//		Manager ob = new Manager("raj",101,ManagerType.SALES);
//		System.out.println(ob);
//		ob.setSalary(1000);
			System.out.println("enter the name,id,salary,speed,accuracy");
		Clerk ob1 = new Clerk(sc.next(),sc.nextInt(),sc.nextInt(),sc.nextInt(),sc.nextInt());
		System.out.println(ob1);
		ob1.setSalary();
	}
}
