package cls17_14_12_2020;

public class Clerk extends Employee{

	private int speed;
	private int accuracy;
	
	
	public Clerk(String name,int emplyeeId,double salary,int speed,int accuracy){
		this.name = name;
		this.emplyeeId = emplyeeId;
		this.salary = salary;
		this.speed = speed;
		this.accuracy = accuracy;
	}
	public int getSpeed() {
		return speed;
	}
	public void setSpeed(int speed) {
		this.speed = speed;
	}
	public int getAccuracy() {
		return accuracy;
	}
	public void setAccuracy(int accuracy) {
		this.accuracy = accuracy;
	}
	public void setSalary() {
		if (speed > 70 && accuracy > 80) {
			salary = salary + 1000;
			System.out.println(salary);
		}
		else {
			System.out.println(salary);
		}
	}
	@Override
	public String toString() {
		return "Clerk [name=" + name + ", emplyeeId=" + emplyeeId + ", speed" + speed + ", accuracy=" + accuracy + ", salary=" + salary + "]";
	}
	
}
