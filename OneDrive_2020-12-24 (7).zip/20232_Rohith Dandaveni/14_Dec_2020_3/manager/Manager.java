package cls17_14_12_2020;

enum ManagerType {
	HR, SALES
}


public class Manager extends Employee {

	String res = "";
	ManagerType managerType;	
	public Manager(String name,int emplyeeId,ManagerType managerType) {
		this.name = name;
		this.emplyeeId = emplyeeId;
		this.managerType = managerType;
//		,double salary
//				this.salary = 45000;
		
	}
	public void setSalary(int num) {
		
		switch(managerType) {
		case HR : 
			res = 45000 + num + "";
			System.out.println("congrats you are bonous  "+res);
			break;
		case SALES :
			res = 35000 + num + "";
			System.out.println("congrats you are bonous  " + res);
		}
		
	}
	@Override
	public String toString() {
		return "Manager [managerType=" + managerType + ", name=" + name + ", emplyeeId=" + emplyeeId +  "]";
	}
	
}
