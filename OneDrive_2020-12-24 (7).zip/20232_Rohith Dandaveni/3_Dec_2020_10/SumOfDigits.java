package cls13_12_3_2020;

import java.util.Scanner;

public class SumOfDigits {

	static int sum(int num) {
		
		int reminder = 0, rev = 0; 
		while (num > 0) {
			reminder = num % 10;
			rev = rev + reminder;
			num = num / 10;
		}
		return rev;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the number");
		int num = scanner.nextInt();
		System.out.println(sum(num));
	}
}
