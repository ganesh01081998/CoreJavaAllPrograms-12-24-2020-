package cls13_12_3_2020;

import java.util.Scanner;

import javax.swing.plaf.synth.SynthSpinnerUI;

public class StartAndEndNumbers {

	static int startAndEnd(int firstNum,int secNum,int size) {
		
		String str = "";
		int result = 0;
		int value[] = new int[size];
		for (int i = firstNum; i < secNum; i++) {
			value[i] = i ;
			System.out.println(print(value));
		}
		
		return result;
	}
	static int print(int value[]) {
		int result1 = 0;
		for(int i = 0; i <value.length; i++) {
			result1 = result1 + value[i];
		}
		return result1;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the 1st range");
		int firstNum = scanner.nextInt();
		System.out.println("enter the 2nd range");
		int secNum = scanner.nextInt();
		int size = firstNum + secNum;
		startAndEnd(firstNum,secNum,size);

	}

}
