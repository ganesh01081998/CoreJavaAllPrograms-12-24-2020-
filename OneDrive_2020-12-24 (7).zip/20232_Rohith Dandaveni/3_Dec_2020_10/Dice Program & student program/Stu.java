package cls13_12_3_2020_constructor;

import java.util.Scanner;

public class Stu {

	String sname;
	int sno;
	int marks[] = new int[5];
	
	void disp(String sname,int sno) {
		this.sname = sname;
		this.sno = sno;
		this.marks = marks;
		int sum = 0;
		int count = 0;
		System.out.println("enter the 5 sub marks");
		for(int i = 0; i < marks.length;i++) {
			Scanner scanner = new Scanner(System.in);
			
			marks[i] = scanner. nextInt();
		}
		for(int i = 0; i < marks.length; i++) {
//			if (check(marks[i]) == true) {
			if(marks[i] <35) {
				count++;
				System.out.println("please take exam again you have failed in =" + count + "sub");
//				break;
			}
			else {
				sum = sum + marks[i];
				
			}
		}
		int avg = sum / marks.length;
		
		System.out.println(" sname " + " " + sname + " " + "sno" + sno );
		System.out.println( "total" +  " " + sum);
		System.out.println( "avg" + " " + avg);
		if (avg > 75 && avg >60) {
			System.out.println("Distinction grade");
		}
		else if (avg > 60 && avg >50) {
			System.out.println("1st class");
		}
		else if (avg > 50) {
			System.out.println("2nd class");
		}
		else {
			System.out.println("3rd class");
		}
	}
	
//	private boolean check(int i) {
//		if (marks[i] < 35) {
//			return true;
//		}
//		return false;
//	}

	public static void main(String[] args) {
		Stu s = new Stu();
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the 1st stundent name");
		String name1 = scanner.next();
		System.out.println("entert the student roll number");
		int rollNumber1 = scanner.nextInt();
		s.disp(name1,rollNumber1);
		
		System.out.println("enter the 2nd stundent name");
		String name2= scanner.next();
		System.out.println("entert the student roll number");
		int rollNumber2 = scanner.nextInt();
		s.disp(name2,rollNumber2);
		
		System.out.println("enter the 3rd stundent name");
		String name3 = scanner.next();
		System.out.println("entert the student roll number");
		int rollNumber3 = scanner.nextInt();
		s.disp(name3,rollNumber3);
		
		System.out.println("enter the 4th stundent name");
		String name4 = scanner.next();
		System.out.println("entert the student roll number");
		int rollNumber4 = scanner.nextInt();
		s.disp(name4,rollNumber4);
		
		System.out.println("enter the 5th stundent name");
		String name5 = scanner.next();
		System.out.println("entert the student roll number");
		int rollNumber5 = scanner.nextInt();
		s.disp(name5,rollNumber5);
		
		
	}
}
