package cls13_12_3_2020_constructor;

import java.util.Scanner;

public class DiceGame {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		Dice d1 = new Dice();
		Dice d2 = new Dice();

		System.out.println("enter the player one name");
		Player p1 = new Player(scanner.next());
		System.out.println("enter the player two name");
		Player p2 = new Player(scanner.next());
		p1.throwDice(d1, d2);
		p2.throwDice(d1, d2);
		
		String res = "";
		if (p1.pValue > p2.pValue) {
			res = p1.pname + "player one won";
		}
		else if (p1.pValue < p2.pValue ) {
			res = p2.pname + "player two won";
		}
		else {
			res = "please try again";
		}
		System.out.println(res);
	}

}
