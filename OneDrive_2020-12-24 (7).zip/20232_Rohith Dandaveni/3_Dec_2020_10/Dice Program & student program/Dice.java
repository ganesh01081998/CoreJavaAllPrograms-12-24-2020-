package cls13_12_3_2020_constructor;

import java.util.*;

public class Dice {

	int diceValue;
	public void roll() {
		Random r = new Random();
		diceValue = r.nextInt(6) + 1;
	}
}
