package cls13_12_3_2020_constructor;

public class Player {

	String pname;
	int pValue;
//	public Player(String next) {
//		// TODO Auto-generated constructor stub
//	}
	public  Player(String pname) {
		this.pname = pname;
	}
	void throwDice(Dice d1,Dice d2) {
		d1.roll();
		d2.roll();
		pValue = d1.diceValue + d2.diceValue;
		System.out.println(pValue + " = " + d1.diceValue + " + " + d2.diceValue);
	}
}
