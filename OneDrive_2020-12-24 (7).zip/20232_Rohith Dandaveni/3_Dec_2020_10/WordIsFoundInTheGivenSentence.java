package cls13_12_3_2020;

import java.util.Scanner;

public class WordIsFoundInTheGivenSentence {

	static String found(String name,String name1) {
		String result = "your given word is not there";
		String words[] = name.split(" ");
		for(int i = 0; i <words.length; i++) {
			if (words[i].equals(name1)) {
				result = "your given word is there" + "--------->" + words[i];
			}
		}
		return result;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the string");
		String name = scanner.nextLine();
		System.out.println("enter the search word");
		String name1 = scanner.next();
//		String name = "are you feeling gud";
//		String name1 = "bad";
		System.out.println(found(name,name1));
		

	}

}
