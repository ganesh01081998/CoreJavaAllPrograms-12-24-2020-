package cls13_12_3_2020;

import java.util.Arrays;
import java.util.Scanner;

public class ShiftLeft {

	static int shift(int arr[],int brr[]) {
		int result = 0;
		
		for(int i = 0; i <arr.length; i++) {
			if (arr[i] != 10) {
				brr[i] = arr[i];
			}
			else {
				brr[i] = 0;
			}
		}
		return result;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the size");
		int size = scanner.nextInt();
		int arr[] = new int[size];
		System.out.println("enter the array values");
		for(int i = 0; i< arr.length; i++) {
			arr[i] = scanner.nextInt();
		}
		int brr[] = new int[size];
		shift(arr,brr);
		System.out.println(Arrays.toString(brr));
	}

}
