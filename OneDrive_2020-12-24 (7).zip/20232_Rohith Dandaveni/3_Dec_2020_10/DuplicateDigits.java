package cls13_12_3_2020;

import java.util.Scanner;

public class DuplicateDigits {

	static String dupli(int num) {
		String result = "";
		String name1 = "";
		int reminder = 0;
		while(num > 0) {
			reminder = num % 10;
			name1 = name1 + reminder + "";
			num = num / 10;
		}
		for (int i = 0; i < name1.length(); i++) {
			int count = 0;
			for(int j = i + 1; j < name1.length(); j++) {
				if (name1.charAt(i) == name1.charAt(j)) {
					count++;
				}
			}
			if(count == 1) {
				result = result + name1.charAt(i);
			}
		}
		return result;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the number");
		int num = scanner.nextInt();
		System.out.println(dupli(num));
	}
}
