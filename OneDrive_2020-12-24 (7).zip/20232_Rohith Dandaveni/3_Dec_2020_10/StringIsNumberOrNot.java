package cls13_12_3_2020;

public class StringIsNumberOrNot {

	static String numOrNot(String name) {
		String result = "it is String";
		for(int i = 0; i < name.length(); i++) {
			char ch = name.charAt(i);
			boolean result1 = Character.isDigit(ch);
			if (result1) {
				return "it is not a string";
			}
		}
		return result;
	}
	public static void main(String[] args) {
		String name = "aaa";
		System.out.println(numOrNot(name));

	}

}
