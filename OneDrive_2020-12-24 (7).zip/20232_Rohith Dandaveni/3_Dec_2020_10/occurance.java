package cls13_12_3_2020;

public class occurance {

	static String occur(String name){
		String result = "";
		int count = 0;
		for (int i = 0; i < name.length();i++) {
			char ch = name.charAt(i);
			if (ch == 'a') {
				count++; 
			}
		}
		result = 'a' + " " +  count + " ";
		return result;
	}
	public static void main(String[] args) {
		String name = "paramahamsa";
		System.out.println(occur(name));
	}
}
