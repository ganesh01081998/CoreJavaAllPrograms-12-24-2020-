package cls13_12_3_2020;

import java.util.Scanner;

public class EvenNumbersInArray {

	static int even(int arr[]) {
		int result = 0;
		int count = 0;
		for(int i = 0 ; i < arr.length; i++) {
			if (arr[i] % 2 == 0) {
				count++;
			}
		}
		result = count;
		return result;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the array size");
		int size = scanner.nextInt();
		int arr[] = new int[size];
		System.out.println("entet the array values");
		for (int i = 0; i < arr.length; i++) {
			arr[i] = scanner.nextInt();
		}
		System.out.println(even(arr));
	}
}
