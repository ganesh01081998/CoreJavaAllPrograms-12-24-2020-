package cls13_12_3_2020;

import java.util.Scanner;

public class CountTheNumberOfWords {
	
	static String countOfWords(String name) {
		String result = "";
		String name1 = name.replaceAll("[^a-zA-z0-9]", " ");
		int count = 0;
		String st[] = name1.split(" ");
		for(int i = 0; i <st.length; i++) {
			count++;
			
		}
		result = result + count;
		return result;
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the words");
		String name = scanner.nextLine();
//		String name = "is it good";
		System.out.println(countOfWords(name));
	}

}
