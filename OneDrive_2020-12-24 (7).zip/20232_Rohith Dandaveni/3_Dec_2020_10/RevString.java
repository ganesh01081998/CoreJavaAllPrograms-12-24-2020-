package cls13_12_3_2020;

import java.util.Scanner;

public class RevString {

	static String rev(String name ){
		String result = "";
		for (int i = name.length()-1; i >= 0; i--) {
			char ch = name.charAt(i);
			result = result + ch;
		}
		return result;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the words");
		String name = scanner.nextLine();
		System.out.println(rev(name));
	}

}
