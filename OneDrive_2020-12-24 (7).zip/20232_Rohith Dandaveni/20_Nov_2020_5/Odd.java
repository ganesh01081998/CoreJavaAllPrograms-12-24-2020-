package cls6Arrays;

import java.util.Scanner;

public class Odd {
	static String getOddCount(int odd[]) {
		String result = "";
		for (int i = 0; i < odd.length; i++) {
			if (odd[i] % 2 !=0) {
				result = result + odd[i] + " ";
				result = result + "\n";
			}
		}
		return result;
		
	}
	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		System.out.println("enter array range");
		int range = scanner.nextInt();
		int odd[] = new int[range];
		System.out.println("enter the array values");
		for (int i = 0; i < odd.length; i++) {
			odd[i] = scanner.nextInt();
		}
		System.out.println(getOddCount(odd));
	}

}
