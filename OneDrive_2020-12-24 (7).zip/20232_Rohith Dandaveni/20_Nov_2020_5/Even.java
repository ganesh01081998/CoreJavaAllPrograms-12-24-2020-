package cls6Arrays;

import java.util.Scanner;

public class Even {
static int brr[] = new int[10];

	static void getEven(int arr1[],int range) {
		int count = 0;
		for (int i = 0; i < arr1.length; i++) {
			
			if (arr1[i] % 2 == 0) {
				 count++;
				brr[i]= arr1[i];
				System.out.println(brr[i]);
			}
		}
		if(count == 0) {
			System.out.println("empty");
		}

	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the range");
		int range = scanner.nextInt();
		int arr[] = new int[range];
		int arr1[] = new int[range];
		if (arr.length != 4) {
			System.out.println("null");
		}
		else {
			System.out.println("enter the values");
			for (int i = 0; i< arr.length; i++) {
				arr[i] = scanner.nextInt();
				arr1 = arr; 
			}
		}
	      getEven(arr1,range);
	}

}
