package cls6Arrays;

import java.util.Scanner;

public class Multiple {
	static String getMultiplesArray(int givenNum,int num) {
		String result = "";
		if (givenNum < 0 && givenNum == 0) {
			result = result + "null";
		}
		else {
			for (int i = 0; i < num ; i++) {
				result = result + givenNum + "*" + i + "=" + (givenNum * i);
				result = result + "\n";
			}
		}
		return result;
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the num value");
		int givenNum = scanner.nextInt();
		System.out.println("range of array");
		int num = scanner.nextInt(); 
		System.out.println(getMultiplesArray(givenNum,num));

	}

}
