package dec_1_2020;

import java.util.Scanner;

public class StringManipulator {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the Words");
		String result  = scan.nextLine();
		System.out.println(is_RemoveVowels(result));
	}

	static String is_RemoveVowels(String result) {
		String ans ="";
		if(result.length() != 0) {
			for (int index = 0; index < result.length(); index++) {
				char ch = result.charAt(index);
				if((ch == 'A')||(ch == 'a') || (ch == 'E')||(ch == 'e')||(ch == 'I')
						||(ch == 'i')||(ch == 'O')||(ch == 'o')||(ch == 'U')||(ch == 'u')) {
					
				}
				else {
					ans +=""+ ch; 
				}
			}
		}
		else {
			ans = "Null";
		}
		return ans;
	}
}
