package dec_1_2020;
import java.util.Arrays;
import java.util.Scanner;
public class Anagram {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the First Words");
		String str1  = scan.nextLine();
		System.out.println("Enter the second Word");
		String str2  = scan.nextLine();
		char [] string1 = new char[str1.length()]; 
		char [] string2 = new char[str1.length()]; 
		if(str1.length() == str2.length()) {
	        for (int index = 0; index < str1.length(); index++) { 
	        	string1 [index] = str1.charAt(index); 
	        	string2 [index] = str2.charAt(index); 
	        }  
	        Arrays.sort(string1);
	        Arrays.sort(string2);
	        System.out.println(checker(string1, string2));
		}
		else {
			System.out.println("NULL");
		}
		
	}
	static String checker(char[] string1, char[] string2) {
		String result = "";
		for (int index = 0; index < string1.length; index++) {
			if(is_flash(string1,string2)) {
				result = "It is an ANAGRAM";
			}
			else {
				result = " It is not an ANAGRAM";
			}
		}
		return result;
	}
	static boolean is_flash(char[] string1, char[] string2) {
		for (int index = 0; index < string2.length; index++) {
			if(string1 [index] != string2[index]) {
				return false;
			}
		}
		return true;
	}
}
