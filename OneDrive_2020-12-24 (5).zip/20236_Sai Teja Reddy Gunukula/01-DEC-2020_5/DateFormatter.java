package dec_1_2020;
import java.util.Scanner;
public class DateFormatter {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the Date");
		String date = scan.nextLine().toLowerCase();
        date = date.replaceAll(",", "");
        date = date.replaceAll(" ", "");
        scan.close();
		if(date.length() == 0) {
			System.out.println("NULL");
		}
		else {
			System.out.println(Checker(date));
		}
	}
	static String Checker(String dates) {
		String date ="", month ="", year ="";
		String [] months = {"jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec"};
		String [] months1 = {"january","february","march","april","may","june","july","august","september","october","november","december"};
		for (int index = 0; index < dates.length(); index++) {
			if(index < 2) {
				date += dates.charAt(index);
			}
			else if((index > 1) && (index < dates.length()-4) ) {
				month += dates.charAt(index);
			}
			else if(index >= dates.length()-4) {
				year += dates.charAt(index);
			}
		}
		if(month.length() > 4) {
			for (int index = 0; index < months1.length; index++) {
				if(month.equals(months1[index])) {
					month = "-" + (index+1) + "-";
					break;
				}
			}
		}
		else {
			for (int index = 0; index < months.length; index++) {
				if(month.equals(months[index])) {
					month = "-" + (index+1) + "-";
					break;
				}
			}
		}
		dates = year + month + date;
		return dates;
	}
}
