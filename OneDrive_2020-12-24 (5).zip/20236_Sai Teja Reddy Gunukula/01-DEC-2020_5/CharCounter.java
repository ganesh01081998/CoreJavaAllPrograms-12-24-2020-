package dec_1_2020;

import java.util.Scanner;
public class CharCounter {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the Words");
		String result  = scan.nextLine();
		System.out.println("Enter the charatcer to search");
		String ch = scan.next();
		char toFind = ch.charAt(0);
		if(result.length() != 0) {
			System.out.println(Checker(result, toFind));
		}
		else {
			System.out.println("-1");
		}
	}
	static String Checker(String result, char toFind) {
		String str = "" + toFind;
		int count = 0;
		for (int index = 0; index < result.length(); index++) {
			String str1 = ""+result.charAt(index);
			boolean flash = equalIgnoreCase(str, str1);
			if(flash) {
				count++;
			}
		}
		if(count>0) {
			return str +" Is the repeted: " + count;
		}
		else {
			return str +" Null";
		}
	}
	static boolean equalIgnoreCase(String string1, String string2) {
		boolean retval = string2.equalsIgnoreCase(string1);
		return retval;
	}
}
