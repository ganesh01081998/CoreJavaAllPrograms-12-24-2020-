package dec_1_2020;

import java.util.Scanner;

public class FilterConsonants {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the Words");
		String words  = scan.nextLine();
		System.out.println(is_FilterConsonants(words));
	}
	static String is_FilterConsonants(String words) {
		String result ="";
		if(words.length() != 0) {
			for (int index = 0; index < words.length(); index++) {
				char ch = words.charAt(index);
				if((ch == 'A')||(ch == 'a') || (ch == 'E')||(ch == 'e')||(ch == 'I')
						||(ch == 'i')||(ch == 'O')||(ch == 'o')||(ch == 'U')||(ch == 'u')) {
					result +=""+ ch; 
				}
			}
		}
		else {
			result = "Null";
		}
		return result;
	}
}

