package javaTasks;

import java.util.Scanner;

public class SumDouble {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter Any Two Numbers : ");
		int firstNumber = scan.nextInt();
		int secondNumber = scan.nextInt();
		System.out.println(is_SumDouble(firstNumber,secondNumber));

	}
	static int is_SumDouble(int first,int second) {
		int sum = 0;
		if(first != second) {
			sum = first + second;
		}
		else if(first == second) {
			sum = (first * 2) + (second * 2);
		}
		return sum;
	}
}