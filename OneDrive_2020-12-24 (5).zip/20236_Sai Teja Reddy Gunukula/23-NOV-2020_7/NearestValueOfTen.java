package javaTasks;

import java.util.Scanner;

public class NearestValueOfTen {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any Two Numbers...");
		int firstNumber = sc.nextInt();
		int secondNumber = sc.nextInt();
		System.out.println(is_NearestValue(firstNumber,secondNumber)); 

	}
	static int is_NearestValue(int first,int second) {
		int diff = 0;
		int nearest = 10 - first;
		int near = 10 - second; 
		nearest = Math.abs(nearest);
		near = Math.abs(near);
		if(nearest < near) {
			diff = first;
		}
		else if(nearest > near) {
			diff = second;
		}
		else if(nearest == near)  {
			diff = 0;
		}
		return diff;
	}

	
}
