package javaTasks;

import java.util.Scanner;

public class NearHundred {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any Number...");
		int number = sc.nextInt();
		System.out.println(is_NearHundred(number));
	}
	static boolean is_NearHundred(int num){
		boolean show = false;
		if(num >= 90 && num <= 110 ){
			num = 100 - num;
			if(num <= 10){
				show = true;
			}
		}
		else if(num >= 190 && num <= 210){
			num = 200 - num;
			if(num <= 10){
				show = true;
			}
		}
		return show;
	}
}

