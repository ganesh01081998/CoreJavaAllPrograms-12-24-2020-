package javaTasks;

import java.util.Scanner;

public class BothInRange304050 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter two numbers");
		int firstNumber = scan.nextInt();
		int secondNumber = scan.nextInt();
		System.out.println(is_BothInRange(firstNumber, secondNumber));
	}

	static boolean is_BothInRange(int first, int second) {
		boolean show = false;
		if ((first >= 30 && first <= 40)&&(second >= 30 && second <= 40)) {
			show = true;
		}
		else if ((first >= 40 && first <= 50)&&(second >= 40 && second <= 50) ) {
			show = true;
		}
		return show;
	}
}
