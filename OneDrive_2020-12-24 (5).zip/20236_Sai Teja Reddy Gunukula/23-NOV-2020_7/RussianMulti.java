package javaTasks;
import java.util.Scanner;

public class RussianMulti {
	static int result = 0;
	public static void main(String[] args) {
		System.out.println("Enter two number");
		Scanner scan = new Scanner(System.in);
		is_RussianMult(scan.nextInt(), scan.nextInt());
		System.out.println(result);
	}

	static int is_RussianMult(int nNum1, int nNum2) {
		if(nNum1 % 2 !=0) {
			result += nNum2;
		}
		while(nNum1 > 1) {
			nNum1 = nNum1 / 2;
			nNum2 = nNum2 * 2;
			if(nNum1 % 2 != 0) {
				result += nNum2;
			}
		}
		return result;
	}
}
