package dec_2_2020;

import java.util.Scanner;

public class ArrayElementsDiagonalSum {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the row size of array");
		int row = scan.nextInt();
		System.out.println("Enter the coloum size of array");
		int coloum = scan.nextInt();
		int [][] array = new int [row][coloum];
		if(row == 3 & coloum == 3) {
			System.out.println("Enter the array elements");
			for (int rows = 0; rows < array.length; rows++) {
				for (int coloums = 0; coloums < array.length; coloums++) {
					array[rows][coloums] = scan.nextInt();
				}
			}
			displayArray(array);
			System.out.println(getDiagonalSum(array));
		}
		else {
			System.out.println("-1");
		}
	}

	static String getDiagonalSum(int[][] array) {
		int sum = 0;
		String result = "";
		for (int insert = 0; insert < array.length; insert++) {
			sum += array[insert][insert];
		}
		result = "The Sum Of Diagonal Sum: " + sum;
		return result;
	}

	static void displayArray(int[][] array) {
		for (int[] is : array) {
			for (int it : is) {
				System.out.print(it + " ");
			}
			System.out.println();
		}
		
	}
}
