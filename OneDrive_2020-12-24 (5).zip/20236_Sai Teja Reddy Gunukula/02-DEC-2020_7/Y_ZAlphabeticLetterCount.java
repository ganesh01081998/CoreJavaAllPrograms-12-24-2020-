package dec_2_2020;

import java.util.Scanner;

public class Y_ZAlphabeticLetterCount {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the word to string");
		String word = scan.nextLine();
		System.out.println(is_LetterCounr(word));
	}
	static String is_LetterCounr(String word) {
		String [] div = word.split(" ");
		String result ="";
		int count = 0;
		for (int index = 0; index < div.length; index++) {
			if((div[index].charAt(div[index].length()-1) == 'z')||
					(div[index].charAt(div[index].length()-1) == 'y')) {
				count ++;
			}
		}
		result = "The Count Of z and y In The Given String is: " + count;
		return result;
	}
}
