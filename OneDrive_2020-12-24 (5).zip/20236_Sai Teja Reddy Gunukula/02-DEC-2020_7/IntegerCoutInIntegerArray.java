package dec_2_2020;

import java.util.Scanner;

public class IntegerCoutInIntegerArray {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the size of array");
		int [] array = new int[scan.nextInt()];
		System.out.println("Enter the array elements");
		for (int index = 0; index < array.length; index++) {
			array[index] = scan.nextInt();
		}
		System.out.println("Enter the search element");
		int search = scan.nextInt();
		System.out.println(is_GetCount(array, search));
	}

	static String is_GetCount(int[] array, int search) {
		int count = 0;
		String result ="";
		for (int check = 0; check < array.length; check++) {
			if(search == array[check]) {
				count++;
			}
		}
		result = search +" is repeted in the given array of: " + count;
		return result;	
	}
}
