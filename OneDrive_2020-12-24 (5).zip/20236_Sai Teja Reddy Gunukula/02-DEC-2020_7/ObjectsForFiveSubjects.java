package dec_3_2020;

import java.util.Scanner;

public class ObjectsForFiveSubjects {
	
	public static void main(String[] args) {
	    Scanner scan = new Scanner(System.in);
	    System.out.println("enter the student details");
	    Students studentsInfo = new Students(scan.nextInt(),scan.next(),scan.nextInt(),scan.nextInt(),scan.nextInt(),scan.nextInt(),scan.nextInt());
	}
}
class Students {
	int studentId;
	String studentName;
	int studentMarks1,studentMarks2,studentMarks3,studentMarks4,studentMarks5;
	Students(int studentId, String studentName,int studentM, int studentMarks2, int studentMarks3,int studentMarks4,int studentMarks5) {
		this.studentId = studentId;
		this.studentName = studentName;
		this.studentMarks1 = studentMarks1;
		this.studentMarks2 = studentMarks2;
		this.studentMarks3 = studentMarks3;
		this.studentMarks4 = studentMarks4;
		this.studentMarks5 = studentMarks5;

		int subjectTotal = studentMarks1 + studentMarks2 + studentMarks3 + studentMarks4 + studentMarks5;
		System.out.println(subjectTotal);
		int subjectAvg = (subjectTotal / 5);
		if(subjectAvg >= 75) {
			System.out.println( "you got distinction");
		}
		else if(subjectAvg >= 65) {
			System.out.println("you got first calss");
		}
		else if(subjectAvg >= 50) {
			System.out.println( "you got second class");;
		}
		else if(subjectAvg >= 35) {
			System.out.println("You got third class");
		}
		else {
			System.out.println("failed! Try again ");
		}
	}
	String dispDetails() {
		return studentId + " " + studentName  + " " + studentMarks1 + " " + studentMarks2 + " " + studentMarks3 + " " + studentMarks4 + " " +studentMarks5;
	}
}
