package dec_2_2020;

import java.util.Scanner;

public class LastNumberIsPalindrome {
	static String result ="";
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter any number");
		int checkNumber = scan.nextInt();
		if(checkNumber > 99 && checkNumber < 1000) {
			System.out.println(checkUntilThePalindrome(checkNumber));
		}
		else {
			System.out.println("ERROR");
		}
	}
	static String checkUntilThePalindrome(int checknumber) {
		int rev, temp, sum=0,count=0;
		result += checknumber + " ";
		temp = checknumber;
		if(count < 10) {
			while (checknumber > 0) {
				rev = checknumber % 10;
				checknumber = checknumber/10;
				sum = (sum*10) + rev;
			}
			if (sum == temp) {
				result +=  "\nThe last number is the palindrome";
			}
			else {
				result += sum + " " ;
				count ++;
				checknumber = sum + temp;
				checkUntilThePalindrome(checknumber);
			}
		}
		return result;
	}
}
