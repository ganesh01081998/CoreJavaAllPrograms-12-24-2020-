package dec_2_2020;

import java.util.Scanner;

public class LargeBlockInString {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the String array");
		String word = scan.nextLine();
		if(word.length() == 0) {
			System.out.println("0");
		}
		else {
			System.out.println(maxBlock(word) + "is the largest block");
		}
	}
	static int maxBlock(String word) {
		int count , temp = 0;
		for (int index = 0; index < word.length(); index++) {
			char ch = word.charAt(index);
			count = 0;
			for (int check = 0; check < word.length(); check++) {
				if(ch == word.charAt(check)) {
					count ++;
				}
			}
			if(temp < count) {
				temp = count;
			}
		}
		return temp;
	}
}
