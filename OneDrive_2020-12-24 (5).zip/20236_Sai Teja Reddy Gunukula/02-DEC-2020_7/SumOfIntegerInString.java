package dec_2_2020;

import java.util.Scanner;

public class SumOfIntegerInString {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the String");
		String word = scan.next();
		System.out.println(NumericCountInString(word));
	}

	static String NumericCountInString(String word) {
		int sum = 0;
		String result = "";
		for (int index = 0; index < word.length(); index++) {
			char ch = word.charAt(index);
			boolean flash = Character.isDigit(ch);
			if(flash) {
				sum += Character.getNumericValue(ch);
			}
		}
		return result = sum + " :is the sum of the numeric values in the String";
		
	}
}
