package dec_10_2020;

public class Address {
	private String hNo;
	private String cityName;
	public Address (String hNo, String cityName) {
		this.hNo = hNo;
		this.cityName = cityName;
	}
	public String toString() {
		return "Address [hno=" + hNo + " cityName=" + cityName + "]";
	}
}
