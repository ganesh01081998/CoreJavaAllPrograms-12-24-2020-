package dec_10_2020;

public class Customer {
	String firstName;
	String lastName;
	public Customer(String firstName, String lastName) {
		
		this.firstName= firstName;
		this.lastName = lastName;
		
	}
	public void display() {
		System.out.println( "Customer [Name=" + firstName + lastName + "]");
	}
}
