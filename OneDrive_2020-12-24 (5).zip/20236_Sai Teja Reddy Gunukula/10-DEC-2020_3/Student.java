package dec_10_2020;

public class Student extends Address {
	private String studentName;
	private String studentBranch;
	Address address;
	public Student(String studentName, String studentBranch, String hNo, String cityName) {
		super(hNo, cityName);
		this.studentName = studentName;
		this.studentBranch = studentBranch;
	}
	@Override
	public String toString() {
		return "Student [studentName=" + studentName + ", studentBranch=" + studentBranch + ", address=" + address
				+ "]";
	}
}
