package javaTasks;
import java.util.Scanner;

public class Prime {
	static String result = "";
	public static void main(String[] args) {
		System.out.println("Enter any numbers ");
		Scanner scan = new Scanner(System.in);
		is_Prime(scan.nextInt());
		scan.close();
		System.out.println(result);
	}

	static void is_Prime(int number) {
		int flag =0;
		for (int count = 1; count <= number; count++) {
			
			if (number % count == 0) {
		        flag ++;
		      }
		}
		if (flag == 2) {
			result = number +" is a prime number";
		}
		else {

			result = number +" is not a prime number";
		}
	}
}
