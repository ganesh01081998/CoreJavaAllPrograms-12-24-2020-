package javaTasks;
import java.util.Scanner;

public class EvenNumbersInRange {
	static String result = "";
	public static void main(String[] args) {
		System.out.println("Enter numbers in range order");
		Scanner scan = new Scanner(System.in);
		is_EvenNumbers(scan.nextInt(),scan.nextInt());
		scan.close();
		System.out.println(result);
	}

	static void is_EvenNumbers(int starting, int ending) {
		while(starting <= ending) {
			if(starting % 2 == 0) {
				result = result + starting + ", ";
			}
			starting++;
		}
	}
}
