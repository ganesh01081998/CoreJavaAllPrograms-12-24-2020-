package javaTasks;

import java.util.Scanner;

public class ArmStrong {
	static String result = "";
	  public static void main(String[] args)  {  
		  Scanner scan = new Scanner(System.in);
		  System.out.println("Enter any number between 100 to 99");
		  is_ArmStrong(scan.nextInt()); 
		  System.out.println(result);
	  }

	static String is_ArmStrong(int number) {
		int sum =0, rev ;
		int temp=number;  
		  while(number>0)  
		  {  
			  rev=number%10;  
			  number=number/10;  
			  sum=sum+(rev*rev*rev);  
		  }  
		  if(temp==sum)  {
		 	  result = sum + "armstrong number";
		  }
		  else  {
			  result = sum + "Not armstrong number";
		  }
		return result;
	}
}
