package javaTasks;
import java.util.Scanner;

public class  Factorial {
	public static void main(String[] args) {
		System.out.println("Enter the any number");
		Scanner scan = new Scanner(System.in);
		getFactorial(scan.nextInt());
		scan.close();
	}

	static void getFactorial(int number) {
		int  sum = 1;
		if (number > 0) {
			while(number > 0) {
				sum = sum * number;
				--number;
			}
			System.out.println("The factorial of the given number is: "+sum);
		}
	}
}


