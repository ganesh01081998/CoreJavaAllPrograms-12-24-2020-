package javaTasks;

import java.util.Scanner;

public class OddElementsInArray {
	static String result = "";
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the size of array");
		int size = scan.nextInt();
		if(checkTheArray(size)) {
			result = "NULL";
		}
		else {
			int [] array = new int [size];
			System.out.println("Enter the array elements");
			for (int insert = 0; insert < array.length; insert++) {
				array[insert] = scan.nextInt();
			}
			evenTheArray(array);
		}
		System.out.println(result);
	}

	static String evenTheArray(int[] array) {
		int sum = 0;
		for (int count = 0; count < array.length; count++) {				
			if (array[count] % 2 !=0) {
				result += array[count] + " ";
				sum ++;
			} 
		}
		return result;
	}

	static boolean checkTheArray(int size) {
		if ((size < 10) || (size > 10)) {
			return true;
		}
		return false;
	}

}
