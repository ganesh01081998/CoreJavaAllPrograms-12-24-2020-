package javaTasks;

import java.util.Scanner;

public class SumOfArrays {
	static String result = "";
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the size of array");
		int size = scan.nextInt();
		int [] array = new int [size];
		System.out.println("Enter array elements one after another");
		for (int insert = 0; insert < array.length; insert++) {
				array[insert] = scan.nextInt();
		}
		sumOfArrays(array);
		System.out.println(result);
	}

	static String sumOfArrays(int[] array) {
		int sum = 0;
		for (int count = 0; count < array.length; count++) {
			sum += array[count];
		}
		return result += sum;
	}
}
