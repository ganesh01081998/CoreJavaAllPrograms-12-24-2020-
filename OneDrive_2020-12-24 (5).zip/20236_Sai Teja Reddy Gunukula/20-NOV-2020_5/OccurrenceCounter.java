package javaTasks;

import java.util.Scanner;

public class OccurrenceCounter {
	static String result = "";
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the size of array");	
		int [] array = new int [scan.nextInt()];
		System.out.println("Enter the array elements");
		for (int insert = 0; insert < array.length; insert++) {
			try {
				array[insert] = scan.nextInt();
			} catch (Exception e) {
				System.out.println("Input Mismatch Exception");
				System.out.println("Enter only integer elements");
				break;
			}	
		}
		int count = 0;
		getCountOfArray(array, count);	
		System.out.println(result);
	}
	static String getCountOfArray(int[] array, int count) {
		for (int check = 0; check < array.length; check++) {
			count = 0;
			for (int find = 0; find < array.length; find++) {
				if(array[check] == array[find]) {
					count++;
				}
			}
			result += array[check] +" " + count + "\n";
		}
		return result;
	}
}
