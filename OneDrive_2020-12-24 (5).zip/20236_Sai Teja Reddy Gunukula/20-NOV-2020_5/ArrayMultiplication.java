package javaTasks;

import java.util.Scanner;

public class ArrayMultiplication {
	static String result = "";
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the size of array");
		int size = scan.nextInt();
		int [] array = new int [size];
		System.out.println("Enter array elements one after another");
		for (int insert = 0; insert < array.length; insert++) {
			int num = scan.nextInt();
			if(num > 0) {
				array[insert] = scan.nextInt();
				getMultiply(array[insert]);
			}
			else {
				System.out.println("NULL");
			}
		}
		System.out.println(result);
	}

	static void getMultiply(int number) {
		for (int multiplyer = 1; multiplyer < 11; multiplyer++) {
			result += number + " * " + multiplyer + " = " + (number * multiplyer) + "\n";
		}
		result += "\n";
	}
}
