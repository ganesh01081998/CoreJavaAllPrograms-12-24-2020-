package javaTasks;

import java.util.Scanner;

public class Palindrome {
	static String result = "";
	public static void main(String[] args) {
		
		System.out.println("Enter any three degit number");
		Scanner scan = new Scanner(System.in);
		is_palindrome(scan.nextInt());
		System.out.println(result);
	}

	static String is_palindrome(int number) {
		int rev, temp, sum=0;
		temp = number;
		while (number > 0) {
			rev = number % 10;
			sum = (sum*10) + rev;
			number = number/10;
		}
		if (sum == temp) {
			result = " The given number is palindrome " + temp;
		}
		else {
			result = " The given number is not a palindrome " + temp;
		}
		return result;
	}
}
