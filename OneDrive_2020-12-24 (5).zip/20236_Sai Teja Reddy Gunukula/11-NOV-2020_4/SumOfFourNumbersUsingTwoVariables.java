package javaTasks;

public class SumOfFourNumbersUsingTwoVariables {
	public static void main(String[] args) {
		if(args.length < 4) {
			System.out.println("Enter the correct number of array elements");
		}
		else {
			int num1 = Integer.parseInt(args[0]);
			int num2 = Integer.parseInt(args[1]);
			num1 += Integer.parseInt(args[2]);
			num2 += Integer.parseInt(args[3]);
			System.out.println("Sum = " + (num1 + num2));
		}
		
	}
}
