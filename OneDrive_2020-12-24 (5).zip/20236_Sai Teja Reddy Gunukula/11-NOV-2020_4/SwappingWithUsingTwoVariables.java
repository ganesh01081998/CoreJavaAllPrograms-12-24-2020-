package javaTasks;

import java.util.Scanner;

public class SwappingWithUsingTwoVariables 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the First Variable");
		int a=sc.nextInt();
		System.out.println("Enter the second Variable");
		int b = sc.nextInt();
		sc.close();
		swapping(a, b);
	
	}
	static void swapping(int a, int b) {
		System.out.println("Befor Chanaging value of First Variable:"+a+" value of Second varable:"+b);
		a = a + b;
		b = a - b;
		a = a - b;
		System.out.println("After Chanaging value of First Variable:"+a+" value of Second varable:"+b);
	}
}
