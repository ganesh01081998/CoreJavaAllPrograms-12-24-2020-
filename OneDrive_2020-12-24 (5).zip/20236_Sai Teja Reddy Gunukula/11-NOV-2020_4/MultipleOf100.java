package javaTasks;

import java.util.Scanner;

public class MultipleOf100 {
	static int sum =0;
	public static void main(String[] args) {
		
		System.out.println("enter any number with three digits");
		Scanner scan = new Scanner(System.in);
		is_NextMultipleOf100(scan.nextInt());
		System.out.println(sum);
	}

	static int is_NextMultipleOf100(int number) {
		if(number > 0) {
			int rev = number / 100;
			sum = (rev + 1) * 100;
		}
		return sum;
	}
}
