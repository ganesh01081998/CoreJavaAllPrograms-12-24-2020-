package javaTasks;

import java.util.Scanner;

public class PrimeUsingNestedForLoop {
	static String result = "";
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the numbers to give range");
		is_printPrime(scan.nextInt(), scan.nextInt());
		System.out.println(result);
	}
	static String is_printPrime(int starting, int ending) {
		while(starting <= ending) {
			if(is_prime(starting)) {
				result += starting +" is a prime number " + "\n";
			}
			starting++;
		}
		return result;
	}
	static boolean is_prime(int starting) {
		for (int check = starting; check <= starting; check++) {
			int count = 0;
			for (int num = 1; num <= starting; num++) {
				if(check % num == 0) {
					count++;
				}
			}
			if(count == 2) {
				return true ;
			}
		}
		return false;
	}
}
