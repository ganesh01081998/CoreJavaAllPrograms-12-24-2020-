package dec_7_2020;

import java.util.Scanner;
public class SumOfTheValues {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter any three values ");
		int first = scan.nextInt();
		int second = scan.nextInt();
		int three = scan.nextInt();
		System.out.println(check(first, second, three));
	}
	static int check(int first, int second, int three) {
		int sum = 0;
		sum += fixTeen(first);
		sum += fixTeen(second);
		sum += fixTeen(three); 
		return sum;
	}
	static int fixTeen(int num) {
		if((num >= 13 && num<= 14)||(num >= 17 && num<= 19)) {
			return 0;
		}
		else {
			return num;
		}
	}
}
