package dec_7_2020;
import java.util.Scanner;
public class SumOfNumberInString {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("enter the String");
		String word = scan.next();
		System.out.println(count(word));
	}
	static int count(String word) {
		int sum = 0;
		for (int index = 0; index < word.length(); index++) {
			boolean flash = Character.isDigit(word.charAt(index));
			if(flash) {
				sum += Character.getNumericValue(word.charAt(index));
			}
		}
		return sum;
	}
}
