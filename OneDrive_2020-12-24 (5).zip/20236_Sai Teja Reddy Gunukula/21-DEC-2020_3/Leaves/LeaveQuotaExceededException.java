package dec_22_2020;

public class LeaveQuotaExceededException extends RuntimeException{
	public LeaveQuotaExceededException(String exception) {
		super(exception);
	}
}
