package dec_22_2020;

import java.util.Scanner;

public class LeavesSystem {
	int leaves;
	public LeavesSystem(int leaves) {
		this.leaves = leaves;
	}
	public void getLeaves() {
		if (leaves < 20) {
			System.out.println("Leave are successfully graduated");
		}
		else {
			throw new LeaveQuotaExceededException("Your Leaves Are Exceeded");
		}
	}
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the number of leaves you want");
		LeavesSystem lev = new LeavesSystem(scan.nextInt());
		lev.getLeaves();
	}
}
