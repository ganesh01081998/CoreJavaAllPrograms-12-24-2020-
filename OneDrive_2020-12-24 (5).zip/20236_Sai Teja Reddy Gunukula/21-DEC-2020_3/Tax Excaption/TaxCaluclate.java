package dec_22_2020;

public class TaxCaluclate {
	double tax;

	public double caluclateTax(Employee emp) {
		if (emp.name.isEmpty() || emp.name.equals(null)) {
			return tax = 1.0;
		}
		if (emp.nationality.equalsIgnoreCase("India")) {
			return tax = 2.0;
		}
		if (emp.salary > 100000) {
			tax = (emp.salary * 8) / 100;

		} 
		else if (emp.salary > 50000) {
			tax = (emp.salary * 6) / 100;

		} 
		else if (emp.salary > 30000) {
			tax = (emp.salary * 5) / 100;

		} 
		else if (emp.salary > 10000) {

			tax = (emp.salary * 4) / 100;
		}
		else {
			return tax = 3.0;
		}
		return tax;
	}
}
