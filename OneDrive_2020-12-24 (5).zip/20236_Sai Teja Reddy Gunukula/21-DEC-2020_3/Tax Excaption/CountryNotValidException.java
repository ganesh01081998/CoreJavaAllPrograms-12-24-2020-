package dec_22_2020;

public class CountryNotValidException extends Throwable {
	public CountryNotValidException(String Exception) {
		System.out.println(Exception);
	}
}
