package dec_22_2020;

public class TaxSimulator {
	public void findTaxOutput(Employee emp) throws NameNotValidException, CountryNotValidException, NotEligibleForTaxException {
		TaxCaluclate tax = new TaxCaluclate();
		double outPut = tax.caluclateTax(emp);
		if (outPut == 2.0) {
			try {
				throw new CountryNotValidException("The employee should be an Indian citizen for calculating tax");
			} catch (CountryNotValidException e) {
			}
		} else if (outPut == 1.0) {
			try {
				throw new NameNotValidException("The employee name cannot be null or empty");
			} catch (NameNotValidException e) {
			}
		} else if (outPut == 3.0) {
			try {
				throw new NotEligibleForTaxException("The employee does not need to pay tax");
			} catch (NotEligibleForTaxException e) {
			}

		} else {
			System.out.println("The tax Amount is :" + outPut);
		}
	}
}
