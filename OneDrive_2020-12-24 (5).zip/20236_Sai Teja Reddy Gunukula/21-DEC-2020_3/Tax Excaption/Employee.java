package dec_22_2020;

public class Employee extends TaxCaluclate{
	String name;
	String nationality;
	double salary;
	public Employee(String name, String nationality, double salary) {

		setName(name);
		setNationality(nationality);
		setSalary(salary);
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNationality() {
		return nationality;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
}
