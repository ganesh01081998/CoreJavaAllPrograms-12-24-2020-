package dec_22_2020;

public class NotEligibleForTaxException extends Throwable{
	public NotEligibleForTaxException(String Exception) {
		System.out.println(Exception);
	}
}
