package dec_22_2020;

import java.util.Scanner;

public class Tax {
	public static void main(String[] args) throws NameNotValidException, CountryNotValidException, NotEligibleForTaxException {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the details of Employe \n Name, Nationality and Salary");
		Employee emp = new Employee(scan.next(), scan.next(), scan.nextDouble());
		TaxSimulator ts = new TaxSimulator();
		ts.findTaxOutput(emp);
	}
	
}
