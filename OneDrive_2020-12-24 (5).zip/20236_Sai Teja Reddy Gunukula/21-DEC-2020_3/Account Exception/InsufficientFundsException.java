package dec_22_2020;

public class InsufficientFundsException  extends Exception{
	double amount;
	public InsufficientFundsException(String exception) {
		System.out.println(exception);
	}
	double getAmount() {
		return amount;
	}                                                                                        
}