package dec_18_2020;

public class Cylender_6 extends Circle_6 {

	double height;

	double volume;

	public Cylender_6() {

	}

	public Cylender_6(double radius,double height) {
		super(radius);
		this.height = height;
	}

	public double getVolume() {
		if(height < 0) {
			volume = -1;
		}
		else {
			volume = 3.14 * (radius * radius * height);
		}
		
		return volume;
	}

}
