package dec_18_2020;

import java.util.Scanner;

public class Shape_6 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter Radius And Height...");
		Cylender_6 cylender = new Cylender_6(scan.nextDouble(),scan.nextDouble());
		System.out.println("Area Of Circle : " + cylender.getArea());
		System.out.println("Volume Of Cylender : " + cylender.getVolume());
	}
}
