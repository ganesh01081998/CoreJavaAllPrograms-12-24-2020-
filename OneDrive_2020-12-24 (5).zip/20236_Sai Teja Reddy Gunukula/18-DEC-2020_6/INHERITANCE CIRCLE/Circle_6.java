package dec_18_2020;

public class  Circle_6 {

	double radius;
	double area;
	public Circle_6() {

	}
	public Circle_6(double radius) {
		super();
		this.radius = radius;
	}
	public double getArea() {

		if(radius < 0) {
			area = -1;
		}
		else {
			area = 3.14 * (radius *  radius);
		}
		return area;
	}
}