package dec_18_2020;

public interface AdvancedArithmetic_4 {
	public abstract int divisorSum(int n);
}
