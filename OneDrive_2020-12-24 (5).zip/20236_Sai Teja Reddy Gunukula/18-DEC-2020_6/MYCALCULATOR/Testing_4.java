package dec_18_2020;

import java.util.Scanner;

public class Testing_4 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		MyCalculator_4 obj = new MyCalculator_4();
		System.out.println("Enter the number");
		System.out.println(obj.divisorSum(scan.nextInt()));
	}
}
