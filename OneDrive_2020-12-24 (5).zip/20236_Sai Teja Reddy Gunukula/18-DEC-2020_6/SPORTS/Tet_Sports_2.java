package dec_18_2020;

import java.util.Scanner;

public class Tet_Sports_2 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter The Sports");
		Sports_2 sport = new  Soccer_2();
		sport.getName(scan.nextLine());
		System.out.println( sport.getNumberOfTeamMembers());
	}
}
