package dec_18_2020;

public class Sports_2 {
	
	String sports;
	public String	getName(String sports) { 
		return sports;
	}
	public 	String	getNumberOfTeamMembers() {
		return "Each team has n players in Sports";
	}
}
