package dec_18_2020;

public class Soccer_2 extends Sports_2{

	public String	getName(String sports) { 
		super.sports = sports;
		return sports;
	}
	public	String	getNumberOfTeamMembers() {
		return "In" + super.getName(sports)  + "\n Each team has 11 players";
	}
}
