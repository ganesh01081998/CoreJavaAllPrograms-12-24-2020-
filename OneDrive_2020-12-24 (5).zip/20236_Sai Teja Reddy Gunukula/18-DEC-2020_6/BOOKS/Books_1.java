package dec_18_2020;

abstract public class Books_1 {
	String Book_title;

	abstract void setTitle(String Book_title);

	public String getTitle() {
		return Book_title;
	}

}
