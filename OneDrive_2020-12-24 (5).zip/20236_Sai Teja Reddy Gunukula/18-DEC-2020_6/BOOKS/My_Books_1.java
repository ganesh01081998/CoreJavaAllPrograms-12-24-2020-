package dec_18_2020;

public class My_Books_1 extends Books_1{
	
	void setTitle(String Book_title) {
		super.Book_title = Book_title;

	}
	public String  getTitle() {
		return super.Book_title;
	}


}
