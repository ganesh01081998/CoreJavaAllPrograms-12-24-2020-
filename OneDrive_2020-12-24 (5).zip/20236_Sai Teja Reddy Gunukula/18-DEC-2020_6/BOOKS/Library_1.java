package dec_18_2020;

import java.util.Scanner;

public class Library_1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		My_Books_1 books = new My_Books_1();
		System.out.println("Enter Any Book Name : ");
		books.setTitle(sc.nextLine());
		System.out.println("The title of my book is : " + books.getTitle());

	}
}
