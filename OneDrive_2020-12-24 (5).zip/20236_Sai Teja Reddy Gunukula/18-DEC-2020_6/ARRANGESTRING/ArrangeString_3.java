package dec_18_2020;

import java.util.Scanner;

public class ArrangeString_3 {
	static String str;
	static String result;
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter Any Strings...");
		System.out.println(setArrangeString(scan.next(), scan.next()));
	}
	static String setArrangeString(String string_1,String string_2) {
		int sum_StringLength = string_1.length() + string_2.length();
		string_1 = getChange(string_1);
		string_2 = getChange(string_2);
		String result = "";
		if(Character.getNumericValue(string_1.charAt(0)) > Character.getNumericValue(string_2.charAt(0))) {
			result = (sum_StringLength) + " No " + string_2 + " " + string_1;
		}
		else {
			result = (sum_StringLength) + " Yes " + string_1 + " " + string_2;
		}
		return result;
	}
	private static String getChange(String string) {
		char [] ch = string.toCharArray();
		String result = ch[0] + "";
		result =result.toUpperCase();
		for (int index = 1; index < ch.length; index++) {
			result += ch[index] + "";
		}
		return result;
	}
}
