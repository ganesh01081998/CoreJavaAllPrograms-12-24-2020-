package dec_18_2020;

public class Batsman_5 {
	String name;
	int run;
	int matches;
	double battingavg;
	public Batsman_5() {
		
	}
	public Batsman_5(String name, int run, int matches) {
		this.name = name;
		this.run = run;
		this.matches = matches;
	}
	public double computeBattingAverage() {
		return this.battingavg = (double )(run / matches);
	}
	public String getStatistics() {
		return " Batsman_5 Statistics \n name=" + name + "\n run=" + run + "\n matches=" + matches ;
	}
}
