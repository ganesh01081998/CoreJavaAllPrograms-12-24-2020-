package javaTasks;

public class MergeSort {
	public static void main(String args[])
	{
		int arr[] = { 12, 11, 13, 5, 6, 7 };
		System.out.println("Given Array");
		printArray(arr);
		MergeSort ob = new MergeSort();
		ob.sort(arr, 0, arr.length - 1);
		System.out.println("\nSorted array");
		printArray(arr);
	}
	void merge(int arr[], int lower, int middel, int high)
	{
		int leftSize = middel - lower + 1;
		int rightSize = high - middel;
		int leftArray[] = new int[leftSize];
		int rightArray[] = new int[rightSize];
		for (int insert = 0; insert < leftSize; ++insert) {
			leftArray[insert] = arr[lower + insert];
		}
		for (int check = 0; check < rightSize; ++check) {
			rightArray[check] = arr[middel + 1 + check];
		}
		int i = 0, j = 0;
		int k = lower;
		while (i < leftSize && j < rightSize) {
			if (leftArray[i] <= rightArray[j]) {
				arr[k] = leftArray[i];
				i++;
			}
			else {
				arr[k] = rightArray[j];
				j++;
			}
			k++;
		}
		while (i < leftSize) {
			arr[k] = leftArray[i];
			i++;
			k++;
		}
		while (j < rightSize) {
			arr[k] = rightArray[j];
			j++;
			k++;
		}
	}
	void sort(int arr[], int low, int high)
	{
		if (low < high) {
			int middle = (low + high) / 2;
			sort(arr, low, middle);
			sort(arr, middle + 1, high);
			merge(arr, low, middle, high);
		}
	}
	static void printArray(int arr[])
	{
		for (int i = 0; i < arr.length; ++i) {
			System.out.print(arr[i] + " ");
		}
		System.out.println();
	}

}

