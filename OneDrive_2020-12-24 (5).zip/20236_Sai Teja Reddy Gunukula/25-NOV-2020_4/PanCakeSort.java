package javaTasks;

public class PanCakeSort {
	public static void main (String[] args) {
		int arr[] = {23, 10, 20, 11, 12, 6, 7};  
		pancakeSort(arr);
		System.out.println("Sorted Array: ");
		printArray(arr);
	}
	static int pancakeSort(int arr[]) {
		for (int curr_size = arr.length; curr_size > 1; --curr_size) {
			int mi = findMax(arr, curr_size);
			if (mi != curr_size-1) {
				flip(arr, mi);
				flip(arr, curr_size-1);
			}
		}
		return 0;
	}
	static void flip(int arr[], int i) {
		int temp, start = 0;
		while (start < i) {
			temp = arr[start];
			arr[start] = arr[i];
			arr[i] = temp;
			start++;
			i--;
		}
	}
	static int findMax(int arr[], int n) {
		int mi, i;
		for (mi = 0, i = 0; i < n; ++i) {
			if (arr[i] > arr[mi]) {
				mi = i;
			}
		}
		return mi;
	}
	static void printArray(int arr[]) {
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
		System.out.println("");
	}
}
