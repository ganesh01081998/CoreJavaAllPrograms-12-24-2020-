package javaTasks;
import java.util.Scanner;

public class MinInTheArray {
	static String result ="";
	public static void main(String[] args) {
		System.out.println("Enter the size of an array");
		Scanner scan = new Scanner(System.in);
		int size = scan.nextInt();
		if (size == 10) {
			int [] array = new int [size];
			System.out.println("Enter the elements in to the array");
			for (int insert = 0; insert < array.length; insert++) {
				try {
					array[insert] = scan.nextInt();
				} catch (Exception e) {
					result = "-1";
				}
				minInTheArray(array);
			}
		}
		else {
			result ="-1";
		}
		System.out.println(result);
	}
	static String minInTheArray(int[] array) {
		int sum = array[0];
		for (int check = 1; check < array.length; check++) {
			if(sum > array[check]) {
				sum = array[check];
			}
		}
		return result = "The Min Numbers In The Array is: "+ sum;
		
	}
}
