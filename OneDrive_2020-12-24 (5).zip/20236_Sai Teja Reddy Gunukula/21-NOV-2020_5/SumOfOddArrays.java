package javaTasks;
import java.util.Scanner;

public class SumOfOddArrays {
	static String result ="";
	public static void main(String[] args) {
		System.out.println("Enter the size of an array");
		Scanner scan = new Scanner(System.in);
		int size = scan.nextInt();
		if (size == 10) {
			int [] array = new int [size];
			System.out.println("Enter the elements in to the array");
			for (int insert = 0; insert < array.length; insert++) {
				try {
					array[insert] = scan.nextInt();
				} catch (Exception e) {
					result = "-1";
				}
			}
			sumOfOddNumber(array);
		}
		else {
			result ="-1";
		}
		System.out.println(result);
	}
	static String sumOfOddNumber(int[] array) {
		int sum = 0;
		for (int check = 0; check < array.length; check++) {
			if(array[check] % 2 != 0) {
				sum += array[check];
			}
		}
		return result = "The Sum Of The Odd Numbers is: "+ sum;	
	}
}
