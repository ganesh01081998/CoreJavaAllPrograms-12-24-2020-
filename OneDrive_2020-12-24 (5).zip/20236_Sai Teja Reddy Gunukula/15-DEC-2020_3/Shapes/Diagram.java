package dec_1_15_2020;

import java.util.Scanner;

public class Diagram {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the Shape You Want To Draw \n Circle\n Square\n Rectangle\n Enter Your Required Shape");
		switch (scan.next().toLowerCase()) {
		case "circle":
			System.out.println("Enter the radius of the Circle");
			Circle cir = new Circle();
			cir.setRadius(scan.nextDouble());
			cir.getArea();
			cir.getPerimeter();
			break;
		case "square":
			System.out.println("Enter the side of the Square");
			Square sqr = new Square();
			sqr.setSquare(scan.nextDouble());
			sqr.getArea();
			sqr.getPerimeter();
			break;
		case "rectangle":
			System.out.println("Enter the length and width of the Rectangle");
			Rectangle rec = new Rectangle();
			rec.setLength(scan.nextDouble());
			rec.setWidth(scan.nextDouble());
			rec.getArea();
			rec.getPerimeter();
			break;

		default:
			System.out.println("Enter the valid Option");
			break;
		}
	}
}
