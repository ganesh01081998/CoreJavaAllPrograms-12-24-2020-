package dec_1_15_2020;

public class Square extends Shape{
	double square;
	public double getSquare() {
		return square;
	}
	public void setSquare(double sqquare) {
		this.square = sqquare;
	}
	void getArea() {
		System.out.println("Area Of the Square = " + (getSquare() * getSquare() * getSquare() * getSquare()));
	}
	void getPerimeter() {
		System.out.println("Perimeter Of the Square = " + (getSquare() * getSquare()));
	}

}
