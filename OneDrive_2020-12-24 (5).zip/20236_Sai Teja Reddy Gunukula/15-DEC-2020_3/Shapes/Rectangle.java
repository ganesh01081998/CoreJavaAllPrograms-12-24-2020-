package dec_1_15_2020;

public class Rectangle extends Shape{
	double length;
	double width;
	public double getWidth() {
		return width;
	}
	public void setWidth(double width) {
		this.width = width;
	}

	public double getLength() {
		return length;
	}
	public void setLength(double length) {
		this.length = length;
	}
	void getArea() {
		System.out.println("Area Of the Square = " + (getLength() + getWidth()));
	}
	void getPerimeter() {
		System.out.println("Area Of the Square = " + (2 * (getLength() + getWidth())));
	}

}
