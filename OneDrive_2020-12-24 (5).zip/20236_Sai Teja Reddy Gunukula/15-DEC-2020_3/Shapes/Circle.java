package dec_1_15_2020;

public class Circle extends Shape{
	double pi = 3.14;
	double radius;
	
	public double getRadius() {
		return radius;
	}
	public void setRadius(double radius) {
		this.radius = radius;
	}
	public double getPi() {
		return pi;
	}
	void getArea() {
		System.out.println("Area Of the Circle = " + (getPi() + (getRadius() * getRadius())));
	}
	void getPerimeter() {
		System.out.println("Perimeter Of the Circle = " + (2 * (getPi() + getRadius())));
	}
}
