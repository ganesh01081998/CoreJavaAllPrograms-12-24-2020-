package dec_1_15_2020;

abstract public class Shape {
	abstract void getArea();
	abstract void getPerimeter();
}
