package dec_2_15_2020;

abstract public class Class {
	String name;
	String stdname;
	protected static int noofstudents;
	
	
	public Class(String name,String stdname) {
		this.name = name;
		this.stdname = stdname;
		
	}
	
	abstract int getPercentage();
}
