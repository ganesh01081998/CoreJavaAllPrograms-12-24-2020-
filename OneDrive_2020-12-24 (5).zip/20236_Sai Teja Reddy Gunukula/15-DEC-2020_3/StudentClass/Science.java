package dec_2_15_2020;

public class Science extends Class {
	int phyMarks;
	int chemMarks;
	int matMarks;
	public Science(String name, String stdname, int phyMarks, int chemMarks, int matMarks) {
		super(name, stdname);
		this.phyMarks = phyMarks;
		this.chemMarks = chemMarks;
		this.matMarks = matMarks;
	}
	int getPercentage() {
		int pec = 0;
		int totalMarks = 0;
		if(phyMarks<=100 && chemMarks <=100 && matMarks<=100 ) {
			 totalMarks=phyMarks+chemMarks+matMarks ;
			System.out.println("total marks"+ totalMarks);
			return pec = (totalMarks)/3;
		}
		else {
			System.out.println("give marks below 100!");
		}
		return pec;
	}
	@Override
	public String toString() {
		return "ScienceStudent [phyMarks=" + phyMarks + ", chemMarks=" + chemMarks + ", matMarks=" + matMarks + "]";
	}
}
