package dec_2_15_2020;

public class History extends Class{
	int historyMarks;
	int CivicsMarks;
	public History(String name, String stdname, int historyMarks, int civicsMarks) {
		super(name, stdname);
		this.historyMarks = historyMarks;
		this.CivicsMarks = civicsMarks;
	}
	int getPercentage() {
		int pec = 0;
		if(historyMarks<=100 && CivicsMarks <=100 ) {
			int totalMarks= historyMarks+CivicsMarks;
			System.out.println("total marks"+ totalMarks);
			return pec = (totalMarks)/2;
		}
		else {
			System.out.println("give marks below 100!");
		}
		return pec;
	}
	@Override
	public String toString() {
		return "HistoryStudent [historyMarks=" + historyMarks + ", CivicsMarks=" + CivicsMarks + "]";
	}	
}
