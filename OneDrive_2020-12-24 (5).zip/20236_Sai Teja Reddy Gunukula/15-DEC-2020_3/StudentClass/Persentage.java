package dec_2_15_2020;

import java.util.Scanner;

public class Persentage {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter type of student");
		String str = "";
		str += "1.ScienceStudent\n";
		str += "2.HistoryStudent\n";
		System.out.println(str);
		System.out.println("enter your choice");
		int ch = sc.nextInt();
		switch(ch) {
		case 1:
			System.out.println("enter student name,class,physics,chem,maths");
			Science std = new Science(sc.next(), sc.next(), sc.nextInt(), sc.nextInt(), sc.nextInt());
			System.out.println("percentage of science student is " + std.getPercentage()+"%");
			System.out.println(std);
			break;
		case 2:
			System.out.println("enter student name,class,history,civics");
			History std1 = new History(sc.next(), sc.next(), sc.nextInt(), sc.nextInt());
			System.out.println("percentage of history student is " + std1.getPercentage()+"%");
			System.out.println(std1);
			break;
		default :
			System.out.println("invalid choice");
		}


	}
}