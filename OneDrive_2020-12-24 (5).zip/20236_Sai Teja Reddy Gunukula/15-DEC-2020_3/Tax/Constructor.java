package dec_3_15_2020;

import java.util.Scanner;

public class Constructor {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		TaxUtil tax = new TaxUtil();
		System.out.println("please Select One option");
		System.out.println("1.Employee");
		System.out.println("2.Manager");
		System.out.println("3.Trainee");
		System.out.println("4.Sourcing");
		int option = sc.nextInt();
		switch (option) {
		case 1:
			System.out.println("enter your id, name, basicSalary ,drape,hraper");
			Employee employee = new Employee(sc.nextInt(), sc.next(), sc.nextDouble(), sc.nextDouble(),
					sc.nextDouble());
			double grossSalary = employee.calculateGrossSalary();
			double tax1 = tax.calculateTaxEmployee(sc, employee.calculateGrossSalary());
			System.out.println("Gross Salary will be   : " + employee.calculateGrossSalary());
			System.out.println("The tax Amount will be : " + tax1);
			System.out.println(employee);
			break;
		case 2:
			System.out.println("enter your id, name, basicSalary ,drape,hraper,project Allowance");
			Manager m = new Manager(sc.nextInt(), sc.next(), sc.nextDouble(), sc.nextDouble(), sc.nextDouble(),
					sc.nextDouble());
			double grossSalary1 = m.calculateGrossSalary();
			double tax2 = tax.calculateTaxEmployee(sc, m.calculateGrossSalary());
			System.out.println("Gross Salary will be   : " + m.calculateGrossSalary());
			System.out.println("The tax Amount will be : " + tax2);
			System.out.println(m);
			break;
		case 3:
			System.out.println(
					"enter your id, name, basicSalary ,drape,hraper,project Allowance,batchCount,perkPerBatch");
			Trainer t = new Trainer(sc.nextInt(), sc.next(), sc.nextDouble(), sc.nextDouble(), sc.nextDouble(),
					sc.nextDouble(), sc.nextInt(), sc.nextDouble());
			double grossSalary2 = t.calculateGrossSalary();
			double tax3 = tax.calculateTaxEmployee(sc, t.calculateGrossSalary());
			System.out.println("Gross Salary will be   : " + t.calculateGrossSalary());
			System.out.println("The tax Amount will be : " + tax3);
			System.out.println(t);
			break;
		case 4:
			System.out.println(
					"enter your id, name, basicSalary ,drape,hraper,project Allowance,enrollmentReached,perkPerEnrollment");
			Sourcing s = new Sourcing(sc.nextInt(), sc.next(), sc.nextDouble(), sc.nextDouble(), sc.nextDouble(),
					sc.nextInt(), sc.nextInt(), sc.nextDouble());
			double grossSalary3 = s.calculateGrossSalary();
			double tax4 = tax.calculateTaxEmployee(sc, s.calculateGrossSalary());
			System.out.println("Gross Salary will be   : " + s.calculateGrossSalary());
			System.out.println("The tax Amount will be : " + tax4);
			System.out.println(s);
			break;
		}
	}

}
