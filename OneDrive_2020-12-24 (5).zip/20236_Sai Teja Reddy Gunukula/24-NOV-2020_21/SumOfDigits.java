package javaTasks;

import java.util.Scanner;

public class SumOfDigits {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter any number");
		int number = scan.nextInt();
		System.out.println(getCounytDigit(number) + " Is the sum of the digit");
	}

	static int getCounytDigit(int number) {
		int sum =0;
		while(number>0) {
			int rev = number % 10;
			sum +=rev;
			number = number / 10;
		}
		return sum;
	}
}
