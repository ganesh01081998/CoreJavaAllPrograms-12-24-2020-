package javaTasks;

import java.util.Scanner;

public class ReverseAWordInAString {
	static String result ="";
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter any words ");
		String word = scan.next();
		getReverseString(word);
		System.out.println(result);
	}

	static void getReverseString(String word) {
		for (int disp = word.length()-1; disp >=0 ; disp--) {
			result += word.charAt(disp);
		}
	}
}
