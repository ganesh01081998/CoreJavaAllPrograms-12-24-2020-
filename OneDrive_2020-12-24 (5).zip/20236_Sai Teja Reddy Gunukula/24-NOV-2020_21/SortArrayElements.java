package javaTasks;

import java.util.Scanner;

public class SortArrayElements {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the size of array");
		int array[] = new int[scan.nextInt()];
		System.out.println("Enter the array elements");
		for (int insert = 0; insert < array.length; insert++) {
			array[insert] = scan.nextInt();
		}
		sortArray(array);
		for (int i = 0; i < array.length; i++) {
			System.out.println(array[i]);
		}
	}

	static void sortArray(int[] array) {
		for (int i = 0; i < array.length; i++) {
			for (int j = i+1; j < array.length; j++) {
				if(array[i] > array[j]) {
					int temp = array[i];
					array[i] = array[j];
					array[j] = temp;
				}
			}
		}
		
	}
}
