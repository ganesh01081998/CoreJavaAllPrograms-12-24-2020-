package javaTasks;

import java.util.Scanner;

public class ConsonantsInString {
	static String result="";
	public static void main(String[] args) {
		
			String name;
			System.out.println("Enter you name id");
			Scanner scan = new Scanner(System.in);
			name =scan.next();
			displayVowels(name.toLowerCase());
			System.out.println(result.toUpperCase());
		}
	
	static void displayVowels(String name) {
		for (int i = 0; i < name.length(); i++) {
			char ch = name.charAt(i);
            if(ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' ) 
            {
                
            }
            else {
            	result += ch + " " ;
            }
		}
		
	}
}
