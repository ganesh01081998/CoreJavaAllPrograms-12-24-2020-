package javaTasks;

import java.util.Scanner;
public class FindMax {
	static String result="";
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the size of array");
		int array[] = new int[scan.nextInt()];
		System.out.println("Enter the array elements");
		for (int insert = 0; insert < array.length; insert++) {
			array[insert] = scan.nextInt();
		}
		get_FindMax(array);
		System.out.println(result);
	}

	static String get_FindMax(int[] array) {
		if(array.length<=0) {
			result ="0";
		}
		int count = 0, temp =0; 
		for (int check = 0; check < array.length; check++) {
			if(array[check]<0) {
				count++;
			}
			if(temp < array[check]) {
				temp = array[check];
			}
		}
		if(count >= 3) {
			result = temp +" is the max number in the array";
		}
		else {
			result = "-1";
		}
		return result;
	}
}
