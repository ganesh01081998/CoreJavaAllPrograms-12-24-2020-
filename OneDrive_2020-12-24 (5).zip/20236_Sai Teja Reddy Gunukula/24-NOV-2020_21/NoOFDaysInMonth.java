package javaTasks;

import java.util.Scanner;

public class NoOFDaysInMonth {

	static String result = "";
	static String getDays(String[] month,int[] days,String str) {
		for (int i = 0; i < month.length; i++) {
			if(str.equals(month[i])) {
				result += days[i];
			}    
		}
		return result;
	}
	static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String[] month = {"jan","feb","mar","apr","may","jun","july","aug","sep","oct","nov","dec"};
		int[] days = {31,28,31,30,31,30,31,31,30,31,30,31};
		System.out.println("Enter Any Month Name");
		String monthName = sc.next().toLowerCase();
		getDays(month,days,monthName);
		System.out.println("The Month " + monthName + " has " + result);
	}
}
