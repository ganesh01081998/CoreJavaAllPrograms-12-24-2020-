package javaTasks;

import java.util.Scanner;

public class LuckyNumber {
	public static void main(String[] args) {
        int sum = 0;
        String monthName = "";
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter Your Date Of Birth : ");
        String dateOfBirth = scan.next().toLowerCase();
        dateOfBirth = dateOfBirth.replaceAll("-", "");
        dateOfBirth = dateOfBirth.replaceAll("/", "");
        String[] month = {"jan","feb","mar","apr","may","jun","july","aug","sep","oct","nov","dec"};
        for (int i = 2; i < 5; i++) {
            monthName += dateOfBirth.charAt(i);
        }
        System.out.println(monthName);
        for (int index = 0; index < month.length; index++) {
            if(monthName.equals(month[index])) {
                sum += index+1 ;
            }
        }
        for (int index = 0; index < dateOfBirth.length(); index++) {
            char ch  = dateOfBirth.charAt(index);
            if(index < 2 || index > 4) {
            sum += Character.getNumericValue(ch);
            }
        }
        while(sum > 10) {
            int rev = sum % 10;
            sum = sum / 10;
            sum = sum + rev;
        }
        System.out.println(sum);
	}
}
