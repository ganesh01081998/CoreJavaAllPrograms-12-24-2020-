package dec_14_2020;

public class DayScholar extends Student {
	
double transportFee;
	
	
	public DayScholar() {
		
	}

	public DayScholar(int studentId,String name,double examFee,double transportFee) {
		super(studentId,name,examFee);
		this.transportFee = transportFee;
	}
	
	public void payFee() {
		int total = 8000;
		if((examFee + transportFee) == total) {
			System.out.println("The Total Fee Is Paid");
		}
		else if((examFee + transportFee) < total) {
			System.out.println("The Due To Pay Amount is: " + ((examFee + transportFee) - total));
		}
		else if((examFee + transportFee) > total) {
			System.out.println("The Extra Take Amount is: " + ((examFee + transportFee) - total));
		}
	}
	
	public String dispDetails() {

		return toString();
	}

	@Override
	public String toString() {
		return "DayScholar [transportFee=" + transportFee + "]";
	}
	
	

}