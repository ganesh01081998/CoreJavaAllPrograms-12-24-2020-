package dec_14_2020;

public class Manager extends Employee{

	ManagerType mt;

	public ManagerType getMt() {
		return mt;
	}

	public void setMt(ManagerType mt) {
		this.mt = mt;
	}

	public Manager() {

	}

	public Manager(ManagerType mt) {
		super();
		this.mt = mt;
	}

	public void setSalary() {
		switch(mt) {
		case HR : 
			this.salary += 10000;
			break;

		case SALES : 
			this.salary += 5000;
			break;
		}
	}

	@Override
	public String toString() {
		return "Manager [mt=" + mt + "]";
	}

}
