package dec_14_2020;

import java.util.Scanner;

public class TestCheck {
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		Student stu = new Student();
		System.out.println("Enter the Student type\n 1. Day Scholat\n 2. Hosteller");
		switch (scan.nextInt()) {
		case 1:
			System.out.println("Enter the student Id, Student Name, Student Exam Fee, Student Transport Fee");
			DayScholar ds = new DayScholar(scan.nextInt(), scan.next(), scan.nextDouble(),scan.nextDouble());
			ds.dispDetails();
			ds.payFee();
			break;
		case 2:
			System.out.println("Enter the student Id, Student Name, Student Exam Fee, Student Transport Fee");
			Hosteller hs = new Hosteller(scan.nextInt(), scan.next(), scan.nextDouble(),scan.nextDouble());
			hs.dispDetails();
			hs.payFee();
			break;
		default:
			System.out.println("Enter The Correct Option");
			break;
		}
	}
}
