package dec_3_2020;

import java.util.Scanner;

public class VerifyIfTheStringIsNumber {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the number");
		String number = scan.next();
		System.out.println(is_VerifyTheString(number));
	}

	static String is_VerifyTheString(String number) {
		int count = 0;
		String result = "";
		for (int index = 0; index < number.length(); index++) {
			char ch = number.charAt(index);
			boolean flash = Character.isDigit(ch);
			if(flash) {
				count ++;
			}
		}
		if(count == number.length()) {
			result = "The given String contain only integer values.";
		}
		else {
			result = "The given String does not contain only integer values.";
		}
		return result;
	}
}
