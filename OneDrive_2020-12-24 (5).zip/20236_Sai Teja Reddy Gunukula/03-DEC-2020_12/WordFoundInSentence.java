package dec_3_2020;

import java.util.Scanner;

public class WordFoundInSentence {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the sentence");
		String sectence = scan.nextLine();
		System.out.println("Enter the search word");
		String word = scan.next();
		System.out.println(is_WordFoundInSentence(sectence, word));
	}

	static String is_WordFoundInSentence(String sectence, String word) {
		String [] words = sectence.split(" ");
		String result = "";
		int count = 0;
		for (int index = 0; index < words.length; index++) {
			if(word.equalsIgnoreCase(words[index])) {
				count ++;
			}
		}
		if(count > 0) {
			result = word + " Is found in the given Secntence";
		}
		else {
			result = word + " Is not found in the given Secntence";
		}
		return result;
	}
}
