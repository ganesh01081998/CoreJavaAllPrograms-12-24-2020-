package dec_3_2020;

import java.util.Scanner;

public class EvenNumbersInTheArray {
	public static void main(String[] args) {
		String result ="";
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the array Size");
		int array[] = new int [scan.nextInt()];
		System.out.println("Enter the array elements");
		for (int insert = 0; insert < array.length; insert++) {
			array[insert] = scan.nextInt();
			if(array[insert] % 2 == 0) {
				result += array[insert] + ",";
			}
		}
		System.out.println(result + "This are the EVEN number in the array given");
	}
}
