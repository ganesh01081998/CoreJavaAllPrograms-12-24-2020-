package dec_3_2020;

import java.util.Scanner;

public class ReverseOfTheWord {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the word");
		String word = scan.next();
		is_Reverse(word);
	}
	static void is_Reverse(String word) {
		char [] chara = new char[word.length()];
		for (int insert = 0; insert < chara.length; insert++) {
			chara[insert] = word.charAt(insert);
		}
		for (int index = word.length()-1; index >= 0 ; index--) {
			System.out.println(chara[index]);
		}
		
	}
}
