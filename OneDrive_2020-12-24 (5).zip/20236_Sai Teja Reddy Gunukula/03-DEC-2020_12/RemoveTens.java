package dec_3_2020;

import java.util.Scanner;

public class RemoveTens {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the size of array");
		int [] array = new int[scan.nextInt()];
		System.out.println("Enter the array elements");
		for (int insert = 0; insert < array.length; insert++) {
			array[insert] = scan.nextInt();
		}
		is_CheckForTens(array);
	}

	private static void is_CheckForTens(int[] array) {
		int num = 0;
		int array2 [] = new int [array.length];
		for (int insert = 0; insert < array.length; insert++) {
			if(array[insert] % 10 == 0) {
				array[insert] = 0;
			}
			else {
				array2[num] = array[insert];
				num++;
			}
		}
		for (int check : array2) {
			System.out.println(check);
		}
		
	}
}
