package dec_3_2020;

public class DuplicateDigits {
	public static void main(String[] args) {
		int number =625345236 ;
		System.out.println(findDuplicateDigit(number));
	}

	static String findDuplicateDigit(int number) {
		String word = number + "", result = "";
		for(int i = 0; i < word.length(); i++) {  
			for(int j = i + 1; j < word.length(); j++) {  
				if(word.charAt(i) == word.charAt(j))  {
					result += word.charAt(j);
				}
			}  
		}
		return result;  
	}
}
