package dec_3_2020;

import java.util.Scanner;

public class WordsInAGivenSentence {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the sentence");
		String sectence = scan.nextLine();
		is_WordInSentence(sectence);
	}

	static void is_WordInSentence(String sectence) {
		String [] words = sectence.split(" ");
		System.out.println("The number of words in the given sectence are: " + words.length);
	}
}
