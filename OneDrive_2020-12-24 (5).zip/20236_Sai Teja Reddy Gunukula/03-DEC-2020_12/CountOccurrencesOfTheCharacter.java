package dec_3_2020;

public class CountOccurrencesOfTheCharacter {
	public static void main(String[] args) {
		String name = "paramahamsa";
		char searchCharacter = 'a';
		is_check(name,searchCharacter);
	}

	static void is_check(String name, char searchCharacter) {
		int count = 0;
		for (int index = 0; index < name.length(); index++) {
			if(searchCharacter == name.charAt(index)) {
				count++;
			}
		}
		System.out.println(searchCharacter + " is occurred in the given word is: "+count);
	}
}

