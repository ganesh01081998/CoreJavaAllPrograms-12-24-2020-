package javaTasks;
import java.util.Scanner;

public class TwinPrime {
	static String result ="";
    public static void main(String[] args) {
    	System.out.println("Enter the range for twin prime");
    	Scanner scan = new Scanner(System.in);
        is_TwinPrime(scan.nextInt(),scan.nextInt());
        System.out.println(result);
    }
    public static void is_TwinPrime(int num1,int num2) {
         while (num1 <= num2) {        
        	 if ((is_prime(num1)) && (is_prime(num1 + 2))){
                    result = result+ (num1) + "," + ( num1 + 2) + " is TwinPrime \n";
             }
             num1++;
         }
    }
    public static boolean is_prime(int num) {
    	int count = 0;
        for (int i = 1; i <= num; i++) {
        	if (num % i == 0) {
        		count++;
            }
        }
        if (count == 2){
        	return true;
        }
        else {
        	return false;
        }   
    }
}
