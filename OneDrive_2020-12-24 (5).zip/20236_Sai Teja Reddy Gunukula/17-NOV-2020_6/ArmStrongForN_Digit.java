package javaTasks;
import java.util.Scanner;

public class ArmStrongForN_Digit {
	static int number, sum = 0, temp, remainder, digits = 0;
	static String result="";
	public static void main(String[] args){
		Scanner scan = new Scanner(System.in);
		System.out.println("Input a number to check if it's an Armstrong number");    
		get_palindrome(scan.nextInt());
		System.out.println(result);
	}
	static String get_palindrome(int number) {
		temp = number;
		while (temp > 0) {
			digits++;
			temp = temp/10;
		} 
		temp = number; 
		while (temp > 0) {
			remainder = temp % 10;
			sum = sum + power(remainder, digits);
			temp = temp/10;
		} 
		if (number == sum) {
			result += number + " is an Armstrong number.";
		}
		else {
			result += number + " isn't an Armstrong number.";
		}
		return result;
		
	}
	static int power(int rem, int digi) {
		int count = 1; 
		for (int steps = 1; steps <= digi; steps++) {
			count = count * rem;
		}
		return count;
	}
}
