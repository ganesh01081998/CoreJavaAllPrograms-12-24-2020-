package dec_4_2020;

import java.util.Scanner;

public class StudentDetails {
	public int studentId;
	public String studentName;
	private int studentMarks;
	private char studentGrade;
	StudentDetails(int studentId, String studentName,int studentMarks) {
		this.studentId = studentId;
		this.studentName = studentName;
		this.studentMarks = studentMarks;
		calculateGrade(studentMarks);
	}
	public String displayDetails() {
		String result = "";
		result = "Student [ name = " + studentName + " Student ID = " + studentId +" Student Marks = " + studentMarks + " Student Grade = " + studentGrade +" ]";
		return result;
	}
	private void calculateGrade(int studentMarks) {
		
		if(studentMarks > 90) {
			this.studentGrade = 'A';
		}
		else if(studentMarks >80 && studentMarks <= 90) {
			this.studentGrade = 'B';
		}
		else if(studentMarks >70 && studentMarks <= 80) {
			this.studentGrade = 'C';
		}
		else if(studentMarks >60 && studentMarks <= 70) {
			this.studentGrade = 'D';
		}
		else {
			this.studentGrade = 'E';
		}
		
	}
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the StudentId and StudentName and Student marks");
		StudentDetails obj = new StudentDetails(scan.nextInt(), scan.next(), scan.nextInt());
		System.out.println(obj.displayDetails());
	}
}
