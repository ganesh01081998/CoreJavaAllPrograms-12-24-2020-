package dec_1_23_2020;

import java.util.Scanner;

public class LSideIsEqualToRSide {
	public static void main(String[] args) {
		int sum = 0, sum1 = 0;
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the array size");
		int size = scan.nextInt();
		int [] array = new int[size];
		System.out.println("Enter the array elements");
		for (int insert = 0; insert < array.length; insert++) {
			array[insert]= scan.nextInt();
		}
		size /= 2;
		for (int calculate = 0; calculate < array.length; calculate++) {
			if (calculate <= size) {
				sum += array[calculate];
			}
			if (calculate >= size) {
				sum1 += array[calculate];
			}
		}
		if (sum == sum1) {
			System.out.println("true");
		}
		else {
			System.out.println("false");
		}
	}
}
