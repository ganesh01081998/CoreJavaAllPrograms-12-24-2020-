package dec_1_23_2020;

public class CharacterCount {
	public static void main(String[] args) {
		String word= "paramahamsa";
		char search = 'a';
		int count = 0;
		for (int check = 0; check < word.length(); check++) {
			if(search == word.charAt(check)) {
				count++;
			}
		}
		System.out.println("The Character " + search +" is Repeted for: "+count);
	}
}
