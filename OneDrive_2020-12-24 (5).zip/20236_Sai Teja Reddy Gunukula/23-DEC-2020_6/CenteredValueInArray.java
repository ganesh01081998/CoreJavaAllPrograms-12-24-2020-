package dec_1_23_2020;

import java.util.Scanner;

public class CenteredValueInArray {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the array size");
		int size = scan.nextInt();
		int [] array = new int[size];
		int count = 0;
		System.out.println("Enter the array elements");
		for (int insert = 0; insert < array.length; insert++) {
			size = scan.nextInt();
			if(size <= 0) {
				count++;
			}
			array[insert] = size;
		}
		if(count == 0) {
			size = array.length/2;
			System.out.println("The Centered Element is: "+array[size]);
		}
		else {
			System.out.println("The array consist Negitive or zeros -3");
		}
	}
}
