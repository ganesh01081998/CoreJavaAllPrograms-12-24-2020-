package dec_1_23_2020;

import java.util.Scanner;

public class StringManipulator {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter any words");
		String word = scan.nextLine();
		String mirror = word.toLowerCase();
		String result = "";
		for (int check = 0; check < word.length(); check++) {
			char c = mirror.charAt(check);
			if(c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
				
			}
			else {
				result += word.charAt(check);
			}
		}
		System.out.println(result);
	}
}
