package dec_1_23_2020;

import java.util.Scanner;

public class MaxOfArray {
	public static void main(String[] args) {
		int count = 0;
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the array size");
		int size = scan.nextInt();
		int [] array = new int[size];
		System.out.println("Enter the array elements");
		for (int insert = 0; insert < array.length; insert++) {
			size = scan.nextInt();
			if(size < 0) {
				count++;
			}
			array[insert] = size;
		}
		if(count >= 3) {
			System.out.println("the max value in the array "+ findMax(array));			
		}
		else {
			System.out.println("The array consist Negitive or zeros -3");
		}
	}

	static int findMax(int[] array) {
		int max = array[0];
		for (int check = 1; check < array.length; check++) {
			if(max < array[check]) {
				max = array[check];
			}
		}
		return max;
		
	}
}
