package dec_1_23_2020;

import java.util.Scanner;

public class MirrorImage {
	public static void main(String[] args) {
		int count = 0;
		String mirror ="";
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the string in form of mirror");
		String word = scan.next();
		int size = word.length() - 1;
		while(count < word.length()) {
			if(word.charAt(count) == word.charAt(size)) {
				mirror +=word.charAt(count);
			}
			else {
				break;
			}
			count++;
			size--;
		}
		System.out.println(mirror);
	}
}
