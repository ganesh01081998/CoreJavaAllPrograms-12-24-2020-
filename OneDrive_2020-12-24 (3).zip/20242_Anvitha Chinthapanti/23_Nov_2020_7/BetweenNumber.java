package anvi;

import java.util.Scanner;

public class BetweenNumber {

static boolean betweenNumberOrNot(int num1 , int num2) {
	boolean b = false ;

	if( num1 >= 30 && num1 <= 40 && num2 >= 30 && num2 <= 40 ){
		b = true;
	}
	else if(num1 >= 41 && num1 <= 50 && num2 >= 41 && num2 <= 50){
		b= true;
	}
	return b ;
}
public static void main(String[] args) {
	Scanner scr = new Scanner(System.in);
	System.out.println("enter two  numbers");
	int num1 = scr.nextInt();
	int num2 = scr.nextInt();
	System.out.println(betweenNumberOrNot(num1 , num2));
}

}
