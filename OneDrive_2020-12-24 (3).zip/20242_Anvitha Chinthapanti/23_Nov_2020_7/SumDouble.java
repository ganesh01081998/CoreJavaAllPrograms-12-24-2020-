package demo;

import java.util.Scanner;

public class SumDouble {
static void isSumDouble(int num1,int num2) {
		int sum = 0;
		if(num1 != num2) {
		 sum = num1 +num2; 
		}
		else if(num1 == num2) {
			sum = (num1 * 2) + (num2 * 2);
		}
		System.out.println(sum);
		
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter two values");
		int num1 = sc.nextInt();
		int num2 = sc.nextInt();
       isSumDouble(num1, num2);
	}

}



