package demo;

import java.util.Scanner;

public class Near {

	static int isNegative(int num) {
		if (num < 0) {
			num += Math.abs(num);

		}
		else {
			num += num;
		}
		nearTO100Or200(num);
		return num;
	}

	static boolean  nearTO100Or200(int num) {
		boolean b = false;

		if(100 - num <= 10 && 100 - num >=0){
			b =true ;
		}
		else if(200 - num <= 10 && 200 - num >= 0 ) {
			b = true;
		}


		return b ;
	}

public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		System.out.println("enter a number");
		int num = scr.nextInt();
		System.out.println(nearTO100Or200(num));

	}

}
