package demo;

import java.util.Scanner;

public class MultipleHundredCommandline {
	static void isMultiof100(int num) {
	        int rem,quo,result;
	        if(num > 1) {
	        quo = num / 100;
	        result = (quo + 1) * 100;
	        System.out.println("multi of given number :"+result);
	        } 
	        else if(num < 0 || num == 0){
	            System.out.println(-1);
	        }
	    }
	public static void main(String  []args) {
	    Scanner sc = new Scanner(System.in);
	    System.out.println("enter the number :");
	    isMultiof100(sc.nextInt());
	}
	}

