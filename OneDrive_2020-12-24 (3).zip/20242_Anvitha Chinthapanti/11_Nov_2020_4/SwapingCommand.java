package demo;

public class SwapingCommand {

	static void swappingCommandline(int num1 ,int num2) {
		 num1 = num1 + num2 ;
		 num2 = num1 - num2 ;
		 num1 = num1 - num2 ;
		 System.out.println("after Swapping "+ num1 + " " + num2);
	 }
	public static void main(String[] args) {
		int num1 = Integer.parseInt(args[0]);
		int num2 = Integer.parseInt(args[1]);
		System.out.println("before Swapping" + num1 + " " + num2);
		swappingCommandline(num1,num2);
	}



	}


