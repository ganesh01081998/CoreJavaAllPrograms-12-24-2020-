package demo;

public class AddSumCommand extends Vowels {

static String add(int add, int num) {
	 String res = "";
	 add = add + num;
	 add += num;
	 add += num;
	 add += num;
	return res += add; 
 }
 public static void main(String[] args) {
	int sum = Integer.parseInt(args[0]);
	int num = Integer.parseInt(args[1]);
	System.out.println(add(sum,num));
}
}
