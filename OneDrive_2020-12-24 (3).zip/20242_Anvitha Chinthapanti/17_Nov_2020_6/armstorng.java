package anvi;

public class armstorng {
	static void armstrongNumber(int num) {

	//public static void main(String[] args) {
		
		int temp = num;
		int r,sum = 0;
		//for(int i = num; i <= num; i++) {
		while(num>0)
		{
			r = num %10;
			num = num/10;
			sum = sum+(r*r*r);

		}

		if (temp==sum){
		System.out.println("it is armstrong number"); }
		else 
			System.out.println("it is not an armstrong"); 
		}
	
		public static void main(String[] args) {
			armstrongNumber(153);
	}
}
