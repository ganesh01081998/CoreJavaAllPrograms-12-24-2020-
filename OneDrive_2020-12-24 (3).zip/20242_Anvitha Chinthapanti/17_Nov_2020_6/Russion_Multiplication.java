package anvi;

    public class Russion_Multiplication {
	static void russionMulti(int num1,int num2){
	int sum = 0;
	while(num1 > 0){
	if(num1%2!=0){
	sum = sum + num2;
	num1 = num1/2;
	num2 =num2*2;
	}
	else{
	num1 = num1/2;
	num2 =num2*2;
	}
	}
	System.out.println(sum);
	}
    public static void main(String[] args) {
	russionMulti(11,7);
	}
    }
