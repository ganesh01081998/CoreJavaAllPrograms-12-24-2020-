package anvi;
import java.util.Scanner;


public class Twinprime {

	static boolean prime(int num) {
		boolean b = true;
		for(int i = 2 ; i <= num / 2 ; i++) {
			if(num % i == 0) {
				b = false ;
				break;
			}
		}
		return b;
	}
	static void range() {
		for(int i = 2 ; i <= 100 ; i++) {
			if(prime(i) && prime(i+2)) {
				System.out.println(i+","+(i+2));

			}
		}
	}
	public static void main(String[] args) {
		System.out.println("Twin primes are:");
		range();
	}

}