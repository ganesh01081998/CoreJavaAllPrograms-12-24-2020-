package anvi;

import java.util.Scanner;

public class FibonacciPolindrom {
	static String isFibonacci(int firstNum, int secNum,int range) {
		String res = "";
		for(int i=0;i <= range;i++) {
			int sum = firstNum + secNum;
			firstNum = secNum;
			secNum = sum;
			if(isPalindrome(sum)){
				res += sum + " " ;
			}
		}
		return res;

	}
	static boolean isPalindrome(int num) {
		boolean f = false;
		int rev = 0, temp = 0, tempnum =num;
		while(num > 0) {
			temp = num % 10;
			rev = rev * 10 + temp;
			num = num / 10;
		}
		if(tempnum == rev) {
			f = true;
		}
		return f;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter numbers");
		System.out.println(isFibonacci(sc.nextInt(),sc.nextInt(),sc.nextInt()));
	}
}

