package anvi;

import java.util.Scanner;

public class CollatzSequence {
	static String collatzSequence(int num) {
		String result = "";
		while(num>1) {
			if(num%2==0) {
				num=num/2;}
			else {
				num=(num*3)+1;
				}
				result +=num+" ";
			}
		
		return result;
	}	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the value");
		int num=sc.nextInt();
		System.out.println(collatzSequence(num));
	}

}
