package demo;
import java.util.Scanner;

public class BinarySearch {

	public static void getSearch(int arr[] , int searchNum) {
		int lowerIndex = 0;
		int higherIndex = arr.length - 1;
		int mid = (lowerIndex + higherIndex) / 2;

		while(lowerIndex <= higherIndex) {

			if ( arr[mid] < searchNum ){  
				lowerIndex = mid + 1;     
			}

			else if ( arr[mid] == searchNum ){  
				System.out.println("Element is found at index: " + mid);  
				break;  
			}

			else{  
				higherIndex = mid - 1;  
			} 
			mid = (lowerIndex + higherIndex) / 2;
		}

		if ( lowerIndex > higherIndex ){  
			System.out.println("Element is not found!");  
		} 
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter size");
		int size = scanner.nextInt();
		System.out.println("enter elements");
		int arr[] = new int[size];
		for(int i = 0 ;i < arr.length; i++) {
			arr[i] = scanner.nextInt();            
		}
		System.out.println("enter search number");
		int search = scanner.nextInt();
		getSearch(arr, search);
	}
}


