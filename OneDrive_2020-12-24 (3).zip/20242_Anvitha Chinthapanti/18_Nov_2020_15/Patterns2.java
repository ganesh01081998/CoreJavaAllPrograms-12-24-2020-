package anvi;

import java.util.Scanner;

public class Patterns2 {
	static String getPatterns() {
		String result = "";
		for(int i = 5; i>=1; i-- ) {
			for(int j = 5; j>=1; j--) {
				result += j+ " ";
			}
			result+= " \n";	
			}
		return result;
	}

public static void main(String args[]) {
	Scanner sc = new Scanner(System.in);
	System.out.println(getPatterns());
	
}
	
}