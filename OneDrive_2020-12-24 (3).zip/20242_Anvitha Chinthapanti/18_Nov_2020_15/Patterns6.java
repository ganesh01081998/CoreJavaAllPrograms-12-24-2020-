package anvi;
 import java.util.Scanner;
public class Patterns6 {
		static String getPatterns() {
			String result = "";
			int num = 1;
			for(int i=1; i<=5; i++ ) {
			for(int j =1 ;j<=i;j++) {
				result += num+"";
				num = num + 1;
			}
			result += " \n";
			}
			return result;
		}
		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			System.out.println(getPatterns());
		}

		}



	


