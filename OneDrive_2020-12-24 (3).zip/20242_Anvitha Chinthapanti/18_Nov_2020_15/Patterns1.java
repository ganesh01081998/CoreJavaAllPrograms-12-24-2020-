package anvi;

import java.util.Scanner;

public class Patterns1 {
	static String getPatterns(int num1, int num2) {
		String result = "";
		 for(int i = 1; i<=5; i++) {
			 for(int j = 1; j<=5; j++) {
				 result += j+ " ";
				 
			 }
			 result += "\n";
		 }
		 return result;
		
	}

	public static void main(String[] args) {
		System.out.println(getPatterns(5,5));

	}

}
