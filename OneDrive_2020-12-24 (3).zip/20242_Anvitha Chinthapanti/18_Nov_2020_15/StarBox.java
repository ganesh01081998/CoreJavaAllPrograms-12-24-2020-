package anvi;

public class StarBox {
	static String getStarBox() {
		String result = "";
		int n = 5;
		for(int i =1; i<=n ; i++) {
			for(int j =1; j<=n; j++) {
				if((j==1)||(j==n)||(i==1)||(i==n)) {
					result +="*";}
					else {
				
				result +=" ";
					}
				}
			result +="\n";
			}
		return result;
			}
		public static void main(String[] args) {
		System.out.print(getStarBox());
		

	}

}
