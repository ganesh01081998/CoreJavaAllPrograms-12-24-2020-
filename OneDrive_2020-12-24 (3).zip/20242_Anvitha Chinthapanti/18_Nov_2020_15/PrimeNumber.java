package anvi;

import java.util.Scanner;

public class PrimeNumber {
	static String getPrimeNumbers(int num1, int num2) {
		String result = "";
        int flag = 0;
		for(int i = num1; i <= num2; i++) {
			for(int j = num1; j <= num2; j++) {
				if(i%j==0) {
				flag++;
				}
			}
		
		if(flag==2) {
			result += i+ " ";
		}
		flag=0;
		}
		return result;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the value");
		
		System.out.println(getPrimeNumbers(sc.nextInt(),sc.nextInt()));

	}

}
