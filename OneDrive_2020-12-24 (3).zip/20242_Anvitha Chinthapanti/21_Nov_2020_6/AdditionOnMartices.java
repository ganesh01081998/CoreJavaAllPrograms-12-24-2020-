package demo;

import java.util.Scanner;

public class AdditionOnMartices {
public static void getSum(int array[][], int array1[][], int rows, int columns) {
		int sumAry[][] = new int[rows][columns];
		for (int i = 0; i < rows; i++) {
			System.out.println("");
			for (int j = 0; j < columns; j++) {
				sumAry[i][j] = array[i][j] + array1[i][j];
			}
		}
		System.out.println("sum of two matrices");
		for (int i = 0; i < rows; i++) {
			System.out.println("");
			for (int j = 0; j < columns; j++) {
				System.out.print(sumAry[i][j] + " ");
			}
		}

	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter no of rows in array");
		int rows = sc.nextInt();
		System.out.println("enter no of columns in array");
		int columns = sc.nextInt();
		System.out.println("enter first array elements");
		int array[][] = new int[rows][columns];
		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array.length; j++) {
				array[i][j] = sc.nextInt();
			}
		}
		
		System.out.println("enter second array elements");
		int array1[][] = new int[rows][columns];
		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array.length; j++) {
				array1[i][j] = sc.nextInt();
			}
		}

		getSum(array, array1, rows, columns);
	}


	}


