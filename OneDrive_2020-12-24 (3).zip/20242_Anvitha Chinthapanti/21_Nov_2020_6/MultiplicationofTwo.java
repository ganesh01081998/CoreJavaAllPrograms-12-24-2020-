package demo;

import java.util.Scanner;

public class MultiplicationofTwo {

	static void getAddition(int arr1[][], int arr2[][],int rows,int cols) {
		int add[][] = new int[rows][cols];
		for(int i = 0;i < rows;i++) {
			for(int j = 0;j < cols;j++) {
				add[i][j] = arr1[i][j] * arr2[i][j];
			}
		}
		System.out.println("sum of two matrices");
		for(int i = 0;i < rows;i++) {
			System.out.println(" ");
			for(int j = 0;j < cols;j++) {
				System.out.print(add[i][j] + " ");
			}
		}
	}
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("enter row size");
		int rows = scn.nextInt();
		System.out.println("enter the column size");
		int cols = scn.nextInt();
		System.out.println("enter the first array elements");
		int arr1[][] = new int[rows][cols];
		for(int i = 0;i < rows;i++) {
			for(int j = 0;j < cols;j++){
				arr1[i][j] = scn.nextInt();
			}
		}
		System.out.println("enter the second array elements");
		int arr2[][] = new int[rows][cols];
		for(int i = 0;i < rows;i++) {
			for(int j = 0;j < cols;j++)	{
				arr2[i][j] = scn.nextInt();
			}
		}
		getAddition(arr1,arr2,rows,cols);


	}

}


