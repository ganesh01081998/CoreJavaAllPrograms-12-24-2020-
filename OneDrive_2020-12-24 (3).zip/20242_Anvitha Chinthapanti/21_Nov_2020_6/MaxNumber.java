package demo;

import java.util.Scanner;

public class MaxNumber {
	static int max;
	static Scanner sc = new Scanner(System.in);

	static int getMax(int size) {


		int[] arr = new int[size];

		System.out.println("Enter Array Elements");
		for (int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		max = arr[0];
		for (int i = 0; i < arr.length; i++) {
			if(arr[i] > max) {
				max = arr[i];
			}
		}

		return max;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Array Size");
		int size = sc.nextInt();
		if(size != 10) {
			System.out.println(-1);
		}
		else {
			System.out.println("Max Element is : " + getMax(size));
		}
	}

}



