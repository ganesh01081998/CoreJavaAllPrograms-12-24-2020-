package anvi;

public class BigNum {
	static void bigNumInArray(int array[]){
		int big = array[0];
		for(int i = 0 ; i < array.length ; i++) {
			if (array[i] > big) {
				big = array[i];
			}
		}
		System.out.println(big);
	}

	public static void main(String[] args) {
		int array[]={1,2,3,4,5,6,-1,-6,-7} ;
		for (int i=0 ; i < array.length; i++) {
			
			System.out.println(array[i]);
		}
		bigNumInArray(array);
	}

}
