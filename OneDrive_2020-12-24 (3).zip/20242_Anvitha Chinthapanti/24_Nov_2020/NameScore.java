package demo;

import java.util.Scanner;

public class NameScore {

static int nameScore(String str) {
		int result = 0;
		for(int i=0 ; i < str.length() ; i++){
			boolean b;
			char ch = str.charAt(i);
			b = Character.isUpperCase(ch);
			if(b == true){
				result += ch-64;
			}
			else {
				result += ch - 96;
			}
		}
		return result;
	}

	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		System.out.println("Enter a String ");
		String str = scr.next();
		System.out.println(nameScore(str));
	}

}
