package anvi;

import java.util.Scanner;

public class Months {


static int monthDays(String str){
			int result = 0;
			String month[] = {"jan","feb","mar","apr","may","jun","jul","aug","sep","act","nov","dec"} ;
			int days[] ={31,28,31,30,31,30,31,31,30,31,30,31};
			for(int i =0 ; i < month.length;i++){
				if(str.equals(month[i])) {
					result = days[i];
				}
			}
			return result;
		}
	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		System.out.println("enter a String");
		String str = scr.next();
			str =str.toLowerCase();
			System.out.println(monthDays(str));

	}

}