package anvi;
import java.util.Scanner;

public class SortArray {

	static int[] sortElementArray(int array[]) {
		int arr[] = new int[array.length];
		for (int i = 0; i < array.length; i++) {
			for (int j = i + 1; j < array.length; j++) {
				if (array[i] > array[j]) {
					int temp = array[i];
					array[i] = array[j];
					array[j] = temp;
				}
			}

		}
		return arr;
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter size");
		int size = scanner.nextInt();
		System.out.println("enter elements");
		int array[] = new int[size];
		for (int i = 0; i < array.length; i++) {
			array[i] = scanner.nextInt();
		}
		int res[] = sortElementArray(array);
		for (int x : res) {
			System.out.println(x);
		}
	}
}