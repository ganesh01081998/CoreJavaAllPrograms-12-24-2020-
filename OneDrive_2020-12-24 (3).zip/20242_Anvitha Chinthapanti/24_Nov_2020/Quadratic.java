package anvi;

public class Quadratic {



static int quadrtic(int num) {
		int num1 = 1;
		int num2 = 2;
		
		for (int i = 1; i < num; i++) {
			num1 = num1 + num2;
			num2++;
		}
		return num1;
	}
public static void main(String[] args) {
	int num = 5;
	System.out.println(quadrtic(num));
}
}
