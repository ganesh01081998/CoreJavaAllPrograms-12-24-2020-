package demo;

import java.util.Scanner;

public class Vowels {
	static String vowelInString(String str) {
		String result = " ";

		int len = str.length();

		for (int i=0 ; i < len ; i++){
			char ch = str.charAt(i);
			if(ch == 'a' ||ch == 'e' ||ch == 'i'||ch == 'o'||ch == 'u'){
				result += ch ;
			}
		}
		return result ;
	}
	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		System.out.println("enter String =");
		String str = scr.next();
		System.out.println(vowelInString(str));
	}

}
