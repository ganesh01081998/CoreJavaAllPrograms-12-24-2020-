package demo;

import java.util.Scanner;

public class DoubleNumber {
	static String concateSumOfDigits( String doublevalue, int indexvalue) {
		int leftsum = 0;
		int rightsum = 0;
		for(int i = 0;i < doublevalue.length();i++) {
			if(i < indexvalue) {
				leftsum += Character.getNumericValue(doublevalue.charAt(i));
			}
			else  if (i > indexvalue){
				rightsum += Character.getNumericValue(doublevalue.charAt(i));
				
			}
		}
		String leftsum1 = Integer.toString(leftsum);
		String rightsum1 = Integer.toString(rightsum);
		String str = leftsum +":" + rightsum;
		return str;
	}
		
	

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in) ;
		System.out.println("enter the number");
		double number = sc.nextDouble();
		String doublenum = Double.toString(number) ;
		int indexvalue = doublenum.indexOf(".") ;
		String doublesum = concateSumOfDigits(doublenum,indexvalue);
		System.out.println(doublesum);
		
		

	}

}
