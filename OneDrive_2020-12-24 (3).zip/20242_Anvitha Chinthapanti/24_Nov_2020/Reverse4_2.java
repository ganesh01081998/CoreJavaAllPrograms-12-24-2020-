package demo;

public class Reverse4_2 {
	 static String getReversed(String name) {
		 StringBuffer sb = new StringBuffer(name) ;
		 return sb.reverse().toString();
		  }
	 public static void main(String[] args) {
		String str = "java";
		System.out.println(getReversed(str));
	}

}
