package demo;


import java.util.Scanner;

public class SumOfEvenArray {
	static int result = 0,temp = 0,count = 0;
	static int sumOfEvenNumbers(int array[]) {
		for(int i = 0;i<array.length;i++) {
			if(array[i]==0) {
				count++;
			}
		}
		for(int j = 0;j<array.length;j++) {
			if(array[j] < 0) {
				temp++;
			}
		}
		for(int i = 0;i<array.length;i++ ) {
			if(count > 0) {
				return -3;
			}
			else 
				if(temp > 0) {
					return -2;
				}
				else 
					if(array[i] <=0) {
						return -1;
					}
					else {
						if(array[1]%2==0) {
							result +=array[i];
						}
					}
		}
		return result;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in) ;
		System.out.println("enter the values");
		int array []= new int[5];
		for(int i = 0;i<array.length;i++) {
			array[i] = sc.nextInt();
		}
		System.out.println(sumOfEvenNumbers(array));
	}
}








