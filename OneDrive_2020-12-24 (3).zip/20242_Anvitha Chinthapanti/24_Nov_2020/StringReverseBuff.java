package strings;

public class StringReverseBuff {

	

	public static void main(String[] args) {
		String str = "java is programing language";
		String[] str1 = str.split(" ");
		String revStr = "";
		for (int i = 0; i < str1.length; i++)
		{
			String words = str1[i];
			String revWord = "";
			for (int j = words.length()-1; j >= 0; j--) 
			{
				revWord = revWord + words.charAt(j);
			}
			revStr = revStr + revWord + " ";
		}
		System.out.println(revStr);
	}
}