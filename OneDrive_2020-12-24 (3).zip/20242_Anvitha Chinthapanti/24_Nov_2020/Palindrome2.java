package demo;

import java.util.Scanner;

public class Palindrome2 {

 
    static String result ="";
    static String palindromGenerator(int num ) {
        result = ""+num;
        int temp = num ;
        int rem = 0 , rev = 0 ;
        while(num > 0) {
            rem = num % 10 ;
            rev = (rev * 10) + rem ;
            num = num / 10 ;
        }
        
        if (temp == rev)
        {
            result = ""+rev+"given number palindrom";
        }
        else {
            result += "" +rev;
            System.out.println(temp);
            num = rev + temp;
            
            System.out.println(rev);
            palindromGenerator(num);
        }
        return result;
        
    }
    
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        System.out.println("enter a number");
        int num = scr.nextInt();
        palindromGenerator(num);
        System.out.println(result);
    }

 

}
