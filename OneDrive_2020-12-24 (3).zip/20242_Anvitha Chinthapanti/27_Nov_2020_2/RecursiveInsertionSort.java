package anvi;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;

public class RecursiveInsertionSort {
	static void getRecursiveInsertion(int array[],int n) {
		if(n <= 1)
			return;
		getRecursiveInsertion(array,n-1);
		int last = array[n-1];
		int j = n-2;
		while (j >=0 && array[j] > last) {
			array [j+1] = array[j];
			j--;
		}
	
	array[j+1] = last;
}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int array[] = new int[5];
		System.out.println("enter the elements");
		for(int i = 0;i <array.length;i++) {
			 array[i] = sc.nextInt();
		}
		getRecursiveInsertion(array,array.length);
		System.out.println(Arrays.toString(array));
		
	

	}

}
