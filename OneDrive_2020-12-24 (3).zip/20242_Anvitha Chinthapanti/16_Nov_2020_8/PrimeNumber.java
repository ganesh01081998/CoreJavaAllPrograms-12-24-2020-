package anvi;

import java.util.Scanner;

public class PrimeNumber {
	static String getPrimeNumbers(int num1, int num2) {
		String result = "";
        int flag = 0;
		for(int i = 1; i <= 10; i++) {
			for(int j = 1; j <= 10; j++) {
				if(i%j==0) {
				flag++;
				} 
			}
		
		if(flag==2) {
			result += i+ " ";
		}
		flag=0;
		}
		return result;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the value");
		
		System.out.println(getPrimeNumbers(sc.nextInt(),sc.nextInt()));

	}

}
