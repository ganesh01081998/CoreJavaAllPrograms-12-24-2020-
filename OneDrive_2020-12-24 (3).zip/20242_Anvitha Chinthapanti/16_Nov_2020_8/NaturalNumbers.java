package anvi;
import java.util.Scanner;


public class NaturalNumbers {

static String getNaturalNum(int startNum,int endNum) {
		String str = " ";
		while( startNum <= endNum ) {
			str += startNum + "," ;
			startNum++;
		}
		return str.substring(0, str.length()-1);
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the number");
		String res = getNaturalNum(sc.nextInt(),sc.nextInt());
		System.out.println(res);
	}
}
