package demo;

import java.util.Scanner;

public class EvenNumber {


	static String naturalNumbers(int num1 , int num2) {
		String results = "";
		for (int i = num1 ; i<= num2 ; i++ ) {
			if (i % 2 == 0 ) {
				System.out.print(i + " ");
			}
		}
		return results;

	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the range");
		int num1 = scanner.nextInt();
		int num2 = scanner.nextInt();
		naturalNumbers(num1 , num2);

	}



}


