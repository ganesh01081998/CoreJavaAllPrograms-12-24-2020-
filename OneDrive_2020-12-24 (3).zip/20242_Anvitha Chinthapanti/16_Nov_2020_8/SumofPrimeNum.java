package anvi;

import java.util.Scanner;

public class SumofPrimeNum {


	static String sum(int startNum, int endNum) {
		String str = "";
		int sum = 0;
		for (int i = startNum; i <= endNum; i++) {
			sum = sum + i;
		}
		str += sum;
		return str;
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter range");
		System.out.println(sum(scanner.nextInt(), scanner.nextInt()));
	}
}
