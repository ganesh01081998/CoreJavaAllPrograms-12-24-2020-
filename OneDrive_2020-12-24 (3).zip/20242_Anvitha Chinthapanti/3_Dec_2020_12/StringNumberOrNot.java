package Dec_3_2020;

import java.util.Scanner;
public class StringNumberOrNot {
    String isNumberOrNot(String str) {
        String result = "Not a Number";
        try {
            int number = Integer.parseInt(str);
            return result = "Is  a number";
        }
        catch (NumberFormatException nfe) {
           
        }
        return result;
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        StringNumberOrNot sinon = new StringNumberOrNot();
        System.out.println("Enter the number ");
        String str = scanner.next();
        System.out.println(sinon.isNumberOrNot(str));
    }    
}
