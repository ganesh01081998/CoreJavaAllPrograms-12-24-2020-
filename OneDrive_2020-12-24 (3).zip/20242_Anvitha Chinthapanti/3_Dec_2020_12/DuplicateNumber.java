package Dec_3_2020;

public class DuplicateNumber {
	static void getDuplicatesNumber(String args[]) {
		String st1 = "625345238";
		int count=0;
		char ch[] = st1.toCharArray();
		System.out.println("Duplicate digits in a given number: ");
		for (int i = 0; i < ch.length; i++) {
			count = 1;
			for (int j = i + 1; j < ch.length; j++) {
				if (ch[i] == ch[j] && ch[i] != ' ') {
					count++;
					ch[j] = '0';
				}
			}
			if (count > 1 && ch[i] != '0') {
				System.out.println(ch[i]);
			}

		}
		return;
	}

	public static void main(String[] args) {
		getDuplicatesNumber(args);
		// System.out.println();
	}
}
