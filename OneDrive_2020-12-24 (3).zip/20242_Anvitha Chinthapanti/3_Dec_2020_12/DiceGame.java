package DiceProgram;

import java.util.Scanner;

public class DiceGame {
	public static void main(String[] args) {
		Scanner sc  =  new Scanner(System.in);
		Dice d1  =  new Dice();
		Dice d2  =  new Dice();
		System.out.println("enter the first player name");
		Player p1  =  new Player(sc.next());
		System.out.println("enter the second player name");
		Player p2  =  new Player(sc.next());
		p1.throwDice(d1, d2);
		p2.throwDice(d1, d2);
		String res  =  "";
		if(p1.playerValue > p2.playerValue)  {
			res  =  p1.pname  +  "wins the game";
		}
		else if(p2.playerValue > p1.playerValue)  {
			res  =  p2.pname + "wins the game";
		}
		else {
			res  =  "pls try again";
			
		}
		System.out.println(res);
	}

}
