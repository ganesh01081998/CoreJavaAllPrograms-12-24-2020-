package Dec_3_2020;

public class ReverseWord {
	static void getReverseWord(String str) {
//		String str = "anvitha";
//		int count  = 0;
//		String str1 = str.split("");
		char ch[] = str.toCharArray();
		for(int i = ch.length-1; i >= 0;i--) {
			System.out.print(ch[i]);
			
			
		}
		
	}

	public static void main(String[] args) {
		String str = "anvitha";
		getReverseWord(str);
		
	}

}
