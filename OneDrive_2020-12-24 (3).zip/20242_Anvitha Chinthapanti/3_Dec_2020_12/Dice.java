package DiceProgram;

import java.util.*;

public class Dice {
	int facevalue;
	public void roll() {
		Random r = new Random();
		facevalue = r. nextInt(6) + 1;
		
	}

}
