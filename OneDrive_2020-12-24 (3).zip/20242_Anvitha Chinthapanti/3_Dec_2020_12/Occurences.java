package Dec_3_2020;

public class Occurences {
	static int getOccurences(String args[]) {
		String str = "";
		int count =0;
		char ch[] = str.toCharArray() ;
		for(int i = 0;i < str.length();i++) {
			if(ch[i]==' ') {
				count++;
			}
		}
		
		return count;
		
	}

	public static void main(String[] args) {
		System.out.println(getOccurences(args ));

	}

}
