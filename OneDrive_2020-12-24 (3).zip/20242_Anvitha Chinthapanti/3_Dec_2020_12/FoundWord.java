package Dec_3_2020;

import java.util.Scanner;

public class FoundWord {
static boolean getWord(String str, String word) {
		boolean b = false;
		String array[] = str.split(" ");
		for (int i = 0; i < array.length; i++) {
			if(array[i].equals(word)){
				b = true;
			}
			
		}
		return b;
	}
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("enter the sentence");
    String str = sc.nextLine();
	System.out.println("enter the word");
	String word = sc.nextLine();
	System.out.println(getWord(str,word));
}
}

