package Dec_3_2020;

import java.util.Scanner;

public class StartNumberEndNumber {
	static int[] getStartNumber( int n,int start,int end) {
		int array[] = new int[n];
		int y = 0;
		for(int i = start;i <end ;i++){
			array[y]=i; 
				y++;
			}
		
		return array;
		
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the start number");
		int start = sc.nextInt();
		System.out.println("enter the end number");
		int end = sc.nextInt();
		int n = start-end;
		 int [] res= getStartNumber(n,start,end);
		for(int i = 0;i < res.length;i++) {
			System.out.println(res[i]);
			
		}
	}

}
	


