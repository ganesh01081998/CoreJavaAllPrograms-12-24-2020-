package Dec_3_2020;

import java.util.Scanner;

public class CountNumbersofWords {

	static int getOccurences(String st) {
		String str = " ";
		//String st[]= str.split(" ");
		int count =1;
		char ch[] = st.toCharArray() ;
//		for(int i = 0;i<ch.length;i++) {
//			System.out.println(ch[i]);
//		}
		for(int i = 0;i < ch.length;i++) {
			if(ch [i]==' ') {
				count++;
			}
		}

		return count;

	}

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		System.out.println("enter the sentence");
		String st = sc.nextLine();
		System.out.println(getOccurences(st ));

	}

}

