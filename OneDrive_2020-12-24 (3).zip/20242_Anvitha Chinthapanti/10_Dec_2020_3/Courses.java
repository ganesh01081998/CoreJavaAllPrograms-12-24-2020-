package Dec_7_2020;
import java.util.Scanner;

public class Courses {




static int price;
	private Student student;
	private Adress address;
	
	static String menu = "Select Any Course : \n 1. Java\n 2. Python\n 3. Testing \n 4. .Net \n 5. Java + Python \n 6. Java + Testing \n 7. Java + .Net";
	
	public Courses(Student student,Adress adress) {
	
		this.student = student;
		this.address = address;
		
	}
		
	public void display(int choice) {
		System.out.println("Course : "+ choice + " Price : " + price + " " + student + " " + address );
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Student Number And Name...");
		Student s = new Student(sc.nextInt(),sc.next());
		System.out.println("Enter Your Address...");
		Adress add = new Adress(sc.next(),sc.next());
		int[] arr = {15000,20000,10000,8000,30000,25000,18000};
		System.out.println(menu);
		int choice = sc.nextInt();
		switch(choice) {
		case 1 : price = arr[0];
					break;
		case 2 : price = arr[1];
		            break;
		case 3 : price = arr[2];
					break;
		case 4 : price = arr[3];
					break;
		case 5 : price = arr[4];
					break;
		case 6 : price = arr[5];
					break;
		case 7 : price = arr[6];
		            break;
		 default : System.out.println("Choose Correct Option..."); 
		 		            
		}

		Courses c = new Courses(s,add);
		c.display(choice);
	}

}

