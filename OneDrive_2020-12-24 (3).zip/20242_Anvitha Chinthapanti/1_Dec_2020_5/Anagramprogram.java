package nov_1_2020;
import java.util.Arrays;
public class Anagramprogram {
	public static void s1() {
		String s1="anvi";
		String s2="ivna1";
		if(s1.length()==s2.length()) {
			char c1[]=s1.toCharArray();
			char c2[]=s2.toCharArray();
			sorting(c1);
			sorting(c2);
			boolean status=Arrays.equals(c1,c2);if(true) {
				System.out.println("anagram " );
			}
		}
		else {
			System.out.println("not anagram");
		}
	}
	public static void sorting(char[] c1) {

		for(char ch='a';ch<='z';ch++) {
			for(int i=0;i<c1.length;i++) {
				int ch1 =c1.length;
				if(ch==ch1) {
					System.out.println(ch);
				}
			}
		}
	}
	public static void main(String[] args) {

		s1();
	}
}
