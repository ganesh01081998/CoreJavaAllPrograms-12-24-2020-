package nov_1_2020;

public class occurance {
	public static void main(String[] args) {

		String str = "hhelloworldd";
		String mostr = str;
		for (int i = 0; i < str.length(); i++) {
			int count = 1;
			str = mostr;
			for (int j = i + 1; j < str.length(); j++) {
				if (str.charAt(i) == str.charAt(j)) {
					count++;
					mostr = str.replace(str.charAt(j), 'x');
				}

			}
			if (str.charAt(i) != 'x') {
				System.out.println(str.charAt(i) + " = " + count);
			}
		}

	}

}
