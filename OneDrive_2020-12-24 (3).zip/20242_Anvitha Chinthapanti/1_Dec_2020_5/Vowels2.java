package nov_1_2020;

import java.util.Scanner;

public class Vowels2 {
	static String vowelInString(String str) {
		String result = " ";

		int len = str.length();
		if(str.equals("")){
			System.out.println("null");
		}
		for (int i=0 ; i < len ; i++){
			char ch = str.charAt(i);
			if(ch == 'a' ||ch == 'e' ||ch == 'i'||ch == 'o'||ch == 'u'){
				result += ch ;
			}
		}
		return result ;
	}
	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		System.out.println("enter String =");
		String str = scr.nextLine();
		System.out.println(vowelInString(str));
	}

}
