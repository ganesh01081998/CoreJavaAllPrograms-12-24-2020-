package Dec_7_2020;

import java.util.Scanner;

public class luckyNumber {
	static void getLuckyNum(int firstnum,int secnum,int threenum) {
		int sum = 0;
		if(firstnum !=0 && secnum != 0 &&threenum !=0 ) {
			sum = firstnum+secnum+threenum;
			}
		else if(firstnum == 13) 
		{
			sum = sum;
		}
			else if(secnum ==13) 
			{
				sum = firstnum; 
				}
			else if(threenum == 13) 
		{
			sum = firstnum + secnum; 
			}
		System.out.println(sum); 
	}
		
	

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter three numbers");
		int FirstNum = sc.nextInt();
		int SecNum = sc.nextInt();
		int ThreeNum = sc.nextInt();
		getLuckyNum(FirstNum ,SecNum,ThreeNum) ;
		
		
		

	}

}
