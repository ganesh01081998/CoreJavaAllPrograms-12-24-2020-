package nov_2_2020;

import java.util.Scanner;

public class SumOfDigits {


	  static int  addingNumberInString(String str) {
		  int result = 0;
		  String str1 = "";
		  char ch[] = str.toCharArray();
		  for(int i = 0 ; i < ch.length ; i++) {
			  if(Character.isLetter(ch[i])){
				  
			  }
			  else {
				 
				   str1 = "" +ch[i];
				   int num = Integer.parseInt(str1);
				  result +=num;
			  }
		  }
		  return result ;
	  }
	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		System.out.println("enter a String=");
		 	String str = scr.next();
		System.out.println(addingNumberInString(str));

	}

}