package nov_2_2020;

import java.util.Scanner;

public class DiagonalMatrix {
	static int diagonalSum(int array[][]){
		int count = 0;
		for(int i = 0 ; i < array.length ; i++) {
			for(int j = 0 ; j < array.length ; j++) {
				if(i == j)
					count += array[i][j] ;
			}
		}
		return count ;
	}
	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		int array[][] = new int[3][3];
		System.out.println("enter a array elements");
		for(int i = 0 ; i < array.length ; i++) {
			for(int j = 0 ; j < array.length ; j++) {
				array[i][j] = scr.nextInt();
			}
		}
		System.out.println(diagonalSum(array));
	}
	}