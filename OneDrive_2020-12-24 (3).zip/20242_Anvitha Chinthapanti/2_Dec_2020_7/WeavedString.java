package nov_2_2020;

import java.util.Scanner;

public class WeavedString {
	private static String getWeavedString(String str1, String str2) {
		String str = "";
		int value1 = str1.length();
		int value2 = str2.length();
		
		if (str1.equals(null) || str2.equals(null)) {
			str+= -1;
		}
		if (str1.length() > str2.length()) {
			str += str2 + str1 + str2;
		} 
		else if (str1.length() < str2.length()) {
			str += str1 + str2 + str1;
		} 
		else {
			for (int i = 0; i < str1.length();i++) {



				str += "" + str1.charAt(i) + str2.charAt(i);
				}
		}
		return str;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter any two names");
		String value1 = sc.nextLine();
		String value2 = sc.nextLine();
		String wavalue=getWeavedString(value1, value2);
		System.out.println(wavalue);
	}
}
