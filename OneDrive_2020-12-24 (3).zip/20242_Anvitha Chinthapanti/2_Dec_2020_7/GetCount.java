package nov_2_2020;

import java.util.Scanner;

public class GetCount {
static String getCount(int array[] , int n) {
		String result = "";
		int count = 0, i;
		for( i = 0 ; i < array.length ; i++) {
			if (array[i] == n) {
				count++;
			}
		}
		if (count > 0) {
			result += n +""+"is repeated"+""+count +""+"times" ;
		}
		else {
			result += "Not in array";
		}
		return result ;
	}
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int array [] = new int[3];
	System.out.println("enter array elemnets");
	for(int i = 0 ; i < array.length; i++) {
		array[i] = sc.nextInt();
	}
	System.out.println("enter a search element");
	int searchElement = sc.nextInt();
	System.out.println(getCount(array, searchElement));
}

}

