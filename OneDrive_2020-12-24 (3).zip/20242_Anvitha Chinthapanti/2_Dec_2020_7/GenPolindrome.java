package nov_2_2020;

import java.util.Scanner;
 public class GenPolindrome {
	 static String result = "";
	 static String getGenPolindrome(int num) {
		 result =""+num;
		 int temp = num;
		 int rev = 0, rem = 0;
		 while(num > 0) {
			 rem = num % 10;
			 rev = (rev *10) +rem;
			 num = num /10;
		 }
		 if(temp == rev) {
			 result = ""+rev+"given number palindrom";
	        }
	        else {
	            result += "" +rev;
	            System.out.println(temp);
	            num = rev + temp;
	            
	            System.out.println(rev);
	            getGenPolindrome(num);
	        }
	        return result;
	 } 
	 public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
		 System.out.println("enter the number");
		 int num = sc.nextInt();
		getGenPolindrome(num);
		 System.out.println(result);
		 
		 
	 }
	}
			 
		 
		 
	 
 