package Arrays;

import java.util.Scanner;
public class ArrayOdd {
	static void getArray(int[] evenArray  ) {
		int[] evenArray1=  new int[5];
		int k = 0;
		for(int i = 0; i<evenArray.length;i++) {
			if(evenArray[i] % 2!=0) {
				evenArray1[k] = evenArray[i];
				
			    System.out.println(evenArray1[k]);
			    }
			}
		}
public static void main(String[] args) {
		System.out.println("enter the size");
		Scanner sc = new Scanner(System.in);
		int size = sc.nextInt();
				
		System.out.println("enter the values");
		int evenArray [] = new int[size];
		for(int i = 0; i <evenArray.length; i++ ) {
			evenArray[i] = sc.nextInt();
		}
			//System.out.println(evenArray[i]);
		
		getArray(evenArray);
		
			
		}
		
		
			}


