package Arrays;

import java.util.Scanner;

public class ArraySum {
	static void getArraySum() {
	
	int n [] = new int[5];
	int sum  = 0;
	  n [0] = 10;
	  n [1] = 20;
	  n [2] = 30;
	  n [3] = 40;
	  n [4] = 50;
	  for(int i = 0; i<n.length;i++) {
		  sum +=n[i];}
	  System.out.println(sum);
		
	}
	public static void main(String[] args) {
	getArraySum();
	}	
	}

	
		 
		
		



	
	


