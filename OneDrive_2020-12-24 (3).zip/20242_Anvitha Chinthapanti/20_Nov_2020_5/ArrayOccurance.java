package Arrays;

import java.util.Scanner;

public class ArrayOccurance {
	static int getCount(int[]inputarray,int givennumber) {
		int count = 0;
		int res = 0;
		for(int i = 0;i<inputarray.length;i++) {
			if(inputarray[i] < 0) {
				int k = inputarray[i]*-1;
				inputarray[i] = k;
			}
			if(inputarray[i] == givennumber) {
				count++;
				res = count;
				}
			
		}
		return res;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the size");
		int size = sc.nextInt();
		System.out.println("enter elements");
		int array[] = new int[size];
		for(int i = 0;i<array.length;i++){
			array[i] = sc.nextInt();
		}
		System.out.println("enter the number");
		int n = sc.nextInt();
		System.out.println("number of " + n + "' is "+getCount(array,n));
		
	}
}


