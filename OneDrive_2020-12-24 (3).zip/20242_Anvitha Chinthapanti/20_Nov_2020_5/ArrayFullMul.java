package Arrays;

import java.util.Scanner;

public class ArrayFullMul {
	static String getFillMultiple(int n) {
		int arr [] = new int[10];
		String result = "";
		for(int i = 0;i<arr.length;i++) {
			arr[i] = n *i;
		}
			for(int i = 0;i<arr.length;i++) {
				result += arr[i]+"\n ";
				
		}
			return result;
		
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the number");
		int n = sc.nextInt();
		System.out.println(getFillMultiple(n));
		
	}

}
